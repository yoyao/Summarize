﻿

using View.DesktopAgent.Communication.Message;
using View.DesktopAgent.Communication.Protocol;
using ViewService.Model;
using ViewService.Utils;
using System;

namespace ViewService.Sender
{
  public class IMessageSender
  {
    private MessageSender messageSender;

    public IMessageSender()
    {
      this.messageSender = new MessageSender();
    }

    public void SendMessage(MessageBase message)
    {
      if (StateMachine.GetDesktopState() != DesktopState.WORKING)
        return;
      this.messageSender.SendMessage(StateMachine.GetServerIP(), StateMachine.GetServerPort(), message);
    }

    public void SendHeartBeat()
    {
      string ip = Common.GetIP();
      string string1 = Environment.OSVersion.ToString();
      string environmentVariable = Environment.GetEnvironmentVariable("ComputerName");
      string string2 = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
      string UUID = Common.encodeUnicode(StateMachine.GetUUID());
      if (StateMachine.GetDesktopState() != DesktopState.WORKING)
        return;
      string SessionState = "EMPTY";
      string ConnectTime = "";
      string LogonTime = "";
      try
      {
        SessionEventModel sessionEventModel = new Cassia2().ShowCurrentSession3();
        if (sessionEventModel != null)
        {
          if (sessionEventModel.State == "Active")
            SessionState = "IN_USE";
          else if (sessionEventModel.State == "Disconnected")
            SessionState = !(sessionEventModel.UserAccount == "") ? "DISCONNECT" : "EMPTY";
          ConnectTime = sessionEventModel.ConnectTime;
          LogonTime = sessionEventModel.LogonTime;
        }
      }
      catch (Exception ex)
      {
          string mytest = ex.Message;
      }
      this.messageSender.SendMessage(StateMachine.GetServerIP(), StateMachine.GetServerPort(), (MessageBase) new HeartBeatMessage(UUID, ip, string1, environmentVariable, SessionState, ConnectTime, LogonTime, string2));
    }
  }
}
