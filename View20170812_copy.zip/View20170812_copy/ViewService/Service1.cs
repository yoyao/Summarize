﻿

using View.DesktopAgent.Communication.Message;
using ViewService.Model;
using ViewService.Receiver;
using ViewService.Sender;
using ViewService.Utils;
using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.ServiceProcess;
using System.Threading;
using System.Timers;

namespace ViewService
{
  internal class Service1 : ServiceBase
  {
    private IMessageSender isender = (IMessageSender) null;
    private Thread ListenerThread = (Thread) null;
    private SessionEventModel loginSession = (SessionEventModel) null;
    private bool emptyState = false;
    private string lastReason = (string) null;
    private IContainer components = (IContainer) null;
    private System.Timers.Timer timer2;

    public Service1()
    {
      this.InitializeComponent();
    }

    protected override void OnStop()
    {
      this.timer2.Stop();
      StateMachine.ChangeDesktopState(DesktopState.STOPPED);
      if (this.ListenerThread == null)
        return;
      try
      {
        this.ListenerThread.Abort();
      }
      catch (ThreadAbortException ex)
      {
        EventLog.WriteEntry("ViewServer", "关闭线程出错：" + ex.ToString());
      }
    }

    protected override void OnStart(string[] args)
    {
      StateMachine.Init();
      this.isender = new IMessageSender();
      if (ConfigMachine.GetIsInstalled() == "")
        ConfigMachine.SetIsInstalled("true");
      if (ConfigMachine.GetFireWall() == "")
      {
        int serverPort = StateMachine.GetServerPort();
        INetFwManger.NetFwAddPorts("ViewService", serverPort, "UDP");
        string windowsVersion = Common.GetWindowsVersion();
        if (windowsVersion.IndexOf("Windows 7") > -1 || windowsVersion.IndexOf("Windows 8") > -1)
        {
          RegistryKey registryKey1 = Registry.LocalMachine;
          RegistryKey registryKey2 = registryKey1.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\NetworkList\\Profiles", true);
          foreach (string subKeyName in registryKey2.GetSubKeyNames())
          {
            RegistryKey registryKey3 = registryKey2.OpenSubKey(subKeyName, true);
            if (registryKey3.GetValue("Description").ToString().IndexOf("网络") > -1)
            {
              registryKey3.SetValue("Category", (object) 1, RegistryValueKind.DWord);
              registryKey3.SetValue("CategoryType", (object) 0, RegistryValueKind.DWord);
              registryKey3.SetValue("IconType", (object) 0, RegistryValueKind.DWord);
            }
            else
              registryKey3.SetValue("Category", (object) 2, RegistryValueKind.DWord);
          }
          string name = "SYSTEM\\CurrentControlSet\\services\\SharedAccess\\Parameters\\FirewallPolicy\\FirewallRules";
          RegistryKey registryKey4 = registryKey1.OpenSubKey(name, true);
          foreach (string valueName in registryKey4.GetValueNames())
          {
            string @string = registryKey4.GetValue(valueName).ToString();
            if (valueName == "RemoteDesktop-In-TCP")
              registryKey4.SetValue(valueName, (object) "v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=6|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=System|Name=远程桌面(TCP-In)|Desc=@FirewallAPI.dll,-28756|EmbedCtxt=@FirewallAPI.dll,-28752|");
            if (valueName == "RemoteDesktop-UserMode-In-TCP")
              registryKey4.SetValue(valueName, (object) "v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=6|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=%SystemRoot%\\system32\\svchost.exe|Svc=termservice|Name=远程桌面 - RemoteFX (TCP-In)|Desc=@FirewallAPI.dll,-28856|EmbedCtxt=@FirewallAPI.dll,-28852|");
            if (valueName == "RemoteDesktop-UserMode-In-UDP")
              registryKey4.SetValue(valueName, (object) "v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=17|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=%SystemRoot%\\system32\\svchost.exe|Svc=termservice|Name=Remote Desktop - RemoteFX (UDP-In)|Desc=@RdpGroupPolicyExtension.dll,-102|EmbedCtxt=@FirewallAPI.dll,-28852|");
            if (@string.IndexOf("ViewService") > -1)
              registryKey4.SetValue(valueName, (object) ("v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=17|Profile=Domain|Profile=Private|Profile=Public|LPort=" + (object) serverPort + "|Name=ViewService|"));
          }
        }
        else
        {
          Common.SetRegeditData("SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\DomainProfile\\GloballyOpenPorts\\List", serverPort.ToString() + ":UDP", serverPort.ToString() + ":UDP:*:Enabled:ViewService");
          Common.SetRegeditData("SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile\\GloballyOpenPorts\\List", serverPort.ToString() + ":UDP", serverPort.ToString() + ":UDP:*:Enabled:ViewService");
        }
      }
  
      try
      {
        Thread.Sleep(500);
      }
      catch (Exception ex)
      {
          string mytest = ex.Message;
      }
      this.timer2 = new System.Timers.Timer((double) Common.StrToInt(StateMachine.GetInterval()));
      this.timer2.Elapsed += new ElapsedEventHandler(this.timer1_Elapsed);
      this.timer2.Enabled = true;
      this.timer2.Start();
      this.ListenerThread = new Thread(new ThreadStart(new Listener().Receive));
      this.ListenerThread.Start();
    }

    private void timer1_Elapsed(object sender, ElapsedEventArgs e)
    {
      this.isender.SendHeartBeat();
    }

    private SessionEventModel GetSessionState(string reason)
    {
      try
      {
        SessionEventModel sessionEventModel = new Cassia2().ShowCurrentSession3();
        if (sessionEventModel != null)
        {
          sessionEventModel.TimeStamp = DateTime.Now.ToString();
          sessionEventModel.OSVersion = Environment.OSVersion.ToString();
          sessionEventModel.SessionEvent = reason;
        }
        return sessionEventModel;
      }
      catch (Exception ex)
      {
          string mytest = ex.Message;
        return (SessionEventModel) null;
      }
    }

    private void SendMessage(SessionEventModel model)
    {
      if (model == null)
        return;
      this.isender.SendMessage((MessageBase) new SessionEventMessage(Common.encodeUnicode(StateMachine.GetUUID()), StateMachine.GetIP(), model.UserAccount, model.IP, model.SessionEvent, model.LogonTime, model.ConnectTime, model.IdleTime, model.WindowStationName, model.OSVersion, model.TimeStamp, StateMachine.GetServerIP(), model.SessionID));
    }

    private void ResetSession()
    {
      this.loginSession = (SessionEventModel) null;
    }

    private SessionEventModel ReadSession()
    {
      return this.loginSession;
    }

    private void SaveSession(SessionEventModel model)
    {
      this.loginSession = model;
    }

    private void UpdateSession(string reason)
    {
      try
      {
        if (this.loginSession == null)
          return;
        this.loginSession.TimeStamp = DateTime.Now.ToString();
        this.loginSession.OSVersion = Environment.OSVersion.ToString();
        this.loginSession.SessionEvent = reason;
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("ViewServer UpdateState Error", ex.ToString());
      }
    }

    protected override void OnSessionChange(SessionChangeDescription changeDescription)
    {
      SessionChangeReason reason = changeDescription.Reason;
      string @string = reason.ToString();
      if (reason == SessionChangeReason.RemoteConnect)
      {
        if (this.ReadSession() == null)
        {
          this.emptyState = true;
        }
        else
        {
          this.UpdateSession(@string);
          if (this.ReadSession() != null)
          {
            this.emptyState = true;
            this.SendMessage(this.ReadSession());
          }
        }
        this.lastReason = "RemoteConnect";
      }
      else if (reason == SessionChangeReason.RemoteDisconnect)
      {
        if (this.emptyState)
        {
          this.emptyState = false;
          if (this.ReadSession() != null)
          {
            this.UpdateSession(@string);
            this.SendMessage(this.ReadSession());
          }
        }
        else if (this.lastReason != "SessionLogoff" && this.ReadSession() != null)
        {
          this.UpdateSession(@string);
          this.SendMessage(this.ReadSession());
        }
        this.lastReason = "RemoteDisconnect";
      }
      else if (reason == SessionChangeReason.SessionLogoff)
      {
        this.UpdateSession(@string);
        this.SendMessage(this.ReadSession());
        this.ResetSession();
        this.lastReason = "SessionLogoff";
      }
      else
      {
        if (reason != SessionChangeReason.SessionLogon)
          return;
        this.SaveSession(this.GetSessionState(@string));
        this.SendMessage(this.ReadSession());
        this.lastReason = "SessionLogon";
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      this.ServiceName = "ViewServer";
      this.CanHandleSessionChangeEvent = true;
      this.CanPauseAndContinue = true;
      this.CanShutdown = true;
    }
  }
}
