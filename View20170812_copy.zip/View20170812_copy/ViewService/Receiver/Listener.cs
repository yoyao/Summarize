﻿
using View.DesktopAgent.Communication.Message;
using View.DesktopAgent.Communication.Protocol;
using ViewService.Model;
using ViewService.Utils;
using System;
using System.Diagnostics;

namespace ViewService.Receiver
{
  public class Listener
  {
    private static MessageReceiver receiver;

    private void Receiver_DataReceive(object sender1, DataReceiveEventArgs e)
    {
      switch (e.MessageType)
      {
        case MessageType.HeartBeat:
          break;
        case MessageType.SessionEvent:
          break;
        case MessageType.Command:
          string message = CommandMessage.FromPackage(e.Data).Message;
          if (message.IndexOf("sysprep|") > -1)
          {
            string[] strArray = message.Split('|');
            new CommandReceiver().SysprepReceive(new SysprepModel()
            {
              ServerIP = e.RemoteEP.Address.ToString(),
              Password = strArray[1],
              TimeZone = strArray[2],
              ProductKey = strArray[3],
              FullName = strArray[4],
              OrgName = strArray[5],
              ComputerName = strArray[6],
              LanguageGroup = strArray[7],
              JoinDomain = strArray[8],
              DomainAdmin = strArray[9],
              DomainAdminPassword = strArray[10],
              PreUserName = strArray[11],
              PrePassword = strArray[12]
            });
          }
          if (message.IndexOf("control|") > -1)
          {
            string[] strArray = message.Split('|');
            new CommandReceiver().ControlReceive(new ControlModel()
            {
              TimeStamp = strArray[1],
              ServerName = strArray[2],
              SessionID = strArray[3],
              ControlType = strArray[4]
            });
          }
          if (message.IndexOf("format|") > -1)
          {
            string[] strArray = message.Split('|');
            new CommandReceiver().FormatDiskReceive(new FormatDiskModel()
            {
              Disk = strArray[1],
              Size = strArray[2],
              Letter = strArray[3]
            });
          }
          if (message.IndexOf("sync|") > -1)
            new CommandReceiver().SyncDateTimeReceive(message.Split('|')[1]);
          if (message.IndexOf("restore|") > -1)
            new CommandReceiver().RestoreReceive(bool.Parse(message.Split('|')[1]));
          if (message.IndexOf("share|") <= -1)
            break;
          string[] strArray1 = message.Split('|');
          new CommandReceiver().ShareReceive(strArray1[1], strArray1[2]);
          break;
        case MessageType.Identity:
          IdentityMessage identityMessage = IdentityMessage.FromPackage(e.Data);
          if (identityMessage == null)
            break;
          StateMachine.UpdateServerState(identityMessage.ServerIP, StateMachine.GetServerPort(), Common.decodeUnicode(identityMessage.UUID), identityMessage.GridName, identityMessage.Interval);
          if (ConfigMachine.GetAD() != "")
          {
            Common.RunCmd2(" localgroup \"Remote Desktop Users\" \"Domain Users\" /add");
            EventLog.WriteEntry("ViewServer Receive Identity Message", "ViewServer receive IdentityMessage and add \"Domain Users\" to \"Remote Desktop Users\" " + identityMessage.Interval);
          }
          else
          {
            Common.RunCmd2(" localgroup \"Remote Desktop Users\" \"" + ConfigMachine.GetPreUserName() + "\" /add");
            EventLog.WriteEntry("ViewServer Receive Identity Message", "ViewServer receive IdentityMessage and add \"" + ConfigMachine.GetPreUserName() + "\" to \"Remote Desktop Users\"  " + identityMessage.Interval);
          }
          ConfigMachine.SetFireWall("true");
          break;
        default:
          Console.Out.WriteLine("Not match." + UnknowMessage.FromPackage(e.Data).Message);
          break;
      }
    }

    public void Receive()
    {
      Listener.receiver = new MessageReceiver();
      Listener.receiver.DataReceive += new EventHandler<DataReceiveEventArgs>(this.Receiver_DataReceive);
      Listener.receiver.Start();
    }
  }
}
