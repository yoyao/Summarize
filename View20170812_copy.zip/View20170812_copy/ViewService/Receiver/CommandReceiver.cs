﻿

using Cassia;
using ViewService.Model;
using ViewService.Utils;
using System;
using System.Diagnostics;
using System.IO;

namespace ViewService.Receiver
{
  public class CommandReceiver
  {
    private static readonly ITerminalServicesManager _manager = (ITerminalServicesManager) new TerminalServicesManager();

    public void ShareReceive(string ServerIP, string UserId)
    {
      if (UserId == null)
        return;
      string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
      if (File.Exists(baseDirectory + UserId + ".bat"))
        File.Delete(baseDirectory + UserId + ".bat");
      Common.CheckLog("@echo off\r\nECHO Y|net use * /del >NUL\r\nnet use h: \\\\" + ServerIP + "\\share$\\" + UserId + " \"user\" /user:user123 >NUL\r\nexit\r\n@echo on", baseDirectory + UserId + ".bat");
      Common.RunPath(baseDirectory, baseDirectory + UserId + ".bat");
      EventLog.WriteEntry("ViewService Receive Share Message", "Receive Share Message");
    }

    public void RestoreReceive(bool isStart)
    {
      if (isStart)
      {
        ConfigMachine.SetRestore("true");
        Common.RunCmd(AppDomain.CurrentDomain.BaseDirectory + "restoreStart.bat");
        EventLog.WriteEntry("ViewService Receive Restore Message", "Receive Restore Message Start");
      }
      else
      {
        ConfigMachine.SetRestore("false");
        Common.RunCmd(AppDomain.CurrentDomain.BaseDirectory + "restoreEnd.bat");
        EventLog.WriteEntry("ViewService Receive Restore Message", "Receive Restore Message End");
      }
    }

    public void SyncDateTimeReceive(string datetime)
    {
      SystemDateTime.SetLocalTimeByStr(datetime);
      EventLog.WriteEntry("ViewService Receive SyncDateTime Message", "Receive SyncDateTime Message");
    }

    public void FormatDiskReceive(FormatDiskModel model)
    {
      if (model == null)
        return;
      string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
      if (File.Exists(baseDirectory + model.Letter + ".bat"))
        File.Delete(baseDirectory + model.Letter + ".bat");
      if (File.Exists(baseDirectory + model.Letter + ".txt"))
        File.Delete(baseDirectory + model.Letter + ".txt");
      Common.CheckLog("diskpart /s " + model.Letter + ".txt\r\necho y | format " + model.Letter + ":/fs:ntfs /q", baseDirectory + model.Letter + ".bat");
      Common.CheckLog("select disk " + model.Disk + "\r\ncreate partition primary size=" + model.Size + "\r\nassign letter=" + model.Letter + "\r\nactive\r\nexit", baseDirectory + model.Letter + ".txt");
      Common.RunPath(baseDirectory, baseDirectory + model.Letter + ".bat");
      EventLog.WriteEntry("ViewService Receive Format Disk", "Receive Format Message");
    }

    public void ControlReceive(ControlModel model)
    {
      if (model == null)
        return;
      this.Cassia(model.ServerName, model.SessionID, model.ControlType);
      EventLog.WriteEntry("ViewService Receive Control Message", "Receive Control Message");
    }

    public void SysprepReceive(SysprepModel model)
    {
      if (model == null)
        return;
      string windowsVersion = Common.GetWindowsVersion();
      string str1 = "";
      string str2 = "";
      if (windowsVersion.Equals("Windows XP"))
      {
        str1 = "";
        string str3;
        if (model.JoinDomain != "")
        {
          str3 = Common.ReadLog(AppDomain.CurrentDomain.BaseDirectory + "\\sysprep_xp.inf").Replace("{Password}", model.Password).Replace("{TimeZone}", model.TimeZone).Replace("{ProductKey}", model.ProductKey).Replace("{FullName}", model.FullName).Replace("{OrgName}", model.OrgName).Replace("{ComputerName}", model.ComputerName).Replace("{LanguageGroup}", model.LanguageGroup).Replace("{JoinDomain}", model.JoinDomain + ".COM").Replace("{DomainAdmin}", model.DomainAdmin).Replace("{DomainAdminPassword}", model.DomainAdminPassword);
        }
        else
        {
          ConfigMachine.SetPreUserName(model.PreUserName);
          Common.RunCmd2(" user \"" + model.PreUserName + "\" \"" + model.PrePassword + "\" /add");
          str3 = Common.ReadLog(AppDomain.CurrentDomain.BaseDirectory + "\\sysprep_xp_2.inf").Replace("{Password}", model.Password).Replace("{TimeZone}", model.TimeZone).Replace("{ProductKey}", model.ProductKey).Replace("{FullName}", model.FullName).Replace("{OrgName}", model.OrgName).Replace("{ComputerName}", model.ComputerName).Replace("{LanguageGroup}", model.LanguageGroup);
        }
        if (!Directory.Exists("C:\\\\Sysprep\\"))
        {
          Directory.CreateDirectory("C:\\\\Sysprep\\");
          Common.CheckLog(str3, "C:\\\\Sysprep\\sysprep.inf");
        }
        else
        {
          File.Delete("C:\\\\Sysprep\\sysprep.inf");
          Common.CheckLog(str3, "C:\\\\Sysprep\\sysprep.inf");
        }
        ConfigMachine.SetServerIP(model.ServerIP);
        try
        {
          Common.RunCmd(AppDomain.CurrentDomain.BaseDirectory + "sysprep_xp.bat");
        }
        catch (Exception ex)
        {
          EventLog.WriteEntry("Sysprep Error", ex.ToString());
        }
        EventLog.WriteEntry("ViewService Receive Sysprep Message", str3);
      }
      else if (windowsVersion.IndexOf("Windows 7") > -1)
      {
        str2 = "";
        string str3 = !windowsVersion.Equals("Windows 7(32-bit)") ? "sysprep_win7_64" : "sysprep_win7_32";
        str1 = "";
        string str4;
        if (model.JoinDomain != "")
        {
          str4 = Common.ReadLog(AppDomain.CurrentDomain.BaseDirectory + "\\" + str3 + ".inf").Replace("{ProductKey}", model.ProductKey).Replace("{FullName}", model.FullName).Replace("{OrgName}", model.OrgName).Replace("{ComputerName}", model.ComputerName).Replace("{JoinDomain}", model.JoinDomain + ".COM").Replace("{Domain}", model.JoinDomain).Replace("{DomainAdmin}", model.DomainAdmin).Replace("{DomainAdminPassword}", model.DomainAdminPassword);
        }
        else
        {
          ConfigMachine.SetPreUserName(model.PreUserName);
          str4 = Common.ReadLog(AppDomain.CurrentDomain.BaseDirectory + "\\" + str3 + "_2.inf").Replace("{ProductKey}", model.ProductKey).Replace("{FullName}", model.FullName).Replace("{OrgName}", model.OrgName).Replace("{ComputerName}", model.ComputerName).Replace("{PreUserName}", model.PreUserName).Replace("{PrePassword}", model.PrePassword);
        }
        Common.CheckLog(str4, "C:\\\\Windows\\system32\\sysprep\\sysprep.xml");
        ConfigMachine.SetServerIP(model.ServerIP);
        try
        {
          Common.RunCmd(AppDomain.CurrentDomain.BaseDirectory + "\\sysprep_win7.bat");
        }
        catch (Exception ex)
        {
          EventLog.WriteEntry("Sysprep Error", ex.ToString());
        }
        EventLog.WriteEntry("ViewService Receive Sysprep Message", str4);
      }
      else if (windowsVersion.IndexOf("Windows 8") > -1)
      {
        str2 = "";
        string str3 = !windowsVersion.Equals("Windows 8(32-bit)") ? "sysprep_win8_64" : "sysprep_win8_32";
        str1 = "";
        string str4;
        if (model.JoinDomain != "")
        {
          str4 = Common.ReadLog(AppDomain.CurrentDomain.BaseDirectory + "\\" + str3 + ".inf").Replace("{ProductKey}", model.ProductKey).Replace("{FullName}", model.FullName).Replace("{OrgName}", model.OrgName).Replace("{ComputerName}", model.ComputerName).Replace("{JoinDomain}", model.JoinDomain + ".COM").Replace("{Domain}", model.JoinDomain).Replace("{DomainAdmin}", model.DomainAdmin).Replace("{DomainAdminPassword}", model.DomainAdminPassword);
        }
        else
        {
          ConfigMachine.SetPreUserName(model.PreUserName);
          str4 = Common.ReadLog(AppDomain.CurrentDomain.BaseDirectory + "\\" + str3 + "_2.inf").Replace("{ProductKey}", model.ProductKey).Replace("{FullName}", model.FullName).Replace("{OrgName}", model.OrgName).Replace("{ComputerName}", model.ComputerName).Replace("{PreUserName}", model.PreUserName).Replace("{PrePassword}", model.PrePassword);
        }
        Common.CheckLog(str4, "C:\\\\Windows\\system32\\sysprep\\sysprep.xml");
        ConfigMachine.SetServerIP(model.ServerIP);
        try
        {
          Common.RunCmd(AppDomain.CurrentDomain.BaseDirectory + "\\sysprep_win7.bat");
        }
        catch (Exception ex)
        {
          EventLog.WriteEntry("Sysprep Error", ex.ToString());
        }
        EventLog.WriteEntry("ViewService Receive Sysprep Message", str4);
      }

        // By esage 2016-07-01 CS0219
      str2 = str1;
    }

    private static ITerminalServer GetServerFromName(string serverName)
    {
      return serverName.Equals("local", StringComparison.InvariantCultureIgnoreCase) ? CommandReceiver._manager.GetLocalServer() : CommandReceiver._manager.GetRemoteServer(serverName);
    }

    private void Cassia(string ServerName, string SessionId, string ControlType)
    {
      Cassia2 cassia2 = new Cassia2();
      switch (ControlType)
      {
        case "shutdown":
          using (ITerminalServer serverFromName = CommandReceiver.GetServerFromName(ServerName))
          {
            serverFromName.Open();
            ShutdownType shutdownType = (ShutdownType) Enum.Parse(typeof (ShutdownType), "2", true);
            serverFromName.Shutdown(shutdownType);
            break;
          }
        case "restart":
          using (ITerminalServer serverFromName = CommandReceiver.GetServerFromName(ServerName))
          {
            serverFromName.Open();
            ShutdownType shutdownType = (ShutdownType) Enum.Parse(typeof (ShutdownType), "4", true);
            serverFromName.Shutdown(shutdownType);
            break;
          }
        case "logoff":
          using (ITerminalServer serverFromName = CommandReceiver.GetServerFromName(ServerName))
          {
            serverFromName.Open();
            serverFromName.GetSession(int.Parse(SessionId)).Logoff();
            break;
          }
        case "disconnect":
          using (ITerminalServer serverFromName = CommandReceiver.GetServerFromName(ServerName))
          {
            serverFromName.Open();
            serverFromName.GetSession(int.Parse(SessionId)).Disconnect();
            break;
          }
        default:
          using (ITerminalServer serverFromName = CommandReceiver.GetServerFromName(ServerName))
          {
            serverFromName.Open();
            ShutdownType shutdownType = (ShutdownType) Enum.Parse(typeof (ShutdownType), ControlType, true);
            serverFromName.Shutdown(shutdownType);
            break;
          }
      }
    }
  }
}
