﻿
using System;
using System.Runtime.InteropServices;
using System.Text;

namespace ViewService
{
  public class TSControl
  {
    [DllImport("wtsapi32", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool WTSEnumerateSessions(int hServer, int Reserved, int Version, ref long ppSessionInfo, ref int pCount);

    [DllImport("wtsapi32.dll")]
    public static extern void WTSFreeMemory(IntPtr pMemory);

    [DllImport("wtsapi32.dll")]
    public static extern bool WTSLogoffSession(int hServer, long SessionId, bool bWait);

    [DllImport("Wtsapi32.dll")]
    public static extern bool WTSQuerySessionInformation(IntPtr hServer, int sessionId, TSControl.WTSInfoClass wtsInfoClass, out StringBuilder ppBuffer, out int pBytesReturned);

    public static TSControl.WTS_SESSION_INFO[] SessionEnumeration()
    {
      int hServer = 0;
      long ppSessionInfo = 0;
      int pCount = 0;
      TSControl.WTS_SESSION_INFO wtsSessionInfo = new TSControl.WTS_SESSION_INFO();
      bool flag = TSControl.WTSEnumerateSessions(hServer, 0, 1, ref ppSessionInfo, ref pCount);
      TSControl.WTS_SESSION_INFO[] wtsSessionInfoArray = new TSControl.WTS_SESSION_INFO[0];
      if (flag)
      {
        wtsSessionInfoArray = new TSControl.WTS_SESSION_INFO[pCount];
        long num = ppSessionInfo;
        for (int index = 0; index < pCount; ++index)
        {
          wtsSessionInfoArray[index] = (TSControl.WTS_SESSION_INFO) Marshal.PtrToStructure(new IntPtr(num), wtsSessionInfo.GetType());
          num += (long) Marshal.SizeOf(wtsSessionInfo.GetType());
        }
        TSControl.WTSFreeMemory(new IntPtr(ppSessionInfo));
      }
      return wtsSessionInfoArray;
    }

    public enum WTSInfoClass
    {
      WTSInitialProgram,
      WTSApplicationName,
      WTSWorkingDirectory,
      WTSOEMId,
      WTSSessionId,
      WTSUserName,
      WTSWinStationName,
      WTSDomainName,
      WTSConnectState,
      WTSClientBuildNumber,
      WTSClientName,
      WTSClientDirectory,
      WTSClientProductId,
      WTSClientHardwareId,
      WTSClientAddress,
      WTSClientDisplay,
      WTSClientProtocolType,
    }

    public enum WTS_CONNECTSTATE_CLASS
    {
      WTSActive,
      WTSConnected,
      WTSConnectQuery,
      WTSShadow,
      WTSDisconnected,
      WTSIdle,
      WTSListen,
      WTSReset,
      WTSDown,
      WTSInit,
    }

    public struct WTS_SESSION_INFO
    {
      public int SessionID;
      [MarshalAs(UnmanagedType.LPTStr)]
      public string pWinStationName;
      public TSControl.WTS_CONNECTSTATE_CLASS state;
    }
  }
}
