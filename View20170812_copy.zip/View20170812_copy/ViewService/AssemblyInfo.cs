﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("北京易思捷信息技术有限公司")]
[assembly: AssemblyCopyright("Copyright © eSage 2016")]
[assembly: AssemblyTitle("ViewService")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyProduct("ViewService")]
[assembly: Guid("e9b1302c-3144-4047-a7d4-6a959aa0bc9d")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
