﻿
namespace ViewService.Model
{
  public class FormatDiskModel
  {
    private string _Disk;
    private string _Size;
    private string _Letter;

    public string Disk
    {
      get
      {
        return this._Disk;
      }
      set
      {
        this._Disk = value;
      }
    }

    public string Size
    {
      get
      {
        return this._Size;
      }
      set
      {
        this._Size = value;
      }
    }

    public string Letter
    {
      get
      {
        return this._Letter;
      }
      set
      {
        this._Letter = value;
      }
    }
  }
}
