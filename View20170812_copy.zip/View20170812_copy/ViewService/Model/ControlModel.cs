﻿

namespace ViewService.Model
{
  public class ControlModel
  {
    private string _TimeStamp;
    private string _ServerName;
    private string _SessionID;
    private string _ControlType;

    public string TimeStamp
    {
      get
      {
        return this._TimeStamp;
      }
      set
      {
        this._TimeStamp = value;
      }
    }

    public string ServerName
    {
      get
      {
        return this._ServerName;
      }
      set
      {
        this._ServerName = value;
      }
    }

    public string SessionID
    {
      get
      {
        return this._SessionID;
      }
      set
      {
        this._SessionID = value;
      }
    }

    public string ControlType
    {
      get
      {
        return this._ControlType;
      }
      set
      {
        this._ControlType = value;
      }
    }
  }
}
