﻿

namespace ViewService.Model
{
  public class SessionEventModel
  {
    private string _UUID = "";
    private string _TimeStamp = "";
    private string _SessionEvent = "";
    private string _OSVersion = "";
    private string _IP = "";
    private string _UserAccount = "";
    private string _WindowStationName = "";
    private string _ConnectTime = "";
    private string _LogonTime = "";
    private string _IdleTime = "";
    private string _ServerIP = "";
    private string _State = "";
    private string _SessionID = "";

    public string UUID
    {
      get
      {
        return this._UUID;
      }
      set
      {
        this._UUID = value;
      }
    }

    public string TimeStamp
    {
      get
      {
        return this._TimeStamp;
      }
      set
      {
        this._TimeStamp = value;
      }
    }

    public string SessionEvent
    {
      get
      {
        return this._SessionEvent;
      }
      set
      {
        this._SessionEvent = value;
      }
    }

    public string OSVersion
    {
      get
      {
        return this._OSVersion;
      }
      set
      {
        this._OSVersion = value;
      }
    }

    public string IP
    {
      get
      {
        return this._IP;
      }
      set
      {
        this._IP = value;
      }
    }

    public string UserAccount
    {
      get
      {
        return this._UserAccount;
      }
      set
      {
        this._UserAccount = value;
      }
    }

    public string WindowStationName
    {
      get
      {
        return this._WindowStationName;
      }
      set
      {
        this._WindowStationName = value;
      }
    }

    public string ConnectTime
    {
      get
      {
        return this._ConnectTime;
      }
      set
      {
        this._ConnectTime = value;
      }
    }

    public string LogonTime
    {
      get
      {
        return this._LogonTime;
      }
      set
      {
        this._LogonTime = value;
      }
    }

    public string IdleTime
    {
      get
      {
        return this._IdleTime;
      }
      set
      {
        this._IdleTime = value;
      }
    }

    public string ServerIP
    {
      get
      {
        return this._ServerIP;
      }
      set
      {
        this._ServerIP = value;
      }
    }

    public string State
    {
      get
      {
        return this._State;
      }
      set
      {
        this._State = value;
      }
    }

    public string SessionID
    {
      get
      {
        return this._SessionID;
      }
      set
      {
        this._SessionID = value;
      }
    }
  }
}
