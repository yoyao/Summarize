﻿

namespace ViewService.Model
{
  public class IdentityModel
  {
    private string _ServerIP;
    private string _IP;
    private string _GridName;
    private string _UUID;

    public string ServerIP
    {
      get
      {
        return this._ServerIP;
      }
      set
      {
        this._ServerIP = value;
      }
    }

    public string IP
    {
      get
      {
        return this._IP;
      }
      set
      {
        this._IP = value;
      }
    }

    public string GridName
    {
      get
      {
        return this._GridName;
      }
      set
      {
        this._GridName = value;
      }
    }

    public string UUID
    {
      get
      {
        return this._UUID;
      }
      set
      {
        this._UUID = value;
      }
    }
  }
}
