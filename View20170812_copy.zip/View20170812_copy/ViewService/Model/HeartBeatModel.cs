﻿

namespace ViewService.Model
{
  internal class HeartBeatModel
  {
    private string _UUID;
    private string _IP;
    private string _OSVersion;
    private string _TimeStamp;

    public string UUID
    {
      get
      {
        return this._UUID;
      }
      set
      {
        this._UUID = value;
      }
    }

    public string IP
    {
      get
      {
        return this._IP;
      }
      set
      {
        this._IP = value;
      }
    }

    public string OSVersion
    {
      get
      {
        return this._OSVersion;
      }
      set
      {
        this._OSVersion = value;
      }
    }

    public string TimeStamp
    {
      get
      {
        return this._TimeStamp;
      }
      set
      {
        this._TimeStamp = value;
      }
    }
  }
}
