﻿
using System;
using System.Runtime.InteropServices;

namespace ViewService.Model
{
  public class SystemDateTime
  {
    [DllImport("Kernel32.dll")]
    private static extern bool SetLocalTime(ref SystemTime sysTime);

    public static bool SetLocalTimeByStr(string timestr)
    {
      bool flag = false;
      SystemTime sysTime = new SystemTime();
      DateTime dateTime = Convert.ToDateTime(timestr);
      sysTime.wYear = Convert.ToUInt16(dateTime.Year);
      sysTime.wMonth = Convert.ToUInt16(dateTime.Month);
      sysTime.wDay = Convert.ToUInt16(dateTime.Day);
      sysTime.wHour = Convert.ToUInt16(dateTime.Hour);
      sysTime.wMinute = Convert.ToUInt16(dateTime.Minute);
      sysTime.wSecond = Convert.ToUInt16(dateTime.Second);
      sysTime.wMiliseconds = Convert.ToUInt16(dateTime.Millisecond);
      try
      {
        flag = SystemDateTime.SetLocalTime(ref sysTime);
      }
      catch (Exception ex)
      {
        Console.WriteLine("SetSystemDateTime 函数执行异常" + ex.Message);
      }
      return flag;
    }
  }
}
