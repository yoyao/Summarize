﻿

namespace ViewService.Model
{
  public class SysprepModel
  {
    private string _ServerIP;
    private string _Password;
    private string _TimeZone;
    private string _ProductKey;
    private string _FullName;
    private string _OrgName;
    private string _ComputerName;
    private string _LanguageGroup;
    private string _JoinDomain;
    private string _DomainAdmin;
    private string _DomainAdminPassword;
    private string _PreUserName;
    private string _PrePassword;

    public string ServerIP
    {
      get
      {
        return this._ServerIP;
      }
      set
      {
        this._ServerIP = value;
      }
    }

    public string Password
    {
      get
      {
        return this._Password;
      }
      set
      {
        this._Password = value;
      }
    }

    public string TimeZone
    {
      get
      {
        return this._TimeZone;
      }
      set
      {
        this._TimeZone = value;
      }
    }

    public string ProductKey
    {
      get
      {
        return this._ProductKey;
      }
      set
      {
        this._ProductKey = value;
      }
    }

    public string FullName
    {
      get
      {
        return this._FullName;
      }
      set
      {
        this._FullName = value;
      }
    }

    public string OrgName
    {
      get
      {
        return this._OrgName;
      }
      set
      {
        this._OrgName = value;
      }
    }

    public string ComputerName
    {
      get
      {
        return this._ComputerName;
      }
      set
      {
        this._ComputerName = value;
      }
    }

    public string LanguageGroup
    {
      get
      {
        return this._LanguageGroup;
      }
      set
      {
        this._LanguageGroup = value;
      }
    }

    public string JoinDomain
    {
      get
      {
        return this._JoinDomain;
      }
      set
      {
        this._JoinDomain = value;
      }
    }

    public string DomainAdmin
    {
      get
      {
        return this._DomainAdmin;
      }
      set
      {
        this._DomainAdmin = value;
      }
    }

    public string DomainAdminPassword
    {
      get
      {
        return this._DomainAdminPassword;
      }
      set
      {
        this._DomainAdminPassword = value;
      }
    }

    public string PreUserName
    {
      get
      {
        return this._PreUserName;
      }
      set
      {
        this._PreUserName = value;
      }
    }

    public string PrePassword
    {
      get
      {
        return this._PrePassword;
      }
      set
      {
        this._PrePassword = value;
      }
    }
  }
}
