﻿

using System;
using System.Diagnostics;

namespace ViewService.Utils
{
  internal class Config
  {
    public static string GetValue(string IniName, string ValName)
    {
      Assistant assistant = new Assistant();
      string str = "";
      try
      {
        assistant.parse(AppDomain.CurrentDomain.BaseDirectory + IniName + ".ini", true);
        str = assistant.get(ValName);
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "获取配置文件出错：\r\n\r\n" + ex.ToString());
      }
      return str;
    }

    public static void UpdateValue(string IniName, string KeyName, string ValName)
    {
      Assistant assistant = new Assistant();
      try
      {
        assistant.parse(AppDomain.CurrentDomain.BaseDirectory + IniName + ".ini", true);
        assistant.put(KeyName, ValName);
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "获取配置文件出错：\r\n\r\n" + ex.ToString());
      }
    }
  }
}
