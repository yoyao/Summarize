﻿
using NetFwTypeLib;
using System;
using System.Diagnostics;

namespace ViewService.Utils
{
  public static class INetFwManger
  {
    public static void NetFwAddPorts(string name, int port, string protocol)
    {
      INetFwMgr netFwMgr = (INetFwMgr) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"));
      INetFwOpenPort Port = (INetFwOpenPort) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwOpenPort"));
      Port.Name = name;
      Port.Port = port;
      Port.Protocol = !(protocol.ToUpper() == "TCP") ? NET_FW_IP_PROTOCOL_.NET_FW_IP_PROTOCOL_UDP : NET_FW_IP_PROTOCOL_.NET_FW_IP_PROTOCOL_TCP;
      Port.Scope = NET_FW_SCOPE_.NET_FW_SCOPE_ALL;
      Port.Enabled = true;
      bool flag = false;
      INetFwOpenPorts netFwOpenPorts = (INetFwOpenPorts) null;
      try
      {
        netFwOpenPorts = netFwMgr.LocalPolicy.CurrentProfile.GloballyOpenPorts;
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("FireWall1", ex.Message);
      }
      if (netFwOpenPorts != null)
      {
        foreach (INetFwOpenPort netFwOpenPort in netFwOpenPorts)
        {
          if (Port.Name == netFwOpenPort.Name)
          {
            flag = true;
            break;
          }
        }
      }
      if (flag)
        return;
      try
      {
        netFwMgr.LocalPolicy.CurrentProfile.GloballyOpenPorts.Add(Port);
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("FireWall2", ex.Message);
      }
    }

    public static void NetFwAddApps(string name, string executablePath)
    {
      INetFwAuthorizedApplications authorizedApplications = ((INetFwMgr) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"))).LocalPolicy.CurrentProfile.AuthorizedApplications;
      INetFwAuthorizedApplication app = (INetFwAuthorizedApplication) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwAuthorizedApplication"));
      bool flag = false;
      foreach (INetFwAuthorizedApplication authorizedApplication in authorizedApplications)
      {
        if (app.Name == authorizedApplication.Name)
        {
          flag = true;
          break;
        }
      }
      app.ProcessImageFileName = executablePath;
      app.Name = name;
      if (flag)
        return;
      authorizedApplications.Add(app);
    }

    public static void NetFwAddApps1(string name, string executablePath)
    {
      INetFwMgr netFwMgr = (INetFwMgr) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"));
      INetFwAuthorizedApplication app = (INetFwAuthorizedApplication) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwAuthorizedApplication"));
      app.Name = name;
      app.ProcessImageFileName = executablePath;
      app.Enabled = true;
      netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
      bool flag = false;
      foreach (INetFwAuthorizedApplication authorizedApplication in netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications)
      {
        if (app.Name == authorizedApplication.Name)
        {
          flag = true;
          break;
        }
      }
      if (flag)
        return;
      netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
    }

    public static void NetFwAddApps2(string name, string executablePath)
    {
      INetFwMgr netFwMgr = (INetFwMgr) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"));
      INetFwAuthorizedApplication app = (INetFwAuthorizedApplication) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwAuthorizedApplication"));
      app.Name = name;
      app.ProcessImageFileName = executablePath;
      app.Enabled = true;
      netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
      bool flag = false;
      foreach (INetFwAuthorizedApplication authorizedApplication in netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications)
      {
        if (app.Name == authorizedApplication.Name)
        {
          flag = true;
          break;
        }
      }
      if (flag)
        return;
      netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
    }

    public static void NetFwDelApps(int port, string protocol)
    {
      INetFwMgr netFwMgr = (INetFwMgr) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"));
      if (protocol == "TCP")
        netFwMgr.LocalPolicy.CurrentProfile.GloballyOpenPorts.Remove(port, NET_FW_IP_PROTOCOL_.NET_FW_IP_PROTOCOL_TCP);
      else
        netFwMgr.LocalPolicy.CurrentProfile.GloballyOpenPorts.Remove(port, NET_FW_IP_PROTOCOL_.NET_FW_IP_PROTOCOL_UDP);
    }

    public static void NetFwDelApps(string executablePath)
    {
      ((INetFwMgr) Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"))).LocalPolicy.CurrentProfile.AuthorizedApplications.Remove(executablePath);
    }
  }
}
