﻿
using System;
using System.IO;

namespace ViewService.Utils
{
  internal class Assistant
  {
    private string section = "section1";
    private StreamWriter writer = (StreamWriter) null;
    private StreamReader reader = (StreamReader) null;
    private bool isSection = false;
    private bool isReader = false;
    private string path;
    private bool isAppend;

    public string Path
    {
      get
      {
        return this.path;
      }
      set
      {
        this.path = value;
      }
    }

    public string Section
    {
      get
      {
        return this.section;
      }
      set
      {
        this.section = value;
      }
    }

    ~Assistant()
    {
      if (this.isSection)
        this.writer.Close();
      else if (this.isReader)
        this.reader.Close();
      this.reader = (StreamReader) null;
      this.writer = (StreamWriter) null;
    }

    public void parse(string path, bool isAppend)
    {
      this.path = path;
      this.isAppend = isAppend;
    }

    public void put(string Key, string Value)
    {
      string str1 = "";
      this.reader = File.OpenText(this.path);
      for (string str2 = this.reader.ReadLine(); str2 != null; str2 = this.reader.ReadLine())
      {
        if (str2.IndexOf(Key) >= 0)
          str1 = str1 + Key + "=" + Value + "\r\n";
        else
          str1 = str1 + str2 + "\r\n";
      }
      this.reader.Close();
      this.writer = File.CreateText(this.path);
      this.writer.WriteLine(str1);
      this.writer.Flush();
      this.writer.Close();
      this.isReader = true;
      this.isSection = true;
    }

    public string get(string Key)
    {
      string str1 = "";
      if (!File.Exists(this.path))
        throw new FileNotFoundException(this.path + "未找到,请确认文件是否存在!");
      try
      {
        this.reader = File.OpenText(this.path);
        string str2 = this.reader.ReadLine();
        while (str2 != null)
        {
          if (str2.IndexOf("[" + this.section + "]") < 0 && (str2.IndexOf(";") < 0 && str2.IndexOf("#") < 0))
          {
            if (str2.IndexOf(Key) >= 0 && str2.IndexOf(";") < 0 && str2.IndexOf("#") < 0)
              str1 = str2.Substring(Key.Length + "=".Length);
            str2 = this.reader.ReadLine();
          }
        }
      }
      catch (Exception ex)
      {
        this.reader.Close();
        throw new Exception(ex.Message);
      }
      this.reader.Close();
      return str1;
    }

    public void release()
    {
      if (this.isSection)
        this.writer.Close();
      else if (this.isReader)
        this.reader.Close();
      this.reader = (StreamReader) null;
      this.writer = (StreamWriter) null;
    }
  }
}
