﻿

namespace ViewService.Utils
{
  public enum DesktopState
  {
    WAITING,
    WORKING,
    STOPPED,
    STARTING,
  }
}
