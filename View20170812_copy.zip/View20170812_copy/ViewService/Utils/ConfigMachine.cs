﻿

namespace ViewService.Utils
{
  public static class ConfigMachine
  {
    private static string _Dir = (string) null;
    private static string _ServerIP = (string) null;
    private static string _Port = (string) null;
    private static string _IP = (string) null;
    private static string _UUID = (string) null;
    private static string _GridName = (string) null;
    private static string _Interval = (string) null;
    private static string _AD = (string) null;
    private static string _PreUserName = (string) null;
    private static string _FireWall = (string) null;
    private static string _Restore = (string) null;
    private static string _IsInstalled = (string) null;

    public static string GetDir()
    {
      if (ConfigMachine._Dir == null)
        ConfigMachine._Dir = Config.GetValue("config", "_dir");
      return ConfigMachine._Dir;
    }

    public static string GetServerIP()
    {
      if (ConfigMachine._ServerIP == null)
        ConfigMachine._ServerIP = Config.GetValue("config", "_serverip");
      return ConfigMachine._ServerIP;
    }

    public static int GetPort()
    {
      if (ConfigMachine._Port == null)
        ConfigMachine._Port = Config.GetValue("config", "_port");
      int num;
      try
      {
        num = int.Parse(ConfigMachine._Port);
      }
      catch
      {
        num = -1;
      }
      return num;
    }

    public static string GetIP()
    {
      if (ConfigMachine._IP == null)
        ConfigMachine._IP = Config.GetValue("config", "_ip");
      return ConfigMachine._IP;
    }

    public static string GetUUID()
    {
      if (ConfigMachine._UUID == null)
        ConfigMachine._UUID = Config.GetValue("config", "_uuid");
      return ConfigMachine._UUID;
    }

    public static string GetGridName()
    {
      if (ConfigMachine._GridName == null)
        ConfigMachine._GridName = Config.GetValue("config", "_gridname");
      return ConfigMachine._GridName;
    }

    public static string GetInterval()
    {
      if (ConfigMachine._Interval == null)
        ConfigMachine._Interval = Config.GetValue("config", "_interval");
      if (ConfigMachine._Interval == "")
        ConfigMachine._Interval = "50000";
      return ConfigMachine._Interval;
    }

    public static string GetAD()
    {
      if (ConfigMachine._AD == null)
        ConfigMachine._AD = Config.GetValue("config", "_ad");
      return ConfigMachine._AD;
    }

    public static string GetPreUserName()
    {
      if (ConfigMachine._PreUserName == null)
        ConfigMachine._PreUserName = Config.GetValue("config", "_preusername");
      return ConfigMachine._PreUserName;
    }

    public static string GetFireWall()
    {
      if (ConfigMachine._FireWall == null)
        ConfigMachine._FireWall = Config.GetValue("config", "_firewall");
      return ConfigMachine._FireWall;
    }

    public static string GetRestore()
    {
      if (ConfigMachine._Restore == null)
        ConfigMachine._Restore = Config.GetValue("config", "_restore");
      return ConfigMachine._Restore;
    }

    public static string GetIsInstalled()
    {
      if (ConfigMachine._IsInstalled == null)
        ConfigMachine._IsInstalled = Config.GetValue("config", "_isinstalled");
      return ConfigMachine._IsInstalled;
    }

    public static void SetDir(string Dir)
    {
      ConfigMachine._Dir = Dir;
      Config.UpdateValue("config", "_dir", Dir);
    }

    public static void SetServerIP(string ServerIP)
    {
      ConfigMachine._ServerIP = ServerIP;
      Config.UpdateValue("config", "_serverip", ServerIP);
    }

    public static void SetPort(string Port)
    {
      ConfigMachine._Port = Port;
      Config.UpdateValue("config", "_port", Port);
    }

    public static void SetIP(string IP)
    {
      ConfigMachine._IP = IP;
      Config.UpdateValue("config", "_ip", IP);
    }

    public static void SetUUID(string UUID)
    {
      ConfigMachine._UUID = UUID;
      Config.UpdateValue("config", "_uuid", UUID);
    }

    public static void SetGridName(string GridName)
    {
      ConfigMachine._GridName = GridName;
      Config.UpdateValue("config", "_gridname", GridName);
    }

    public static void SetInterval(string Interval)
    {
      ConfigMachine._Interval = Interval;
      Config.UpdateValue("config", "_interval", Interval);
    }

    public static void SetAD(string AD)
    {
      ConfigMachine._AD = AD;
      Config.UpdateValue("config", "_ad", AD);
    }

    public static void SetPreUserName(string PreUserName)
    {
      ConfigMachine._PreUserName = PreUserName;
      Config.UpdateValue("config", "_preusername", PreUserName);
    }

    public static void SetFireWall(string FireWall)
    {
      ConfigMachine._FireWall = FireWall;
      Config.UpdateValue("config", "_firewall", FireWall);
    }

    public static void SetRestore(string Restore)
    {
      ConfigMachine._Restore = Restore;
      Config.UpdateValue("config", "_restore", Restore);
    }

    public static void SetIsInstalled(string IsInstalled)
    {
      ConfigMachine._IsInstalled = IsInstalled;
      Config.UpdateValue("config", "_isinstalled", IsInstalled);
    }
  }
}
