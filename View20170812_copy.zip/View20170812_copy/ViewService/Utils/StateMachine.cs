﻿

using System;

namespace ViewService.Utils
{
  public class StateMachine
  {
    private static DesktopState _DesktopState = DesktopState.STOPPED;
    private static object o = new object();
    private static string _ServerIP;
    private static int _Port;
    private static string _UUID;
    private static string _GridName;
    private static string _Interval;
    private static string _AD;
    private static string _PreUserName;
    private static string _IP;
    private static string _UserAccount;

    public static void Init()
    {
      StateMachine._ServerIP = ConfigMachine.GetServerIP();
      StateMachine._Port = ConfigMachine.GetPort();
      StateMachine._UUID = ConfigMachine.GetUUID();
      StateMachine._GridName = ConfigMachine.GetGridName();
      StateMachine._Interval = ConfigMachine.GetInterval();
      StateMachine._AD = ConfigMachine.GetAD();
      StateMachine._PreUserName = ConfigMachine.GetPreUserName();
      StateMachine._IP = ConfigMachine.GetIP();
      if (!(StateMachine._ServerIP.Trim() != ""))
        return;
      StateMachine.ChangeDesktopState(DesktopState.WORKING);
    }

    public static void SetUserAccount(string UserAccount)
    {
      StateMachine._UserAccount = UserAccount;
    }

    public static string GetUserAccount()
    {
      return StateMachine._UserAccount;
    }

    public static DesktopState GetDesktopState()
    {
      return StateMachine._DesktopState;
    }

    public static void ChangeDesktopState(DesktopState DesktopState)
    {
      lock (StateMachine.o)
        StateMachine._DesktopState = DesktopState;
    }

    public static void UpdateServerState(string ServerIP, int Port, string UUID, string GridName, string Interval)
    {
      StateMachine._ServerIP = ServerIP;
      StateMachine._Port = Port;
      StateMachine._UUID = UUID;
      StateMachine._GridName = GridName;
      if (Interval == "" || Interval == "0")
        Interval = "20000";
      StateMachine._Interval = Interval;
      StateMachine._IP = Common.GetIP();
      try
      {
        ConfigMachine.SetServerIP(ServerIP);
        ConfigMachine.SetPort(Port.ToString());
        ConfigMachine.SetUUID(UUID);
        ConfigMachine.SetGridName(GridName);
        ConfigMachine.SetInterval(Interval);
        ConfigMachine.SetIP(StateMachine._IP);
      }
      catch (Exception ex)
      {
        throw ex;
      }
      finally
      {
        StateMachine.ChangeDesktopState(DesktopState.WORKING);
      }
    }

    public static string GetServerIP()
    {
      return StateMachine._ServerIP;
    }

    public static int GetServerPort()
    {
      return StateMachine._Port;
    }

    public static string GetUUID()
    {
      return StateMachine._UUID;
    }

    public static string GetGridName()
    {
      return StateMachine._GridName;
    }

    public static string GetInterval()
    {
      return StateMachine._Interval;
    }

    public static string GetAD()
    {
      return StateMachine._AD;
    }

    public static string GetPreUserName()
    {
      return StateMachine._PreUserName;
    }

    public static string GetIP()
    {
      return StateMachine._IP;
    }
  }
}
