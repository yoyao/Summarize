﻿
using Cassia;
using ViewService.Model;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Security.Principal;
using System.Text;

namespace ViewService.Utils
{
  internal class Cassia2
  {
    private static readonly ITerminalServicesManager _manager = (ITerminalServicesManager) new TerminalServicesManager();
    private SessionEventModel s;

    private static void WaitForEvents()
    {
      Console.WriteLine("Waiting for events; press Enter to exit.");
      SystemEvents.SessionSwitch += (SessionSwitchEventHandler) ((sender, args) => Console.WriteLine((object) args.Reason));
      Console.ReadLine();
    }

    private static void Shutdown(string[] args)
    {
      if (args.Length < 3)
      {
        Console.WriteLine("Usage: SessionInfo shutdown [server] [shutdown type]");
      }
      else
      {
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          ShutdownType shutdownType = (ShutdownType) Enum.Parse(typeof (ShutdownType), args[2], true);
          serverFromName.Shutdown(shutdownType);
        }
      }
    }

    private static void KillProcess(string[] args)
    {
      if (args.Length < 4)
      {
        Console.WriteLine("Usage: SessionInfo killprocess [server] [process id] [exit code]");
      }
      else
      {
        int num1 = int.Parse(args[2]);
        int num2 = int.Parse(args[3]);
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          serverFromName.GetProcess(num1).Kill(num2);
        }
      }
    }

    private static void ListProcesses(string[] args)
    {
      if (args.Length < 2)
      {
        Console.WriteLine("Usage: SessionInfo listprocesses [server]");
      }
      else
      {
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          Cassia2.WriteProcesses((IEnumerable<ITerminalServicesProcess>) serverFromName.GetProcesses());
        }
      }
    }

    private static void WriteProcesses(IEnumerable<ITerminalServicesProcess> processes)
    {
      using (IEnumerator<ITerminalServicesProcess> enumerator = processes.GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
          Cassia2.WriteProcessInfo(enumerator.Current);
      }
    }

    private static void WriteProcessInfo(ITerminalServicesProcess process)
    {
      Console.WriteLine("Session ID: " + (object) process.SessionId);
      Console.WriteLine("Process ID: " + (object) process.ProcessId);
      Console.WriteLine("Process Name: " + process.ProcessName);
      Console.WriteLine("SID: " + (object) process.SecurityIdentifier);
      Console.WriteLine("Working Set: " + (object) process.UnderlyingProcess.WorkingSet64);
    }

    private static void ListServers(string[] args)
    {
      string str = args.Length > 1 ? args[1] : (string) null;
      using (IEnumerator<ITerminalServer> enumerator = ((IEnumerable<ITerminalServer>) Cassia2._manager.GetServers(str)).GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
         // Console.WriteLine(enumerator.Current.get_ServerName());
            Console.WriteLine(enumerator.Current.ServerName);
      }
    }

    private static void AskQuestion(string[] args)
    {
      if (args.Length < 8)
      {
        Console.WriteLine("Usage: SessionInfo ask [server] [session id] [icon] [caption] [text] [timeout] [buttons]");
      }
      else
      {
        int num1 = int.Parse(args[6]);
        int num2 = int.Parse(args[2]);
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          ITerminalServicesSession session = serverFromName.GetSession(num2);
          RemoteMessageBoxIcon remoteMessageBoxIcon = (RemoteMessageBoxIcon) Enum.Parse(typeof (RemoteMessageBoxIcon), args[3], true);
          RemoteMessageBoxButtons messageBoxButtons = (RemoteMessageBoxButtons) Enum.Parse(typeof (RemoteMessageBoxButtons), args[7], true);
          Console.WriteLine("Response: " + (object) session.MessageBox(args[5], args[4], messageBoxButtons, remoteMessageBoxIcon, (RemoteMessageBoxDefaultButton) 0, (RemoteMessageBoxOptions) 0, TimeSpan.FromSeconds((double) num1), true));
        }
      }
    }

    private static void SendMessage(string[] args)
    {
      if (args.Length < 6)
      {
        Console.WriteLine("Usage: SessionInfo message [server] [session id] [icon] [caption] [text]");
      }
      else
      {
        int num = int.Parse(args[2]);
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          ITerminalServicesSession session = serverFromName.GetSession(num);
          RemoteMessageBoxIcon remoteMessageBoxIcon = (RemoteMessageBoxIcon) Enum.Parse(typeof (RemoteMessageBoxIcon), args[3], true);
          session.MessageBox(args[5], args[4], remoteMessageBoxIcon);
        }
      }
    }

    private static void GetSessionInfo(string[] args)
    {
      if (args.Length < 3)
      {
        Console.WriteLine("Usage: SessionInfo get [server] [session id]");
      }
      else
      {
        int num = int.Parse(args[2]);
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          Cassia2.WriteSessionInfo(serverFromName.GetSession(num));
        }
      }
    }

    private static void ListSessionProcesses(string[] args)
    {
      if (args.Length < 3)
      {
        Console.WriteLine("Usage: SessionInfo listsessionprocesses [server] [session id]");
      }
      else
      {
        int num = int.Parse(args[2]);
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          Cassia2.WriteProcesses((IEnumerable<ITerminalServicesProcess>) serverFromName.GetSession(num).GetProcesses());
        }
      }
    }

    private static void ListSessions(string[] args)
    {
      if (args.Length < 2)
      {
        Console.WriteLine("Usage: SessionInfo listsessions [server]");
      }
      else
      {
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args[1]))
        {
          serverFromName.Open();
          using (IEnumerator<ITerminalServicesSession> enumerator = ((IEnumerable<ITerminalServicesSession>) serverFromName.GetSessions()).GetEnumerator())
          {
            while (((IEnumerator) enumerator).MoveNext())
              Cassia2.WriteSessionInfo(enumerator.Current);
          }
        }
      }
    }

    public string ListSessions2(string args)
    {
      string str = "";
      if (args.Length < 2)
        str = "";
      using (ITerminalServer serverFromName = Cassia2.GetServerFromName(args))
      {
        serverFromName.Open();
        using (IEnumerator<ITerminalServicesSession> enumerator = ((IEnumerable<ITerminalServicesSession>) serverFromName.GetSessions()).GetEnumerator())
        {
          while (((IEnumerator) enumerator).MoveNext())
          {
            ITerminalServicesSession current = enumerator.Current;
            str += Cassia2.WriteSessionInfo2(current);
          }
        }
      }
      return str;
    }

    private static void ShowCurrentSession()
    {
      //Cassia2.WriteSessionInfo(Cassia2._manager.get_CurrentSession());
        Cassia2.WriteSessionInfo(Cassia2._manager.CurrentSession);
    }

    public string ShowCurrentSession2()
    {
      string str = (string) null;
      using (ITerminalServer serverFromName = Cassia2.GetServerFromName("local"))
      {
        serverFromName.Open();
        using (IEnumerator<ITerminalServicesSession> enumerator = ((IEnumerable<ITerminalServicesSession>) serverFromName.GetSessions()).GetEnumerator())
        {
          while (((IEnumerator) enumerator).MoveNext())
          {
            ITerminalServicesSession current = enumerator.Current;
            str = str + Cassia2.WriteSessionInfo2(current) + "\n\n------------------------\n\n";
          }
        }
      }
      return str;
    }

    private static void LogoffSession(string[] args)
    {
      if (args.Length < 3)
      {
        Console.WriteLine("Usage: SessionInfo logoff [server] [session id]");
      }
      else
      {
        string serverName = args[1];
        int num = int.Parse(args[2]);
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(serverName))
        {
          serverFromName.Open();
          serverFromName.GetSession(num).Logoff();
        }
      }
    }

    private static ITerminalServer GetServerFromName(string serverName)
    {
      return serverName.Equals("local", StringComparison.InvariantCultureIgnoreCase) ? Cassia2._manager.GetLocalServer() : Cassia2._manager.GetRemoteServer(serverName);
    }

    private static void DisconnectSession(string[] args)
    {
      if (args.Length < 3)
      {
        Console.WriteLine("Usage: SessionInfo disconnect [server] [session id]");
      }
      else
      {
        string serverName = args[1];
        int num = int.Parse(args[2]);
        using (ITerminalServer serverFromName = Cassia2.GetServerFromName(serverName))
        {
          serverFromName.Open();
          serverFromName.GetSession(num).Disconnect();
        }
      }
    }

    public SessionEventModel ShowCurrentSession3()
    {
      SessionEventModel sessionEventModel = (SessionEventModel) null;
      using (ITerminalServer localServer = Cassia2._manager.GetLocalServer())
      {
        localServer.Open();
        try
        {
          int num = 0;
          using (IEnumerator<ITerminalServicesSession> enumerator = ((IEnumerable<ITerminalServicesSession>) localServer.GetSessions()).GetEnumerator())
          {
            while (((IEnumerator) enumerator).MoveNext())
            {
              if (enumerator.Current.UserAccount != (NTAccount) null)
                ++num;
            }
          }
          using (IEnumerator<ITerminalServicesSession> enumerator = ((IEnumerable<ITerminalServicesSession>) localServer.GetSessions()).GetEnumerator())
          {
            while (((IEnumerator) enumerator).MoveNext())
            {
              ITerminalServicesSession current = enumerator.Current;
             // By esage 2016-07-01
             // if (current.ConnectionState == null && current.WindowStationName.IndexOf("RDP-Tcp#") > -1 && current.ClientIPAddress != null)
              if (current.ConnectionState == ConnectionState.Active && current.WindowStationName.IndexOf("RDP-Tcp#") > -1 && current.ClientIPAddress != null)
              {
                sessionEventModel = this.WriteSessionInfo3(current);
                break;
              }
          //    if (current.ConnectionState == 4 && current.WindowStationName.IndexOf("RDP-Tcp#") > -1 && current.UserAccount == (NTAccount) null)
              if (current.ConnectionState == ConnectionState.Disconnected && current.WindowStationName.IndexOf("RDP-Tcp#") > -1 && current.UserAccount == (NTAccount)null)
              {
                sessionEventModel = this.WriteSessionInfo3(current);
                break;
              }
             // if (current.ConnectionState == 4 && current.UserAccount != (NTAccount) null)
              if (current.ConnectionState == ConnectionState.Disconnected && current.UserAccount != (NTAccount)null)
              {
                sessionEventModel = this.WriteSessionInfo3(current);
                if (num == 1)
                  break;
              }
            }
          }
        }
        catch (Win32Exception ex)
        {
          EventLog.WriteEntry("ViewServer Cassia", "Cassia 无法初始化：" + ex.ToString());
        }
        catch (Exception ex)
        {
          EventLog.WriteEntry("ViewServer Cassia", "Cassia 无法初始化：" + ex.ToString());
        }
      }
      return sessionEventModel;
    }

    private SessionEventModel WriteSessionInfo3(ITerminalServicesSession session)
    {
      SessionEventModel sessionEventModel = new SessionEventModel();
      sessionEventModel.UserAccount = !(session.UserAccount != (NTAccount) null) ? "" : session.UserAccount.ToString();
      sessionEventModel.WindowStationName = session.WindowStationName == null ? "" : session.WindowStationName;
      sessionEventModel.ConnectTime = session.ConnectTime.ToString();
      sessionEventModel.LogonTime = session.LoginTime.ToString();
      sessionEventModel.IdleTime = session.IdleTime.ToString();
      sessionEventModel.IP = session.ClientIPAddress == null ? "" : session.ClientIPAddress.ToString();
      sessionEventModel.State = ((object) session.ConnectionState).ToString();
      sessionEventModel.SessionID = session.SessionId.ToString();
      try
      {
        this.s = sessionEventModel;
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("错误8", ex.ToString());
      }
      return sessionEventModel;
    }

    private static string WriteSessionInfo2(ITerminalServicesSession session)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.AppendLine("Session ID: " + (object) session.SessionId);
      if (session.UserAccount != (NTAccount) null)
        stringBuilder.AppendLine("User: " + (object) session.UserAccount);
      if (session.ClientIPAddress != null)
        stringBuilder.AppendLine("IP Address: " + (object) session.ClientIPAddress);
      stringBuilder.AppendLine("Window Station: " + session.WindowStationName);
      stringBuilder.AppendLine("Client Build Number: " + (object) session.ClientBuildNumber);
      stringBuilder.AppendLine("State: " + (object) session.ConnectionState);
      stringBuilder.AppendLine("Connect Time: " + (object) session.ConnectTime);
      stringBuilder.AppendLine("Logon Time: " + (object) session.LoginTime);
      stringBuilder.AppendLine("Idle Time: " + (object) session.IdleTime);
      stringBuilder.AppendLine(string.Format("Client Display: {0}x{1} with {2} bits per pixel", (object) session.ClientDisplay.HorizontalResolution, (object) session.ClientDisplay.VerticalResolution, (object) session.ClientDisplay.BitsPerPixel));
      return stringBuilder.ToString();
    }

    private static void WriteSessionInfo(ITerminalServicesSession session)
    {
      Console.WriteLine("Session ID: " + (object) session.SessionId);
      if (session.UserAccount != (NTAccount) null)
        Console.WriteLine("User: " + (object) session.UserAccount);
      if (session.ClientIPAddress != null)
        Console.WriteLine("IP Address: " + (object) session.ClientIPAddress);
      Console.WriteLine("Window Station: " + session.WindowStationName);
      Console.WriteLine("Client Build Number: " + (object) session.ClientBuildNumber);
      Console.WriteLine("State: " + (object) session.ConnectionState);
      Console.WriteLine("Connect Time: " + (object) session.ConnectTime);
      Console.WriteLine("Logon Time: " + (object) session.LoginTime);
      Console.WriteLine("Idle Time: " + (object) session.IdleTime);
      Console.WriteLine(string.Format("Client Display: {0}x{1} with {2} bits per pixel", (object) session.ClientDisplay.HorizontalResolution, (object) session.ClientDisplay.VerticalResolution, (object) session.ClientDisplay.BitsPerPixel));
      Console.WriteLine();
    }
  }
}
