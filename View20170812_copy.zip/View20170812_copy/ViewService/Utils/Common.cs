﻿

using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace ViewService.Utils
{
  internal class Common
  {
    public static double StrToDouble(string str)
    {
      double num = 50.0;
      if (str != null)
      {
        try
        {
          num = double.Parse(str);
        }
        catch
        {
          num = 50.0;
        }
      }
      return num;
    }

    public static int StrToInt(string str)
    {
      int num = 10000;
      if (str != null)
      {
        try
        {
          num = int.Parse(str);
        }
        catch
        {
          num = 10000;
        }
      }
      return num;
    }

    public static string GetWindowsVersion()
    {
      OperatingSystem osVersion = Environment.OSVersion;
      switch (osVersion.Platform)
      {
        case PlatformID.Win32Windows:
          switch (osVersion.Version.Minor)
          {
            case 0:
              return "Windows 95";
            case 10:
              return osVersion.Version.Revision.ToString() == "2222A" ? "Windows 98 第二版" : "Windows 98";
            case 90:
              return "Windows Me";
          }
          break;
        case PlatformID.Win32NT:
          switch (osVersion.Version.Major)
          {
            case 3:
              return "Windows NT 3.51";
            case 4:
              return "Windows NT 4.0";
            case 5:
              switch (osVersion.Version.Minor)
              {
                case 0:
                  return "Windows 200";
                case 1:
                  return "Windows XP";
                case 2:
                  return "Windows 2003";
              }
              break;
            case 6:
              switch (osVersion.Version.Minor)
              {
                case 0:
                  return "Windows Vista";
                case 1:
                  return IntPtr.Size == 4 ? "Windows 7(32-bit)" : "Windows 7(64-bit)";
                case 2:
                  return IntPtr.Size == 4 ? "Windows 8(32-bit)" : "Windows 8(64-bit)";
              }
              break;
          }
          break;
      }
      return "None";
    }

    public static void CheckLog(string Log, string LogFile)
    {
      Common.WriteLog(Log, LogFile);
    }

    private static void WriteLog(string Log, string LogFile)
    {
      if (!System.IO.File.Exists(LogFile))
      {
        try
        {
          System.IO.File.Create(LogFile).Close();
        }
        catch (Exception ex)
        {
          EventLog.WriteEntry("ViewServer", "创建文件报错：\r\n\r\n " + ex.ToString());
        }
      }
      FileStream fileStream = (FileStream) null;
      StreamWriter streamWriter = (StreamWriter) null;
      try
      {
        fileStream = new FileStream(LogFile, FileMode.Append);
        streamWriter = new StreamWriter((Stream) fileStream);
        streamWriter.WriteLine(Log);
        streamWriter.Flush();
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "写入文件报错：\r\n\r\n " + ex.ToString());
      }
      finally
      {
        if (streamWriter != null)
          streamWriter.Close();

        //  By esage 2016-07-08
        //if (fileStream != null)
        //  fileStream.Close();
      }
    }

    public static string ReadLog(string LogFile)
    {
      string str1 = "";
      try
      {
        using (StreamReader streamReader = new StreamReader(LogFile))
        {
          for (string str2 = streamReader.ReadLine(); str2 != null; str2 = streamReader.ReadLine())
            str1 = str1 + str2 + "\r\n";
        }
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "读取配置文件出错：\r\n\r\n " + ex.ToString());
      }
      return str1;
    }

    public static string GetIP()
    {
        // By esage 2016-07-01
     // IPAddress[] addressList = Dns.GetHostByName(Dns.GetHostName()).AddressList;
        IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
      string str = (string) null;
      for (int index = 0; index < addressList.Length; ++index)
      {
        if (addressList[index].ToString().IndexOf(".") > -1)
          str = addressList[index].ToString();
      }
      return str;
    }

    public static string GetIP2()
    {
      IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
      string str = (string) null;
      for (int index = 0; index < addressList.Length; ++index)
      {
        if (addressList[index].ToString().IndexOf(".") > -1)
          str = addressList[index].ToString();
      }
      return str;
    }

    public static void RunCmd2(string path)
    {
      ProcessStartInfo startInfo = new ProcessStartInfo();
      startInfo.FileName = "net.exe";
      startInfo.Arguments = path;
      startInfo.WorkingDirectory = "";
      startInfo.WindowStyle = ProcessWindowStyle.Hidden;
      startInfo.ErrorDialog = false;
      startInfo.CreateNoWindow = true;
      try
      {
        Process.Start(startInfo);
      }
      catch (Win32Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "运行CMD报错：" + ex.ToString());
      }
    }

    public static void RootCmd()
    {
      ProcessStartInfo startInfo = new ProcessStartInfo();
      startInfo.FileName = "shutdown.exe";
      startInfo.Arguments = " -r -t 0";
      startInfo.WorkingDirectory = "";
      startInfo.WindowStyle = ProcessWindowStyle.Hidden;
      startInfo.ErrorDialog = false;
      startInfo.CreateNoWindow = true;
      try
      {
        Process.Start(startInfo);
      }
      catch (Win32Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "运行CMD报错：" + ex.ToString());
      }
    }

    public static void RunCmd(string path)
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = path,
        WindowStyle = ProcessWindowStyle.Hidden,
        ErrorDialog = false,
        CreateNoWindow = true
      });
    }

    public static void RunPath(string Path, string FileName)
    {
      new Process()
      {
        StartInfo = {
          WindowStyle = ProcessWindowStyle.Hidden,
          WorkingDirectory = Path,
          FileName = FileName,
          UseShellExecute = true,
          CreateNoWindow = true
        }
      }.Start();
    }

    public static string GetCmdOutString(string path, string arguments)
    {
      ProcessStartInfo startInfo = new ProcessStartInfo();
      startInfo.FileName = path;
      startInfo.UseShellExecute = true;
      startInfo.Arguments = arguments;
      startInfo.CreateNoWindow = false;
      startInfo.RedirectStandardOutput = true;
      startInfo.UseShellExecute = false;
      string str = "";
      Process process = Process.Start(startInfo);
      while (!process.WaitForExit(0))
        str = str + process.StandardOutput.ReadLine() + "\r\n";
      process.Close();
      return str;
    }

    public static void SetRegeditData(string subName, string keyName, int keyValue)
    {
      RegistryKey registryKey1 = Registry.LocalMachine;
      RegistryKey registryKey2 = registryKey1.OpenSubKey(subName, true);
      registryKey2.SetValue(keyName, (object) keyValue, RegistryValueKind.DWord);
      registryKey2.Close();
      registryKey1.Close();
    }

    public static void SetRegeditData(string subName, string keyName, string keyValue)
    {
      RegistryKey registryKey1 = Registry.LocalMachine;
      RegistryKey registryKey2 = registryKey1.OpenSubKey(subName, true);
      registryKey2.SetValue(keyName, (object) keyValue);
      registryKey2.Close();
      registryKey1.Close();
    }

    public static string decodeUnicode(string dataStr)
    {
      return new Regex("(?i)\\\\[uU]([0-9a-f]{4})").Replace(dataStr, (MatchEvaluator) (m => ((char) Convert.ToInt32(m.Groups[1].Value, 16)).ToString()));
    }

    public static string encodeUnicode(string str)
    {
      Encoding bigEndianUnicode = Encoding.BigEndianUnicode;
      string str1 = string.Empty;
      byte[] bytes = bigEndianUnicode.GetBytes(str);
      for (int startIndex = 0; startIndex < bytes.Length; ++startIndex)
        str1 = startIndex % 2 != 0 ? str1 + BitConverter.ToString(bytes, startIndex, 1) : str1 + "\\u" + BitConverter.ToString(bytes, startIndex, 1);
      return str1;
    }
  }
}
