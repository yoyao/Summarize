﻿

using System;
using System.Runtime.InteropServices;
using System.Security;

namespace ViewService
{
    public class CSControl
    {
        private const int SE_PRIVILEGE_ENABLED = 2;
        private const int TOKEN_QUERY = 8;
        private const int TOKEN_ADJUST_PRIVILEGES = 32;
        private const string SE_SHUTDOWN_NAME = "SeShutdownPrivilege";

        private static  IntPtr GetCurrentProcess()
        {
            return SafeNativeMethods.GetCurrentProcess();
        }
        private static  bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok)
        {
            return SafeNativeMethods.OpenProcessToken(h, acc, ref phtok);
        }

        private static bool LookupPrivilegeValue(string host, string name, ref long pluid)
        {
            return SafeNativeMethods.LookupPrivilegeValue(host, name, ref pluid);
        }

        private static bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref CSControl.TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen)
        {
            return SafeNativeMethods.AdjustTokenPrivileges(htok, disall, ref newst, len, prev, relen);
        }

         private static bool ExitWindowsEx(CSControl.ExitWindows uFlags, CSControl.ShutdownReason dwReason)
        {
            return SafeNativeMethods.ExitWindowsEx(uFlags, dwReason);
        }

        public static void DoExitWindows(CSControl.ExitWindows flag)
        {
            IntPtr currentProcess = CSControl.GetCurrentProcess();
            IntPtr phtok = IntPtr.Zero;
            CSControl.OpenProcessToken(currentProcess, 40, ref phtok);
            CSControl.TokPriv1Luid newst;
            newst.Count = 1;
            newst.Luid = 0L;
            newst.Attr = 2;
            CSControl.LookupPrivilegeValue((string)null, "SeShutdownPrivilege", ref newst.Luid);
            CSControl.AdjustTokenPrivileges(phtok, false, ref newst, 0, IntPtr.Zero, IntPtr.Zero);
            CSControl.ExitWindowsEx(flag, CSControl.ShutdownReason.MajorOther);
        }

        [Flags]
        public enum ExitWindows : uint
        {
            LogOff = 0,
            ShutDown = 1,
            Reboot = 2,
            Force = 4,
            PowerOff = 8,
            ForceIfHung = 16,
        }

        [Flags]
        internal enum ShutdownReason : uint
        {
            MajorApplication = 262144,
            MajorHardware = 65536,
            MajorLegacyApi = 458752,
            MajorOperatingSystem = 131072,
            MajorOther = 0,
            MajorPower = MajorOperatingSystem | MajorApplication,
            MajorSoftware = MajorOperatingSystem | MajorHardware,
            MajorSystem = MajorHardware | MajorApplication,
            MinorBlueScreen = 15,
            MinorCordUnplugged = 11,
            MinorDisk = 7,
            MinorEnvironment = 12,
            MinorHardwareDriver = 13,
            MinorHotfix = 17,
            MinorHung = 5,
            MinorInstallation = 2,
            MinorMaintenance = 1,
            MinorMMC = 25,
            MinorNetworkConnectivity = 20,
            MinorNetworkCard = 9,
            MinorOther = 0,
            MinorOtherDriver = MinorInstallation | MinorEnvironment,
            MinorPowerSupply = 10,
            MinorProcessor = 8,
            MinorReconfig = 4,
            MinorSecurity = 19,
            MinorSecurityFix = 18,
            MinorSecurityFixUninstall = 24,
            MinorServicePack = 16,
            MinorServicePackUninstall = MinorServicePack | MinorReconfig | MinorInstallation,
            MinorTermSrv = 32,
            MinorUnstable = MinorReconfig | MinorInstallation,
            MinorUpgrade = MinorMaintenance | MinorInstallation,
            MinorWMI = MinorServicePack | MinorReconfig | MinorMaintenance,
            FlagUserDefined = 1073741824,
            FlagPlanned = 2147483648,
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        internal struct TokPriv1Luid
        {
            public int Count;
            public long Luid;
            public int Attr;
        }

        [SuppressUnmanagedCodeSecurityAttribute]
        internal static class SafeNativeMethods
        {
            [DllImport("kernel32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
            internal static extern IntPtr GetCurrentProcess();

            [DllImport("advapi32.dll", CharSet = CharSet.Auto, ExactSpelling = true, SetLastError = true)]
            internal static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);

            [DllImport("advapi32.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
            internal static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

            [DllImport("advapi32.dll", SetLastError = true)]
            internal static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref CSControl.TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);

            [DllImport("user32.dll")]
            internal static extern bool ExitWindowsEx(CSControl.ExitWindows uFlags, CSControl.ShutdownReason dwReason);
        }

    }

   


/*
  public class CSControl
  {
    private const int SE_PRIVILEGE_ENABLED = 2;
    private const int TOKEN_QUERY = 8;
    private const int TOKEN_ADJUST_PRIVILEGES = 32;
    private const string SE_SHUTDOWN_NAME = "SeShutdownPrivilege";

    [DllImport("kernel32.dll")]
     private static extern IntPtr GetCurrentProcess();

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref CSControl.TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);

    [DllImport("user32.dll")]
    private static extern bool ExitWindowsEx(CSControl.ExitWindows uFlags, CSControl.ShutdownReason dwReason);

    public static void DoExitWindows(CSControl.ExitWindows flag)
    {
      IntPtr currentProcess = CSControl.GetCurrentProcess();
      IntPtr phtok = IntPtr.Zero;
      CSControl.OpenProcessToken(currentProcess, 40, ref phtok);
      CSControl.TokPriv1Luid newst;
      newst.Count = 1;
      newst.Luid = 0L;
      newst.Attr = 2;
      CSControl.LookupPrivilegeValue((string) null, "SeShutdownPrivilege", ref newst.Luid);
      CSControl.AdjustTokenPrivileges(phtok, false, ref newst, 0, IntPtr.Zero, IntPtr.Zero);
      CSControl.ExitWindowsEx(flag, CSControl.ShutdownReason.MajorOther);
    }

    [Flags]
    public enum ExitWindows : uint
    {
      LogOff = 0,
      ShutDown = 1,
      Reboot = 2,
      Force = 4,
      PowerOff = 8,
      ForceIfHung = 16,
    }

    [Flags]
    private enum ShutdownReason : uint
    {
      MajorApplication = 262144,
      MajorHardware = 65536,
      MajorLegacyApi = 458752,
      MajorOperatingSystem = 131072,
      MajorOther = 0,
      MajorPower = MajorOperatingSystem | MajorApplication,
      MajorSoftware = MajorOperatingSystem | MajorHardware,
      MajorSystem = MajorHardware | MajorApplication,
      MinorBlueScreen = 15,
      MinorCordUnplugged = 11,
      MinorDisk = 7,
      MinorEnvironment = 12,
      MinorHardwareDriver = 13,
      MinorHotfix = 17,
      MinorHung = 5,
      MinorInstallation = 2,
      MinorMaintenance = 1,
      MinorMMC = 25,
      MinorNetworkConnectivity = 20,
      MinorNetworkCard = 9,
      MinorOther = 0,
      MinorOtherDriver = MinorInstallation | MinorEnvironment,
      MinorPowerSupply = 10,
      MinorProcessor = 8,
      MinorReconfig = 4,
      MinorSecurity = 19,
      MinorSecurityFix = 18,
      MinorSecurityFixUninstall = 24,
      MinorServicePack = 16,
      MinorServicePackUninstall = MinorServicePack | MinorReconfig | MinorInstallation,
      MinorTermSrv = 32,
      MinorUnstable = MinorReconfig | MinorInstallation,
      MinorUpgrade = MinorMaintenance | MinorInstallation,
      MinorWMI = MinorServicePack | MinorReconfig | MinorMaintenance,
      FlagUserDefined = 1073741824,
      FlagPlanned = 2147483648,
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    private struct TokPriv1Luid
    {
      public int Count;
      public long Luid;
      public int Attr;
    }
  }
*/
}
