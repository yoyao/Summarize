
// ControlDomainDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ControlDomain.h"
#include "ControlDomainDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CControlDomainDlg �Ի���



CControlDomainDlg::CControlDomainDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CControlDomainDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CControlDomainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CControlDomainDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_JOIN_DOMAIN, &CControlDomainDlg::OnBnClickedButtonJoinDomain)
	ON_BN_CLICKED(IDC_BUTTON_ADD_USER, &CControlDomainDlg::OnBnClickedButtonAddUser)
	ON_BN_CLICKED(IDC_BUTTON_TEST, &CControlDomainDlg::OnBnClickedButtonTest)
	ON_CBN_EDITCHANGE(IDC_COMBO1, &CControlDomainDlg::OnCbnEditchangeCombo1)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CControlDomainDlg::OnCbnSelchangeCombo1)
	ON_BN_CLICKED(IDC_BUTTON2, &CControlDomainDlg::OnBnClickedButton2)
END_MESSAGE_MAP()


// CControlDomainDlg ��Ϣ��������

BOOL CControlDomainDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ  ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO:  �ڴ����Ӷ���ĳ�ʼ������

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CControlDomainDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ  ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CControlDomainDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CControlDomainDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

//�޸�PC����
void ModifyComputerName(CString newName)
{
	//HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\ComputerName\ActiveComputerName
	HKEY hKey;
	LONG lRet = ERROR_SUCCESS;

	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\CurrentControlSet\\Control\\ComputerName"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	HKEY hSubKey;
	lRet = RegOpenKeyEx(hKey, _T("ActiveComputerName"), 0, KEY_WRITE, &hSubKey);
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hSubKey, _T("ComputerName"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hSubKey);
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hSubKey);

	lRet = RegOpenKeyEx(hKey, _T("ComputerName"), 0, KEY_WRITE, &hSubKey);
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hSubKey, _T("ComputerName"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hSubKey);
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hSubKey);
	RegCloseKey(hKey);


	//HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Tcpip\Parameters
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\CurrentControlSet\\Services\\Tcpip\\Parameters"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("Hostname"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hKey, _T("NV Hostname"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_CURRENT_USER\Volatile Environment
	lRet = RegOpenKeyEx(HKEY_CURRENT_USER, _T("Volatile Environment"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("USERDOMAIN"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	CString str(_T("\\\\"));
	str += newName;
	lRet = RegSetValueEx(hKey, _T("LOGONSERVER"), 0, REG_SZ, (BYTE*)(str.GetBuffer()), (str.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Reliability
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Reliability"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("LastComputerName"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\System\ControlSet002\Control\ComputerName\ComputerName
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\ControlSet002\\Control\\ComputerName\\ComputerName"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("ComputerName"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\System\ControlSet002\Services\Tcpip\Parameters
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\ControlSet002\\Services\\Tcpip\\Parameters"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("Hostname"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hKey, _T("NV Hostname"), 0, REG_SZ, (BYTE*)(newName.GetBuffer()), (newName.GetLength() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);
}
//�޸�DNS
void ModifyDNS(CString DnsIP)
{
	HKEY hKey;
	LONG lRet = ERROR_SUCCESS;
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\CurrentControlSet\\Control\\Class\\{4D36E972-E325-11CE-BFC1-08002BE10318}"), 0, KEY_READ, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	DWORD dwIndex = 0;
	TCHAR szSubKey[256] = { 0 };
	TCHAR szData[256] = { 0 };
	TCHAR szAapterName[256] = { 0 };
	DWORD dwBufSize = 256;
	HKEY hSubKey;
	HKEY hNdiIntKey;
	while (RegEnumKeyEx(hKey, dwIndex++, szSubKey, &dwBufSize, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
	{
		if (RegOpenKeyEx(hKey, szSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS)
		{

			if (RegOpenKeyEx(hSubKey, _T("Ndi\\Interfaces"), 0, KEY_READ, &hNdiIntKey) == ERROR_SUCCESS)
			{
				dwBufSize = 256 * sizeof(TCHAR);
				if (RegQueryValueEx(hNdiIntKey, _T("LowerRange"), 0, NULL, (BYTE*)szData, &dwBufSize) == ERROR_SUCCESS)
				{
					if (_tcscmp(szData, _T("ethernet")) == 0)
					{
						dwBufSize = 256 * sizeof(TCHAR);
						if (RegQueryValueEx(hSubKey, _T("NetCfgInstanceID"), 0, NULL, (BYTE*)szData, &dwBufSize) == ERROR_SUCCESS)
						{
							//szData�б�������������   
							_tcscpy_s(szAapterName, 256, szData);
							RegCloseKey(hNdiIntKey);
							RegCloseKey(hSubKey);
							break;
						}
					}
				}
				RegCloseKey(hNdiIntKey);
			}
			RegCloseKey(hSubKey);
		}
		dwBufSize = 256;
	}

	RegCloseKey(hKey);

	_tcscpy_s(szSubKey, 256, _T("SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\"));
	_tcscat_s(szSubKey, 256, szAapterName);
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, szSubKey, 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	RegSetValueEx(hKey, _T("NameServer"), 0, REG_SZ, (BYTE*)(DnsIP.GetBuffer()), (DnsIP.GetLength() + 1)*sizeof(TCHAR));

	RegCloseKey(hKey);
}

//������
void CControlDomainDlg::OnBnClickedButtonJoinDomain()
{
	//HANDLE hToken;
	//BOOL bRet = OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken);
	//TOKEN_PRIVILEGES tp;
	//LUID luid;
	//bRet = LookupPrivilegeValue(NULL, _T("SeTcbPrivilege"), &luid);
	//tp.PrivilegeCount = 1;
	//tp.Privileges[0].Luid = luid;
	//tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	//bRet = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), (PTOKEN_PRIVILEGES)NULL, (PDWORD)NULL);
	//TCHAR CoName[MAX_COMPUTERNAME_LENGTH] = _T("WIN");
	//BOOL bSuccess = SetComputerNameEx(ComputerNamePhysicalNetBIOS, CoName);

	ModifyComputerName(_T("ADMINTEST"));

	TCHAR Computer[64] = { 0 };
	DWORD dwSize = 64;
	GetComputerName(Computer, &dwSize);

	ModifyDNS(_T("192.168.0.121"));

	BOOL bRet = SetEnvironmentVariable(_T("COMPUTERNAME"), _T("ADMINTEST"));



	NET_API_STATUS status = NERR_Success;
	//DWORD OUCount = 0;
	//wchar_t** OUs = NULL;

	//status = NetGetJoinableOUs(NULL, _T("VIEW.DEMO"), _T("administrator@view.demo"), _T("password"), &OUCount, (LPWSTR**)&OUs);
	//for (DWORD i = 0; i < OUCount; ++i)
	//{
	//	*OUs[i];
	//}

	/*{"serverreq":{"JoinDomain":{"password":"2012.cn","domainuser":"someone@view.demo","ou":"OU=Desktop,OU=Test,DC=view,DC=demo","domainadmin":"administrator"}}}*/
	CString strServer(_T("ADMINTEST"));
	CString strDomain(_T("univew50.local"));
	CString strAccountOU(_T("OU=UVUsers,DC=univew50,DC=local"));
	CString strAccount(_T("administrator@univew50.local"));
	CString strPassword(_T("2012.cn"));
	DWORD JoinOptions = NETSETUP_JOIN_DOMAIN | NETSETUP_ACCT_CREATE;

	status = NetJoinDomain(strServer, strDomain, strAccountOU, strAccount, strPassword, JoinOptions);
	wchar_t ss[64] = { 0 };
	wsprintfW(ss, L"%d", status);
	MessageBox(NULL, ss,  MB_OK);

	//status = NetUnjoinDomain(NULL, strAccount, strPassword, NETSETUP_ACCT_DELETE);
}


void CControlDomainDlg::OnBnClickedButtonAddUser()
{
	NET_API_STATUS status = NERR_Success;

	LOCALGROUP_MEMBERS_INFO_3 pmem3 = { 0 };
	DWORD dwSize = _tcslen(_T("VIEW\\esage")) + 1;

	pmem3.lgrmi3_domainandname = new TCHAR[dwSize];
	_tcscpy_s(pmem3.lgrmi3_domainandname, dwSize, _T("VIEW\\esage"));

	dwSize = 1;
	status = NetLocalGroupSetMembers(NULL, _T("Remote Desktop Users"), 3, (BYTE*)&pmem3, dwSize);
}


void OnBnClickedButtonReboot()
{
	//HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon
	HKEY hKey;
	LONG lRet = ERROR_SUCCESS;
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	TCHAR Buffer[64] = { 0 };
	DWORD dwSize = 64;
	dwSize = GetEnvironmentVariable(_T("USERNAME"), Buffer, dwSize);


	DWORD data = 1;
	lRet = RegSetValueEx(hKey, _T("AutoAdminLogon"), 0, REG_DWORD, (BYTE*)&data, sizeof(data));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hKey, _T("DefaultUserName"), 0, REG_SZ, (BYTE*)Buffer, (dwSize + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	dwSize = 64;
	dwSize = GetEnvironmentVariable(_T("USERDOMAIN"), Buffer, dwSize);

	lRet = RegSetValueEx(hKey, _T("DefaultDomainName"), 0, REG_SZ, (BYTE*)Buffer, (dwSize + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hKey);


	HANDLE hToken;
	BOOL bRet = OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken);
	TOKEN_PRIVILEGES tp;
	LUID luid;
	bRet = LookupPrivilegeValue(NULL, _T("SeShutdownPrivilege"), &luid);
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	bRet = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), (PTOKEN_PRIVILEGES)NULL, (PDWORD)NULL);

	InitiateSystemShutdown(NULL, NULL, 0, TRUE, TRUE);
}

void CControlDomainDlg::OnBnClickedButtonTest()
{
	//sysprep|View|210|762RK-C976M-YGT26-C6JP6-VXTW8|View User|View|*|,9,10,||||admin|abc123 ,   r e t = 8 7 ,   t r u e s i z e = 1 6 ,   s i z e o f ( s o c k a d d r _ i n ) = 1 6 
	char message[] = "1sysprep|View|210|762RK-C976M-YGT26-C6JP6-VXTW8|View User|View|*|,9,10,||||admin|abc123";

	char* pFind = strstr(&message[1], "sysprep|");




}


void CControlDomainDlg::OnCbnEditchangeCombo1()
{
	// TODO: Add your control notification handler code here

}


void CControlDomainDlg::OnCbnSelchangeCombo1()
{
	// TODO: Add your control notification handler code here
}


void CControlDomainDlg::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	CString str1 = L"aa1";
	CString str2 = L"aa";
	if (str1.Compare(str2) == 0)
	{
		AfxMessageBox(L"equl");
	}
	else
	{
		AfxMessageBox(L"not equl");
	}
}
