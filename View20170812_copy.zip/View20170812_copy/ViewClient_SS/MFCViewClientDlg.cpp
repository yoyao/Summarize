
// MFCViewClientDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCViewClient.h"
#include "MFCViewClientDlg.h"
#include "afxdialogex.h"
#include "UserInfoWeb.h"
#include "resource.h"


#define IDT_TIMER_AUTOLOGIN		20

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#ifdef WIN32

#endif


SIZE clientRect[11] =
{
	{ 0, 0 }, { 640, 480 }, { 800, 600 }, { 1024, 768 }, { 1280, 720 }, { 1280, 768 }, { 1366, 768 }, { 1440, 900 }, { 1600, 900 }, { 1680,1050 },{1920,1080}
};


Desktop CMFCViewClientDlg::m_desktop;

// CMFCViewClientDlg �Ի���
CMFCViewClientDlg::CMFCViewClientDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMFCViewClientDlg::IDD, pParent)
{
	m_pRDPDlg	= NULL;
	m_bIsLowRDP = FALSE;
	m_bShow = FALSE;
}

void CMFCViewClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_USER, m_user);
	DDX_Control(pDX, IDC_EDIT_PASSWORD, m_password);
	DDX_Control(pDX, IDC_EDIT_SERVERIP, m_serverip);
	DDX_Control(pDX, IDC_PICTURE_BOX, m_picturebox);
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_save);
	DDX_Control(pDX, IDC_BUTTON_CANCEL, m_cancel);
	DDX_Control(pDX, IDC_BUTTON_PBUSERINFO, m_pbuserinfo);
	DDX_Control(pDX, IDC_CHECK_PASSWORD, m_remember);
	DDX_Control(pDX, IDC_CHECK_AUTOLOGIN, m_autologin);
	DDX_Control(pDX, IDC_CHECK_FULLSCREEN, m_fullscreen);
	DDX_Control(pDX, IDC_STATIC_SERVERIP, m_labelip);
	DDX_Control(pDX, IDC_STATIC_ICON, m_icon);
	//DDX_Control(pDX, IDC_STATIC_ESAGE, m_esage);
	DDX_Control(pDX, IDC_STATIC_USER, m_labeluser);
	DDX_Control(pDX, IDC_STATIC_PASSWORD, m_labelpassword);
	DDX_Control(pDX, IDC_BUTTON_LOGIN, m_login);
	DDX_Control(pDX, IDC_STATIC_VERSION, m_staticVersion);
	DDX_Control(pDX, IDC_SCREEN_PX, m_screenpx);
}

BEGIN_MESSAGE_MAP(CMFCViewClientDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_MESSAGE(WM_HOTKEY, OnHotKey)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_CHECK_PASSWORD, &CMFCViewClientDlg::OnBnClickedCheckPassword)
	ON_BN_CLICKED(IDC_CHECK_AUTOLOGIN, &CMFCViewClientDlg::OnBnClickedCheckAutologin)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CMFCViewClientDlg::OnBnClickedButtonSave)
	ON_BN_CLICKED(IDC_CHECK_FULLSCREEN, &CMFCViewClientDlg::OnBnClickedButtonChangePX)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CMFCViewClientDlg::OnBnClickedButtonCancel)
	ON_BN_CLICKED(IDC_BUTTON_LOGIN, &CMFCViewClientDlg::OnBnClickedButtonLogin)
	ON_BN_CLICKED(IDC_BUTTON_PBUSERINFO, &CMFCViewClientDlg::OnBnClickedButtonPbuserinfo)
	ON_CBN_SELCHANGE(IDC_SCREEN_PX, &CMFCViewClientDlg::OnCBNScreenPXChange)
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_MOVING()
END_MESSAGE_MAP()


// CMFCViewClientDlg ��Ϣ��������
void CMFCViewClientDlg::OnPaint()
{
	CDialogEx::OnPaint();
}

void CMFCViewClientDlg::OnDestroy()
{
	DlgUnRegisterHotKey();

	CDialogEx::OnDestroy();

	delete this;
}

int CMFCViewClientDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialogEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	HICON icon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	
	//���ô�ͼ��
	SetIcon(icon, TRUE);	

	//����Сͼ��
	SetIcon(icon, FALSE);	
	//SetWindowText(_T("��˼���ƿͻ���"));

	CString str;
	str.Format(IDS_STRING_ESAGE);
	SetWindowText(str);	

	SetBackgroundColor(RGB(255, 255, 255));

	return 0;
}


void CMFCViewClientDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	if (m_bShow)
	{
		m_desktop.width	 = cx;
		m_desktop.height = cy;
		LayoutPictureBox(cx, cy);
	}
}

void CMFCViewClientDlg::OnTimer(UINT_PTR nIDEvent)
{
	if (IDT_TIMER_AUTOLOGIN == nIDEvent)
	{
		KillTimer(IDT_TIMER_AUTOLOGIN);
		DlgAutoLogin();
	}

	CDialogEx::OnTimer(nIDEvent);
}


BOOL CMFCViewClientDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->wParam == VK_RETURN)
	{
		HWND hWnd = ::GetFocus();
		int ID = ::GetDlgCtrlID(hWnd);
		if (IDC_EDIT_USER == ID)
		{
			CString sText;
			m_user.GetWindowText(sText);
			if (!(sText.IsEmpty()))
			{
				m_password.SetFocus();
			}
			return TRUE;
		}
		else if (IDC_EDIT_PASSWORD == ID)
		{
			CString sText;
			CString sPwd;
			m_user.GetWindowText(sText);
			m_password.GetWindowText(sPwd);
			if (!(sText.IsEmpty()) && !(sPwd.IsEmpty()))
			{
				OnBnClickedButtonLogin();
			}
			return TRUE;
		}
		else if (IDC_CHECK_PASSWORD == ID)
			return TRUE;
		else if (IDC_CHECK_AUTOLOGIN == ID)
			return TRUE;
		else if (IDC_EDIT_SERVERIP == ID)
			return TRUE;
		else if (IDC_CHECK_FULLSCREEN == ID)
			return TRUE;
		else if (IDC_SCREEN_PX == ID)
			return TRUE;

		
	}
	else if (pMsg->wParam == VK_ESCAPE)
	{
		return TRUE;
	}

	//����ϵͳ����
	if (pMsg->message == WM_KEYDOWN)
	if (pMsg->wParam == VK_ESCAPE )    //���λس���ESC  
		return TRUE;
	if (pMsg->message == WM_SYSKEYDOWN && pMsg->wParam == VK_F4)  //����ALT+F4
	{
		AfxMessageBox(L"enter Alt+F4");
		return TRUE;
	}

	if (pMsg->message == WM_SYSKEYDOWN && pMsg->wParam == VK_F4)  //����ALT+F4
	{
		AfxMessageBox(L"enter Alt+F4");
		return TRUE;
	}

	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == MOD_ALT)  //����ALT
	{
		AfxMessageBox(L"enter Alt");
		return TRUE;
	}
	//if (pMsg->wParam == MOD_ALT)  //����ALT
	//{
	//	AfxMessageBox(L"enter Alt");
	//	return TRUE;
	//}

	return CDialogEx::PreTranslateMessage(pMsg);
}

LRESULT CMFCViewClientDlg::OnHotKey(WPARAM wPARAM, LPARAM lPARAM)
{
	switch (wPARAM)
	{
	case IDOK:
		OnHotKeyOK();
		break;
	case ID_IPADDRESS:
		OnShowIPAddress();
		break;
	default:
		break;
	}
	return 0;
}

void CMFCViewClientDlg::OnHotKeyOK()
{
	::PostQuitMessage(0);
	//if (m_pRDPDlg != NULL)
	//	m_pRDPDlg->Destroy();

	//CDialogEx::OnOK();
	//DestroyWindow();
}

void CMFCViewClientDlg::ShowLoginView()
{
	m_serverip.ShowWindow(SW_HIDE);
	m_labelip.ShowWindow(SW_HIDE);
	m_save.ShowWindow(SW_HIDE);
	m_cancel.ShowWindow(SW_HIDE);

	m_user.ShowWindow(SW_SHOW);
	m_password.ShowWindow(SW_SHOW);
	m_remember.ShowWindow(SW_SHOW);
	m_autologin.ShowWindow(SW_SHOW);
	m_pbuserinfo.ShowWindow(SW_SHOW);
	m_labeluser.ShowWindow(SW_SHOW);
	m_labelpassword.ShowWindow(SW_SHOW);
	m_login.ShowWindow(SW_SHOW);
	m_fullscreen.ShowWindow(SW_SHOW);
	m_screenpx.ShowWindow(SW_SHOW);

	//����ʾ�����ֱ���
//	m_fullscreen.ShowWindow(SW_HIDE);
//	m_screenpx.ShowWindow(SW_HIDE);
}
void CMFCViewClientDlg::ShowConfigView()
{
	m_user.ShowWindow(SW_HIDE);
	m_password.ShowWindow(SW_HIDE);
	m_remember.ShowWindow(SW_HIDE);
	m_autologin.ShowWindow(SW_HIDE);
	m_pbuserinfo.ShowWindow(SW_HIDE);
	m_labeluser.ShowWindow(SW_HIDE);
	m_labelpassword.ShowWindow(SW_HIDE);
	m_login.ShowWindow(SW_HIDE);
	m_fullscreen.ShowWindow(SW_HIDE);
	m_screenpx.ShowWindow(SW_HIDE);

	m_serverip.ShowWindow(SW_SHOW);
	m_labelip.ShowWindow(SW_SHOW);
	m_save.ShowWindow(SW_SHOW);
	m_cancel.ShowWindow(SW_SHOW);
}
void CMFCViewClientDlg::OnShowIPAddress()
{
	ShowConfigView();
}

BOOL CMFCViewClientDlg::DlgInit()
{
	if (!DlgRegisterHotKey())
		return FALSE;

	CheckRDPVersion();

	return TRUE;
}

void CMFCViewClientDlg::DlgShow()
{
	m_bShow = TRUE;

	if ((m_desktop.visual > 0) && (m_desktop.visual < 11))
	{
		int client_cx = clientRect[m_desktop.visual].cx;
		int client_cy = clientRect[m_desktop.visual].cy;

		int w = client_cx + GetSystemMetrics(SM_CXFRAME);
		int h = client_cy + GetSystemMetrics(SM_CYFRAME);

		CRect rect(0, 0, w, h);
		CalcWindowRect(&rect);

		ModifyStyle(WS_THICKFRAME | WS_MAXIMIZEBOX, 0);
		CMenu *pMenu = this->GetSystemMenu(FALSE);
		if (pMenu != NULL)
		{
			//�ر� ��ť
			pMenu->EnableMenuItem(SC_CLOSE, MF_DISABLED);
			pMenu->EnableMenuItem(SC_RESTORE, MF_DISABLED);
		}
		
		int screencx = GetSystemMetrics(SM_CXFULLSCREEN);
		int	screency = GetSystemMetrics(SM_CYFULLSCREEN);

		int x = (screencx - rect.Width()) / 2;
		int y = (screency - rect.Height()) / 2;

		SetWindowPos(NULL, x, y, rect.Width(), rect.Height(), SWP_SHOWWINDOW);
		ShowWindow(SW_SHOW);
	}
	else
	{	//ȫ��ģʽ
		ModifyStyle(WS_CAPTION, 0);
		ModifyStyleEx(WS_EX_DLGMODALFRAME, 0); 
		ModifyStyle(WS_SYSMENU, 0);
		ShowWindow(SW_MAXIMIZE);
	}	
}

void CMFCViewClientDlg::DlgStartTimer()
{
	SetTimer(IDT_TIMER_AUTOLOGIN, 300, NULL);
}

void CMFCViewClientDlg::CheckRDPVersion()
{
	HMODULE hLib = LoadLibrary(_T("C:\\Windows\\System32\\mstscax.dll"));
	if (NULL == hLib)
		return;

	typedef int	(*DLLGETTSCCTLVER)();

	DLLGETTSCCTLVER DllGetTscCtlVer;
	DllGetTscCtlVer = (DLLGETTSCCTLVER)GetProcAddress(hLib, "DllGetTscCtlVer");
	if (DllGetTscCtlVer == NULL)
	{
		FreeLibrary(hLib);
		hLib = NULL;
		return;
	}

	//if (DllGetTscCtlVer() < 0x6032580)
	//{
	//	m_bIsLowRDP = TRUE;
	//}

	FreeLibrary(hLib);
	hLib = NULL;
}

void CMFCViewClientDlg::EnableStartup()
{
	HKEY hKey;
	LONG lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"), 0, KEY_WRITE, &hKey);
	if (lRet == ERROR_SUCCESS)
	{
		TCHAR FileName[MAX_PATH] = { 0 };
		DWORD dwRet = GetModuleFileName(NULL, FileName, MAX_PATH)+1;
		lRet = RegSetValueEx(hKey, _T("eSage"), 0, REG_SZ, (BYTE *)FileName, dwRet*sizeof(TCHAR));
		RegCloseKey(hKey);
	}
}

void CMFCViewClientDlg::DisableStartup()
{
	HKEY hKey;
	LONG lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"), 0, KEY_WRITE, &hKey);
	if (lRet == ERROR_SUCCESS)
	{
		lRet = RegDeleteValue(hKey, _T("eSage"));
		RegCloseKey(hKey);
	}
}

BOOL CMFCViewClientDlg::DlgRegisterHotKey()
{
	::RegisterHotKey(GetSafeHwnd(), IDOK, MOD_CONTROL, 'D');			//�˳�����
	::RegisterHotKey(GetSafeHwnd(), ID_IPADDRESS, MOD_CONTROL, 'A');	//��ʾIP��ַ����

	//::RegisterHotKey(GetSafeHwnd(), 300, MOD_SHIFT, VK_F1);  //F1
	//::RegisterHotKey(GetSafeHwnd(), 301, MOD_CONTROL, VK_F1);  //F1
	//::RegisterHotKey(GetSafeHwnd(), ID_IPADDRESS, MOD_ALT, VK_TAB);  //ALT + TAB
	//::RegisterHotKey(GetSafeHwnd(), ID_IPADDRESS, MOD_CONTROL, VK_F4);  //ALT + F4
//	::RegisterHotKey(GetSafeHwnd(), 100, MOD_SHIFT, VK_F1);  //F1

		//None = 0,
		//Alt = 1,
		//Ctrl = 2,
		//Shift = 4,
		//WindowsKey = 8,
	//public void RegistHotKey()
	//{
	//	HotKey.RegisterHotKey(this.Handle, 100, HotKey.KeyModifiers.Shift, Keys.F1);
	//	HotKey.RegisterHotKey(this.Handle, 101, HotKey.KeyModifiers.Ctrl, Keys.D);
	//	HotKey.RegisterHotKey(this.Handle, 102, HotKey.KeyModifiers.Ctrl, Keys.F1);
	//	HotKey.RegisterHotKey(this.Handle, 103, HotKey.KeyModifiers.Alt, Keys.Tab);
	//	HotKey.RegisterHotKey(this.Handle, 104, HotKey.KeyModifiers.Alt, Keys.F4);
	//	HotKey.RegisterHotKey(this.Handle, 105, HotKey.KeyModifiers.Shift, Keys.F2);
	//	HotKey.RegisterHotKey(this.Handle, 106, HotKey.KeyModifiers.Ctrl, Keys.F2);
	//	HotKey.RegisterHotKey(this.Handle, 107, HotKey.KeyModifiers.Shift, Keys.K);
	//	if (!Desktop.autoLogin)
	//	{
	//		HotKey.RegisterHotKey(this.Handle, 108, HotKey.KeyModifiers.None, Keys.Return);
	//		HotKey.RegisterHotKey(this.Handle, 109, HotKey.KeyModifiers.Shift, Keys.Return);
	//	}
	//	HotKey.RegisterHotKey(this.Handle, 110, HotKey.KeyModifiers.Ctrl, Keys.E);
	//	HotKey.RegisterHotKey(this.Handle, 111, HotKey.KeyModifiers.Alt, Keys.D);
	//}

	return TRUE;
}

BOOL CMFCViewClientDlg::DlgUnRegisterHotKey()
{
	::UnregisterHotKey(GetSafeHwnd(), IDOK);
	::UnregisterHotKey(GetSafeHwnd(), ID_IPADDRESS);

	return TRUE;
}

//���ƿؼ�
void CMFCViewClientDlg::LayoutPictureBox(int nCX, int nCY)
{
	int xOffset;
	int yOffset;
	int cx;
	int cy;

	// PICTURE
	cx = 500;
	cy = 400;
	xOffset = (nCX - cx) / 2 ;
	yOffset = (nCY - cy) / 2 - 10;

	if (m_bIsLowRDP)
		m_staticVersion.ShowWindow(SW_SHOW);
	else
		m_staticVersion.ShowWindow(SW_HIDE);

	//����ʾ�����ֱ���
//	m_fullscreen.ShowWindow(SW_HIDE);
//	m_screenpx.ShowWindow(SW_HIDE);

	if (m_desktop.server.IsEmpty())
	{
		m_user.ShowWindow(SW_HIDE);
		m_password.ShowWindow(SW_HIDE);
		m_remember.ShowWindow(SW_HIDE);
		m_autologin.ShowWindow(SW_HIDE);
		m_pbuserinfo.ShowWindow(SW_HIDE);
		m_labeluser.ShowWindow(SW_HIDE);
		m_labelpassword.ShowWindow(SW_HIDE);
		m_login.ShowWindow(SW_HIDE);
		m_fullscreen.ShowWindow(SW_HIDE);
		m_screenpx.ShowWindow(SW_HIDE);
	}
	else
	{
		m_serverip.ShowWindow(SW_HIDE);
		m_labelip.ShowWindow(SW_HIDE);
		m_save.ShowWindow(SW_HIDE);
		m_cancel.ShowWindow(SW_HIDE);
		m_serverip.SetWindowText(m_desktop.server);
	}
	::MoveWindow(m_picturebox.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//ICON
	xOffset = (nCX - cx) / 2 + (cx - 80) / 2;
	yOffset += 15;
	cx = 100;
	cy = 50;
	::MoveWindow(m_icon.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	////esage
	//yOffset -= 7;
	//xOffset += 30;
	//cx = 60;
	//cy = 50;
	//::MoveWindow(m_esage.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//labeluser
	xOffset = (nCX - 500) / 2 + 110;
	yOffset += 82;
	cx = 60;
	cy = 30;
	::MoveWindow(m_labeluser.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//user
	cx = 200;
	cy = 30;
	xOffset += 65;	
	yOffset -= 2;
	::MoveWindow(m_user.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_user.SetWindowText(m_desktop.uname);
		m_user.EnableWindow(FALSE);
	}

	if (m_desktop.isRemember)
	{
		m_user.SetWindowText(m_desktop.uname);
	}

	//labelpassword
	cx = 60;
	cy = 30;
	xOffset = (nCX - 500) / 2 + 110;
	yOffset += 50;
	::MoveWindow(m_labelpassword.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//password
	cx = 200;
	cy = 30;
	xOffset += 65;
	yOffset -= 2;
	::MoveWindow(m_password.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_password.SetWindowText(m_desktop.pwd);
		m_password.EnableWindow(FALSE);
	}

	if (m_desktop.isRemember)
	{
		m_password.SetWindowText(m_desktop.pwd);
	}

	//login
	xOffset += 205;
	cx = 75;
	::MoveWindow(m_login.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	xOffset -= 205;
	if (m_desktop.isAutoLogin)
	{
		m_login.EnableWindow(FALSE);
	}

	//remember
	xOffset -= 140;
	yOffset += 60;
	//����ʾ�ֱ���
//	xOffset += 80;
	cx = 100;
	cy = 20;
	::MoveWindow(m_remember.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_remember.SetCheck(BST_CHECKED);
		m_remember.EnableWindow(FALSE);
	}

	if (m_desktop.isRemember)
	{
		m_remember.SetCheck(BST_CHECKED);
	}

	//autologin
	xOffset += 110;
	//����ʾ�ֱ���
//	xOffset += 130;
	::MoveWindow(m_autologin.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_autologin.SetCheck(BST_CHECKED);
	}

	//fullscreen
	xOffset += 120;
	::MoveWindow(m_fullscreen.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isFullScreen)
	{
		m_fullscreen.SetCheck(BST_CHECKED);
	}

	//px
	xOffset += 130;
	::MoveWindow(m_screenpx.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	//m_screenpx.SetCurSel(GetPxConfig());
	if (m_desktop.isFullScreen)
	{
		//m_screenpx.SetCheck(BST_CHECKED);
		//{ 0, 0 }, { 640, 480 }, { 800, 600 }, { 1024, 768 }, { 1280, 720 }, { 1280, 768 }, { 1366, 768 }, { 1440, 900 }, { 1600, 900 }, { 1680,1050 },{1920,1080}
	
		m_screenpx.ResetContent();
		m_screenpx.InsertString(0,L"ȫ��");
		m_screenpx.InsertString(1,L"640*480");
		m_screenpx.InsertString(2,L"800*600");
		m_screenpx.InsertString(3,L"1024*768");
		m_screenpx.InsertString(4,L"1280*720");
		m_screenpx.InsertString(5,L"1280*768");
		m_screenpx.InsertString(6, L"1366*768");
		m_screenpx.InsertString(7, L"1440*900");
		m_screenpx.InsertString(8, L"1600*900");
		m_screenpx.InsertString(9, L"1680*1050");
		m_screenpx.InsertString(10, L"1920*1080");
		m_screenpx.SetCurSel(this->m_currPX);
		m_screenpx.EnableWindow(1);
	}
	else
	{
		m_screenpx.ResetContent();
		m_screenpx.InsertString(0, L"ȫ��");
		m_screenpx.InsertString(1, L"640*480");
		m_screenpx.InsertString(2, L"800*600");
		m_screenpx.InsertString(3, L"1024*768");
		m_screenpx.InsertString(4, L"1280*720");
		m_screenpx.InsertString(5, L"1280*768");
		m_screenpx.InsertString(6, L"1366*768");
		m_screenpx.InsertString(7, L"1440*900");
		m_screenpx.InsertString(8, L"1600*900");
		m_screenpx.InsertString(9, L"1680*1050");
		m_screenpx.InsertString(10, L"1920*1080");
		m_screenpx.SetCurSel(this->m_currPX);
		m_screenpx.EnableWindow(0);
	}

	//staticVersion
	xOffset -= 140;
	yOffset += 40;
	cx = 300;
	cy = 20;
	::MoveWindow(m_staticVersion.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	m_staticVersion.SetWindowTextW(_T("RDPЭ��汾�ͣ���������8.1����"));

	//userinfo
	yOffset += 60;
	cx = 160;
	cy = 40;
	xOffset = (nCX - cx) / 2 + 10;
	::MoveWindow(m_pbuserinfo.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//labelip
	xOffset = (nCX - 500) / 2 + 100;
	yOffset = (nCY - 400) / 2 + 100;
	cx = 120;
	cy = 30;
	::MoveWindow(m_labelip.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//serverip
	yOffset += 35;
	cx = 300;
	cy = 30;
	::MoveWindow(m_serverip.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//save
	xOffset += 20;
	yOffset += 55;
	cx = 100;
	cy = 30;
	::MoveWindow(m_save.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//cancel
	xOffset += 160;
	::MoveWindow(m_cancel.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	Invalidate();
}


void CMFCViewClientDlg::OnBnClickedCheckPassword()
{
	int nCheck = m_remember.GetCheck();
	if (BST_CHECKED == nCheck)
		m_desktop.isRemember = Desktop::ISREMEMBER(true);
	else if (BST_UNCHECKED == nCheck)
		m_desktop.isRemember = Desktop::ISREMEMBER(false);
}


void CMFCViewClientDlg::OnBnClickedCheckAutologin()
{
	int nCheck = m_autologin.GetCheck();
	if (BST_CHECKED == nCheck)
	{
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(true);
		m_remember.SetCheck(BST_CHECKED);
		m_remember.EnableWindow(FALSE);
		m_user.EnableWindow(FALSE);
		m_password.EnableWindow(FALSE);
		m_login.EnableWindow(FALSE);
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(true);
		m_desktop.isRemember = Desktop::ISREMEMBER(true);
		//���ÿ�������
		EnableStartup();
		OnBnClickedButtonLogin();
	}
	else if (BST_UNCHECKED == nCheck)
	{
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(false);
		m_remember.EnableWindow(TRUE);
		m_user.EnableWindow(TRUE);
		m_password.EnableWindow(TRUE);
		m_login.EnableWindow(TRUE);
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(false);
		//ȡ����������
		DisableStartup();
	}
}
//ѡ��ֱ���
void CMFCViewClientDlg::OnBnClickedButtonChangePX()
{
	int nCheck = m_fullscreen.GetCheck();
	if (BST_CHECKED == nCheck)
		m_screenpx.EnableWindow(1);
	else if (BST_UNCHECKED == nCheck)
		m_screenpx.EnableWindow(0);
	
}
//����ֱ���
void CMFCViewClientDlg::OnCBNScreenPXChange()
{
	//::MessageBox(NULL, _T("aaaa"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
    
	if (m_screenpx.GetCurSel() != m_currPX)
	{
		//���������ļ�
		WritePxConfig();
		//�˳������½���
		this->OnDestroy();
	}
}
void CMFCViewClientDlg::OnBnClickedButtonSave()
{
	CString serverip;
	m_serverip.GetWindowText(serverip);
	m_desktop.server = Desktop::SERVER(serverip);

	//m_serverip.ShowWindow(SW_HIDE);
	//m_labelip.ShowWindow(SW_HIDE);
	//m_save.ShowWindow(SW_HIDE);
	//m_cancel.ShowWindow(SW_HIDE);

	//m_user.ShowWindow(SW_SHOW);
	//m_password.ShowWindow(SW_SHOW);
	//m_remember.ShowWindow(SW_SHOW);
	//m_autologin.ShowWindow(SW_SHOW);
	//m_pbuserinfo.ShowWindow(SW_SHOW);
	//m_labeluser.ShowWindow(SW_SHOW);
	//m_labelpassword.ShowWindow(SW_SHOW);
	//m_login.ShowWindow(SW_SHOW);
	ShowLoginView();

}


void CMFCViewClientDlg::OnBnClickedButtonCancel()
{
	//m_serverip.ShowWindow(SW_HIDE);
	//m_labelip.ShowWindow(SW_HIDE);
	//m_save.ShowWindow(SW_HIDE);
	//m_cancel.ShowWindow(SW_HIDE);

	//m_user.ShowWindow(SW_SHOW);
	//m_password.ShowWindow(SW_SHOW);
	//m_remember.ShowWindow(SW_SHOW);
	//m_autologin.ShowWindow(SW_SHOW);
	//m_pbuserinfo.ShowWindow(SW_SHOW);
	//m_labeluser.ShowWindow(SW_SHOW);
	//m_labelpassword.ShowWindow(SW_SHOW);
	//m_login.ShowWindow(SW_SHOW);
	ShowLoginView();
}

void CMFCViewClientDlg::OnBnClickedButtonPbuserinfo()
{
	if (m_bIsLowRDP)
		return;

	CString sUser(_T(""));
	CString sPassword(_T(""));
	CString sServer(_T(""));

	m_serverip.GetWindowText(sServer);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("�������������ַ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		//m_user.ShowWindow(SW_HIDE);
		//m_password.ShowWindow(SW_HIDE);
		//m_remember.ShowWindow(SW_HIDE);
		//m_autologin.ShowWindow(SW_HIDE);
		//m_pbuserinfo.ShowWindow(SW_HIDE);
		//m_labeluser.ShowWindow(SW_HIDE);
		//m_labelpassword.ShowWindow(SW_HIDE);
		//m_login.ShowWindow(SW_HIDE);
		//
		//m_serverip.ShowWindow(SW_SHOW);
		//m_labelip.ShowWindow(SW_SHOW);
		//m_save.ShowWindow(SW_SHOW);
		//m_cancel.ShowWindow(SW_SHOW);
		ShowConfigView();

		m_serverip.SetFocus();
		return;
	}

	m_user.GetWindowText(sUser);
	if (sUser.IsEmpty())
	{
		::MessageBox(NULL, _T("�������û���"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_user.SetFocus();
		return;
	}

	m_password.GetWindowText(sPassword);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("����������"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_password.SetFocus();
		return;
	}

	m_desktop.server = Desktop::SERVER(sServer);
	//univew50 domain
	//CString dUser;
	//dUser.Format(L"univew50\\%s", sUser);
	//m_desktop.uname = Desktop::UNAME(dUser);
	m_desktop.uname  = Desktop::UNAME(sUser);
	m_desktop.pwd	 = Desktop::PWD(sPassword);

	if (m_desktop.GetMyVMInfo())
	{
		CUserInfoWeb InfoWeb(this, &m_desktop);
		InfoWeb.DoModal();
	}
	else
	{
		::MessageBox(NULL, _T("�û������벻��ȷ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
	}
}

void CMFCViewClientDlg::OnBnClickedButtonLogin()
{
	if (m_bIsLowRDP)
		return;

	CString sUser(_T(""));
	CString sPassword(_T(""));
	CString sServer(_T(""));

	m_serverip.GetWindowText(sServer);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("�������������ַ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		//m_user.ShowWindow(SW_HIDE);
		//m_password.ShowWindow(SW_HIDE);
		//m_remember.ShowWindow(SW_HIDE);
		//m_autologin.ShowWindow(SW_HIDE);
		//m_pbuserinfo.ShowWindow(SW_HIDE);
		//m_labeluser.ShowWindow(SW_HIDE);
		//m_labelpassword.ShowWindow(SW_HIDE);
		//m_login.ShowWindow(SW_HIDE);

		//m_serverip.ShowWindow(SW_SHOW);
		//m_labelip.ShowWindow(SW_SHOW);
		//m_save.ShowWindow(SW_SHOW);
		//m_cancel.ShowWindow(SW_SHOW);
		ShowConfigView();

		m_serverip.SetFocus();
		return;
	}

	m_user.GetWindowText(sUser);
	if (sUser.IsEmpty())
	{
		::MessageBox(NULL, _T("�������û���"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_user.SetFocus();
		return;
	}

	m_password.GetWindowText(sPassword);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("����������"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_password.SetFocus();
		return;
	}

	m_desktop.server = Desktop::SERVER(sServer);
	//univew50 domain
	//CString dUser;
	//dUser.Format(L"univew50\\%s", sUser);
	//m_desktop.uname = Desktop::UNAME(dUser);
	m_desktop.uname = Desktop::UNAME(sUser);
	m_desktop.pwd = Desktop::PWD(sPassword);

#define TEST_PERFORMANCE	0
#if TEST_PERFORMANCE

	LARGE_INTEGER StartingTime, EndingTime, ElapsedMicroseconds;
	LARGE_INTEGER Frequency;

	QueryPerformanceFrequency(&Frequency);
	QueryPerformanceCounter(&StartingTime);
#endif

	if (!m_desktop.GetMyVMInfo())
	{
		::MessageBox(NULL, _T("�û������벻��ȷ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		return;
	}

#if TEST_PERFORMANCE
	QueryPerformanceCounter(&EndingTime);
	ElapsedMicroseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
	ElapsedMicroseconds.QuadPart *= 1000000;
	ElapsedMicroseconds.QuadPart /= Frequency.QuadPart;
#endif

	if (m_pRDPDlg == NULL)
	{
		m_pRDPDlg = new CRDPDialog(this, &m_desktop);
		if (NULL == m_pRDPDlg)
			return;

		m_pRDPDlg->Create(IDD_DIALOG_RDP, this);
	}

	ASSERT(m_pRDPDlg != NULL);
	//ȫ��
	//m_pRDPDlg->ShowWindow(SW_SHOWMAXIMIZED);
	//m_pRDPDlg->ShowWindow(SW_SHOW);

	//::SetWindowPos(m_pRDPDlg->m_hWnd, NULL, 0, 0, 600, 600, SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
	

	if ((m_desktop.visual > 0) && (m_desktop.visual < 11))
	{
		//int client_cx = clientRect[m_desktop.visual].cx;
		//int client_cy = clientRect[m_desktop.visual].cy;


		//CRect rcWindow;
		//GetWindowRect(&rcWindow);

		//int x = rcWindow.left + GetSystemMetrics(SM_CXFRAME)*2;
		//int y = rcWindow.bottom - client_cy - GetSystemMetrics(SM_CYFRAME)*2;

		//m_pRDPDlg->SetWindowPos(NULL, x, y, client_cx, client_cy, SWP_SHOWWINDOW);
		//m_pRDPDlg->ShowWindow(SW_SHOW);
		//m_desktop.width = client_cx;
		//m_desktop.height = client_cy;

		CRect rcClient;
		GetClientRect(&rcClient);
		ClientToScreen(&rcClient);
		m_pRDPDlg->SetWindowPos(NULL, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height(), SWP_SHOWWINDOW);
		m_pRDPDlg->ShowWindow(SW_SHOW);
		m_desktop.width = rcClient.Width();
		m_desktop.height = rcClient.Height();
	}
	else
	{	//ȫ��ģʽ
		m_pRDPDlg->ShowWindow(SW_MAXIMIZE);
	}
	
	//
	m_pRDPDlg->ShowRDP();

	if (!(m_desktop.isRemember))
	{
		m_user.SetWindowText(_T(""));
		m_password.SetWindowText(_T(""));
		m_user.SetFocus();
	}
}

void CMFCViewClientDlg::DlgAutoLogin()
{
	if (m_bIsLowRDP)
		return;

	if (!(m_desktop.isAutoLogin))
		return;

	if (!m_desktop.GetMyVMInfo())
	{
		::MessageBox(NULL, _T("�û������벻��ȷ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		return;
	}

	if (m_pRDPDlg == NULL)
	{
		m_pRDPDlg = new CRDPDialog(this, &m_desktop);
		if (NULL == m_pRDPDlg)
			return;

		m_pRDPDlg->Create(IDD_DIALOG_RDP, NULL);
	}

	ASSERT(m_pRDPDlg != NULL);
	//ȫ�� fullscreen
	m_pRDPDlg->ShowWindow(SW_SHOWMAXIMIZED);
	//m_pRDPDlg->ShowWindow(SW_MAXIMIZE);
	
	//for debug
//	m_pRDPDlg->ShowRDP();
}

HBRUSH CMFCViewClientDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	if (CTLCOLOR_STATIC == nCtlColor)
	{
		if (pWnd->GetDlgCtrlID() == IDC_STATIC_VERSION)
		{
			pDC->SetTextColor(RGB(255, 0, 0));
		}
	}

	return hbr;
}




void CMFCViewClientDlg::OnWindowPosChanging(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanging(lpwndpos);

	if (m_pRDPDlg != NULL)
	{
		m_pRDPDlg->OnWindowPosChanging(lpwndpos);
	}
}


void CMFCViewClientDlg::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanged(lpwndpos);

	if (m_pRDPDlg != NULL)
	{
		m_pRDPDlg->OnWindowPosChanging(lpwndpos);
	}
}


void CMFCViewClientDlg::OnMoving(UINT fwSide, LPRECT pRect)
{
	if (m_pRDPDlg != NULL)
	{
		CRect rtWnd;
		m_pRDPDlg->GetClientRect(&rtWnd);
		ClientToScreen(&rtWnd);
		::SetWindowPos(m_pRDPDlg->GetSafeHwnd(), NULL, rtWnd.left, rtWnd.top, 0, 0, SWP_SHOWWINDOW | SWP_NOSIZE);
	}
	
	
	CDialogEx::OnMoving(fwSide, pRect);

	// TODO: Add your message handler code here
}

//���ķֱ���
void CMFCViewClientDlg::WritePxConfig()
{
	TCHAR path[512] = { 0 };
	TCHAR retBuf[128] = { 0 };
	::GetModuleFileName(NULL, path, MAX_PATH);
	TCHAR* pEnd = _tcsrchr(path, L'\\');
	int i = 0;
	while (pEnd[++i] != 0)
	{
		pEnd[i] = 0;
	}
	CString m_sPath = CString(path);
	m_sPath += _T("setting.ini");
	//GetPrivateProfileString(_T("client"), _T("VisualMode"), _T("0"), retBuf, 128, (LPCWSTR)m_sPath);
	int currsel = m_screenpx.GetCurSel();
	CString temstr;
	temstr.Format(L"%d", currsel);
	WritePrivateProfileString(_T("client"), _T("VisualMode"), temstr, (LPCWSTR)m_sPath);


	//return temppx;
}

