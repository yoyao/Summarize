// RDPDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCViewClient.h"
#include "RDPDialog.h"
#include "afxdialogex.h"
#include "CMsRdpClientAdvancedSettings8.h"
#include "mstscax.h"
#include "mstscaxguid.h"
#include "resource.h"

#define IDT_TIMER_CONNECTING	10

// CRDPDialog �Ի���
IMPLEMENT_DYNAMIC(CRDPDialog, CDialogEx)

CRDPDialog::CRDPDialog(CWnd* pParent, const Desktop* pDesktop)
: CDialogEx(CRDPDialog::IDD, pParent), m_pDesktop(pDesktop)
{
	ASSERT(m_pDesktop != NULL);

	m_nCount = 1;
}

CRDPDialog::~CRDPDialog()
{
}

void CRDPDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MSTSCAX_RDP, m_mstscControl);
}


BEGIN_MESSAGE_MAP(CRDPDialog, CDialogEx)
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_WINDOWPOSCHANGING()
END_MESSAGE_MAP()

//��ʼ��
BOOL CRDPDialog::OnInitDialog()
{
	

	CDialogEx::OnInitDialog();         //ԭ��ΪCDialog::OnInitDialog()
//	AfxMessageBox(L"sssss");

	return TRUE;

}

// CRDPDialog ��Ϣ��������
void CRDPDialog::OnDestroy()
{
	CDialogEx::OnDestroy();

	delete this;
}

BEGIN_EVENTSINK_MAP(CRDPDialog, CDialogEx)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 2, CRDPDialog::OnConnectedMstscaxRdp, VTS_NONE)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 4, CRDPDialog::OnDisconnectedMstscaxRdp, VTS_I4)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 1, CRDPDialog::OnConnectingMstscaxRdp, VTS_NONE)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 15, CRDPDialog::OnConfirmCloseMstscaxRdp, VTS_PBOOL)
END_EVENTSINK_MAP()

void CRDPDialog::Destroy()
{
	CDialogEx::OnOK();

	DestroyWindow();
}

void CRDPDialog::ShowRDP()
{
	m_mstscControl.put_Server(m_pDesktop->ip);
	//�����С
	m_mstscControl.put_DesktopHeight(m_pDesktop->height);
	m_mstscControl.put_DesktopWidth(m_pDesktop->width);
	//m_mstscControl.put_FullScreen(TRUE);
	
	CMsRdpClientAdvancedSettings8 AdvancedSettings9 = CMsRdpClientAdvancedSettings8(m_mstscControl.get_AdvancedSettings9());
	AdvancedSettings9.put_EnableCredSspSupport(TRUE);
	if (m_pDesktop->isPreset)
	{
		m_mstscControl.put_UserName(m_pDesktop->preUsername);
		AdvancedSettings9.put_ClearTextPassword(m_pDesktop->prePassword);
	}
	else
	{
		m_mstscControl.put_UserName(m_pDesktop->uname);
		AdvancedSettings9.put_ClearTextPassword(m_pDesktop->pwd);
	}

	if ((m_pDesktop->domain).IsEmpty())
	{
		m_mstscControl.put_Domain(m_pDesktop->computerName);
	}
	else
	{
		m_mstscControl.put_Domain(m_pDesktop->domain);
	}

	if (m_pDesktop->port > 0)
		AdvancedSettings9.put_RDPPort(m_pDesktop->port);

	AdvancedSettings9.put_SmartSizing(TRUE);

	CString str;
	str.Format(IDS_STRING_LOGIN);
	m_mstscControl.put_ConnectingText(str);

	AdvancedSettings9.put_DisableRdpdr(0);
	AdvancedSettings9.put_RedirectClipboard(m_pDesktop->redirectClipboard);
	AdvancedSettings9.put_RedirectSmartCards(m_pDesktop->redirectSmartCards);
	AdvancedSettings9.put_RedirectPorts(m_pDesktop->redirectPorts);
	AdvancedSettings9.put_RedirectPrinters(m_pDesktop->redirectPrinters);
	AdvancedSettings9.put_AudioCaptureRedirectionMode(TRUE);
	AdvancedSettings9.put_GrabFocusOnConnect(TRUE);
	AdvancedSettings9.put_EnableWindowsKey(1);
	AdvancedSettings9.put_DisableCtrlAltDel(1);
	AdvancedSettings9.put_BitmapPeristence(1);
	AdvancedSettings9.put_Compress(1);
	

	AdvancedSettings9.put_allowBackgroundInput(0);
	AdvancedSettings9.put_EnableAutoReconnect(TRUE);
	AdvancedSettings9.put_AcceleratorPassthrough(1);
	AdvancedSettings9.put_DoubleClickDetect(1);
	AdvancedSettings9.put_RedirectDevices(m_pDesktop->redirectDevices);
	AdvancedSettings9.put_RedirectDrives(m_pDesktop->redirectDrives);



	TCHAR  SysDisk[64] = { 0 };
	if (m_pDesktop->redirectDrives)
	{
		GetSystemDirectory(SysDisk, 64);
	}

	LPUNKNOWN	lpUnknown = m_mstscControl.GetControlUnknown();
	ASSERT(lpUnknown != NULL);
	if (lpUnknown != NULL)
	{
		IMsRdpClient8* pClient8 = NULL;
		HRESULT result = S_FALSE;

		result = lpUnknown->QueryInterface(IID_IMsRdpClient8, (void**)&pClient8);
		if (SUCCEEDED(result))
		{
			IMsRdpClientNonScriptable5* pNon5 = NULL;
			result = pClient8->QueryInterface(IID_IMsRdpClientNonScriptable5, (void**)&pNon5);
			if (SUCCEEDED(result))
			{
				pNon5->put_DisableConnectionBar(VARIANT_TRUE);
				//2017-08-12�� ������̬���̺��豸�ض���
				pNon5->put_RedirectDynamicDevices(VARIANT_TRUE);
				pNon5->put_RedirectDynamicDrives(VARIANT_TRUE);

				IMsRdpDriveCollection* pDriveCollection = NULL;
				result = pNon5->get_DriveCollection(&pDriveCollection);
				if (SUCCEEDED(result))
				{
					unsigned long nDriveCount = 0;
					result = pDriveCollection->get_DriveCount(&nDriveCount);
					if (SUCCEEDED(result))
					{
						IMsRdpDrive* pRdpDrive = NULL;
						for (int i = 0; i < nDriveCount; i++)
						{
							result = pDriveCollection->get_DriveByIndex(i, &pRdpDrive);
							if (SUCCEEDED(result))
							{
								BSTR DriveName = ::SysAllocString(L"");
								result = pRdpDrive->get_Name(&DriveName);
								if (SUCCEEDED(result))
								{
									pRdpDrive->put_RedirectionState(VARIANT_TRUE);

									UINT len = ::SysStringLen(DriveName);
									TCHAR* sz = new TCHAR[len + 1];
									_tcsncpy(sz, DriveName, len);
									if (sz[0] == SysDisk[0])
									{
										//�Ƿ��ض���ϵͳ��
										if (GetRedirectSysDisk() != 1)
										{
											pRdpDrive->put_RedirectionState(VARIANT_FALSE);
										}
									}
									delete[] sz;
									sz = NULL;
								}
								::SysFreeString(DriveName);
							}
						}
					}
					pDriveCollection->Release();
				}


				IMsRdpDeviceCollection* pDeviceCollection = NULL;
				result = pNon5->get_DeviceCollection(&pDeviceCollection);
				if (SUCCEEDED(result))
				{
					IMsRdpDeviceCollection2* pDeviceCollection2 = NULL;
					result = pDeviceCollection->QueryInterface(IID_IMsRdpDeviceCollection2, (void**)&pDeviceCollection2);
					if (SUCCEEDED(result))
					{
						unsigned long nDeviceCount = 0;
						result = pDeviceCollection2->get_DeviceCount(&nDeviceCount);
						if (SUCCEEDED(result))
						{
							IMsRdpDevice* pRdpDevice = NULL;
							for (int i = 0; i < nDeviceCount; i++)
							{
								result = pDeviceCollection2->get_DeviceByIndex(i, &pRdpDevice);
								if (SUCCEEDED(result))
								{
									BSTR DeviceInstanceId = SysAllocString(L"");
									IMsRdpDeviceV2* pRdpDeviceV2 = NULL;
									result = pRdpDevice->QueryInterface(IID_IMsRdpDeviceV2, (void**)&pRdpDeviceV2);
									if (SUCCEEDED(result))
									{
										result = pRdpDeviceV2->put_RedirectionState(VARIANT_TRUE);
										result = pRdpDeviceV2->get_DeviceInstanceId(&DeviceInstanceId);
										result = pDeviceCollection2->raw_AddDeviceByInstanceId(UsbDevice, DeviceInstanceId);
										pRdpDeviceV2->Release();
									}
									SysFreeString(DeviceInstanceId);
									pRdpDevice->Release();
								}
							}
						}
						result = pDeviceCollection2->raw_RedirectNow(UsbDevice);
						pDeviceCollection2->Release();
					}
					pDeviceCollection->Release();
				}
				pNon5->Release();
			}
			pClient8->Release();
		}
	}
	m_mstscControl.Connect();
}


void CRDPDialog::OnConnectedMstscaxRdp()
{
	KillTimer(IDT_TIMER_CONNECTING);
}

void CRDPDialog::OnDisconnectedMstscaxRdp(long discReason)
{
	ShowWindow(SW_HIDE);
}

void CRDPDialog::OnConnectingMstscaxRdp()
{
	SetTimer(IDT_TIMER_CONNECTING, 600, NULL);
}

void CRDPDialog::OnConfirmCloseMstscaxRdp(BOOL* pfAllowClose)
{
	ShowWindow(SW_HIDE);
}


void CRDPDialog::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	::MoveWindow(m_mstscControl.GetSafeHwnd(), 0, 0, cx, cy, FALSE);
	Invalidate();
}

CString strLoading[6] =
{
	_T("."),
	_T(".."),
	_T("..."),
	_T("...."),
	_T("....."),
	_T("......")
};

void CRDPDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch (nIDEvent)
	{
	case IDT_TIMER_CONNECTING:
		{
			m_nCount %= 6;
			CString str1;
			str1.Format(IDS_STRING_LOGIN);
			//CString str = _T("��ӭʹ����˼��������,���ڵ�½") + strLoading[m_nCount];
			CString str = str1 + strLoading[m_nCount];
			m_mstscControl.put_ConnectingText(str);
			m_nCount++;
		}
		break;
	default:
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}

void CRDPDialog::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanged(lpwndpos);

	// TODO: Add your message handler code here
}


void CRDPDialog::OnWindowPosChanging(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanging(lpwndpos);

	// TODO: Add your message handler code here
}

int CRDPDialog::GetRedirectSysDisk()
{
	TCHAR path[512] = { 0 };
	TCHAR retBuf[128] = { 0 };
	::GetModuleFileName(NULL, path, MAX_PATH);
	TCHAR* pEnd = _tcsrchr(path, L'\\');
	int i = 0;
	while (pEnd[++i] != 0)
	{
		pEnd[i] = 0;
	}
	CString m_sPath = CString(path);
	m_sPath += _T("setting.ini");
	//GetPrivateProfileString(_T("client"), _T("VisualMode"), _T("0"), retBuf, 128, (LPCWSTR)m_sPath);
	int temppx = GetPrivateProfileInt(_T("client"), _T("redirectsysdisk"), 0, (LPCWSTR)m_sPath);


	return temppx;
}

//2017-08-12
LRESULT CRDPDialog::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	//�豸���֪ͨԶ������
	if (WM_DEVICECHANGE == message)
	{
		LPUNKNOWN	lpUnknown = m_mstscControl.GetControlUnknown();
		ASSERT(lpUnknown != NULL);
		if (lpUnknown != NULL)
		{
			IMsRdpClient8* pClient8 = NULL;
			HRESULT result = S_FALSE;

			result = lpUnknown->QueryInterface(IID_IMsRdpClient8, (void**)&pClient8);
			if (SUCCEEDED(result))
			{
				IMsRdpClientNonScriptable5* pNon5 = NULL;
				result = pClient8->QueryInterface(IID_IMsRdpClientNonScriptable5, (void**)&pNon5);
				if (SUCCEEDED(result))
				{
					pNon5->raw_NotifyRedirectDeviceChange(wParam, lParam);
					pNon5->Release();
				}
				pClient8->Release();
			}
		}
	}

	return CDialogEx::WindowProc(message, wParam, lParam);
}
