// UserInfoWeb.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCViewClient.h"
#include "UserInfoWeb.h"
#include "afxdialogex.h"
#include "Crypt.h"


// CUserInfoWeb �Ի���

IMPLEMENT_DYNAMIC(CUserInfoWeb, CDialogEx)

CUserInfoWeb::CUserInfoWeb(CWnd* pParent, const Desktop* pDesktop)
: CDialogEx(CUserInfoWeb::IDD, pParent), m_pDesktop(pDesktop)
{
	ASSERT(m_pDesktop != NULL);
}

CUserInfoWeb::~CUserInfoWeb()
{
}

void CUserInfoWeb::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CUserInfoWeb, CDialogEx)
	ON_WM_CREATE()
	ON_WM_SYSCOMMAND()
END_MESSAGE_MAP()

BEGIN_EVENTSINK_MAP(CUserInfoWeb, CDialogEx)
	ON_EVENT(CUserInfoWeb, IDC_USERINFO_WEB, 253, OnQuit, VTS_NONE)
	ON_EVENT(CUserInfoWeb, IDC_USERINFO_WEB, 263, WindowClosing, VTS_BOOL VTS_PBOOL)
	ON_EVENT(CUserInfoWeb, IDC_USERINFO_WEB, 259, OnDocumentComplete, VTS_DISPATCH VTS_PVARIANT)
	ON_EVENT(CUserInfoWeb, IDC_USERINFO_WEB, 252, NavigateComplete2, VTS_DISPATCH VTS_PVARIANT)
END_EVENTSINK_MAP()


void CUserInfoWeb::OnQuit()
{
	// TODO:  �ڴ˴�������Ϣ�����������
}


void CUserInfoWeb::WindowClosing(BOOL IsChildWindow, BOOL* Cancel)
{
	CDialogEx::OnOK();
}



// CUserInfoWeb ��Ϣ��������
int CUserInfoWeb::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialogEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rect;
	GetClientRect(&rect);

	if (!(m_browser.Create(_T("UserInfo"), _T("esageDesktop"), WS_CHILD|WS_VISIBLE, rect, this, IDC_USERINFO_WEB)))
	{
		return -1;
	}

	return 0;
}


BOOL CUserInfoWeb::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	//����OLE�Զ���  
//	EnableAutomation();

	//�����¼��ӿ�  
//	DWORD dwCookie;
//	LPUNKNOWN pUnkSink = GetIDispatch(FALSE);
//	AfxConnectionAdvise((LPUNKNOWN)m_browser.get_Application(), DIID_DWebBrowserEvents2, pUnkSink, FALSE, &dwCookie);


	CString str(_T("http://"));
	str += m_pDesktop->server;
	str += _T(":8080/admin.do?");
	str += _T("parm=login&t=2&username=");
	str += m_pDesktop->uname;
	str += _T("&password=");
	str += MyGetSHA(m_pDesktop->pwd);

	m_browser.EnableScrollBar(SB_BOTH, ESB_DISABLE_BOTH);
	m_browser.put_MenuBar(FALSE);
	m_browser.Navigate(str, NULL, NULL, NULL, NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣:  OCX ����ҳӦ���� FALSE
}


void CUserInfoWeb::OnSysCommand(UINT nID, LPARAM lParam)
{
	if (nID == SC_MOVE || nID == 0xF012)
		return;

	CDialogEx::OnSysCommand(nID, lParam);
}

void CUserInfoWeb::FormClose()
{
	CDialogEx::OnOK();
}



void CUserInfoWeb::OnDocumentComplete(LPDISPATCH pDisp, VARIANT FAR* URL)
{
	// TODO:  �ڴ˴�������Ϣ�����������
}

void CUserInfoWeb::NavigateComplete2(LPDISPATCH pDisp, VARIANT* URL)
{
	
	TCHAR* pStr = _tcsstr(URL->bstrVal, _T("login.do"));
	if (pStr != NULL)
	{
		CDialogEx::OnOK();
		return;
	}	
	
	// TODO: Add your control notification handler code here

	// ���� ������

	HRESULT hr = NULL;
	IHTMLElement *pHTMLElement = NULL;
	IHTMLBodyElement *pHTMLBody = NULL;
	IHTMLDocument2* pDocument = NULL;
	

	pDocument = (IHTMLDocument2*)m_browser.get_Document();
	if (!pDocument) goto EXIT;
	hr = pDocument->get_body(&pHTMLElement);
	if (!pHTMLElement) goto EXIT;
	if (FAILED(hr)) goto EXIT;
	hr = pHTMLElement->QueryInterface(IID_IHTMLBodyElement, (void**)&pHTMLBody);
	if (!pHTMLBody) goto EXIT;
	if (FAILED(hr)) goto EXIT;

	hr = pHTMLBody->put_scroll(L"no");
EXIT:
	if (pHTMLElement) pHTMLElement->Release();
	if (pHTMLBody) pHTMLBody->Release();
	if (pDocument) pDocument->Release();

	// ���� ����������
	m_browser.SetWindowText(_T(""));
	// ������ʾ��web�ؼ�
	CRect rc;
	GetClientRect(&rc);
	if (GetDlgItem(IDC_USERINFO_WEB) && GetDlgItem(IDC_USERINFO_WEB)->GetSafeHwnd())
	{
		GetDlgItem(IDC_USERINFO_WEB)->MoveWindow(rc.left, rc.top, rc.Width(), rc.Height());
	}
}