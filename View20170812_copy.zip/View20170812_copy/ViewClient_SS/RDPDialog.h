#pragma once
#include "mstscaxrdp.h"
#include "Desktop.h"


// CRDPDialog �Ի���

class CRDPDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CRDPDialog)

public:
	CRDPDialog(CWnd* pParent, const Desktop* pDesktop);   // ��׼���캯��
	virtual ~CRDPDialog();

// �Ի�������
	enum { IDD = IDD_DIALOG_RDP };

	void ShowRDP();
	void Destroy();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
private:
	CMstscaxRDP		m_mstscControl;
	const Desktop*		m_pDesktop;
	int						m_nCount;
	int GetRedirectSysDisk();

public:
	afx_msg void OnDestroy();
	DECLARE_EVENTSINK_MAP()
	void OnConnectedMstscaxRdp();
	void OnDisconnectedMstscaxRdp(long discReason);
	void OnConnectingMstscaxRdp();
	void OnConfirmCloseMstscaxRdp(BOOL* pfAllowClose);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL OnInitDialog();

public:
	afx_msg void OnWindowPosChanged(WINDOWPOS* lpwndpos);
	afx_msg void OnWindowPosChanging(WINDOWPOS* lpwndpos);
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
};
