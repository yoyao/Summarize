
// MFCViewClientDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include "Desktop.h"
#include "RDPDialog.h"
#include "MyButton.h"
#include "WebBrowser2.h"
#include "mstscaxrdp.h"

#define ID_IPADDRESS	(WM_USER+1)


// CMFCViewClientDlg �Ի���
class CMFCViewClientDlg : public CDialogEx
{
// ����
public:
	CMFCViewClientDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_MFCVIEWCLIENT_DIALOG };




	BOOL	DlgInit();
	void DlgStart();
	void DlgShow();
	void	DlgAutoLogin();
	void	DlgStartTimer();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��
	virtual BOOL PreTranslateMessage(MSG* pMsg);

// ʵ��
protected:
	// ���ɵ���Ϣӳ�亯��
	afx_msg void OnPaint();
	afx_msg LRESULT OnHotKey(WPARAM wPARAM, LPARAM lPARAM);
	DECLARE_MESSAGE_MAP()


	BOOL	DlgRegisterHotKey();
	BOOL	DlgUnRegisterHotKey();
	void	LayoutPictureBox(int nCX, int nCY);
	void	CheckRDPVersion();
	void	EnableStartup();
	void	DisableStartup();

	void	OnHotKeyOK();
	void	OnShowIPAddress();

	static Desktop	m_desktop;
	BOOL	m_bIsLowRDP;
	BOOL  m_bShow;
	CEdit	m_user;
	CEdit	m_password;
	CEdit	m_serverip;
	CButton m_save;
	CButton m_cancel;
	CMyButton m_pbuserinfo;
	CButton m_remember;
	CButton m_autologin;
	CButton m_fullscreen;
	CComboBox m_screenpx;
	CMyButton m_login;
	CStatic m_labelip;
	CStatic m_icon;
//	CStatic m_esage;
	CStatic m_picturebox;
	CStatic m_labeluser;
	CStatic m_labelpassword;
	CStatic m_staticVersion;

	CRDPDialog*	m_pRDPDlg;

public:
	int m_currPX;

public:
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBnClickedCheckPassword();
	afx_msg void OnBnClickedCheckAutologin();
	afx_msg void OnBnClickedButtonSave();
	afx_msg void OnBnClickedButtonCancel();
	afx_msg void OnBnClickedButtonLogin();
	afx_msg void OnBnClickedButtonPbuserinfo();
	afx_msg void OnBnClickedButtonChangePX();
	afx_msg void OnCBNScreenPXChange();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnWindowPosChanging(WINDOWPOS* lpwndpos);
	afx_msg void OnWindowPosChanged(WINDOWPOS* lpwndpos);
	afx_msg void OnMoving(UINT fwSide, LPRECT pRect);

private:
	void ShowLoginView();
	void ShowConfigView();
	void WritePxConfig();
};
