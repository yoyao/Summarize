#pragma once
#include "WebBrowser2.h"
#include "Desktop.h"

// CUserInfoWeb �Ի���

class CUserInfoWeb : public CDialogEx
{
	DECLARE_DYNAMIC(CUserInfoWeb)

public:
	CUserInfoWeb(CWnd* pParent, const Desktop* pDesktop);   // ��׼���캯��
	virtual ~CUserInfoWeb();

// �Ի�������
	enum { IDD = IDD_DIALOG_USERWEB };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()


private:
	CWebBrowser2	m_browser;
	const Desktop*	m_pDesktop;
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);

	DECLARE_EVENTSINK_MAP()
	void OnQuit();
	void WindowClosing(BOOL IsChildWindow, BOOL* Cancel);
	void OnDocumentComplete(LPDISPATCH pDisp, VARIANT FAR* URL);
	void NavigateComplete2(LPDISPATCH pDisp, VARIANT* URL);
	void FormClose();
};
