﻿
using System;
using System.Diagnostics;
using System.IO;
using System.Net;

namespace WebInstall
{
  internal class Common
  {
    public static void CheckLog(string Log, string LogFile)
    {
      Common.WriteLog(Log, LogFile);
    }

    private static void WriteLog(string Log, string LogFile)
    {
      if (!System.IO.File.Exists(LogFile))
        System.IO.File.Create(LogFile).Close();
      FileStream fileStream = (FileStream) null;
      StreamWriter streamWriter = (StreamWriter) null;
      try
      {
        fileStream = new FileStream(LogFile, FileMode.Create);
        streamWriter = new StreamWriter((Stream) fileStream);
        streamWriter.WriteLine(Log);
        streamWriter.Flush();
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "写入文件报错：\r\n\r\n " + ex.ToString());
      }
      finally
      {
        if (streamWriter != null)
          streamWriter.Close();
        if (fileStream != null)
          fileStream.Close();
      }
    }

    public static string ReadLog(string LogFile)
    {
      string str1 = "";
      try
      {
        using (StreamReader streamReader = new StreamReader(LogFile))
        {
          for (string str2 = streamReader.ReadLine(); str2 != null; str2 = streamReader.ReadLine())
            str1 = str1 + str2 + "\r\n";
        }
      }
      catch (Exception ex)
      {
        EventLog.WriteEntry("ViewServer", "读取配置文件出错：\r\n\r\n " + ex.ToString());
      }
      return str1;
    }

    public static string GetIP()
    {
     // IPAddress[] addressList = Dns.GetHostByName(Dns.GetHostName()).AddressList;
      IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
      string str = (string) null;
      for (int index = 0; index < addressList.Length; ++index)
      {
        if (addressList[index].ToString().IndexOf(".") > -1)
          str = addressList[index].ToString();
      }
      return str;
    }

    public static void RunCmd(string path)
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = path,
        WindowStyle = ProcessWindowStyle.Hidden,
        ErrorDialog = false,
        CreateNoWindow = true
      });
    }

    public static string GetCmdOutString(string path, string arguments)
    {
      ProcessStartInfo startInfo = new ProcessStartInfo();
      startInfo.FileName = path;
      startInfo.UseShellExecute = true;
      startInfo.Arguments = arguments;
      startInfo.CreateNoWindow = false;
      startInfo.RedirectStandardOutput = true;
      startInfo.UseShellExecute = false;
      string str = "";
      Process process = Process.Start(startInfo);
      while (!process.WaitForExit(0))
        str = str + process.StandardOutput.ReadLine() + "\r\n";
      process.Close();
      return str;
    }
  }
}
