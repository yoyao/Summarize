﻿
using System.ComponentModel;
using System.Configuration.Install;
using System.IO;
using System.Reflection;

namespace WebInstall
{
  [RunInstaller(true)]
  public class Install : Installer
  {
    private IContainer components = (IContainer) null;
    private string path = (string) null;

    public Install()
    {
      this.InitializeComponent();
      this.path = Assembly.GetExecutingAssembly().Location;
      this.path = this.path.Substring(0, this.path.LastIndexOf("\\"));
      this.Committing += new InstallEventHandler(this.Install_Committing);
      this.AfterUninstall += new InstallEventHandler(this.Install_AfterUninstall);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
    }

    private void Install_Committing(object sender, InstallEventArgs e)
    {
      Regedit regedit = new Regedit();
      if (!regedit.IsRegeditDirExist("View"))
      {
        regedit.SetRegeditData("View", "View Client", "installed", "1");
        regedit.SetRegeditData("View", "View Client", "version", "20140123");
        Shellex.AutoRegCom();
      }
      INetFwManger.NetFwAddApps("ViewClient", this.path + "\\ViewClient.exe");
    }

    private void Install_AfterUninstall(object sender, InstallEventArgs e)
    {
      Regedit regedit = new Regedit();
      if (regedit.IsRegeditDirExist("View"))
        regedit.DeleteRegist("View", "View Client");
      if (!File.Exists(this.path + "\\setting.ini"))
        return;
      File.Delete(this.path + "\\setting.ini");
    }
  }
}
