﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("WebInstall")]
[assembly: AssemblyCopyright("Copyright ©eSage  2016")]
[assembly: AssemblyTitle("WebInstall")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("90a195b6-6dcb-4788-9c2a-6d26069632e7")]
[assembly: AssemblyVersion("1.0.0.0")]
