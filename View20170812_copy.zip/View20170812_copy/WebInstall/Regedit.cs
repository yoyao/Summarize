﻿
using Microsoft.Win32;
using System.Diagnostics;

namespace WebInstall
{
  internal class Regedit
  {
    public void SetRegeditData(string softname, string subname, string Key_Name, string Key_Value)
    {
      Registry.LocalMachine.OpenSubKey("SOFTWARE", true).CreateSubKey(softname).CreateSubKey(subname).SetValue(Key_Name, (object) Key_Value);
    }

    public bool IsRegeditDirExist(string softname)
    {
      bool flag = false;
      foreach (string subKeyName in Registry.LocalMachine.OpenSubKey("SOFTWARE", true).GetSubKeyNames())
      {
        if (subKeyName == softname)
          return true;
      }
      return flag;
    }

    public void DeleteRegist(string softname, string subname)
    {
      RegistryKey registryKey1 = Registry.LocalMachine.OpenSubKey("SOFTWARE", true);
      RegistryKey registryKey2 = registryKey1.OpenSubKey(softname, true);
      foreach (string subKeyName in registryKey2.GetSubKeyNames())
        registryKey2.DeleteSubKeyTree(subKeyName);
      registryKey1.DeleteSubKey(softname);
    }

    public void RegeditDll()
    {
      new Process()
      {
        StartInfo = {
          FileName = "Regsvr32.exe",
          Arguments = "/s C:\\DllTest.dll"
        }
      }.Start();
    }
  }
}
