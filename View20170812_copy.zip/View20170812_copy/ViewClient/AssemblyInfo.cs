﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: Guid("4d831881-7e22-47f8-9e9a-b7cfae19937d")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("ViewConnection")]
[assembly: AssemblyCompany("eSage")]
[assembly: AssemblyCopyright("Copyright © eSage 2016")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("eSageConnection")]
[assembly: AssemblyVersion("1.0.0.0")]
