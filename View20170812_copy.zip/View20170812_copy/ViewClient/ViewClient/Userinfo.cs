﻿
using ViewClient.Classes;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Web;
using System.Windows.Forms;

namespace ViewClient
{
  [ComVisible(true)]
  public class Userinfo : Form
  {
    private Show show = (Show) null;
    private IContainer components = (IContainer) null;
    private string _username;
    private string _password;
    private Index curParentForm;
    private WebBrowser webBrowser1;

    public Userinfo(string UserName, string Password)
    {
      this._username = UserName;
      this._password = Password;
      this.InitializeComponent();
    }

    private void Userinfo_Load(object sender, EventArgs e)
    {
      this.webBrowser1.ObjectForScripting = (object) this;
      this.webBrowser1.Dock = DockStyle.Fill;
      string str1 = Desktop.server;
      string str2 = "parm=login&t=2&username=" + HttpUtility.UrlEncode(HttpUtility.UrlEncode(this._username)) + "&password=" + Common.GetSHA(this._password);

      string str3 = str1.IndexOf(":") <= -1 ? "http://" + str1 + ":8080/admin.do?" + str2 : "http://" + str1 + "/admin.do?" + str2;
        
      this.webBrowser1.Navigate(str1.IndexOf(":") <= -1 ? "http://" + str1 + ":8080/admin.do?" + str2 : "http://" + str1 + "/admin.do?" + str2);
      this.webBrowser1.IsWebBrowserContextMenuEnabled = false;
      this.webBrowser1.ScrollBarsEnabled = false;
    }

    private void f_ChangeTip2(bool topmost)
    {
      this.curParentForm = (Index) this.Owner;
      if (this.curParentForm.timer != null)
      {
        this.curParentForm.timer.Stop();
        this.curParentForm.timer.Dispose();
        this.curParentForm.timer = (System.Timers.Timer) null;
      }
      if (this.curParentForm.thread != null)
      {
        this.curParentForm.thread.Abort();
        this.curParentForm.thread = (Thread) null;
      }
      if (this.curParentForm.t != null)
      {
        this.curParentForm.t.Abort();
        this.curParentForm = (Index) null;
      }
      this.curParentForm.LTip.Text = "";
      this.curParentForm.PBLogin.Enabled = true;
    }

    public void FormClose()
    {
      this.curParentForm = (Index) this.Owner;
      if (this.curParentForm.timer != null)
      {
        this.curParentForm.timer.Stop();
        this.curParentForm.timer.Dispose();
        this.curParentForm.timer = (System.Timers.Timer) null;
      }
      if (this.curParentForm.thread != null)
      {
        this.curParentForm.thread.Abort();
        this.curParentForm.thread = (Thread) null;
      }
      if (this.curParentForm.t != null)
      {
        this.curParentForm.t.Abort();
        this.curParentForm = (Index) null;
      }
      this.curParentForm.LTip.Text = "";
      this.curParentForm.k = 0;
      this.curParentForm.RegistHotKey();
      Desktop.isOpen = true;
      this.Close();
    }

    public string GetIP()
    {
      return Desktop.ip1;
    }

    public void ShowWindow(string type)
    {
      if (type == "0")
      {
        Desktop.ip = Desktop.ip1;
        Desktop.computerName = Desktop.computername1;
      }
      else if (type == "1")
      {
        Desktop.ip = Desktop.ip2;
        Desktop.computerName = Desktop.computername2;
      }
      else if (type == "2")
      {
        Desktop.ip = Desktop.ip3;
        Desktop.computerName = Desktop.computername3;
      }
      else if (type == "3")
      {
        Desktop.ip = Desktop.ip4;
        Desktop.computerName = Desktop.computername4;
      }
      if (Common.IsNullorEmpty(Desktop.ip))
        return;
      this.TopMost = false;
      if (this.show == null || this.show.IsDisposed)
        this.show = new Show();
      else
        this.show.Activate();
      this.show.ChangeTip2 += new ChangeFormTip2(this.f_ChangeTip2);
      this.show.Owner = (Form) this;
      this.show.Show();
    }

    private void Userinfo_FormClosed(object sender, FormClosedEventArgs e)
    {
      this.UnRegistHotKey();
    }

    private void RegistHotKey()
    {
      HotKey.RegisterHotKey(this.Handle, 100, HotKey.KeyModifiers.Shift, Keys.F1);
      HotKey.RegisterHotKey(this.Handle, 101, HotKey.KeyModifiers.Ctrl, Keys.D);
      HotKey.RegisterHotKey(this.Handle, 102, HotKey.KeyModifiers.Ctrl, Keys.F1);
      HotKey.RegisterHotKey(this.Handle, 103, HotKey.KeyModifiers.Alt, Keys.Tab);
      HotKey.RegisterHotKey(this.Handle, 104, HotKey.KeyModifiers.Alt, Keys.F4);
      HotKey.RegisterHotKey(this.Handle, 105, HotKey.KeyModifiers.Shift, Keys.F2);
      HotKey.RegisterHotKey(this.Handle, 106, HotKey.KeyModifiers.Ctrl, Keys.F2);
      HotKey.RegisterHotKey(this.Handle, 107, HotKey.KeyModifiers.Shift, Keys.K);
      if (!Desktop.autoLogin)
      {
        HotKey.RegisterHotKey(this.Handle, 108, HotKey.KeyModifiers.None, Keys.Return);
        HotKey.RegisterHotKey(this.Handle, 109, HotKey.KeyModifiers.Shift, Keys.Return);
      }
      HotKey.RegisterHotKey(this.Handle, 110, HotKey.KeyModifiers.Ctrl, Keys.E);
    }

    private void UnRegistHotKey()
    {
      HotKey.UnregisterHotKey(this.Handle, 100);
      HotKey.UnregisterHotKey(this.Handle, 102);
      HotKey.UnregisterHotKey(this.Handle, 103);
      HotKey.UnregisterHotKey(this.Handle, 104);
      HotKey.UnregisterHotKey(this.Handle, 105);
      HotKey.UnregisterHotKey(this.Handle, 106);
      HotKey.UnregisterHotKey(this.Handle, 107);
      HotKey.UnregisterHotKey(this.Handle, 108);
      HotKey.UnregisterHotKey(this.Handle, 109);
      HotKey.UnregisterHotKey(this.Handle, 110);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.webBrowser1 = new WebBrowser();
      this.SuspendLayout();
      this.webBrowser1.Location = new Point(2, 1);
      this.webBrowser1.MinimumSize = new Size(20, 20);
      this.webBrowser1.Name = "webBrowser1";
      this.webBrowser1.ScrollBarsEnabled = false;
      this.webBrowser1.Size = new Size(860, 628);
      this.webBrowser1.TabIndex = 0;
      this.AutoScaleDimensions = new SizeF(6f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(860, 628);
      this.Controls.Add((Control) this.webBrowser1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Userinfo";
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "登陆个人中心";
      this.FormClosed += new FormClosedEventHandler(this.Userinfo_FormClosed);
      this.Load += new EventHandler(this.Userinfo_Load);
      this.ResumeLayout(false);
    }
  }
}
