﻿
namespace ViewClient
{
  public class ViM
  {
    public string VM { get; set; }

    public string PreUserName { get; set; }

    public string PrePassword { get; set; }

    public string Remember { get; set; }

    public string AutoLogin { get; set; }

    public string UserCenter { get; set; }

    public string RedirectDrives { get; set; }

    public string RedirectPrinters { get; set; }

    public string RedirectPorts { get; set; }

    public string RedirectSmartCards { get; set; }

    public string RedirectDevices { get; set; }

    public string Domain { get; set; }

    public string IsPassed { get; set; }

    public string IsPreset { get; set; }

    public string IP { get; set; }

    public string CPU { get; set; }

    public string Memory { get; set; }

    public string Storage { get; set; }
  }
}
