﻿
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace ViewClient
{
  internal class Shellex
  {
    [DllImport("shell32.dll", SetLastError = true)]
    public static extern int ShellExecute(IntPtr hWnd, StringBuilder lpszOp, StringBuilder lpszFile, StringBuilder lpszParams, StringBuilder lpszDir, int FsShowCmd);

    public static void AutoRegCom()
    {
      try
      {
        new Process()
        {
          StartInfo = {
            FileName = "Regsvr32.exe",
            Arguments = "/s C:\\Windows\\System32\\mstscax.dll"
          }
        }.Start();
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message.ToString());
      }
    }

    [Flags]
    public enum ShowWindowCommands
    {
      SW_HIDE = 0,
      SW_SHOWNORMAL = 1,
      SW_NORMAL = SW_SHOWNORMAL,
      SW_SHOWMINIMIZED = 2,
      SW_SHOWMAXIMIZED = SW_SHOWMINIMIZED | SW_NORMAL,
      SW_MAXIMIZE = SW_SHOWMAXIMIZED,
      SW_SHOWNOACTIVATE = 4,
      SW_SHOW = SW_SHOWNOACTIVATE | SW_NORMAL,
      SW_MINIMIZE = SW_SHOWNOACTIVATE | SW_SHOWMINIMIZED,
      SW_SHOWMINNOACTIVE = SW_MINIMIZE | SW_NORMAL,
      SW_SHOWNA = 8,
      SW_RESTORE = SW_SHOWNA | SW_NORMAL,
      SW_SHOWDEFAULT = SW_SHOWNA | SW_SHOWMINIMIZED,
      SW_MAX = SW_SHOWDEFAULT,
    }
  }
}
