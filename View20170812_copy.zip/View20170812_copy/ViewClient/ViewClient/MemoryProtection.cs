﻿

using System;

namespace ViewClient
{
  [Flags]
  internal enum MemoryProtection
  {
    Execute = 16,
    ExecuteRead = 32,
    ExecuteReadWrite = 64,
    ExecuteWriteCopy = 128,
    NoAccess = 1,
    x02 = 2,
    ReadWrite = 4,
    WriteCopy = 8,
    GuardModifierflag = 256,
    NoCacheModifierflag = 512,
    WriteCombineModifierflag = 1024,
  }
}
