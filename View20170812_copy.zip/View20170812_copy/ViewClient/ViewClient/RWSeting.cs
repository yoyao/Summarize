﻿
using System.Runtime.InteropServices;
using System.Text;

namespace ViewClient
{
  public class RWSeting
  {
    public static string sPath = "";
    public static string section = "";
    public static string version = "";

    [DllImport("kernel32")]
    private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

    [DllImport("kernel32")]
    private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

    [DllImport("kernel32")]
    private static extern int GetPrivateProfileStringA(string section, string key, string def, StringBuilder retVal, int size, string filePath);

    public static void Write(string key, string value)
    {
      RWSeting.WritePrivateProfileString(RWSeting.section, key, value, RWSeting.sPath);
    }

    public static string Read(string key)
    {
      StringBuilder retVal = new StringBuilder((int) byte.MaxValue);
      RWSeting.GetPrivateProfileStringA(RWSeting.section, key, "", retVal, (int) byte.MaxValue, RWSeting.sPath);
      return retVal.ToString();
    }
  }
}
