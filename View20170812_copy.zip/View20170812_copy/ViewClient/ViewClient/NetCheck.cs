﻿
using System;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ViewClient
{
  internal class NetCheck
  {
    public void NetworkChange_NetworkAddressChanged(object sender, EventArgs e)
    {
      foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces())
      {
        if (networkInterface.NetworkInterfaceType != NetworkInterfaceType.Loopback)
        {
          int num = (int) MessageBox.Show("Changed   {0} is {1}" + networkInterface.OperationalStatus.ToString());
        }
      }
    }

    public bool NetworkChange_NetworkAvailabilityChanged(object sender, NetworkAvailabilityEventArgs e)
    {
      return e.IsAvailable;
    }

    [DllImport("wininet.dll")]
    public static extern bool InternetGetConnectedState(out long lpdwFlags, long dwReserved);

    public static bool NetState()
    {
      try
      {
        long lpdwFlags;
        return NetCheck.InternetGetConnectedState(out lpdwFlags, 0L);
      }
      catch
      {
        return false;
      }
    }
  }
}
