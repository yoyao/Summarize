﻿
using AxMSTSCLib;
using MSTSCLib;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ViewClient
{
  public class Show : Form
  {
    public int device = 0;
    private IContainer components = (IContainer) null;
    private const int TS_PERF_DISABLE_CURSOR_SHADOW = 32;
    private const int TS_PERF_DISABLE_CURSORSETTINGS = 64;
    private const int TS_PERF_DISABLE_FULLWINDOWDRAG = 2;
    private const int TS_PERF_DISABLE_MENUANIMATIONS = 4;
    private const int TS_PERF_DISABLE_NOTHING = 0;
    private const int TS_PERF_DISABLE_THEMING = 0;
    private const int TS_PERF_DISABLE_WALLPAPER = 0;
    private const int TS_PERF_ENABLE_FONT_SMOOTHING = 128;
    private const int TS_PERF_ENABLE_DESKTOP_COMPOSITION = 256;
    private const int WM_DEVICECHANGE = 8592;
    private const int DBT_DEVICEARRIVAL = 32768;
    private const int DBT_DEVICEREMOVECOMPLETE = 32772;
    private const int DBT_DEVNODES_CHANGED = 7;
    private IMsRdpClientNonScriptable5 _nonScriptable5;
    private AxMsRdpClient8NotSafeForScripting rdp;

    public event ChangeFormTip ChangeTip;

    public event ChangeFormTip2 ChangeTip2;

    public Show()
    {
      this.InitializeComponent();
    }

    public Show(string ip)
    {
      Desktop.ip = ip;
    }

    private void Show_Load(object sender, EventArgs e)
    {
      this.ShowRDP();
    }

    private void ShowRDP()
    {
      this.rdp.Dock = DockStyle.Fill;
      this.Controls.Add((Control) this.rdp);
      this.rdp.Server = Desktop.ip;
      this.rdp.DesktopWidth = Desktop.width;
      this.rdp.DesktopHeight = Desktop.height;
      this.rdp.FullScreen = true;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).EnableCredSspSupport = true;
      if (Desktop.isPreset)
      {
        this.rdp.UserName = Desktop.preUsername;
        ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).ClearTextPassword = Desktop.prePassword;
      }
      else
      {
        this.rdp.UserName = Desktop.uname;
        ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).ClearTextPassword = Desktop.pwd;
      }
      this.rdp.Domain = !(Desktop.domain != "") ? Desktop.computerName : Desktop.domain;
      if (Desktop.port > 0)
      {
          ((IMsRdpClientAdvancedSettings8)this.rdp.AdvancedSettings9).RDPPort = Desktop.port;
      }
       
      this.rdp.Name = "易思捷桌面云";
      this.rdp.FullScreenTitle = "易思捷桌面云";
      this.rdp.ConnectedStatusText = "易思捷桌面云";
      this.rdp.ColorDepth = Desktop.color != 0 ? (Desktop.color != 1 ? (Desktop.color != 2 ? 32 : 24) : 16) : 15;
      this.rdp.ConnectingText = "欢迎使用易思捷桌面云";
      this.rdp.DisconnectedText = "感谢使用易思捷桌面云";
      this.rdp.AllowDrop = true;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).DisableRdpdr = 0;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).PinConnectionBar = false;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).DisplayConnectionBar = Desktop.displayConnectionBar;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).ConnectionBarShowMinimizeButton = false;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).ConnectionBarShowPinButton = false;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).ConnectionBarShowRestoreButton = false;
      switch (Desktop.audio)
      {
        case 0:
          ((IMsRdpClientSecuredSettings) this.rdp.SecuredSettings2).AudioRedirectionMode = 2;
          break;
        case 1:
          ((IMsRdpClientSecuredSettings) this.rdp.SecuredSettings2).AudioRedirectionMode = 1;
          break;
        case 2:
          ((IMsRdpClientSecuredSettings) this.rdp.SecuredSettings2).AudioRedirectionMode = 0;
          break;
      }
      ((IMsRdpClientSecuredSettings2) this.rdp.SecuredSettings3).KeyboardHookMode = Desktop.keyboard;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).RedirectClipboard = Desktop.redirectClipboard;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).RedirectSmartCards = Desktop.redirectSmartCards;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).RedirectPorts = Desktop.redirectPorts;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).RedirectPrinters = Desktop.redirectPrinters;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).AudioCaptureRedirectionMode = true;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).GrabFocusOnConnect = true;
        //启用window键
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).EnableWindowsKey =0;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).DisableCtrlAltDel = 1;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).BitmapPeristence = 1;
      ((IMsRdpClientAdvancedSettings8) this.rdp.AdvancedSettings9).Compress = 1;
      this.rdp.AdvancedSettings9.HotKeyCtrlAltDel = 1;
       
      IMsRdpClientAdvancedSettings8 advancedSettings9_1 = this.rdp.AdvancedSettings9;
      int performanceFlags1 = ((IMsRdpClientAdvancedSettings8) advancedSettings9_1).PerformanceFlags;
      ((IMsRdpClientAdvancedSettings8) advancedSettings9_1).PerformanceFlags = performanceFlags1;
      IMsRdpClientAdvancedSettings8 advancedSettings9_2 = this.rdp.AdvancedSettings9;
      int num1 = ((IMsRdpClientAdvancedSettings8) advancedSettings9_2).PerformanceFlags | 128;
      ((IMsRdpClientAdvancedSettings8) advancedSettings9_2).PerformanceFlags = num1;
      IMsRdpClientAdvancedSettings8 advancedSettings9_3 = this.rdp.AdvancedSettings9;
      int num2 = ((IMsRdpClientAdvancedSettings8) advancedSettings9_3).PerformanceFlags | 256;
      ((IMsRdpClientAdvancedSettings8) advancedSettings9_3).PerformanceFlags = num2;
      IMsRdpClientAdvancedSettings8 advancedSettings9_4 = this.rdp.AdvancedSettings9;
      int num3 = ((IMsRdpClientAdvancedSettings8) advancedSettings9_4).PerformanceFlags | 2;
      ((IMsRdpClientAdvancedSettings8) advancedSettings9_4).PerformanceFlags = num3;
      IMsRdpClientAdvancedSettings8 advancedSettings9_5 = this.rdp.AdvancedSettings9;
      int num4 = ((IMsRdpClientAdvancedSettings8) advancedSettings9_5).PerformanceFlags | 4;
      ((IMsRdpClientAdvancedSettings8) advancedSettings9_5).PerformanceFlags = num4;
      IMsRdpClientAdvancedSettings8 advancedSettings9_6 = this.rdp.AdvancedSettings9;
      int performanceFlags2 = ((IMsRdpClientAdvancedSettings8) advancedSettings9_6).PerformanceFlags;
      ((IMsRdpClientAdvancedSettings8) advancedSettings9_6).PerformanceFlags = performanceFlags2;
      ((IMsRdpClientAdvancedSettings7) this.rdp.AdvancedSettings8).allowBackgroundInput = 0;
      ((IMsRdpClientAdvancedSettings7) this.rdp.AdvancedSettings8).EnableAutoReconnect = true;
      ((IMsRdpClientAdvancedSettings7) this.rdp.AdvancedSettings8).AcceleratorPassthrough = 1;
      ((IMsRdpClientAdvancedSettings7) this.rdp.AdvancedSettings8).DoubleClickDetect = 1;
      // By esage 2016-08-05
      this._nonScriptable5 = this.rdp.GetOcx() as IMsRdpClientNonScriptable5;
    //  this._nonScriptable5.DisableConnectionBar = true;
      //

      if (Desktop.redirectDrives)
      {
        this._nonScriptable5 = this.rdp.GetOcx() as IMsRdpClientNonScriptable5;
        for (int index = 0; (long) index < (long) this._nonScriptable5.DriveCollection.DriveCount; ++index)
        {
          if (index > 0)
          {
            // ISSUE: reference to a compiler-generated method
            // ISSUE: variable of a compiler-generated type
            IMsRdpDrive msRdpDrive = this._nonScriptable5.DriveCollection.get_DriveByIndex((uint) index);
            msRdpDrive.RedirectionState = true;
          }
        }
        this._nonScriptable5.RedirectDynamicDrives = true;
      }
      if (Desktop.redirectDevices)
      {
        this._nonScriptable5 = this.rdp.GetOcx() as IMsRdpClientNonScriptable5;
        for (int index = 0; (long) index < (long) this._nonScriptable5.DeviceCollection.DeviceCount; ++index)
        {
          if (index > 0)
          {
            // ISSUE: reference to a compiler-generated method
            // ISSUE: variable of a compiler-generated type
            IMsRdpDevice msRdpDevice = this._nonScriptable5.DeviceCollection.get_DeviceByIndex((uint) index);
            msRdpDevice.RedirectionState = true;
          }
        }
        this._nonScriptable5.RedirectDynamicDevices = true;
      }
      this.rdp.OnDisconnected += new AxMSTSCLib.IMsTscAxEvents_OnDisconnectedEventHandler(this.rdp_OnDisconnected);
      this.rdp.OnConnecting += new EventHandler(this.OnConnecting);
      this.rdp.OnConnected += new EventHandler(this.OnConnected);
      this.rdp.Connect();
      Desktop.connecting = true;

    }

    private void OnConnecting(object sender, EventArgs e)
    {

    }

    private void OnConnected(object sender, EventArgs e)
    {
      Desktop.connected = true;
      this.ChangeTip(true);
    }

    private void rdp_OnDisconnected(object sender, IMsTscAxEvents_OnDisconnectedEvent e)
    {
    // By esage 2016-08-05
    Desktop.connected = false;
    Desktop.connecting = false;
    //
    Desktop.first_autologin = false;
    //
     this.ChangeTip2(true);
      string str = string.Empty;
      bool flag = false;
      
      switch (e.discReason)
      {
        case 2825:
          str = "The remote computer requires Network Level Authentication. Enable NLA in connection options";
          flag = true;
          break;
        case 3078:
          str = "Decryption error.";
          break;
        case 2566:
          str = "Internal security error.";
          break;
        case 2822:
          str = "Encryption error.";
          break;
        case 2056:
          str = "Internal security error.";
          break;
        case 2308:
          str = "Socket closed.";
          break;
        case 2310:
          str = "Internal security error.";
          break;
        case 2312:
          str = "Licensing timeout.";
          break;
        case 1796:
          str = "Timeout occurred.";
          break;
        case 1798:
          str = "Failed to unpack server certificate.";
          break;
        case 2052:
          str = "Bad IP address specified.";
          break;
        case 1286:
          str = "Invalid encryption method specified.";
          break;
        case 1288:
          str = "DNS lookup failed.";
          break;
        case 1540:
          str = "Failed to find the requested server, device, or host.";
          break;
        case 1542:
          str = "Invalid server security data.";
          break;
        case 1544:
          str = "Internal timer error.";
          break;
        case 772:
          str = "Winsock send call failure.";
          break;
        case 774:
          str = "Out of memory.";
          break;
        case 776:
          str = "Invalid IP address specified.";
          break;
        case 1028:
          str = "Winsock recv call failure.";
          break;
        case 1030:
          str = "Invalid security data.";
          break;
        case 1032:
          str = "Internal error.";
          break;
        case 0:
          str = "No information is available.";
          break;
        case 1:
          str = "Local disconnection.";
          break;
        case 2:
          str = "Remote disconnection by user.";
          break;
        case 3:
          str = "Remote disconnection by server.";
          break;
        case 260:
          str = "DNS name lookup failure.";
          break;
        case 262:
          str = "Out of memory.";
          break;
        case 264:
          str = "Connection timed out.";
          break;
        case 516:
          str = "Winsock socket connect failure.";
          break;
        case 518:
          str = "Out of memory.";
          break;
        case 520:
          str = "Host not found.";
          break;
        default:
          str = string.Format("Unrecognized error: code {0}", (object) e.discReason);
          break;
      }

      if (!flag)
      { }
      // By esage 2016-08-05
      //Desktop.connected = false;
      //Desktop.connecting = false;
      //
      // Desktop.first_autologin = false;
      //
      this.Close();
    }

    protected override void WndProc(ref Message m)
    {
      if (Desktop.redirectDrives)
      {
        switch (m.WParam.ToInt32())
        {
          case 32768:
            // ISSUE: reference to a compiler-generated method
            this._nonScriptable5.NotifyRedirectDeviceChange((uint) (int) m.WParam, (int) m.LParam);
            // ISSUE: reference to a compiler-generated method
            this._nonScriptable5.DriveCollection.RescanDrives(true);
            break;
          case 32772:
            // ISSUE: reference to a compiler-generated method
            this._nonScriptable5.NotifyRedirectDeviceChange((uint) (int) m.WParam, (int) m.LParam);
            // ISSUE: reference to a compiler-generated method
            this._nonScriptable5.DriveCollection.RescanDrives(true);
            break;
        }
      }
      base.WndProc(ref m);
    }

    protected override void Dispose(bool disposing)
    {

      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Show));
      this.rdp = new AxMsRdpClient8NotSafeForScripting();
      this.rdp.BeginInit();
      this.SuspendLayout();
      this.rdp.Enabled = true;
      this.rdp.Location = new Point(52, 35);
      this.rdp.Name = "rdp";
      this.rdp.OcxState = (AxHost.State) componentResourceManager.GetObject("rdp.OcxState");
      this.rdp.Size = new Size(613, 414);
      this.rdp.TabIndex = 0;
      this.rdp.Visible = false;
      this.AutoScaleDimensions = new SizeF(6f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.AutoSize = true;
      this.AutoValidate = AutoValidate.Disable;
      this.ClientSize = new Size(698, 470);
      this.Controls.Add((Control) this.rdp);
      this.Enabled = false;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Show";
      this.Opacity = 0.0;
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "易思捷云客户端";
      this.Load += new EventHandler(this.Show_Load);
      this.rdp.EndInit();
      this.ResumeLayout(false);
    }
 
  }
}
