﻿
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace ViewClient
{
  [DebuggerNonUserCode]
  [CompilerGenerated]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  internal class Resource1
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) Resource1.resourceMan, (object) null))
          Resource1.resourceMan = new ResourceManager("ViewClient.Resource1", typeof (Resource1).Assembly);
        return Resource1.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return Resource1.resourceCulture;
      }
      set
      {
        Resource1.resourceCulture = value;
      }
    }

    internal static Bitmap autologin1
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("autologin1", Resource1.resourceCulture);
      }
    }

    internal static Bitmap autologin2
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("autologin2", Resource1.resourceCulture);
      }
    }

    internal static Bitmap autologin3
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("autologin3", Resource1.resourceCulture);
      }
    }

    internal static Bitmap autologin4
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("autologin4", Resource1.resourceCulture);
      }
    }

    internal static Bitmap view
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("view", Resource1.resourceCulture);
      }
    }

    internal static Bitmap loadingFont
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("loadingFont", Resource1.resourceCulture);
      }
    }

    internal static Bitmap loadingPic
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("loadingPic", Resource1.resourceCulture);
      }
    }

    internal static Bitmap login
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("login", Resource1.resourceCulture);
      }
    }

    internal static Bitmap LogPic
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("LogPic", Resource1.resourceCulture);
      }
    }

    internal static Bitmap remember1
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("remember1", Resource1.resourceCulture);
      }
    }

    internal static Bitmap remember2
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("remember2", Resource1.resourceCulture);
      }
    }

    internal static Bitmap remember3
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("remember3", Resource1.resourceCulture);
      }
    }

    internal static Bitmap remember4
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("remember4", Resource1.resourceCulture);
      }
    }

    internal static Bitmap start
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("start", Resource1.resourceCulture);
      }
    }

    internal static Bitmap wallPaper
    {
      get
      {
        return (Bitmap) Resource1.ResourceManager.GetObject("wallPaper", Resource1.resourceCulture);
      }
    }

    internal Resource1()
    {
    }
  }
}
