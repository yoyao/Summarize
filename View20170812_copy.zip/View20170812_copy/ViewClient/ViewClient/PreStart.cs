﻿

using ViewClient.Classes;
using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ViewClient
{
  public class PreStart : Form
  {
    private int t = 0;
    private IContainer components = (IContainer) null;
    private InputHook inputHook;
    private Index i;
    private Thread thread;
    private PictureBox PBLoading1;

    public PreStart()
    {
      this.InitializeComponent();
    }

    [DllImport("wininet.dll")]
    private static extern bool InternetGetConnectedState(int connectionDescription, int reservedValue);

    public static bool IsConnectInternet()
    {
      return PreStart.InternetGetConnectedState(0, 0);
    }

    private static void StopSystemKeys()
    {
      RegistryKey registryKey1 = Registry.CurrentUser;
      string name = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies";
      registryKey1.OpenSubKey(name, true).CreateSubKey("System");
      registryKey1.Close();
      RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", true);
      registryKey2.SetValue("DisableTaskMgr", (object) 1, RegistryValueKind.DWord);
      registryKey2.Close();
    }

    private void EnterKisok1()
    {
      RegistryKey registryKey = Registry.LocalMachine;
      string name = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
      registryKey.OpenSubKey(name, true).OpenSubKey("Winlogon", true).SetValue("Shell", (object) Common.GetCurrentFile());
      registryKey.Close();
    }

    private void ReadIni()
    {
      Desktop.company = RWSeting.Read("company");
      Desktop.address = RWSeting.Read("address");
      Desktop.uname = RWSeting.Read("uname");
      Desktop.pwd = RWSeting.Read("pwd");
      Desktop.server = RWSeting.Read("server");
      Desktop.vm1 = RWSeting.Read("vm");
      Desktop.isRemember = Common.StrToBool(RWSeting.Read("isRemember"));
      Desktop.isAutoLogin = Common.StrToBool(RWSeting.Read("isAutoLogin"));
      Desktop.isUserCenter = Common.StrToBool(RWSeting.Read("isUserCenter"));
      Desktop.remember = Common.StrToBool(RWSeting.Read("remember"));
      Desktop.autoLogin = Common.StrToBool(RWSeting.Read("autoLogin"));
      Desktop.color = Common.StrToInt(RWSeting.Read("color"));
      Desktop.screen = Common.StrToInt(RWSeting.Read("screen"));
      Desktop.width = Common.StrToInt(RWSeting.Read("width"));
      Desktop.height = Common.StrToInt(RWSeting.Read("height"));
      Rectangle bounds;
      if (Desktop.width == 0)
      {
        bounds = Screen.PrimaryScreen.Bounds;
        Desktop.width = bounds.Width;
      }
      if (Desktop.height == 0)
      {
        bounds = Screen.PrimaryScreen.Bounds;
        Desktop.height = bounds.Height;
      }
      Desktop.audio = Common.StrToInt(RWSeting.Read("AudioRedirectionMode"));
      Desktop.keyboard = Common.StrToInt(RWSeting.Read("KeyboardHookMode"));
      Desktop.displayConnectionBar = Common.StrToBool(RWSeting.Read("DisplayConnectionBar"));
      Desktop.redirectClipboard = Common.StrToBool(RWSeting.Read("RedirectClipboard"));
      Desktop.redirectPrinters = Common.StrToBool(RWSeting.Read("RedirectPrinters"));
      Desktop.redirectSmartCards = Common.StrToBool(RWSeting.Read("RedirectSmartCards"));
      Desktop.redirectPorts = Common.StrToBool(RWSeting.Read("RedirectPorts"));
      Desktop.redirectDrives = Common.StrToBool(RWSeting.Read("RedirectDrives"));
      Desktop.redirectDevices = Common.StrToBool(RWSeting.Read("RedirectDevices"));
      Desktop.lockText = Common.StrToBool(RWSeting.Read("lockText"));
      Desktop.lockTask = Common.StrToBool(RWSeting.Read("lockTask"));
      RWSeting.Read("autoLogin");
      Desktop.version = RWSeting.Read("version");
      Desktop.kisok = Common.StrToBool(RWSeting.Read("kisok"));
    }

    private void CreateIni()
    {
      StreamWriter streamWriter = new StreamWriter(RWSeting.sPath, false, Encoding.Default);
      try
      {
        streamWriter.WriteLine("#用户使用信息");
        streamWriter.WriteLine("[" + RWSeting.section + "]");
        streamWriter.WriteLine("IsPreSet=false");
        streamWriter.WriteLine("Installed=false");
        streamWriter.WriteLine("uname=1");
        streamWriter.WriteLine("pwd=1");
        streamWriter.WriteLine("server=");
        streamWriter.WriteLine("vm=");
        streamWriter.WriteLine("isRemember=true");
        streamWriter.WriteLine("isAutoLogin=true");
        streamWriter.WriteLine("isUserCenter=true");
        streamWriter.WriteLine("remember=false");
        streamWriter.WriteLine("autoLogin=false");
        streamWriter.WriteLine("color=3");
        streamWriter.WriteLine("screen=7");
        streamWriter.WriteLine("width=");
        streamWriter.WriteLine("height=");
        streamWriter.WriteLine("DisplayConnectionBar=false");
        streamWriter.WriteLine("AudioRedirectionMode=2");
        streamWriter.WriteLine("KeyboardHookMode=1");
        streamWriter.WriteLine("RedirectClipboard=true");
        streamWriter.WriteLine("RedirectPrinters=true");
        streamWriter.WriteLine("RedirectSmartCards=true");
        streamWriter.WriteLine("RedirectPorts=true");
        streamWriter.WriteLine("RedirectDrives=true");
        streamWriter.WriteLine("RedirectDevices=true");
        streamWriter.WriteLine("lockText=false");
        streamWriter.WriteLine("lockTask=false");
        streamWriter.WriteLine("company=");
        streamWriter.WriteLine("address=");
        streamWriter.WriteLine("version=" + RWSeting.version);
        streamWriter.WriteLine("kisok=true");
        streamWriter.WriteLine("time=" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
        streamWriter.Close();
      }
      catch
      {
        throw new ApplicationException("ini 文件创建失败！");
      }
    }

    private void ShowIndex()
    {
      if (this.PBLoading1.InvokeRequired)
      {
        this.Invoke((Delegate) new PreStart.doDelegate(this.ShowIndex));
      }
      else
      {
        if (this.i == null || this.i.IsDisposed)
          this.i = new Index();
        else
          this.i.Activate();
        this.i.Owner = (Form) this;
        this.i.Show();
        if (this.thread != null)
        {
          this.thread.Abort();
          this.thread = (Thread) null;
        }
      }
    }

    private void ShowIndex2()
    {
      if (this.i == null || this.i.IsDisposed)
        this.i = new Index();
      else
        this.i.Activate();
      this.i.Owner = (Form) this;
      this.i.Show();
    }

    private void ShowIndex3()
    {
      if (this.PBLoading1.InvokeRequired)
      {
        this.Invoke((Delegate) new PreStart.doDelegate(this.ShowIndex3));
      }
      else
      {
        if (this.i == null || this.i.IsDisposed)
          this.i = new Index("服务器地址错误或者网络有异常");
        else
          this.i.Activate();
        this.i.Owner = (Form) this;
        this.i.Show();
        if (this.thread != null)
        {
          this.thread.Abort();
          this.thread = (Thread) null;
        }
      }
    }

    private void ShowIndex4()
    {
      if (this.PBLoading1.InvokeRequired)
      {
        this.Invoke((Delegate) new PreStart.doDelegate(this.ShowIndex4));
      }
      else
      {
        if (this.i == null || this.i.IsDisposed)
          this.i = new Index("客户端未联网！");
        else
          this.i.Activate();
        this.i.Owner = (Form) this;
        this.i.Show();
        if (this.thread != null)
        {
          this.thread.Abort();
          this.thread = (Thread) null;
        }
      }
    }

    private void Connect()
    {
      string hostNameOrAddress = Desktop.server;
      if (hostNameOrAddress.IndexOf(":") > -1)
        hostNameOrAddress = hostNameOrAddress.Substring(0, hostNameOrAddress.IndexOf(":") - 1);
      else if (hostNameOrAddress.IndexOf("/") > -1)
        hostNameOrAddress = hostNameOrAddress.Substring(0, hostNameOrAddress.IndexOf("/") - 1);
      ++this.t;
      Ping ping = new Ping();
      PingOptions options = new PingOptions();
      options.DontFragment = true;
      byte[] bytes = Encoding.ASCII.GetBytes("");
      int timeout = 1000;
      try
      {
        if (ping.Send(hostNameOrAddress, timeout, bytes, options).Status.ToString() == "Success")
          this.ShowIndex();
        else if (this.t > 15)
        {
          this.ShowIndex3();
        }
        else
        {
          int tickCount = Environment.TickCount;
          while (Environment.TickCount - tickCount < 2000)
            Application.DoEvents();
          this.Connect();
        }
      }
      catch
      {
        this.ShowIndex3();
      }
    }

    private void PreStart_Shown(object sender, EventArgs e)
    {
      RWSeting.sPath = Common.GetCurrentPath() + "\\setting.ini";
      RWSeting.section = "client";
      RWSeting.version = DateTime.Now.ToString("yyyyMMdd");
      if (!new FileInfo(RWSeting.sPath).Exists)
        this.CreateIni();
      this.ReadIni();
      this.inputHook = new InputHook();
      if (Desktop.lockTask)
      {
        PreStart.StopSystemKeys();
        this.inputHook.Lock_SysKey(true);
      }
      if (Desktop.kisok)
        this.EnterKisok1();
      Desktop.screenArea = Screen.GetBounds((Control) this);
      this.PBLoading1.Location = new Point((Desktop.screenArea.Width - this.PBLoading1.Width) / 2, (Desktop.screenArea.Height - this.PBLoading1.Height) / 2);
      if (!PreStart.IsConnectInternet())
        this.ShowIndex4();
      if (Desktop.server != "")
        this.ShowIndex();
      else
        this.ShowIndex2();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (PreStart));
      this.PBLoading1 = new PictureBox();
      ((ISupportInitialize) this.PBLoading1).BeginInit();
      this.SuspendLayout();
      this.PBLoading1.BackColor = System.Drawing.Color.Transparent;
      this.PBLoading1.Image = (Image) componentResourceManager.GetObject("PBLoading1.Image");
      this.PBLoading1.Image = (Image)componentResourceManager.GetObject("PBLoading10.Image");
      this.PBLoading1.Location = new Point(268, 187);
      this.PBLoading1.Name = "PBLoading1";
      this.PBLoading1.Size = new Size(293, 36);
      this.PBLoading1.TabIndex = 3;
      this.PBLoading1.TabStop = false;
      this.AutoScaleDimensions = new SizeF(6f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new Size(868, 504);
      this.Controls.Add((Control) this.PBLoading1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "PreStart";
      this.Text = "预加载页面";
      this.WindowState = FormWindowState.Maximized;
      this.Shown += new EventHandler(this.PreStart_Shown);
      ((ISupportInitialize) this.PBLoading1).EndInit();
      this.ResumeLayout(false);
    }

    private delegate void doDelegate();
  }
}
