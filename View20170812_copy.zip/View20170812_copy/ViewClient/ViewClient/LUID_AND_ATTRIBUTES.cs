﻿
namespace ViewClient
{
  internal struct LUID_AND_ATTRIBUTES
  {
    public LUID pLuid;
    public long Attributes;
  }
}
