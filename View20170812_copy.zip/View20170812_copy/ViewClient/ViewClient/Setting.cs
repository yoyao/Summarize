﻿

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ViewClient
{
  public class Setting : Form
  {
    private IContainer components = (IContainer) null;
    private GroupBox gb1;
    private TextBox Server;
    private Label label4;
    private PictureBox CancelBtn;
    private PictureBox SaveBtn;
    private Label ts;
    private ImageList imageList1;
    private ImageList imageList2;
    private Panel panel1;

    public Setting()
    {
      this.InitializeComponent();
    }

    private void Setting_Load(object sender, EventArgs e)
    {
      this.Server.Text = Desktop.server;
      this.RegistHotKey();
    }

    private void Setting_FormClosing(object sender, FormClosingEventArgs e)
    {
      this.UnRegistHotKey();
    }

    private void SaveBtn_Click(object sender, EventArgs e)
    {
      this.Save();
    }

    private void Save()
    {
      string str = this.Server.Text.Trim();
      if (str.Equals(""))
      {
        this.ts.Text = "服务器端地址不能为空";
      }
      else
      {
        RWSeting.Write("server", str);
        Desktop.server = str;
        this.Close();
      }
    }

    private void CancelBtn_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void IndexStart()
    {
      Application.Run((Form) new Index());
    }

    private void SaveBtn_MouseHover(object sender, EventArgs e)
    {
      if (this.imageList1.Images.Count <= 0)
        return;
      this.SaveBtn.Image = this.imageList1.Images[1];
    }

    private void SaveBtn_MouseLeave(object sender, EventArgs e)
    {
      if (this.imageList1.Images.Count <= 0)
        return;
      this.SaveBtn.Image = this.imageList1.Images[0];
    }

    private void CancelBtn_MouseHover(object sender, EventArgs e)
    {
      if (this.imageList1.Images.Count <= 0)
        return;
      this.CancelBtn.Image = this.imageList1.Images[3];
    }

    private void CancelBtn_MouseLeave(object sender, EventArgs e)
    {
      if (this.imageList1.Images.Count <= 0)
        return;
      this.CancelBtn.Image = this.imageList1.Images[2];
    }

    protected override void WndProc(ref Message m)
    {
      base.WndProc(ref m);
      if (m.Msg != 786 || m.WParam.ToInt32() != 108)
        return;
      this.Save();
    }

    private void RegistHotKey()
    {
      HotKey.RegisterHotKey(this.Handle, 108, HotKey.KeyModifiers.None, Keys.Return);
    }

    private void UnRegistHotKey()
    {
      HotKey.UnregisterHotKey(this.Handle, 108);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Setting));
      this.gb1 = new GroupBox();
      this.ts = new Label();
      this.Server = new TextBox();
      this.label4 = new Label();
      this.panel1 = new Panel();
      this.CancelBtn = new PictureBox();
      this.SaveBtn = new PictureBox();
      this.imageList1 = new ImageList(this.components);
      this.imageList2 = new ImageList(this.components);
      this.gb1.SuspendLayout();
      ((ISupportInitialize) this.CancelBtn).BeginInit();
      ((ISupportInitialize) this.SaveBtn).BeginInit();
      this.SuspendLayout();
      this.gb1.BackColor = Color.Transparent;
      this.gb1.Controls.Add((Control) this.ts);
      this.gb1.Controls.Add((Control) this.Server);
      this.gb1.Controls.Add((Control) this.label4);
      this.gb1.Controls.Add((Control) this.panel1);
      this.gb1.ForeColor = Color.Black;
      componentResourceManager.ApplyResources((object) this.gb1, "gb1");
      this.gb1.Name = "gb1";
      this.gb1.TabStop = false;
      componentResourceManager.ApplyResources((object) this.ts, "ts");
      this.ts.BackColor = Color.White;
      this.ts.ForeColor = Color.FromArgb(242, 97, 81);
      this.ts.Name = "ts";
      this.Server.BorderStyle = BorderStyle.None;
      componentResourceManager.ApplyResources((object) this.Server, "Server");
      this.Server.Name = "Server";
      componentResourceManager.ApplyResources((object) this.label4, "label4");
      this.label4.Name = "label4";
      this.panel1.BackColor = Color.DarkGray;
      componentResourceManager.ApplyResources((object) this.panel1, "panel1");
      this.panel1.Name = "panel1";
      this.CancelBtn.BackColor = Color.FromArgb(242, 242, 230);
      componentResourceManager.ApplyResources((object) this.CancelBtn, "CancelBtn");
      this.CancelBtn.Cursor = Cursors.Hand;
      this.CancelBtn.Name = "CancelBtn";
      this.CancelBtn.TabStop = false;
      this.CancelBtn.Click += new EventHandler(this.CancelBtn_Click);
      this.CancelBtn.MouseLeave += new EventHandler(this.CancelBtn_MouseLeave);
      this.CancelBtn.MouseHover += new EventHandler(this.CancelBtn_MouseHover);
      this.SaveBtn.BackColor = Color.FromArgb(242, 242, 230);
      componentResourceManager.ApplyResources((object) this.SaveBtn, "SaveBtn");
      this.SaveBtn.Cursor = Cursors.Hand;
      this.SaveBtn.Name = "SaveBtn";
      this.SaveBtn.TabStop = false;
      this.SaveBtn.Click += new EventHandler(this.SaveBtn_Click);
      this.SaveBtn.MouseLeave += new EventHandler(this.SaveBtn_MouseLeave);
      this.SaveBtn.MouseHover += new EventHandler(this.SaveBtn_MouseHover);
      this.imageList1.ImageStream = (ImageListStreamer) componentResourceManager.GetObject("imageList1.ImageStream");
      this.imageList1.TransparentColor = Color.Transparent;
      this.imageList1.Images.SetKeyName(0, "ok2.png");
      this.imageList1.Images.SetKeyName(1, "ok3.bmp");
      this.imageList1.Images.SetKeyName(2, "cancel.png");
      this.imageList1.Images.SetKeyName(3, "cancel2.png");
      this.imageList2.ImageStream = (ImageListStreamer) componentResourceManager.GetObject("imageList2.ImageStream");
      this.imageList2.TransparentColor = Color.Transparent;
      this.imageList2.Images.SetKeyName(0, "qt2.png");
      this.imageList2.Images.SetKeyName(1, "qt.png");
      componentResourceManager.ApplyResources((object) this, "$this");
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.White;
      this.ControlBox = false;
      this.Controls.Add((Control) this.CancelBtn);
      this.Controls.Add((Control) this.SaveBtn);
      this.Controls.Add((Control) this.gb1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Setting";
      this.FormClosing += new FormClosingEventHandler(this.Setting_FormClosing);
      this.Load += new EventHandler(this.Setting_Load);
      this.gb1.ResumeLayout(false);
      this.gb1.PerformLayout();
      ((ISupportInitialize) this.CancelBtn).EndInit();
      ((ISupportInitialize) this.SaveBtn).EndInit();
      this.ResumeLayout(false);
    }
  }
}
