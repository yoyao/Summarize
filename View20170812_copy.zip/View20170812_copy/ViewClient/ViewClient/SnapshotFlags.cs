﻿
using System;

namespace ViewClient
{
  [Flags]
  internal enum SnapshotFlags : uint
  {
    HeapList = 1,
    Process = 2,
    Thread = 4,
    Module = 8,
    Module32 = 16,
    Inherit = 2147483648,
    All = Module32 | Module | Thread | Process | HeapList,
  }
}
