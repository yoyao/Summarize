﻿
using System;

namespace ViewClient
{
  [Flags]
  internal enum AllocationType
  {
    Commit = 4096,
    Reserve = 8192,
    Decommit = 16384,
    Release = 32768,
    Reset = 524288,
    Physical = 4194304,
    TopDown = 1048576,
    WriteWatch = 2097152,
    LargePages = 536870912,
  }
}
