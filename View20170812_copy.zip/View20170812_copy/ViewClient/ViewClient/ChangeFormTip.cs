﻿
namespace ViewClient
{
  public delegate void ChangeFormTip(bool topmost);
}
