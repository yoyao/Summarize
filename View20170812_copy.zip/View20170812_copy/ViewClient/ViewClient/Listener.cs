﻿
using ViewClient.Classes;
using System;
using System.IO;
using System.Net;
using System.Text;
using View.DesktopAgent.Communication.Message;
using View.DesktopAgent.Communication.Protocol;

namespace ViewClient
{
  public class Listener
  {
    private static MessageReceiver receiver;
    public Listener.testDelegate mainThread;

    public void Receive()
    {
      Listener.receiver = new MessageReceiver();
      Listener.receiver.DataReceive += new EventHandler<DataReceiveEventArgs>(this.Receiver_DataReceive);
      Listener.receiver.Start();
    }

    private void Receiver_DataReceive(object sender1, DataReceiveEventArgs e)
    {
      if (e.MessageType == MessageType.Command)
      {
        string message = CommandMessage.FromPackage(e.Data).Message;
        if (message.IndexOf("ip|") <= -1)
          return;
        string[] strArray = message.Split('|');
        this.IPReceive1(strArray[1], strArray[2]);
      }
      else
        Console.Out.WriteLine("Not match." + UnknowMessage.FromPackage(e.Data).Message);
    }

    public void IPReceive1(string ServerIP, string Password)
    {
      RWSeting.Write("server", ServerIP + ":8080/viewweb/");
      Desktop.server = ServerIP + ":8080/viewweb/";
      string pageHtml = this.GetPageHTML("http://" + ServerIP + ":8080/viewweb/user.do?parm=login3&ip=" + Common.GetIP());
      if (!(pageHtml != ""))
        return;
      RWSeting.Write("uname", pageHtml);
      RWSeting.Write("pwd", Password);
      RWSeting.Write("remember", "true");
      Desktop.uname = pageHtml;
      Desktop.pwd = Common.GetSHA(Password);
      this.mainThread(pageHtml, Password);
    }

    private string GetPageHTML(string url)
    {
      string str = "";
      try
      {
        HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(url);
        httpWebRequest.Method = "GET";
        httpWebRequest.UserAgent = "MSIE 7.0; Windows NT 5.1";
        httpWebRequest.KeepAlive = false;
        httpWebRequest.Timeout = 2000;
        httpWebRequest.ReadWriteTimeout = 2000;
        httpWebRequest.AllowAutoRedirect = false;
        HttpWebResponse httpWebResponse = (HttpWebResponse) httpWebRequest.GetResponse();
        using (Stream responseStream = httpWebResponse.GetResponseStream())
        {
          using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
          {
            str = streamReader.ReadToEnd();
            streamReader.Close();
          }
          responseStream.Close();
        }
        httpWebResponse.Close();
      }
      catch
      {
        str = "";
      }
      return str;
    }

    public delegate void testDelegate(string str1, string str2);
  }
}
