﻿
using System;
using System.Diagnostics;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace ViewClient.Classes
{
  public class Common
  {
    public static void RunCmd(string path)
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = path,
        WindowStyle = ProcessWindowStyle.Hidden,
        ErrorDialog = false,
        CreateNoWindow = true
      });
    }

    public static string GetCmdOutString(string path, string arguments)
    {
      ProcessStartInfo startInfo = new ProcessStartInfo();
      startInfo.FileName = path;
      startInfo.UseShellExecute = true;
      startInfo.Arguments = arguments;
      startInfo.CreateNoWindow = false;
      startInfo.RedirectStandardOutput = true;
      startInfo.UseShellExecute = false;
      string str = "";
      Process process = Process.Start(startInfo);
      while (!process.WaitForExit(0))
        str = str + process.StandardOutput.ReadLine() + "\r\n";
      process.Close();
      return str;
    }

    public static string GetCurrentPath()
    {
      Assembly executingAssembly = Assembly.GetExecutingAssembly();
      return executingAssembly.Location.Remove(executingAssembly.Location.LastIndexOf("\\"));
    }

    public static string GetCurrentFile()
    {
      Assembly executingAssembly = Assembly.GetExecutingAssembly();
      try
      {
        return executingAssembly.Location;
      }
      catch
      {
        return "Explorer.exe";
      }
    }

    public static string DecodeUnicode(string dataStr)
    {
      return new Regex("(?i)\\\\[uU]([0-9a-f]{4})").Replace(dataStr, (MatchEvaluator) (m => ((char) Convert.ToInt32(m.Groups[1].Value, 16)).ToString()));
    }

    private static string byteToString(byte b)
    {
      byte num1 = 240;
      byte num2 = 15;
      byte b1 = (byte) (((int) b & (int) num1) >> 4);
      byte b2 = (byte) ((uint) b & (uint) num2);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(Common.findHex(b1));
      stringBuilder.Append(Common.findHex(b2));
      return stringBuilder.ToString();
    }

    private static char findHex(byte b)
    {
      int num1 = (int) b;
      int num2 = num1 < 0 ? num1 + 16 : num1;
      if (0 <= num2 && num2 <= 9)
        return (char) (num2 + 48);
      return (char) (num2 - 10 + 65);
    }

    public static string GetSHA(string str)
    {
      byte[] hash = SHA1.Create().ComputeHash(Encoding.UTF8.GetBytes(str));
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < hash.Length; ++index)
        stringBuilder.Append(Common.byteToString(hash[index]));
      return stringBuilder.ToString().ToLower();
    }

    public static string EncodeBase64(string str)
    {
      return Convert.ToBase64String(Encoding.UTF8.GetBytes(str));
    }

    public static string DecodeBase64(string str)
    {
      return Encoding.UTF8.GetString(Convert.FromBase64String(str));
    }

    public static int StrToInt(string str)
    {
      int num = 0;
      if (string.IsNullOrEmpty(str) || str.Trim().Length >= 11 || !Regex.IsMatch(str.Trim(), "^([-]|[0-9])[0-9]*(\\.\\w*)?$"))
        return num;
      int result;
      if (int.TryParse(str, out result))
        return result;
      return Convert.ToInt32(Common.StrToFloat(str, (float) num));
    }

    public static float StrToFloat(string strValue, float defValue)
    {
      if (strValue == null || strValue.Length > 10)
        return defValue;
      float result = defValue;
      if (strValue != null && Regex.IsMatch(strValue, "^([-]|[0-9])[0-9]*(\\.\\w*)?$"))
        float.TryParse(strValue, out result);
      return result;
    }

    public static bool StrToBool(string str)
    {
      bool flag = false;
      if (str != null)
      {
        if (string.Compare(str, "true", true) == 0)
          return true;
        if (string.Compare(str, "false", true) == 0)
          return false;
      }
      return flag;
    }

    public static string GetIP()
    {
     // IPAddress[] addressList = Dns.GetHostByName(Dns.GetHostName()).AddressList;
        IPAddress[] addressList = Dns.GetHostEntry(Dns.GetHostName()).AddressList;
      string str = (string) null;
      for (int index = 0; index < addressList.Length; ++index)
      {
        if (addressList[index].ToString().IndexOf(".") > -1)
          str = addressList[index].ToString();
      }
      return str;
    }

    public static bool IsIPAddress(string ip)
    {
      if (ip.IndexOf(":") > -1)
        return true;
      if (string.IsNullOrEmpty(ip) || ip.Length < 7 || ip.Length > 15)
        return false;
      return new Regex("^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])$", RegexOptions.IgnoreCase).IsMatch(ip);
    }

    public static bool IsNullorEmpty(string str)
    {
      return str == null || str.Equals("");
    }
  }
}
