﻿
namespace ViewClient
{
  internal struct TOKEN_PRIVILEGES
  {
    public long PrivilegeCount;
    public LUID_AND_ATTRIBUTES Privileges;
  }
}
