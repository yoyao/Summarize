﻿
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ViewClient
{
  public class Finish : Form
  {
    private IContainer components = (IContainer) null;

    public Finish()
    {
      this.InitializeComponent();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.SuspendLayout();
      this.AutoScaleDimensions = new SizeF(6f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.FromArgb(2, 61, 153);
      this.BackgroundImage = (Image) Resource1.LogPic;
      this.BackgroundImageLayout = ImageLayout.Stretch;
      this.ClientSize = new Size(742, 520);
      this.FormBorderStyle = FormBorderStyle.None;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Finish";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.Text = "Finish";
      this.WindowState = FormWindowState.Maximized;
      this.ResumeLayout(false);
    }
  }
}
