﻿
using System;

namespace ViewClient
{
  [Flags]
  internal enum FreeType
  {
    Decommit = 16384,
    Release = 32768,
  }
}
