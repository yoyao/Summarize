﻿

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace ViewClient.Properties
{
  [CompilerGenerated]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) ViewClient.Properties.Resources.resourceMan, (object) null))
          ViewClient.Properties.Resources.resourceMan = new ResourceManager("ViewClient.Properties.Resources", typeof (ViewClient.Properties.Resources).Assembly);
        return ViewClient.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return ViewClient.Properties.Resources.resourceCulture;
      }
      set
      {
        ViewClient.Properties.Resources.resourceCulture = value;
      }
    }

    internal static string BackGround
    {
      get
      {
        return ViewClient.Properties.Resources.ResourceManager.GetString("BackGround", ViewClient.Properties.Resources.resourceCulture);
      }
    }

    internal Resources()
    {
    }
  }
}
