﻿

namespace ViewClient
{
  internal struct PROCESSENTRY32W
  {
    public long dwSize;
    public long cntUsage;
    public long h32ProcessID;
    public long th32DefaultHeapID;
    public long h32ModuleID;
    public long cntThreads;
    public long th32ParentProcessID;
    public long pcPriClassBase;
    public long dwFlags;
    public int[] szExeFile;
  }
}
