﻿

using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace ViewClient
{
  internal class RDApp
  {
    public void CloseApp(string ProcessName)
    {
      Process[] processesByName = Process.GetProcessesByName(ProcessName);
      if (processesByName.Length <= 0)
        return;
      foreach (Process process in processesByName)
      {
        // By esage 2016-07-01
        if (process.ProcessName.Equals("ViewConnection"))
        {
          try
          {
            process.Kill();
          }
          catch (Exception ex)
          {
            int num = (int) MessageBox.Show(ex.ToString());
          }
        }
      }
    }

    public void StartApp(string AppPath)
    {
    }

    public void GetFolderApp(string AppPath)
    {
      foreach (string file in Directory.GetFiles(AppPath))
      {
        FileInfo fileInfo = new FileInfo(file);
        if (fileInfo.Extension.Equals(".exe") && fileInfo.Name.Equals("explorer.exe"))
          Process.Start(file);
      }
    }
  }
}
