﻿
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ViewClient
{
  public class Loading : Form
  {
    private IContainer components = (IContainer) null;
    private PictureBox PBLoading1;

    public Loading()
    {
      this.InitializeComponent();
      this.PBLoading1.Location = new Point((Desktop.screenArea.Width - this.PBLoading1.Width) / 2, (Desktop.screenArea.Height - this.PBLoading1.Height) / 2);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Loading));
      this.PBLoading1 = new PictureBox();
      ((ISupportInitialize) this.PBLoading1).BeginInit();
      this.SuspendLayout();
      this.PBLoading1.BackColor = Color.Transparent;
      this.PBLoading1.Image = (Image) Resource1.loadingFont;
      this.PBLoading1.Location = new Point(425, 252);
      this.PBLoading1.Name = "PBLoading1";
      this.PBLoading1.Size = new Size(293, 36);
      this.PBLoading1.TabIndex = 19;
      this.PBLoading1.TabStop = false;
      this.AutoScaleDimensions = new SizeF(6f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.White;
      this.ClientSize = new Size(1412, 862);
      this.Controls.Add((Control) this.PBLoading1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Loading";
      this.Text = "Loading";
      this.WindowState = FormWindowState.Maximized;
      ((ISupportInitialize) this.PBLoading1).EndInit();
      this.ResumeLayout(false);
    }

  }
}
