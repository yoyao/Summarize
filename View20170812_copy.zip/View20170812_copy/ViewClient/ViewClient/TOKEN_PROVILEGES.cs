﻿

namespace ViewClient
{
  internal struct TOKEN_PROVILEGES
  {
    public long PrivilegeCount;
    public LUID_AND_ATTRIBUTES Privileges;
  }
}
