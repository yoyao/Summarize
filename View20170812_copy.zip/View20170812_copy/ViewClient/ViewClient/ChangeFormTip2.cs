﻿

namespace ViewClient
{
  public delegate void ChangeFormTip2(bool topmost);
}
