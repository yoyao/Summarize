﻿
using ViewClient.Classes;
using System.IO;
using System.Net;
using System.Text;

namespace ViewClient
{
  public class CommandReceiver
  {
    public void IPReceive1(string ServerIP, string Password)
    {
      RWSeting.Write("server", ServerIP);
      Desktop.server = ServerIP;
      string pageHtml = this.GetPageHTML("http://" + ServerIP + ":8080/viewweb/user.do?parm=login3&ip=" + Common.GetIP());
      if (!(pageHtml != ""))
        return;
      RWSeting.Write("uname", pageHtml);
      RWSeting.Write("pwd", Password);
      RWSeting.Write("remember", "true");
      Desktop.uname = pageHtml;
      Desktop.pwd = Common.GetSHA(Password);
    }

    private string GetPageHTML(string url)
    {
      string str = "";
      try
      {
        HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(url);
        httpWebRequest.Method = "GET";
        httpWebRequest.UserAgent = "MSIE 7.0; Windows NT 5.1";
        httpWebRequest.KeepAlive = false;
        httpWebRequest.Timeout = 2000;
        httpWebRequest.ReadWriteTimeout = 2000;
        httpWebRequest.AllowAutoRedirect = false;
        HttpWebResponse httpWebResponse = (HttpWebResponse) httpWebRequest.GetResponse();
        using (Stream responseStream = httpWebResponse.GetResponseStream())
        {
          using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
          {
            str = streamReader.ReadToEnd();
            streamReader.Close();
          }
          responseStream.Close();
        }
        httpWebResponse.Close();
      }
      catch
      {
        str = "";
      }
      return str;
    }
  }
}
