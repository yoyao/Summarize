﻿
using System.Drawing;

namespace ViewClient
{
  public class Desktop
  {
    public static string company = "";
    public static string address = "";
    public static bool isOpen = true;
    public static bool isPreset = false;
    public static string computerName = "";
    public static string ip = "";
    public static int port = 0;
    public static string uname = "";
    public static string pwd = "";
    public static string preUsername = "Administrator";
    public static string prePassword = "123456";
    public static bool isRemember = true;
    public static bool isAutoLogin = true;
    public static bool isUserCenter = true;
    public static bool remember = false;
    public static bool autoLogin = false;
    // By esage 2016-08-05
    public static bool first_autologin = true;
    //
    public static string server = "";
    public static string domain = "";
    public static int screen = 0;
    public static int width = 0;
    public static int height = 0;
    public static int color = 3;
    public static bool displayConnectionBar = false;
    public static int audio = 0;
    public static int keyboard = 0;
    public static bool redirectClipboard = false;
    public static bool redirectPrinters = true;
    public static bool redirectSmartCards = true;
    public static bool redirectPorts = true;
    public static bool redirectDrives = true;
    public static bool redirectDevices = true;
    public static bool connected = false;
    public static bool connecting = false;
    public static string fileName = "";
    public static bool lockText = false;
    public static bool lockTask = false;
    public static bool over = true;
    public static string version = "";
    public static bool kisok = false;
    public static int num = 0;
    public static string computername1 = "";
    public static string ip1 = "";
    public static string cpu1 = "";
    public static string memory1 = "";
    public static string storage1 = "";
    public static string vm1 = "";
    public static string computername2 = "";
    public static string ip2 = "";
    public static string cpu2 = "";
    public static string memory2 = "";
    public static string storage2 = "";
    public static string vm2 = "";
    public static string computername3 = "";
    public static string ip3 = "";
    public static string cpu3 = "";
    public static string memory3 = "";
    public static string storage3 = "";
    public static string vm3 = "";
    public static string computername4 = "";
    public static string ip4 = "";
    public static string cpu4 = "";
    public static string memory4 = "";
    public static string storage4 = "";
    public static string vm4 = "";
    public static Rectangle screenArea;
  }
}
