﻿

using System;
using System.Threading;
using System.Windows.Forms;

namespace ViewClient
{
  internal static class Program
  {
    private static Mutex mutex;

    [STAThread]
    private static void Main()
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Program.mutex = new Mutex(true, "OnlyRun");
      if (Program.mutex.WaitOne(0, false))
      {
        Application.Run((Form) new PreStart());
      }
      else
      {
        int num = (int) MessageBox.Show("程序已经在运行！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        Application.Exit();
      }
    }
  }
}
