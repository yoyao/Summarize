﻿
using ViewClient.Classes;
using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Timers;
using System.Web;
using System.Web.Script.Serialization;
using System.Windows.Forms;


namespace ViewClient
{
  public class Index : Form
  {
    private static int i = 0;
    private Show show = (Show) null;
    private Setting setting = (Setting) null;
    private NetCheck nc = new NetCheck();
  //  private Thread ListenerThread = (Thread) null;
    private HttpWebRequest req = (HttpWebRequest) null;
    private string strResult = "";
    public int k = 0;
    private IContainer components = (IContainer) null;
    private const uint SC_CLOSE = 61536;
    private const uint MF_BYCOMMAND = 0;
    private InputHook inputHook;
    private IntPtr ptrHook;
    private Index.LowLevelKeyboardProc objKeyboardProcess;
    public Thread t;
    public Thread thread;
    private Loading loading;
    public System.Timers.Timer timer;
    private ImageList ILClosePic;
    private Label LCompanyName;
    public TextBox TBUname;
    public TextBox TBPwd;
    private Label LAddress;
    private BackgroundPanel PPwd;
    public PictureBox PBLogin;
    private BackgroundPanel PUname;
    public Label LTip;
    private PictureBox PBLogo1;
    private PictureBox PBUserinfo;
    private PictureBox PBRemember;
    private PictureBox PBAutoLogin;
    private BackgroundPanel PMain;
    // By esage 2016-08-04
    private Button PBLoginbutton;

    public Index(string tip)
    {
      ProcessModule mainModule = Process.GetCurrentProcess().MainModule;
      this.objKeyboardProcess = new Index.LowLevelKeyboardProc(this.captureKey);
      this.ptrHook = Index.SetWindowsHookEx(13, this.objKeyboardProcess, Index.GetModuleHandle(mainModule.ModuleName), 0U);
      this.InitializeComponent();
      this.DoubleBuffered = true;
      this.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer, true);
      this.LTip.Text = tip;
    }

    public Index()
    {
      ProcessModule mainModule = Process.GetCurrentProcess().MainModule;
      this.objKeyboardProcess = new Index.LowLevelKeyboardProc(this.captureKey);
      this.ptrHook = Index.SetWindowsHookEx(13, this.objKeyboardProcess, Index.GetModuleHandle(mainModule.ModuleName), 0U);
      this.InitializeComponent();
      this.DoubleBuffered = true;
      this.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer, true);
    }

    [DllImport("USER32.DLL")]
    private static extern IntPtr GetSystemMenu(IntPtr hWnd, uint bRevert);

    [DllImport("USER32.DLL")]
    private static extern uint RemoveMenu(IntPtr hMenu, uint nPosition, uint wFlags);

    [DllImport("wininet.dll")]
    private static extern bool InternetGetConnectedState(out int connectionDescription, int reservedValue);

    [DllImport("ntdll.dll")]
    public static extern long RtlAdjustPrivilege(long Privilege, long Enable, long CurrentThread, long Enabled);

    [DllImport("kernel32.dll")]
    public static extern int OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

    [DllImport("kernel32.dll")]
    public static extern uint GetLastError();

    [DllImport("ntdll.dll", SetLastError = true)]
    public static extern int NtSuspendProcess(IntPtr hProcess);

    [DllImport("ntdll.dll", SetLastError = true)]
    public static extern int NtResumeProcess(IntPtr hProcess);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int id, Index.LowLevelKeyboardProc callback, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hook);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr CallNextHookEx(IntPtr hook, int nCode, IntPtr wp, IntPtr lp);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string name);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern short GetAsyncKeyState(Keys key);

    private IntPtr captureKey(int nCode, IntPtr wp, IntPtr lp)
    {
      if (nCode >= 0)
      {
        Index.KBDLLHOOKSTRUCT kbdllhookstruct = (Index.KBDLLHOOKSTRUCT) Marshal.PtrToStructure(lp, typeof (Index.KBDLLHOOKSTRUCT));
        if (kbdllhookstruct.key == Keys.RWin || kbdllhookstruct.key == Keys.LWin)
          return (IntPtr) 1;
      }
      return Index.CallNextHookEx(this.ptrHook, nCode, wp, lp);
    }

    private void LoadData_AutoLogin()
    {
        if (Desktop.isRemember)
          this.PBRemember.Visible = true;
        else
          this.PBRemember.Visible = false;
        if (Desktop.isAutoLogin)
          this.PBAutoLogin.Visible = true;
        else
          this.PBAutoLogin.Visible = false;
        if (Desktop.isUserCenter)
          this.PBUserinfo.Visible = true;
        else
          this.PBUserinfo.Visible = false;

      if (Desktop.lockText)
      {
        this.TBUname.Enabled = false;
        this.TBPwd.Enabled = false;
        this.PBRemember.Image = Desktop.remember ? (Image) Resource1.remember4 : (Image) Resource1.remember3;
        this.PBAutoLogin.Image = Desktop.autoLogin ? (Image) Resource1.autologin4 : (Image) Resource1.autologin3;
      }

        this.PMain.Visible = true;
        this.TBUname.Visible = true;
        this.TBPwd.Visible = true;
        this.PBLogin.Visible = true;
        this.PBLogo1.Visible = true;
        this.PUname.Visible = true;
        this.PPwd.Visible = true;
        this.LCompanyName.Visible = true;
        this.LAddress.Visible = true;
    }
    private void LoadData()
    {
      this.inputHook = new InputHook();
      NetworkChange.NetworkAvailabilityChanged += new NetworkAvailabilityChangedEventHandler(this.NetworkChange_NetworkAvailabilityChanged);
      this.PBRemember.Image = !Desktop.remember ? (Image) Resource1.remember1 : (Image) Resource1.remember2;
      this.PBAutoLogin.Image = !Desktop.autoLogin ? (Image) Resource1.autologin1 : (Image) Resource1.autologin2;
      this.TBUname.Text = Desktop.uname;
      this.TBPwd.Text = Desktop.pwd;
      if (!Desktop.autoLogin)
      {
        if (Desktop.isRemember)
          this.PBRemember.Visible = true;
        else
          this.PBRemember.Visible = false;
        if (Desktop.isAutoLogin)
          this.PBAutoLogin.Visible = true;
        else
          this.PBAutoLogin.Visible = false;
        if (Desktop.isUserCenter)
          this.PBUserinfo.Visible = true;
        else
          this.PBUserinfo.Visible = false;
      }
      if (Desktop.lockText)
      {
        this.TBUname.Enabled = false;
        this.TBPwd.Enabled = false;
        this.PBRemember.Image = Desktop.remember ? (Image) Resource1.remember4 : (Image) Resource1.remember3;
        this.PBAutoLogin.Image = Desktop.autoLogin ? (Image) Resource1.autologin4 : (Image) Resource1.autologin3;
      }
      if (Desktop.lockTask)
      {
        Index.StopSystemKeys();
        this.inputHook.Lock_SysKey(true);
        this.EnterKisok1();
      }
      this.RegistHotKey();
      if (!Desktop.autoLogin)
        this.PMain.Visible = true;
      this.PMain.Controls.Add((Control) this.TBUname);
      this.PMain.Controls.Add((Control) this.PUname);
      this.PMain.Controls.Add((Control) this.TBPwd);
      //this.PMain.Controls.Add((Control) this.PBLogin);
      this.PMain.Controls.Add((Control) this.PPwd);
      // By esage 2016-08-04
      this.PMain.Controls.Add((Control)this.PBLoginbutton);
      //
      this.PPwd.Controls.Add((Control) this.PBLogin);
      this.PMain.Controls.Add((Control) this.PBLogo1);
      this.PMain.Controls.Add((Control) this.LTip);
      this.PMain.Controls.Add((Control) this.PBRemember);
      this.PMain.Controls.Add((Control) this.PBAutoLogin);
      this.PMain.Location = new Point((Desktop.screenArea.Width - this.PMain.Width) / 2, Desktop.screenArea.Height / 2 - 250);
      if (System.IO.File.Exists(Application.StartupPath + "\\logo1.png"))
      {
        this.PBLogo1.Image = Image.FromFile(Application.StartupPath + "\\logo1.png");
        this.PBLogo1.Width = 120;
        this.PBLogo1.Height = 48;
        this.PBLogo1.Location = new Point((this.PMain.Width - this.PBLogo1.Width) / 2 - 6, this.PBLogo1.Top + 10);
      }
      this.PBLogin.Focus();
      this.LCompanyName.Text = Desktop.company;
      this.LAddress.Text = Desktop.address;
      this.LCompanyName.Location = new Point((Desktop.screenArea.Width - this.LCompanyName.Width) / 2, Desktop.screenArea.Height / 2 + 270);
      this.LAddress.Location = new Point((Desktop.screenArea.Width - this.LAddress.Width) / 2, Desktop.screenArea.Height / 2 + 295);
      if (Desktop.autoLogin)
        return;
      this.TBUname.Visible = true;
      this.TBPwd.Visible = true;
      this.PBLogin.Visible = true;
      this.PBLogo1.Visible = true;
      this.PUname.Visible = true;
      this.PPwd.Visible = true;
      this.LCompanyName.Visible = true;
      this.LAddress.Visible = true;
    }

    private void RefreshText(string UserName, string Password)
    {
      if (this.TBUname.InvokeRequired)
      {
        this.Invoke((Delegate) new Listener()
        {
          mainThread = new Listener.testDelegate(this.RefreshText)
        }.mainThread, (object) UserName, (object) Password);
      }
      else
      {
        this.TBUname.Text = UserName;
        this.TBPwd.Text = Password;
        this.EAutoLogin();
        Desktop.first_autologin = false;
      }
    }

    private void Index_Load(object sender, EventArgs e)
    {
    }

    private void Index_Shown(object sender, EventArgs e)
    {
      this.LoadData();
      if (Common.IsNullorEmpty(Desktop.server) || !Desktop.autoLogin)
        return;
      this.PBLogin.Enabled = false;
      if (Desktop.uname.Equals("1"))
      {
        this.LTip.Text = "";
        this.TBUname.Focus();
      }
      else
      {
        this.UnRegistHotKey();
        this.EAutoLogin();
        Desktop.first_autologin = false;
      }
    }

    private void EAutoLogin()
    {
      if (this.t != null)
        this.t.Abort();
      this.t = new Thread(new ThreadStart(this.vAutoLogin));
      this.t.IsBackground = true;
      this.t.Start();
    }

    private void vAutoLogin()
    {
      if (!Desktop.connecting)
      {
        this.k = 1;
        this.Login3();
        int tickCount = Environment.TickCount;
        while (Environment.TickCount - tickCount < 3000)
          Application.DoEvents();        
        this.vAutoLogin();
      }
      else
      {
        int tickCount = Environment.TickCount;
        while (Environment.TickCount - tickCount < 3000)
          Application.DoEvents();
       this.vAutoLogin();
      }
    }

    private void f_ChangeTip(bool topmost)
    {
      this.LTip.Text = "";
      this.PBLogin.Enabled = true;
      if (!Desktop.autoLogin)
        this.loading.Close();
      if (this.timer != null)
      {
        this.timer.Stop();
        this.timer.Dispose();
        this.timer = (System.Timers.Timer) null;
      }
      if (this.thread != null)
      {
        this.thread.Abort();
        this.thread = (Thread) null;
      }
      if (this.t == null)
        return;
      this.t.Abort();
      this.t = (Thread) null;
    }

    private void f_ChangeTip2(bool topmost)
    {
        this.k = 0;
        if (!Desktop.remember)
            this.TBPwd.Text = "";
        this.RegistHotKey();
        if (Common.IsNullorEmpty(Desktop.server) || !Desktop.autoLogin)
            return;
        this.PBLogin.Enabled = true;
        if (Desktop.autoLogin)
        {
            this.loading.Close();
            this.LoadData_AutoLogin();
         }
        if (Desktop.uname.Equals("1"))
        {
            this.LTip.Text = "";
            this.TBUname.Focus();
        }
        else
        {
            if (Desktop.first_autologin)
                this.EAutoLogin();
        }
    }

    //private void f_ChangeTip2(bool topmost)
    //{
    //  this.k = 0;
    //  if (!Desktop.remember)
    //    this.TBPwd.Text = "";
    //  this.RegistHotKey();
    //  if (Common.IsNullorEmpty(Desktop.server) || !Desktop.autoLogin)
    //    return;
    //  this.PBLogin.Enabled = false;
    //  if (Desktop.uname.Equals("1"))
    //  {
    //    this.LTip.Text = "";
    //    this.TBUname.Focus();
    //  }
    //  else
    //  {
    //     this.EAutoLogin();
    //   }
    //}

    private void Theout(object source, ElapsedEventArgs e)
    {
      if (this.thread != null)
        this.thread.Abort();
      this.thread = new Thread(new ThreadStart(this.FillDataTable2));
      this.thread.IsBackground = true;
      this.thread.Start();
    }

    private void FillDataTable2()
    {
      if (!this.LTip.InvokeRequired)
        return;
      if (!this.LTip.IsDisposed)
      {
        try
        {
          this.LTip.Invoke((Delegate) new Index.SetLabelDelegate(this.SetLabeDo));
        }
        catch (ArgumentException ex)
        {
          int num = (int) MessageBox.Show(ex.ToString());
        }
      }
    }

    private void SetLabeDo()
    {
      this.strResult = this.strResult.Trim();
      if (!Common.IsNullorEmpty(this.strResult) && this.strResult.IndexOf("Connection refused") == -1)
      {
        if (this.timer != null)
        {
          this.timer.Stop();
          this.timer.Dispose();
          this.timer = (System.Timers.Timer) null;
        }
        ViM viM = new JavaScriptSerializer().Deserialize<ViM>(this.strResult);
        if (Common.DecodeUnicode(viM.IsPassed).Equals("false"))
        {
          if (this.t != null)
            this.t.Abort();
          Index.i = 0;
          this.k = 0;
          this.LTip.Text = "";
          if (Desktop.remember)
          {
            this.TBUname.Enabled = true;
            this.TBPwd.Enabled = true;
            this.PBRemember.Image = (Image) Resource1.remember1;
            RWSeting.Write("remember", "false");
            Desktop.remember = false;
          }
          if (Desktop.autoLogin)
          {
            this.PBAutoLogin.Image = (Image) Resource1.autologin1;
            RWSeting.Write("autoLogin", "false");
            Desktop.autoLogin = false;
          }
          if (Desktop.lockText)
          {
            this.TBUname.Enabled = true;
            this.TBPwd.Enabled = true;
            RWSeting.Write("locktext", "false");
            Desktop.lockText = false;
          }
          this.loading.Close();
          this.PBLogin.Enabled = true;
          this.PMain.Visible = true;
          this.TBUname.Visible = true;
          this.TBPwd.Visible = true;
          this.PBLogin.Visible = true;
          // By esage 2016-08-04
          this.PBLoginbutton.Visible = true; 
         //
          this.PBRemember.Visible = true;
          this.PBAutoLogin.Visible = true;
          this.PBLogo1.Visible = true;
          this.PUname.Visible = true;
          this.PPwd.Visible = true;
          this.LCompanyName.Visible = true;
          this.LAddress.Visible = true;
          this.RegistHotKey();
        }
        else
        {
          string str1 = Common.DecodeUnicode(viM.VM);
          string str2 = Common.DecodeUnicode(viM.PreUserName);
          string str3 = Common.DecodeUnicode(viM.PrePassword);
          string str4 = Common.DecodeUnicode(viM.Remember);
          string str5 = Common.DecodeUnicode(viM.AutoLogin);
          string str6 = Common.DecodeUnicode(viM.UserCenter);
          string str7 = Common.DecodeUnicode(viM.RedirectDrives);
          string str8 = Common.DecodeUnicode(viM.RedirectPrinters);
          string str9 = Common.DecodeUnicode(viM.RedirectPorts);
          string str10 = Common.DecodeUnicode(viM.RedirectSmartCards);
          string str11 = Common.DecodeUnicode(viM.RedirectDevices);
          string str12 = Common.DecodeUnicode(viM.Domain);
          string str13 = Common.DecodeUnicode(viM.IsPreset);
          RWSeting.Write("IsPreSet", str13);
          Desktop.isPreset = bool.Parse(str13);
          Desktop.preUsername = Common.DecodeBase64(str2);
          Desktop.prePassword = Common.DecodeBase64(str3);
          Desktop.isRemember = bool.Parse(str4);
          RWSeting.Write("isRemember", str4);
          Desktop.isAutoLogin = bool.Parse(str5);
          RWSeting.Write("isAutoLogin", str5);
          Desktop.isUserCenter = bool.Parse(str6);
          RWSeting.Write("isUserCenter", str6);
          Desktop.redirectDrives = bool.Parse(str7);
          RWSeting.Write("redirectDrives", str7);
          Desktop.redirectPrinters = bool.Parse(str8);
          RWSeting.Write("redirectPrinters", str8);
          Desktop.redirectPorts = bool.Parse(str9);
          RWSeting.Write("redirectPorts", str9);
          Desktop.redirectSmartCards = bool.Parse(str10);
          RWSeting.Write("redirectSmartCards", str10);
          Desktop.redirectDevices = bool.Parse(str11);
          RWSeting.Write("redirectDevices", str11);
          Desktop.domain = str12.Equals("") ? "" : str12.Substring(0, str12.LastIndexOf("."));
          if (str1.Equals(""))
          {
            if (this.t != null)
              this.t.Abort();
            Index.i = 0;
            this.k = 0;
            this.LTip.Text = "没有足够桌面分配，请联系管理员";
            this.PMain.Visible = true;
            this.TBUname.Visible = true;
            this.TBPwd.Visible = true;
            this.PBLogin.Visible = true;
            this.PBRemember.Visible = true;
            this.PBAutoLogin.Visible = true;
            this.PBLogo1.Visible = true;
            this.PUname.Visible = true;
            this.PPwd.Visible = true;
            // By esage 2016-08-04
            this.PBLoginbutton.Visible = true;
            //
            this.LCompanyName.Visible = true;
            this.LAddress.Visible = true;
            if (Desktop.autoLogin)
            {
              this.PBAutoLogin.Image = (Image) Resource1.autologin1;
              Desktop.autoLogin = false;
            }
            if (Desktop.lockText)
            {
              this.TBUname.Enabled = true;
              this.TBPwd.Enabled = true;
              Desktop.lockText = false;
            }
            this.PBLogin.Enabled = true;
            if (this.loading != null)
              this.loading.Close();
            this.PBLogin.Enabled = true;
            this.RegistHotKey();
          }
          else
          {
            string[] strArray1 = str1.Split('|');
            Desktop.num = strArray1.Length;
            string str14 = this.TBUname.Text.Trim();
            string str15 = this.TBPwd.Text.Trim();
            Desktop.uname = str14;
            Desktop.pwd = Common.GetSHA(str15);
            if (Desktop.remember)
            {
              RWSeting.Write("uname", str14);
              RWSeting.Write("pwd", str15);
              RWSeting.Write("remember", "true");
              Desktop.remember = true;
            }
            else
            {
              RWSeting.Write("uname", str14);
              RWSeting.Write("pwd", "");
              RWSeting.Write("remember", "false");
              Desktop.remember = false;
            }
            if (Desktop.autoLogin)
            {
              RWSeting.Write("autoLogin", "true");
              Desktop.autoLogin = true;
            }
            else
            {
              RWSeting.Write("autoLogin", "false");
              Desktop.autoLogin = false;
            }
            if (strArray1.Length == 1)
            {
              string[] strArray2 = strArray1[0].Split('=');
              Desktop.computername1 = strArray2[0];
              Desktop.ip1 = strArray2[1];
              Desktop.cpu1 = strArray2[2];
              Desktop.memory1 = strArray2[3];
              Desktop.storage1 = strArray2[4];
              Desktop.vm1 = strArray2[6];
              if (strArray2[5].Equals("1"))
              {
                if (this.t != null)
                  this.t.Abort();
                Index.i = 0;
                this.k = 0;
                this.LTip.Text = "桌面已关闭，请联系管理员";
                this.PMain.Visible = true;
                this.TBUname.Visible = true;
                this.TBPwd.Visible = true;
                this.PBLogin.Visible = true;
                this.PBRemember.Visible = true;
                this.PBAutoLogin.Visible = true;
                this.PBLogo1.Visible = true;
                this.PUname.Visible = true;
                this.PPwd.Visible = true;
                // By esage 2016-08-04
                this.PBLoginbutton.Visible = true;
                //
                this.LCompanyName.Visible = true;
                this.LAddress.Visible = true;
                if (Desktop.autoLogin)
                {
                  this.PBAutoLogin.Image = (Image) Resource1.autologin1;
                  Desktop.autoLogin = false;
                }
                if (Desktop.lockText)
                {
                  this.TBUname.Enabled = true;
                  this.TBPwd.Enabled = true;
                  Desktop.lockText = false;
                }
                this.PBLogin.Enabled = true;
                this.loading.Close();
                this.RegistHotKey();
              }
              else if (strArray2[5].Equals("2"))
              {
                if (this.t != null)
                  this.t.Abort();
                Index.i = 0;
                this.k = 0;
                this.LTip.Text = "桌面正在准备中，请耐心等待";
                this.PMain.Visible = true;
                this.TBUname.Visible = true;
                this.TBPwd.Visible = true;
                this.PBLogin.Visible = true;
                this.PBRemember.Visible = true;
                this.PBAutoLogin.Visible = true;
                this.PBLogo1.Visible = true;
                this.PUname.Visible = true;
                this.PPwd.Visible = true;
                // By esage 2016-08-04
                this.PBLoginbutton.Visible = true;
                //
                this.LCompanyName.Visible = true;
                this.LAddress.Visible = true;
                if (Desktop.autoLogin)
                {
                  this.PBAutoLogin.Image = (Image) Resource1.autologin1;
                  Desktop.autoLogin = false;
                }
                if (Desktop.lockText)
                {
                  this.TBUname.Enabled = true;
                  this.TBPwd.Enabled = true;
                  Desktop.lockText = false;
                }
                this.PBLogin.Enabled = true;
                this.loading.Close();
                this.RegistHotKey();
              }
              else
              {
                RWSeting.Write("vm", Desktop.vm1);
                Desktop.ip = Desktop.ip1;
                Desktop.computerName = Desktop.computername1;
                if (Common.IsNullorEmpty(Desktop.ip) || !Desktop.isOpen)
                  return;
                Index.i = 0;
                if (this.show == null || this.show.IsDisposed)
                  this.show = new Show();
                else
                  this.show.Activate();
                this.show.Owner = (Form) this;
                this.show.ChangeTip += new ChangeFormTip(this.f_ChangeTip);
                this.show.ChangeTip2 += new ChangeFormTip2(this.f_ChangeTip2);
                this.show.Show();
              }
            }
            else if (strArray1.Length == 2)
            {
              if (this.t != null)
                this.t.Abort();
              if (this.timer != null)
              {
                this.timer.Stop();
                this.timer.Dispose();
                this.timer = (System.Timers.Timer) null;
              }
              if (this.thread != null)
              {
                this.thread.Abort();
                this.thread = (Thread) null;
              }
              string[] strArray2 = strArray1[0].Split('=');
              Desktop.computername1 = strArray2[0];
              Desktop.ip1 = strArray2[1];
              Desktop.cpu1 = strArray2[2];
              Desktop.memory1 = strArray2[3];
              Desktop.storage1 = strArray2[4];
              Desktop.vm1 = strArray2[6];
              string[] strArray3 = strArray1[1].Split('=');
              Desktop.computername2 = strArray3[0];
              Desktop.ip2 = strArray3[1];
              Desktop.cpu2 = strArray3[2];
              Desktop.memory2 = strArray3[3];
              Desktop.storage2 = strArray3[4];
              Desktop.vm2 = strArray3[6];
              this.loading.Close();
            }
            else if (strArray1.Length == 3)
            {
              if (this.t != null)
                this.t.Abort();
              if (this.timer != null)
              {
                this.timer.Stop();
                this.timer.Dispose();
                this.timer = (System.Timers.Timer) null;
              }
              if (this.thread != null)
              {
                this.thread.Abort();
                this.thread = (Thread) null;
              }
              string[] strArray2 = strArray1[0].Split('=');
              Desktop.computername1 = strArray2[0];
              Desktop.ip1 = strArray2[1];
              Desktop.cpu1 = strArray2[2];
              Desktop.memory1 = strArray2[3];
              Desktop.storage1 = strArray2[4];
              Desktop.vm1 = strArray2[6];
              string[] strArray3 = strArray1[1].Split('=');
              Desktop.computername2 = strArray3[0];
              Desktop.ip2 = strArray3[1];
              Desktop.cpu2 = strArray3[2];
              Desktop.memory2 = strArray3[3];
              Desktop.storage2 = strArray3[4];
              Desktop.vm2 = strArray3[6];
              string[] strArray4 = strArray1[2].Split('=');
              Desktop.computername3 = strArray4[0];
              Desktop.ip3 = strArray4[1];
              Desktop.cpu3 = strArray4[2];
              Desktop.memory3 = strArray4[3];
              Desktop.storage3 = strArray4[4];
              Desktop.vm3 = strArray4[6];
              this.loading.Close();
            }
            else
            {
              if (strArray1.Length != 4)
                return;
              if (this.t != null)
                this.t.Abort();
              if (this.timer != null)
              {
                this.timer.Stop();
                this.timer.Dispose();
                this.timer = (System.Timers.Timer) null;
              }
              if (this.thread != null)
              {
                this.thread.Abort();
                this.thread = (Thread) null;
              }
              string[] strArray2 = strArray1[0].Split('=');
              Desktop.computername1 = strArray2[0];
              Desktop.ip1 = strArray2[1];
              Desktop.cpu1 = strArray2[2];
              Desktop.memory1 = strArray2[3];
              Desktop.storage1 = strArray2[4];
              Desktop.vm1 = strArray2[6];
              string[] strArray3 = strArray1[1].Split('=');
              Desktop.computername2 = strArray3[0];
              Desktop.ip2 = strArray3[1];
              Desktop.cpu2 = strArray3[2];
              Desktop.memory2 = strArray3[3];
              Desktop.storage2 = strArray3[4];
              Desktop.vm2 = strArray3[6];
              string[] strArray4 = strArray1[2].Split('=');
              Desktop.computername3 = strArray4[0];
              Desktop.ip3 = strArray4[1];
              Desktop.cpu3 = strArray4[2];
              Desktop.memory3 = strArray4[3];
              Desktop.storage3 = strArray4[4];
              Desktop.vm3 = strArray4[6];
              string[] strArray5 = strArray1[3].Split('=');
              Desktop.computername4 = strArray5[0];
              Desktop.ip4 = strArray5[1];
              Desktop.cpu4 = strArray5[2];
              Desktop.memory4 = strArray5[3];
              Desktop.storage4 = strArray5[4];
              Desktop.vm4 = strArray5[6];
              this.loading.Close();
            }
          }
        }
      }
      else
      {
        ++Index.i;
        if (Index.i <= 5)
          return;
        if (this.timer != null)
        {
          this.timer.Stop();
          this.timer.Dispose();
          this.timer = (System.Timers.Timer) null;
        }
        if (this.t != null)
        {
          this.t.Abort();
          this.t = (Thread) null;
        }
        this.k = 0;
        Index.i = 0;
        this.PMain.Visible = true;
        this.TBUname.Visible = true;
        this.TBPwd.Visible = true;
        this.PBLogin.Visible = true;
        this.PBRemember.Visible = true;
        this.PBAutoLogin.Visible = true;
        this.PBLogo1.Visible = true;
        this.PUname.Visible = true;
        this.PPwd.Visible = true;
        // By esage 2016-08-04
        this.PBLoginbutton.Visible = true;
        //
        this.LCompanyName.Visible = true;
        this.LAddress.Visible = true;
        if (Desktop.autoLogin)
        {
          this.PBAutoLogin.Image = (Image) Resource1.autologin1;
          Desktop.autoLogin = false;
        }
        if (Desktop.lockText)
        {
          this.TBUname.Enabled = true;
          this.TBPwd.Enabled = true;
          Desktop.lockText = false;
        }
        this.PBLogin.Enabled = true;
        this.loading.Close();
        this.LTip.Text = "连接超时，请检查服务器地址";
        this.RegistHotKey();
      }
    }

    private void GetIP(string uname, string pwd)
    {
      string str1 = Desktop.server;
      if (str1.Equals(""))
      {
        this.LTip.Text = "请输入服务端地址";
        this.k = 0;
      }
      else
      {
        string str2 = "parm=login&username=" + HttpUtility.UrlEncode(HttpUtility.UrlEncode(uname)) + "&password=" + Common.GetSHA(pwd) + "&ip=" + Common.GetIP();

        string url = str1.IndexOf(":") <= -1 ? "http://" + str1 + ":8080/user.do?" + str2 : "http://" + str1 + "/user.do?" + str2;
       
        this.GetReq(url);

        if (this.t == null)
          this.PBLogin.Enabled = false;
        if (this.timer == null)
        {
          this.LTip.Text = "";
          this.timer = new System.Timers.Timer(3000.0);
          this.timer.Elapsed += new ElapsedEventHandler(this.Theout);
          this.timer.AutoReset = true;
          this.timer.Enabled = true;
          if (this.IsDisposed)
          {
            this.timer.Stop();
            this.timer.Dispose();
            this.timer = (System.Timers.Timer) null;
          }
        }
      }
    }

    private void GetReq(string url)
    {
      try
      {
        this.strResult = "";
        this.req = (HttpWebRequest) WebRequest.Create(new Uri(url));
        this.req.Method = "GET";
        this.req.KeepAlive = false;
        this.req.UserAgent = "MSIE 7.0; Windows NT 5.1";
        this.req.Timeout = 2000;
        this.req.ReadWriteTimeout = 2000;
        this.req.AllowAutoRedirect = false;
        this.req.BeginGetResponse(new AsyncCallback(this.ReadCallback), (object) this.req);
      }
      catch (Exception ex)
      {
       // By esage 2016-07-01 
       this.strResult = ex.Message;
      //  
        this.strResult = "";
      }
    }

    private void ReadCallback(IAsyncResult asynchronousResult)
    {
      HttpWebRequest httpWebRequest = (HttpWebRequest) asynchronousResult.AsyncState;
      try
      {
        HttpWebResponse httpWebResponse = (HttpWebResponse) httpWebRequest.EndGetResponse(asynchronousResult);
        using (Stream responseStream = httpWebResponse.GetResponseStream())
        {
          using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
          {
            this.strResult = streamReader.ReadToEnd();

            streamReader.Close();
          }
          responseStream.Close();
        }
        if (httpWebResponse == null)
          return;
        httpWebResponse.Close();
      }
      catch
      {
        this.strResult = "";
      }
    }

    private string GetPageHTML(string url)
    {
      string str = "";
      try
      {
        HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(url);
        httpWebRequest.Method = "GET";
        httpWebRequest.UserAgent = "MSIE 7.0; Windows NT 5.1";
        httpWebRequest.KeepAlive = false;
        httpWebRequest.Timeout = 2000;
        httpWebRequest.ReadWriteTimeout = 2000;
        httpWebRequest.AllowAutoRedirect = false;
        HttpWebResponse httpWebResponse = (HttpWebResponse) httpWebRequest.GetResponse();
        using (Stream responseStream = httpWebResponse.GetResponseStream())
        {
          using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
          {
            str = streamReader.ReadToEnd();
            streamReader.Close();
          }
          responseStream.Close();
        }
        httpWebResponse.Close();
      }
      catch
      {
        str = "";
      }
      return str;
    }

    private string GetPageHTML2(string url)
    {
      string str = "";
      try
      {
        HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(url);
        httpWebRequest.Method = "GET";
        httpWebRequest.Accept = "*/*";
        httpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; InfoPath.2; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)";
        httpWebRequest.KeepAlive = true;
        httpWebRequest.ServicePoint.ConnectionLimit = 100;
        httpWebRequest.AllowAutoRedirect = true;
        httpWebRequest.Timeout = 50000;
        using (HttpWebResponse httpWebResponse = (HttpWebResponse) httpWebRequest.GetResponse())
        {
          using (Stream responseStream = httpWebResponse.GetResponseStream())
          {
            responseStream.ReadTimeout = 1000;
            using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
              str = streamReader.ReadToEnd();
          }
        }
      }
      catch
      {
        str = "";
      }
      return str;
    }

    public void Login2()
    {
      if (this.InvokeRequired)
      {
        this.Invoke((Delegate) new Index.ReadDelegate(this.Login2), new object[0]);
      }
      else
      {
        string uname = this.TBUname.Text.Trim();
        string pwd = this.TBPwd.Text.Trim();
        if (uname.Equals("") || pwd.Equals("") || uname.Equals("1"))
        {
          if (this.timer != null)
          {
            this.timer.Stop();
            this.timer.Dispose();
            this.timer = (System.Timers.Timer) null;
          }
          if (this.thread != null)
          {
            this.thread.Abort();
            this.thread = (Thread) null;
          }
          if (this.t != null)
          {
            this.t.Abort();
            this.t = (Thread) null;
          }
          this.k = 0;
          Index.i = 0;
          this.LTip.Text = "请输入用户名密码";
          if (Desktop.autoLogin)
          {
            this.PBAutoLogin.Image = (Image) Resource1.autologin1;
            RWSeting.Write("autoLogin", "false");
            Desktop.autoLogin = false;
          }
          if (Desktop.remember)
          {
            this.PBRemember.Image = (Image) Resource1.remember1;
            RWSeting.Write("remember", "false");
            Desktop.remember = false;
          }
          this.RegistHotKey();
        }
        else
        {
          this.GetIP(uname, pwd);
          if (Desktop.isOpen)
          {
            if (this.loading == null || this.loading.IsDisposed)
              this.loading = new Loading();
            else
              this.loading.Activate();
            this.loading.Owner = (Form) this;
            this.loading.Show();
          }
        }
      }
    }

    private void Login_Click(object sender, EventArgs e)
    {
      if (Desktop.autoLogin || this.k != 0)
        return;
      this.k = 1;
      this.Login3();
    }

    public void Login3()
    {
      if (this.TBUname.Text.Equals("1") && this.TBPwd.Text.Equals("1"))
      {
        HotKey.UnregisterHotKey(this.Handle, 108);
        this.k = 0;
        Index.i = 0;

        if (this.t == null)
        {
            this.LTip.Text = "";
        }
          
        if (this.setting == null || this.setting.IsDisposed)
        {
            this.setting = new Setting();
        }
        else
        {
            this.setting.Activate();
        }
          
        this.setting.FormClosed += new FormClosedEventHandler(this.setting_FormClosed);
        this.setting.Owner = (Form) this;
        this.setting.Show();
      }
      else
        this.Login2();
    }

    private void setting_FormClosed(object sender, FormClosedEventArgs e)
    {
      this.RegistHotKey();
    }

    protected override void WndProc(ref Message m)
    {
      if (m.Msg == 786)
      {
        switch (m.WParam.ToInt32())
        {
          case 100:
            if (!Desktop.lockText)
            {
              this.TBUname.Enabled = false;
              this.TBPwd.Enabled = false;
              this.PBRemember.Image = Desktop.remember ? (Image) Resource1.remember4 : (Image) Resource1.remember3;
              this.PBAutoLogin.Image = Desktop.autoLogin ? (Image) Resource1.autologin4 : (Image) Resource1.autologin3;
              RWSeting.Write("locktext", "true");
              Desktop.lockText = true;
              this.LTip.Text = "文本框已锁定，请按 Ctrl + F1 解锁";
              break;
            }
            break;
          case 101:
            if (this.timer != null)
            {
              this.timer.Stop();
              this.timer.Dispose();
              this.timer = (System.Timers.Timer) null;
            }
            if (this.thread != null)
            {
              this.thread.Abort();
              this.thread = (Thread) null;
            }
            if (this.t != null)
            {
              this.t.Abort();
              this.t = (Thread) null;
            }
            this.EnterExplorer3();
            Environment.Exit(0);
            break;
          case 102:
            if (Desktop.lockText)
            {
              this.TBUname.Enabled = true;
              this.TBPwd.Enabled = true;
              this.PBRemember.Image = Desktop.remember ? (Image) Resource1.remember2 : (Image) Resource1.remember1;
              this.PBAutoLogin.Image = Desktop.autoLogin ? (Image) Resource1.autologin2 : (Image) Resource1.autologin1;
              RWSeting.Write("locktext", "false");
              Desktop.lockText = false;
              this.LTip.Text = "文本框已解锁，请按 Shift+F1 锁定";
              break;
            }
            break;
          case 105:
            if (!Desktop.lockTask)
            {
              Index.StopSystemKeys();
              this.inputHook.Lock_SysKey(true);
              RWSeting.Write("locktask", "true");
              Desktop.lockTask = true;
              this.EnterKisok1();
              this.LTip.Text = "屏蔽任务管理器，请按 Ctrl + F2 启动";
              break;
            }
            break;
          case 106:
            if (Desktop.lockTask)
            {
              Index.UseSystemKeys();
              this.inputHook.Lock_SysKey(false);
              RWSeting.Write("locktask", "false");
              Desktop.lockTask = false;
              this.LTip.Text = "启动任务管理器，请按 Shift+F2 屏蔽";
              break;
            }
            break;
          case 107:
            this.EnterKisok2();
            break;
          case 108:
            if (!Desktop.autoLogin && this.k == 0)
            {
              this.k = 1;
              this.Login3();
              break;
            }
            break;
          case 109:
            if (!Desktop.autoLogin && this.k == 0)
            {
              this.k = 1;
              this.Login3();
              break;
            }
            break;
          case 110:
            string text1 = this.TBUname.Text;
            string text2 = this.TBPwd.Text;
            if (!Common.IsNullorEmpty(text1) && !Common.IsNullorEmpty(text2) && !text1.Equals("1") && !text2.Equals("1"))
            {
              RWSeting.Write("uname", text1);
              RWSeting.Write("pwd", text2);
              Desktop.uname = text1;
              Desktop.pwd = Common.GetSHA(text2);
              if (!Desktop.lockText)
              {
                this.TBUname.Enabled = false;
                this.TBPwd.Enabled = false;
                this.PBRemember.Image = Desktop.remember ? (Image) Resource1.remember4 : (Image) Resource1.remember3;
                this.PBAutoLogin.Image = Desktop.autoLogin ? (Image) Resource1.autologin4 : (Image) Resource1.autologin3;
                RWSeting.Write("locktext", "true");
                Desktop.lockText = true;
              }
              if (!Desktop.lockTask)
              {
                Index.StopSystemKeys();
                this.inputHook.Lock_SysKey(true);
                RWSeting.Write("locktask", "true");
                Desktop.lockTask = true;
                this.EnterKisok1();
              }
              this.PBRemember.Image = (Image) Resource1.remember2;
              RWSeting.Write("remember", "true");
              this.PBAutoLogin.Image = (Image) Resource1.autologin2;
              RWSeting.Write("autoLogin", "true");
              Process.Start("shutdown", "/r /t 0");
              break;
            }
            this.LTip.Text = "用户名和密码不能为空";
            return;
          case 111:
            if (this.timer != null)
            {
              this.timer.Stop();
              this.timer.Dispose();
              this.timer = (System.Timers.Timer) null;
            }
            if (this.thread != null)
            {
              this.thread.Abort();
              this.thread = (Thread) null;
            }
            if (this.t != null)
            {
              this.t.Abort();
              this.t = (Thread) null;
            }
            if (Desktop.autoLogin)
            {
              RWSeting.Write("autoLogin", "false");
              Desktop.autoLogin = false;
            }
            if (Desktop.lockText)
            {
              RWSeting.Write("locktext", "false");
              Desktop.lockText = false;
            }
            if (Desktop.lockTask)
            {
              Index.UseSystemKeys();
              this.inputHook.Lock_SysKey(false);
              RWSeting.Write("locktask", "false");
              Desktop.lockTask = false;
            }
            if (Desktop.kisok)
            {
              RWSeting.Write("kisok", "flase");
              Desktop.kisok = false;
            }
            this.EnterExplorer2();
            Environment.Exit(0);
            break;
        }
      }
      base.WndProc(ref m);
    }

    private void NetworkChange_NetworkAvailabilityChanged(object sender, NetworkAvailabilityEventArgs e)
    {
      Index.i = 0;
      if (e.IsAvailable)
      {
        if (Common.IsNullorEmpty(Desktop.server) || !Desktop.autoLogin)
          return;
        this.LTip.Text = "";
        this.PBAutoLogin.Image = (Image) Resource1.autologin2;
        this.PBLogin.Enabled = false;
        if (Desktop.uname.Equals("1"))
          this.TBUname.Focus();
        else
        {
          this.EAutoLogin();
          Desktop.first_autologin = false;
         }
      }
      else
        this.LTip.Text = "当前网络没有连接";
    }

    private void EnterKisok1()
    {
      RegistryKey registryKey = Registry.LocalMachine;
      string name = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
      registryKey.OpenSubKey(name, true).OpenSubKey("Winlogon", true).SetValue("Shell", (object) Common.GetCurrentFile());
      registryKey.Close();
    }

    private void EnterKisok2()
    {
      RWSeting.Write("kisok", "true");
      Desktop.kisok = true;
      RegistryKey registryKey = Registry.LocalMachine;
      string name = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
      registryKey.OpenSubKey(name, true).OpenSubKey("Winlogon", true).SetValue("Shell", (object) Common.GetCurrentFile());
      registryKey.Close();
      Process.Start("explorer.exe");
    }

    private void EnterExplorer1()
    {
      RWSeting.Write("kisok", "false");
      Desktop.kisok = false;
      RegistryKey registryKey = Registry.LocalMachine;
      string name = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
      registryKey.OpenSubKey(name, true).OpenSubKey("Winlogon", true).SetValue("Shell", (object) "Explorer.exe");
      registryKey.Close();
    }

    private void EnterExplorer2()
    {
      RegistryKey registryKey = Registry.LocalMachine;
      string name = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
      registryKey.OpenSubKey(name, true).OpenSubKey("Winlogon", true).SetValue("Shell", (object) "Explorer.exe");
      registryKey.Close();
      Process.Start("explorer.exe");
    }

    private void EnterExplorer3()
    {
      RegistryKey registryKey = Registry.LocalMachine;
      string name = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
      registryKey.OpenSubKey(name, true).OpenSubKey("Winlogon", true).SetValue("Shell", (object) "Explorer.exe");
      registryKey.Close();
      Process.Start("explorer.exe");
    }

    private static void StopSystemKeys()
    {
      RegistryKey registryKey1 = Registry.CurrentUser;
      string name = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies";
      registryKey1.OpenSubKey(name, true).CreateSubKey("System");
      registryKey1.Close();
      RegistryKey registryKey2 = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", true);
      registryKey2.SetValue("DisableTaskMgr", (object) 1, RegistryValueKind.DWord);
      registryKey2.Close();
    }

    private static void UseSystemKeys()
    {
      try
      {
        RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", true);
        if (registryKey.GetValue("DisableTaskMgr") != null)
        {
            registryKey.DeleteValue("DisableTaskMgr", true);
        }
        registryKey.Close();
      }
      catch
      {
      }
    }

    public void RegistHotKey()
    {
      HotKey.RegisterHotKey(this.Handle, 100, HotKey.KeyModifiers.Shift, Keys.F1);
      HotKey.RegisterHotKey(this.Handle, 101, HotKey.KeyModifiers.Ctrl, Keys.D);
      HotKey.RegisterHotKey(this.Handle, 102, HotKey.KeyModifiers.Ctrl, Keys.F1);
      HotKey.RegisterHotKey(this.Handle, 103, HotKey.KeyModifiers.Alt, Keys.Tab);
      HotKey.RegisterHotKey(this.Handle, 104, HotKey.KeyModifiers.Alt, Keys.F4);
      HotKey.RegisterHotKey(this.Handle, 105, HotKey.KeyModifiers.Shift, Keys.F2);
      HotKey.RegisterHotKey(this.Handle, 106, HotKey.KeyModifiers.Ctrl, Keys.F2);
      HotKey.RegisterHotKey(this.Handle, 107, HotKey.KeyModifiers.Shift, Keys.K);
      if (!Desktop.autoLogin)
      {
        HotKey.RegisterHotKey(this.Handle, 108, HotKey.KeyModifiers.None, Keys.Return);
        HotKey.RegisterHotKey(this.Handle, 109, HotKey.KeyModifiers.Shift, Keys.Return);
      }
      HotKey.RegisterHotKey(this.Handle, 110, HotKey.KeyModifiers.Ctrl, Keys.E);
      HotKey.RegisterHotKey(this.Handle, 111, HotKey.KeyModifiers.Alt, Keys.D);
    }

    public void UnRegistHotKey()
    {
      HotKey.UnregisterHotKey(this.Handle, 100);
      HotKey.UnregisterHotKey(this.Handle, 102);
      HotKey.UnregisterHotKey(this.Handle, 103);
      HotKey.UnregisterHotKey(this.Handle, 104);
      HotKey.UnregisterHotKey(this.Handle, 105);
      HotKey.UnregisterHotKey(this.Handle, 106);
      HotKey.UnregisterHotKey(this.Handle, 107);
      HotKey.UnregisterHotKey(this.Handle, 108);
      HotKey.UnregisterHotKey(this.Handle, 109);
      HotKey.UnregisterHotKey(this.Handle, 110);
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
      if (keyData != Keys.Escape)
      {
          return base.ProcessCmdKey(ref msg, keyData);
      }
     

      if (!Desktop.kisok)
      {
        if (this.timer != null)
        {
          this.timer.Stop();
          this.timer.Dispose();
          this.timer = (System.Timers.Timer) null;
        }
        if (this.t != null)
          this.t.Abort();
        this.EnterExplorer1();
        Index.UseSystemKeys();
        this.inputHook.Lock_SysKey(false);
        Environment.Exit(0);
      }
      return true;
    }

    private void PBUserinfo_Click(object sender, EventArgs e)
    {
      this.UnRegistHotKey();
      Desktop.isOpen = false;
      this.Login2();
      Userinfo userinfo = new Userinfo(this.TBUname.Text, this.TBPwd.Text);
      userinfo.Owner = (Form) this;
      userinfo.Show();
    }

    private void PBLoginbutton_Click(object sender, EventArgs e)
    {
        if (!Desktop.autoLogin && this.k == 0)
        {
            this.k = 1;
            this.Login3();
        }
    }

    private void PBRemember_Click(object sender, EventArgs e)
    {
      if (Desktop.lockText)
        return;
      if (!Desktop.remember)
      {
        RWSeting.Write("remember", "true");
        Desktop.remember = true;
        this.PBRemember.Image = (Image) Resource1.remember2;
      }
      else
      {
        RWSeting.Write("remember", "false");
        Desktop.remember = false;
        this.PBRemember.Image = (Image) Resource1.remember1;
      }
    }

    private void PBAutoLogin_Click(object sender, EventArgs e)
    {
      if (Desktop.lockText)
        return;
      if (!Desktop.autoLogin)
      {
        if (!Desktop.remember)
        {
          this.PBRemember.Image = (Image) Resource1.remember2;
          Desktop.remember = true;
        }
        RWSeting.Write("autoLogin", "true");
        Desktop.autoLogin = true;
        this.PBAutoLogin.Image = (Image) Resource1.autologin2;
        if (!Common.IsNullorEmpty(Desktop.server) && Desktop.autoLogin)
        {
          this.PBLogin.Enabled = false;
          if (this.TBUname.Text.Trim().Equals("1"))
          {
              this.LTip.Text = "";
              this.TBUname.Focus();
          }
          else
          {
              this.EAutoLogin();
              Desktop.first_autologin = false;
          }
        }
      }
      else
      {
        RWSeting.Write("autoLogin", "false");
        Desktop.autoLogin = false;
        this.PBAutoLogin.Image = (Image) Resource1.autologin1;
        this.PBLogin.Enabled = true;
        if (this.timer != null)
        {
          this.timer.Stop();
          this.timer.Dispose();
          this.timer = (System.Timers.Timer) null;
        }
        if (this.thread != null)
        {
          this.thread.Abort();
          this.thread = (Thread) null;
        }
        if (this.t != null)
        {
          this.t.Abort();
          this.t = (Thread) null;
        }
      }
    }

    private void Close_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void Uname_TextChanged(object sender, EventArgs e)
    {
      this.LTip.Text = "";
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Index));
      this.ILClosePic = new ImageList(this.components);
      this.LCompanyName = new Label();
      this.TBPwd = new TextBox();
      this.TBUname = new TextBox();
      this.LAddress = new Label();
      this.PMain = new BackgroundPanel();
      this.PBAutoLogin = new PictureBox();
      this.PBRemember = new PictureBox();
      this.PBUserinfo = new PictureBox();
      this.PBLogo1 = new PictureBox();
      this.LTip = new Label();
      this.PUname = new BackgroundPanel();
      this.PPwd = new BackgroundPanel();
      this.PBLogin = new PictureBox();
      // By esage 2016-08-04
      this.PBLoginbutton = new Button();
      //
      this.PMain.SuspendLayout();
      ((ISupportInitialize) this.PBAutoLogin).BeginInit();
      ((ISupportInitialize) this.PBRemember).BeginInit();
      ((ISupportInitialize) this.PBUserinfo).BeginInit();
      ((ISupportInitialize) this.PBLogo1).BeginInit();
      this.PPwd.SuspendLayout();
      ((ISupportInitialize) this.PBLogin).BeginInit();
      this.SuspendLayout();
      this.ILClosePic.ColorDepth = ColorDepth.Depth8Bit;
      this.ILClosePic.ImageSize = new Size(16, 16);
      this.ILClosePic.TransparentColor = System.Drawing.Color.Transparent;
      this.LCompanyName.AutoSize = true;
      this.LCompanyName.BackColor = System.Drawing.Color.Transparent;
      this.LCompanyName.Font = new Font("微软雅黑", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.LCompanyName.ForeColor = SystemColors.Control;
      this.LCompanyName.Location = new Point(671, 798);
      this.LCompanyName.Name = "LCompanyName";
      this.LCompanyName.Size = new Size(112, 19);
      this.LCompanyName.TabIndex = 18;
      this.LCompanyName.Text = "LCompanyName";
      this.LCompanyName.TextAlign = ContentAlignment.MiddleCenter;
      this.LCompanyName.Visible = false;
      this.TBPwd.BackColor = System.Drawing.Color.White;
      this.TBPwd.BorderStyle = BorderStyle.None;
      this.TBPwd.Font = new Font("幼圆", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 134);
      this.TBPwd.ForeColor = System.Drawing.Color.FromArgb(64, 64, 64);
      this.TBPwd.Location = new Point(203, 231);
      this.TBPwd.MaxLength = 15;
      this.TBPwd.Name = "TBPwd";
      this.TBPwd.PasswordChar = '*';
      this.TBPwd.Size = new Size(163, 18);
      this.TBPwd.TabIndex = 4;
      // By esage 2016-08-04
      this.PBLoginbutton.BackColor = System.Drawing.Color.GreenYellow;
      this.PBLoginbutton.Font = new Font("微软雅黑", 10f, FontStyle.Regular, GraphicsUnit.Point, (byte)16);
      this.PBLoginbutton.Location = new Point(400, 224);
      this.PBLoginbutton.Name = "PBLoginbutton";
      this.PBLoginbutton.Size = new Size(80, 30);
      this.PBLoginbutton.Text = "登 陆";
      this.PBLoginbutton.TabIndex = 5;
      this.PBLoginbutton.Click += new EventHandler(this.PBLoginbutton_Click);
      //
      this.TBUname.BackColor = System.Drawing.Color.White;
      this.TBUname.BorderStyle = BorderStyle.None;
      this.TBUname.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.TBUname.ForeColor = System.Drawing.Color.FromArgb(64, 64, 64);
      this.TBUname.Location = new Point(204, 183);
      this.TBUname.MaxLength = 15;
      this.TBUname.Name = "TBUname";
      this.TBUname.Size = new Size(190, 19);
      this.TBUname.TabIndex = 3;
      this.LAddress.AutoSize = true;
      this.LAddress.BackColor = System.Drawing.Color.Transparent;
      this.LAddress.Font = new Font("微软雅黑", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.LAddress.ForeColor = SystemColors.Control;
      this.LAddress.Location = new Point(690, 826);
      this.LAddress.Name = "LAddress";
      this.LAddress.Size = new Size(65, 19);
      this.LAddress.TabIndex = 19;
      this.LAddress.Text = "LAddress";
      this.LAddress.TextAlign = ContentAlignment.MiddleCenter;
      this.LAddress.Visible = false;
      this.PMain.Anchor = AnchorStyles.None;
      this.PMain.AutoSize = true;
      this.PMain.BackColor = System.Drawing.Color.White;
      this.PMain.BorderStyle = BorderStyle.FixedSingle;
      this.PMain.Controls.Add((Control) this.PBAutoLogin);
      this.PMain.Controls.Add((Control) this.PBRemember);
      this.PMain.Controls.Add((Control) this.PBUserinfo);
      this.PMain.Controls.Add((Control) this.PBLogo1);
      this.PMain.Controls.Add((Control) this.LTip);
      this.PMain.Controls.Add((Control) this.PUname);
      this.PMain.Controls.Add((Control) this.PPwd);
      // By esage 2016-08-04
      this.PMain.Controls.Add((Control)this.PBLoginbutton);
      //
      this.PMain.Location = new Point(421, 291);
      this.PMain.Name = "PMain";
      this.PMain.Size = new Size(600, 443);
      this.PMain.TabIndex = 15;
      this.PMain.Visible = false;
      this.PBAutoLogin.Cursor = Cursors.Hand;
      this.PBAutoLogin.Image = (Image) componentResourceManager.GetObject("PBAutoLogin.Image");
      this.PBAutoLogin.Location = new Point(306, 270);
      this.PBAutoLogin.Name = "PBAutoLogin";
      this.PBAutoLogin.Size = new Size(87, 20);
      this.PBAutoLogin.TabIndex = 19;
      this.PBAutoLogin.TabStop = false;
      this.PBAutoLogin.Click += new EventHandler(this.PBAutoLogin_Click);
      this.PBRemember.Cursor = Cursors.Hand;
      this.PBRemember.Image = (Image) componentResourceManager.GetObject("PBRemember.Image");
      this.PBRemember.Location = new Point(198, 270);
      this.PBRemember.Name = "PBRemember";
      this.PBRemember.Size = new Size(87, 20);
      this.PBRemember.TabIndex = 18;
      this.PBRemember.TabStop = false;
      this.PBRemember.Click += new EventHandler(this.PBRemember_Click);
      this.PBUserinfo.Cursor = Cursors.Hand;
      this.PBUserinfo.Image = (Image) componentResourceManager.GetObject("PBUserinfo.Image");
      // By esage 2016-08-04   
      // this.PBUserinfo.Location = new Point(215, 315);
      this.PBUserinfo.Location = new Point(215, 350);
      // 
      this.PBUserinfo.Name = "PBUserinfo";
      this.PBUserinfo.Size = new Size(160, 34);
      this.PBUserinfo.TabIndex = 17;
      this.PBUserinfo.TabStop = false;
      this.PBUserinfo.Click += new EventHandler(this.PBUserinfo_Click);
      this.PBLogo1.Image = (Image) componentResourceManager.GetObject("PBLogo1.Image");
      this.PBLogo1.Location = new Point(236, 97);
      this.PBLogo1.Name = "PBLogo1";
      this.PBLogo1.Size = new Size(125, 48);
      this.PBLogo1.TabIndex = 0;
      this.PBLogo1.TabStop = false;
      this.PBLogo1.Visible = false;
      this.LTip.AutoSize = true;
      this.LTip.BackColor = System.Drawing.Color.Transparent;
      this.LTip.Font = new Font("微软雅黑", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 134);
      // By esage 2016-08-05
      //this.LTip.ForeColor = System.Drawing.Color.Khaki;
      this.LTip.ForeColor = System.Drawing.Color.Red;
      // 
      this.LTip.Location = new Point(197, 317);
      this.LTip.Name = "LTip";
      this.LTip.Size = new Size(0, 17);
      this.LTip.TabIndex = 8;
      this.PUname.BackColor = System.Drawing.Color.White;
      this.PUname.BorderStyle = BorderStyle.FixedSingle;
      this.PUname.Location = new Point(200, 179);
      this.PUname.Name = "PUname";
      this.PUname.Size = new Size(197, 26);
      this.PUname.TabIndex = 1;
      this.PUname.Visible = false;
      this.PPwd.BackColor = System.Drawing.Color.White;
      this.PPwd.BorderStyle = BorderStyle.FixedSingle;
      this.PPwd.Controls.Add((Control) this.PBLogin);
      this.PPwd.Location = new Point(200, 226);
      this.PPwd.Name = "PPwd";
      this.PPwd.Size = new Size(197, 26);
      this.PPwd.TabIndex = 14;
      this.PPwd.Visible = false;
      this.PBLogin.BackColor = System.Drawing.Color.Transparent;
      this.PBLogin.Cursor = Cursors.Hand;
      this.PBLogin.Location = new Point(203, 1);
      this.PBLogin.Name = "PBLogin";
      this.PBLogin.Size = new Size(26, 30);
      this.PBLogin.TabIndex = 1;
      this.PBLogin.TabStop = false;
      this.PBLogin.Visible = false;
      this.PBLogin.Click += new EventHandler(this.Login_Click);
      this.AutoScaleDimensions = new SizeF(6f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = ImageLayout.None;
      this.ClientSize = new Size(1412, 900);
      this.Controls.Add((Control) this.LAddress);
      this.Controls.Add((Control) this.LCompanyName);
      this.Controls.Add((Control) this.PMain);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Index";
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "易思捷云客户端";
      this.WindowState = FormWindowState.Maximized;
      this.Load += new EventHandler(this.Index_Load);
      this.Shown += new EventHandler(this.Index_Shown);
      this.PMain.ResumeLayout(false);
      this.PMain.PerformLayout();
      ((ISupportInitialize) this.PBAutoLogin).EndInit();
      ((ISupportInitialize) this.PBRemember).EndInit();
      ((ISupportInitialize) this.PBUserinfo).EndInit();
      ((ISupportInitialize) this.PBLogo1).EndInit();
      this.PPwd.ResumeLayout(false);
      ((ISupportInitialize) this.PBLogin).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    private struct KBDLLHOOKSTRUCT
    {
      public Keys key;
      public int scanCode;
      public int flags;
      public int time;
      public IntPtr extra;
    }

    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    private delegate void SetLabelDelegate();

    private delegate void ReadDelegate();
  }
}
