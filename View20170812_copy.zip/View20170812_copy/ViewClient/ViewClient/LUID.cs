﻿
namespace ViewClient
{
  internal struct LUID
  {
    public long lowpart;
    public long highpart;
  }
}
