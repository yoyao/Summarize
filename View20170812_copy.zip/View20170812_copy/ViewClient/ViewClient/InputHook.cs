﻿

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ViewClient
{
  public class InputHook
  {
    private IntPtr m_lHookID = IntPtr.Zero;
    private uint[] m_lShellCode = new uint[317];

    public bool Lock_SomeKey(bool isLock)
    {
      if (isLock)
      {
        if (this.m_lHookID == IntPtr.Zero)
        {
          this.m_lHookID = Win32Lib.SetWindowsHookEx(13, new HookProc(this.LowLevelKeyboardProc), Win32Lib.GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName), 0);
          if (this.m_lHookID == IntPtr.Zero)
          {
            this.Lock_SomeKey(false);
            return false;
          }
        }
        return true;
      }

      bool flag = true;
      if (this.m_lHookID != IntPtr.Zero)
      {
        flag = Win32Lib.UnhookWindowsHookEx(this.m_lHookID);
        this.m_lHookID = IntPtr.Zero;
      }
      return flag;
    }

    public bool Lock_SysKey(bool isLock)
    {
      if ((int) Win32Lib.GlobalFindAtom("Winlogon") == 0 && this.InsertAsmCode() > 0L)
        return false;
        //查找全局原子
      ushort atom = Win32Lib.GlobalFindAtom("HookSysKey");
      if (isLock)
      {
        if ((int) atom == 0)
          Win32Lib.GlobalAddAtom("HookSysKey");
      }
      else if ((int) atom != 0)
      {
        int num = (int) Win32Lib.GlobalDeleteAtom(atom);
      }

      return true;
    }

    private int GetProcessIdFromName(string name)
    {
      foreach (Process process in Process.GetProcesses())
      {
        if (process.ProcessName.ToLower().Replace(".exe", "") == name.ToLower().Replace(".exe", ""))
          return process.Id;
      }
      return -1;
    }

    private void InitShellCode()
    {
      IntPtr moduleHandle = Win32Lib.GetModuleHandle("kernel32.dll");
      this.m_lShellCode[0] = Win32Lib.GetProcAddress(moduleHandle, "GetModuleHandleW").ToUInt32();
      this.m_lShellCode[1] = Win32Lib.GetProcAddress(moduleHandle, "GetProcAddress").ToUInt32();
      this.m_lShellCode[2] = 59475U;
      this.m_lShellCode[3] = 2170224640U;
      this.m_lShellCode[4] = 1074794219U;
      this.m_lShellCode[5] = 37283840U;
      this.m_lShellCode[6] = 3221946368U;
      this.m_lShellCode[7] = 2207076469U;
      this.m_lShellCode[8] = 4198576U;
      this.m_lShellCode[9] = 3499360080U;
      this.m_lShellCode[10] = 251674643U;
      this.m_lShellCode[11] = 3221995703U;
      this.m_lShellCode[12] = 6830709U;
      this.m_lShellCode[13] = 1778515968U;
      this.m_lShellCode[14] = 2365614592U;
      this.m_lShellCode[15] = 1074835587U;
      this.m_lShellCode[16] = 2482982912U;
      this.m_lShellCode[17] = 4198544U;
      this.m_lShellCode[18] = 410304523U;
      this.m_lShellCode[19] = 281187213U;
      this.m_lShellCode[20] = 6946880U;
      this.m_lShellCode[21] = 2482982994U;
      this.m_lShellCode[22] = 4198548U;
      this.m_lShellCode[23] = 74760203U;
      this.m_lShellCode[24] = 183175915U;
      this.m_lShellCode[25] = 277648383U;
      this.m_lShellCode[26] = 48955456U;
      this.m_lShellCode[27] = 3260792883U;
      this.m_lShellCode[28] = 4287299588U;
      this.m_lShellCode[38] = 4259923U;
      this.m_lShellCode[39] = 2097235U;
      this.m_lShellCode[40] = 6881399U;
      this.m_lShellCode[41] = 6553710U;
      this.m_lShellCode[42] = 7798895U;
      this.m_lShellCode[43] = 4287299584U;
      this.m_lShellCode[44] = 6881367U;
      this.m_lShellCode[45] = 7077998U;
      this.m_lShellCode[46] = 6750319U;
      this.m_lShellCode[47] = 7209071U;
      this.m_lShellCode[48] = 2337603584U;
      this.m_lShellCode[49] = 4039410156U;
      this.m_lShellCode[50] = 1409286141U;
      this.m_lShellCode[51] = 232U;
      this.m_lShellCode[52] = 3951123200U;
      this.m_lShellCode[53] = 4198609U;
      this.m_lShellCode[54] = 66664U;
      this.m_lShellCode[55] = 4169501952U;
      this.m_lShellCode[56] = 1358954493U;
      this.m_lShellCode[57] = 4278744575U;
      this.m_lShellCode[58] = 1074823315U;
      this.m_lShellCode[59] = 4169501952U;
      this.m_lShellCode[60] = 1358954493U;
      this.m_lShellCode[61] = 278430605U;
      this.m_lShellCode[62] = 4283433024U;
      this.m_lShellCode[63] = 1074822291U;
      this.m_lShellCode[64] = 1975520000U;
      this.m_lShellCode[65] = 1749052009U;
      this.m_lShellCode[66] = 4096U;
      this.m_lShellCode[67] = 30312U;
      this.m_lShellCode[68] = 4278217216U;
      this.m_lShellCode[69] = 1074820243U;
      this.m_lShellCode[70] = 1958742784U;
      this.m_lShellCode[71] = 2240372820U;
      this.m_lShellCode[72] = 4294966768U;
      this.m_lShellCode[73] = 1979710570U;
      this.m_lShellCode[74] = 2224291592U;
      this.m_lShellCode[75] = 2365603856U;
      this.m_lShellCode[76] = 1075038355U;
      this.m_lShellCode[77] = 4228024576U;
      this.m_lShellCode[78] = 4260412811U;
      this.m_lShellCode[79] = 1991901183U;
      this.m_lShellCode[80] = 2365587456U;
      this.m_lShellCode[81] = 1075016883U;
      this.m_lShellCode[82] = 2376397568U;
      this.m_lShellCode[83] = 1074835587U;
      this.m_lShellCode[84] = 2482982912U;
      this.m_lShellCode[85] = 4198520U;
      this.m_lShellCode[86] = 4260410879U;
      this.m_lShellCode[87] = 4234870783U;
      this.m_lShellCode[88] = 4278744575U;
      this.m_lShellCode[89] = 1074825363U;
      this.m_lShellCode[90] = 3224592640U;
      this.m_lShellCode[91] = 3224568811U;
      this.m_lShellCode[92] = 3267976000U;
      this.m_lShellCode[93] = 7012360U;
      this.m_lShellCode[94] = 7471205U;
      this.m_lShellCode[95] = 6619246U;
      this.m_lShellCode[96] = 3342444U;
      this.m_lShellCode[97] = 3014706U;
      this.m_lShellCode[98] = 7077988U;
      this.m_lShellCode[99] = 108U;
      this.m_lShellCode[100] = 7536757U;
      this.m_lShellCode[101] = 7471205U;
      this.m_lShellCode[102] = 3276851U;
      this.m_lShellCode[103] = 6553646U;
      this.m_lShellCode[104] = 7077996U;
      this.m_lShellCode[105] = 1767243776U;
      this.m_lShellCode[106] = 1635087474U;
      this.m_lShellCode[107] = 1701987948U;
      this.m_lShellCode[108] = 1816592485U;
      this.m_lShellCode[109] = 1818321519U;
      this.m_lShellCode[110] = 1684957510U;
      this.m_lShellCode[111] = 1836020801U;
      this.m_lShellCode[112] = 1816592471U;
      this.m_lShellCode[113] = 1818321519U;
      this.m_lShellCode[114] = 1097098305U;
      this.m_lShellCode[115] = 1466789748U;
      this.m_lShellCode[116] = 1953721344U;
      this.m_lShellCode[117] = 1886217074U;
      this.m_lShellCode[118] = 1325422441U;
      this.m_lShellCode[119] = 1148085616U;
      this.m_lShellCode[120] = 1953198949U;
      this.m_lShellCode[121] = 5730415U;
      this.m_lShellCode[122] = 1836412485U;
      this.m_lShellCode[123] = 1802724676U;
      this.m_lShellCode[124] = 1466986356U;
      this.m_lShellCode[125] = 1868852841U;
      this.m_lShellCode[126] = 1191211895U;
      this.m_lShellCode[(int) sbyte.MaxValue] = 1767339109U;
      this.m_lShellCode[128] = 2003788910U;
      this.m_lShellCode[129] = 1954047316U;
      this.m_lShellCode[130] = 1699151959U;
      this.m_lShellCode[131] = 1852397428U;
      this.m_lShellCode[132] = 1282895716U;
      this.m_lShellCode[133] = 1466396271U;
      this.m_lShellCode[134] = 1952797440U;
      this.m_lShellCode[135] = 1684957527U;
      this.m_lShellCode[136] = 1867282287U;
      this.m_lShellCode[137] = 5728110U;
      this.m_lShellCode[138] = 1819042115U;
      this.m_lShellCode[139] = 1684957527U;
      this.m_lShellCode[140] = 1917876079U;
      this.m_lShellCode[141] = 5727087U;
      this.m_lShellCode[142] = 1282696519U;
      this.m_lShellCode[143] = 1165259617U;
      this.m_lShellCode[144] = 1919906418U;
      this.m_lShellCode[145] = 1919505920U;
      this.m_lShellCode[146] = 1818326388U;
      this.m_lShellCode[147] = 1869376577U;
      this.m_lShellCode[148] = 2337603683U;
      this.m_lShellCode[149] = 4240737260U;
      this.m_lShellCode[150] = 1220555616U;
      this.m_lShellCode[151] = 2382120329U;
      this.m_lShellCode[152] = 1074886275U;
      this.m_lShellCode[153] = 2482982912U;
      this.m_lShellCode[154] = 4198400U;
      this.m_lShellCode[155] = 2215624715U;
      this.m_lShellCode[156] = 250U;
      this.m_lShellCode[157] = 2207119499U;
      this.m_lShellCode[158] = 4198800U;
      this.m_lShellCode[159] = 9699152U;
      this.m_lShellCode[160] = 184565776U;
      this.m_lShellCode[161] = 3817082816U;
      this.m_lShellCode[162] = 2332033024U;
      this.m_lShellCode[163] = 1166249456U;
      this.m_lShellCode[164] = 1342193682U;
      this.m_lShellCode[165] = 76808023U;
      this.m_lShellCode[166] = 2298494992U;
      this.m_lShellCode[167] = 1074820227U;
      this.m_lShellCode[168] = 948145408U;
      this.m_lShellCode[169] = 1342193682U;
      this.m_lShellCode[170] = 76808023U;
      this.m_lShellCode[171] = 2298494992U;
      this.m_lShellCode[172] = 1074826371U;
      this.m_lShellCode[173] = 3263401216U;
      this.m_lShellCode[174] = 1342193681U;
      this.m_lShellCode[175] = 76808023U;
      this.m_lShellCode[176] = 2298494992U;
      this.m_lShellCode[177] = 1074821251U;
      this.m_lShellCode[178] = 2994965760U;
      this.m_lShellCode[179] = 1342193681U;
      this.m_lShellCode[180] = 76808023U;
      this.m_lShellCode[181] = 2298494992U;
      this.m_lShellCode[182] = 1075040387U;
      this.m_lShellCode[183] = 3515059456U;
      this.m_lShellCode[184] = 1342193681U;
      this.m_lShellCode[185] = 76808023U;
      this.m_lShellCode[186] = 2298494992U;
      this.m_lShellCode[187] = 1074822275U;
      this.m_lShellCode[188] = 3682831616U;
      this.m_lShellCode[189] = 1342193681U;
      this.m_lShellCode[190] = 76808022U;
      this.m_lShellCode[191] = 2298494992U;
      this.m_lShellCode[192] = 1074827395U;
      this.m_lShellCode[193] = 3900935424U;
      this.m_lShellCode[194] = 1342193681U;
      this.m_lShellCode[195] = 76808022U;
      this.m_lShellCode[196] = 2298494992U;
      this.m_lShellCode[197] = 1074828419U;
      this.m_lShellCode[198] = 4219702528U;
      this.m_lShellCode[199] = 1342193681U;
      this.m_lShellCode[200] = 76808022U;
      this.m_lShellCode[201] = 2298494992U;
      this.m_lShellCode[202] = 1074823299U;
      this.m_lShellCode[203] = 176393472U;
      this.m_lShellCode[204] = 1342193682U;
      this.m_lShellCode[205] = 76808022U;
      this.m_lShellCode[206] = 2298494992U;
      this.m_lShellCode[207] = 1074824323U;
      this.m_lShellCode[208] = 428051712U;
      this.m_lShellCode[209] = 1342193682U;
      this.m_lShellCode[210] = 76808022U;
      this.m_lShellCode[211] = 2298494992U;
      this.m_lShellCode[212] = 1074825347U;
      this.m_lShellCode[213] = 679709952U;
      this.m_lShellCode[214] = 1342193682U;
      this.m_lShellCode[215] = 76808022U;
      this.m_lShellCode[216] = 2298494992U;
      this.m_lShellCode[217] = 1075039363U;
      this.m_lShellCode[218] = 2311074560U;
      this.m_lShellCode[219] = 2338454597U;
      this.m_lShellCode[220] = 3284794437U;
      this.m_lShellCode[221] = 1408011093U;
      this.m_lShellCode[222] = 232U;
      this.m_lShellCode[223] = 3951123200U;
      this.m_lShellCode[224] = 4199293U;
      this.m_lShellCode[225] = 302808449U;
      this.m_lShellCode[226] = 1962934275U;
      this.m_lShellCode[227] = 3565391132U;
      this.m_lShellCode[228] = 1342193683U;
      this.m_lShellCode[229] = 332436479U;
      this.m_lShellCode[230] = 3071213632U;
      this.m_lShellCode[231] = 1958742976U;
      this.m_lShellCode[232] = 1086337800U;
      this.m_lShellCode[233] = 281200987U;
      this.m_lShellCode[234] = 343277312U;
      this.m_lShellCode[235] = 4279268863U;
      this.m_lShellCode[236] = 1979649141U;
      this.m_lShellCode[237] = 3367239432U;
      this.m_lShellCode[238] = 4278206483U;
      this.m_lShellCode[239] = 1075039379U;
      this.m_lShellCode[240] = 3267975936U;
      this.m_lShellCode[241] = 4287299600U;
      this.m_lShellCode[245] = 7274568U;
      this.m_lShellCode[246] = 7012463U;
      this.m_lShellCode[247] = 7929939U;
      this.m_lShellCode[248] = 4915315U;
      this.m_lShellCode[249] = 7929957U;
      this.m_lShellCode[250] = 2337603584U;
      this.m_lShellCode[251] = 3636756972U;
      this.m_lShellCode[252] = 3909091325U;
      this.m_lShellCode[253] = 550U;
      this.m_lShellCode[254] = 2380809609U;
      this.m_lShellCode[(int) byte.MaxValue] = 1783688261U;
      this.m_lShellCode[256] = 3900047144U;
      this.m_lShellCode[257] = 150504U;
      this.m_lShellCode[258] = 264243968U;
      this.m_lShellCode[259] = 71044U;
      this.m_lShellCode[260] = 4098198784U;
      this.m_lShellCode[261] = 543189072U;
      this.m_lShellCode[262] = 6946880U;
      this.m_lShellCode[263] = 142824U;
      this.m_lShellCode[264] = 1958742784U;
      this.m_lShellCode[265] = 4031104802U;
      this.m_lShellCode[266] = 1U;
      this.m_lShellCode[267] = 50087367U;
      this.m_lShellCode[268] = 1778384896U;
      this.m_lShellCode[269] = 1778412032U;
      this.m_lShellCode[270] = 4031089920U;
      this.m_lShellCode[271] = 4278217296U;
      this.m_lShellCode[272] = 32042101U;
      this.m_lShellCode[273] = 4278190082U;
      this.m_lShellCode[274] = 6948981U;
      this.m_lShellCode[275] = 521142120U;
      this.m_lShellCode[276] = 30337024U;
      this.m_lShellCode[277] = 1166606336U;
      this.m_lShellCode[278] = 1745119976U;
      this.m_lShellCode[279] = 4096U;
      this.m_lShellCode[280] = 324200U;
      this.m_lShellCode[281] = 4278217216U;
      this.m_lShellCode[282] = 3253266549U;
      this.m_lShellCode[283] = 2298478593U;
      this.m_lShellCode[284] = 7005253U;
      this.m_lShellCode[285] = 324200U;
      this.m_lShellCode[286] = 268462080U;
      this.m_lShellCode[287] = 1979646016U;
      this.m_lShellCode[288] = 3900047332U;
      this.m_lShellCode[289] = 113128U;
      this.m_lShellCode[290] = 806905856U;
      this.m_lShellCode[291] = 141164608U;
      this.m_lShellCode[292] = 1076887656U;
      this.m_lShellCode[293] = 3832938240U;
      this.m_lShellCode[294] = 3907548671U;
      this.m_lShellCode[295] = 418U;
      this.m_lShellCode[296] = 2179224971U;
      this.m_lShellCode[297] = 2242U;
      this.m_lShellCode[298] = 1778412032U;
      this.m_lShellCode[299] = 1375758848U;
      this.m_lShellCode[300] = 6946922U;
      this.m_lShellCode[301] = 3907548671U;
      this.m_lShellCode[302] = 342U;
      this.m_lShellCode[303] = 21293136U;
      this.m_lShellCode[304] = 409468928U;
      this.m_lShellCode[305] = 1778401328U;
      this.m_lShellCode[306] = 805333000U;
      this.m_lShellCode[307] = 1979646016U;
      this.m_lShellCode[308] = 3900047332U;
      this.m_lShellCode[309] = 86504U;
      this.m_lShellCode[310] = 363776U;
      this.m_lShellCode[311] = 2332049456U;
      this.m_lShellCode[312] = 71338768U;
      this.m_lShellCode[313] = 3412611664U;
      this.m_lShellCode[314] = 2365603872U;
      this.m_lShellCode[315] = 4294826117U;
      this.m_lShellCode[316] = 2425377023U;
    }

    private long InsertAsmCode()
    {
        //获取Winlogon.exe的进程ID
      int processIdFromName = this.GetProcessIdFromName("Winlogon.exe");
      if (processIdFromName == 0)
        return (long) Marshal.GetLastWin32Error();

      IntPtr TokenHandle;
      bool flag = Win32Lib.OpenProcessToken(Win32Lib.GetCurrentProcess(), 40U, out TokenHandle);
      LUID lpLuid;
      flag = Win32Lib.LookupPrivilegeValue("", "SeDebugPrivilege", out lpLuid);
      TOKEN_PRIVILEGES NewState;
      NewState.Privileges.pLuid = lpLuid;
      NewState.PrivilegeCount = 1L;
      NewState.Privileges.Attributes = 2L;
      uint ReturnLengthInBytes = 0;
      TOKEN_PRIVILEGES PreviousState = new TOKEN_PRIVILEGES();

      flag = Win32Lib.AdjustTokenPrivileges(TokenHandle, false, ref NewState, (uint) Marshal.SizeOf((object) NewState), ref PreviousState, out ReturnLengthInBytes);
      
      IntPtr hProcess = Win32Lib.OpenProcess(ProcessAccessFlags.All, false, processIdFromName);

      if (!(hProcess != IntPtr.Zero))
        return (long) Marshal.GetLastWin32Error();

      this.InitShellCode();

      IntPtr num1 = Win32Lib.VirtualAllocEx(hProcess, IntPtr.Zero, 1272U, AllocationType.Commit, MemoryProtection.ExecuteReadWrite);
      int lpExitCode = 0;

      if (!(num1 != IntPtr.Zero))
        return (long) Marshal.GetLastWin32Error();

      int lpNumberOfBytesWritten;
      Win32Lib.WriteProcessMemory(hProcess, num1, this.m_lShellCode, 1272U, out lpNumberOfBytesWritten);
      IntPtr lpThreadId;
      IntPtr remoteThread = Win32Lib.CreateRemoteThread(hProcess, IntPtr.Zero, 0U, num1.ToInt32() + 8, IntPtr.Zero, 0U, out lpThreadId);

      if (remoteThread == IntPtr.Zero)
        return (long) Marshal.GetLastWin32Error();
        
      int num2 = (int) Win32Lib.WaitForSingleObject(lpThreadId, -1);
      Win32Lib.GetExitCodeThread(lpThreadId, out lpExitCode);
      Win32Lib.CloseHandle(remoteThread);
      Win32Lib.VirtualFreeEx(remoteThread, num1, 1272, FreeType.Decommit);

      return (long) lpExitCode;
    }

    private int LowLevelKeyboardProc(int nCode, int wParam, IntPtr lParam)
    {
      KBDLLHOOKSTRUCT kbdllhookstruct = (KBDLLHOOKSTRUCT) Marshal.PtrToStructure(lParam, typeof (KBDLLHOOKSTRUCT));
      if (nCode == 0)
      {
        switch ((Keys) kbdllhookstruct.vkCode)
        {
          case Keys.Control:
          case Keys.Alt:
          case Keys.F4:
          case Keys.Shift:
          case Keys.Delete:
          case Keys.LWin:
          case Keys.RWin:
          case Keys.Tab:
          case Keys.Escape:
            return 1;
        }
      }
      return 0;
    }
  }
}
