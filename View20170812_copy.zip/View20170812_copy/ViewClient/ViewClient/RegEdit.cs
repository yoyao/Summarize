﻿
using Microsoft.Win32;
using System.Diagnostics;

namespace ViewClient
{
  internal class RegEdit
  {
    public void SetRegeditData(string softname, string subname, string Key_Name, string Key_Value)
    {
      Registry.LocalMachine.OpenSubKey("SOFTWARE", true).CreateSubKey(softname).CreateSubKey(subname).SetValue(Key_Name, (object) Key_Value);
    }

    public bool IsRegeditDirExist(string softname)
    {
      bool flag = false;
      foreach (string subKeyName in Registry.LocalMachine.OpenSubKey("SOFTWARE", true).GetSubKeyNames())
      {
        if (subKeyName == softname)
          return true;
      }
      return flag;
    }

    public void RegeditDll()
    {
      new Process()
      {
        StartInfo = {
          FileName = "Regsvr32.exe",
          Arguments = "/s C:\\DllTest.dll"
        }
      }.Start();
    }
  }
}
