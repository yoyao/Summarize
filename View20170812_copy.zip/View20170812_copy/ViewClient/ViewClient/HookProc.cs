﻿
using System;

namespace ViewClient
{
  internal delegate int HookProc(int code, int wParam, IntPtr lParam);
}
