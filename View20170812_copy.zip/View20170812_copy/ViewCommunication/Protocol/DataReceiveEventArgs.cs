﻿
using View.DesktopAgent.Communication.Message;
using System;
using System.Net;

namespace View.DesktopAgent.Communication.Protocol
{
  public class DataReceiveEventArgs : EventArgs
  {
    public IPEndPoint RemoteEP { get; private set; }

    public byte[] Data { get; private set; }

    public MessageType MessageType { get; private set; }

    public DataReceiveEventArgs(IPEndPoint remoteEP, byte[] data)
    {
      this.RemoteEP = remoteEP;
      this.Data = data;
      this.MessageType = MessageBase.GetMessageType(data);
    }
  }
}
