﻿

using View.DesktopAgent.Communication.Message;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace View.DesktopAgent.Communication.Protocol
{
  public class MessageSender : IDisposable
  {
    private IPEndPoint _ServerIP;
    private UdpClient Client;

    public IPEndPoint ServerIP
    {
      get
      {
        return this._ServerIP;
      }
      set
      {
        this._ServerIP = value;
      }
    }

    public MessageSender()
    {
      this.Client = new UdpClient();
    }

    public void SendIdentity()
    {
    }

    public void SendMessage(string ServerIP, int Port, MessageBase Message)
    {
      if (ServerIP == "")
        throw new Exception("Not Define ServerIP.");
      byte[] packageData = Message.GetPackageData();
      this.Client.Send(packageData, packageData.Length, ServerIP, Port);
    }

    public void SendMessage(string Message, string IP, int Port)
    {
      byte[] bytes = Encoding.UTF8.GetBytes(Message);
      this.Client.Send(bytes, bytes.Length, IP, Port);
    }

    public void Dispose()
    {
      this.Client.Close();
      this.Client = (UdpClient) null;
    }
  }
}
