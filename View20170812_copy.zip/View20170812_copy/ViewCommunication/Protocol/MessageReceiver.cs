﻿
using System;
using System.Net;
using System.Net.Sockets;

namespace View.DesktopAgent.Communication.Protocol
{
  public class MessageReceiver : IDisposable
  {
    public static readonly int Port = 32011;
    public static readonly IPAddress BroadcastAddress = IPAddress.Parse("224.224.224.224");
    public static readonly IPEndPoint ServerAddress = new IPEndPoint(MessageReceiver.BroadcastAddress, MessageReceiver.Port);
    private UdpClient Server;
    private bool IsStarting;
    private AsyncCallback OnDataReceiveCallBack;

    public event EventHandler<DataReceiveEventArgs> DataReceive;

    public MessageReceiver()
    {
      this.IsStarting = false;
      this.Server = new UdpClient(MessageReceiver.Port, AddressFamily.InterNetwork);
      this.OnDataReceiveCallBack = new AsyncCallback(this.OnDataReceive);
    }

    public void Start()
    {
      if (this.IsStarting)
        return;
      this.Server.JoinMulticastGroup(MessageReceiver.BroadcastAddress);
      this.Server.BeginReceive(this.OnDataReceiveCallBack, (object) this.Server);
      this.IsStarting = true;
    }

    public void Stop()
    {
      if (!this.IsStarting)
        return;
      this.IsStarting = false;
      this.Server.DropMulticastGroup(MessageReceiver.BroadcastAddress);
      this.Server.Close();
    }

    public void Dispose()
    {
      this.Stop();
      this.Server = (UdpClient) null;
    }

    private void OnDataReceive(IAsyncResult async)
    {
      if (!this.IsStarting)
        return;
      UdpClient udpClient = (UdpClient) null;
      try
      {
        udpClient = (UdpClient) async.AsyncState;
        IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);
        byte[] data = udpClient.EndReceive(async, ref remoteEP);
        EventHandler<DataReceiveEventArgs> eventHandler = this.DataReceive;
        if (eventHandler != null)
          eventHandler((object) udpClient, new DataReceiveEventArgs(remoteEP, data));
      }
      catch (ObjectDisposedException ex)
      {
        udpClient = (UdpClient) null;
        string myexcept = ex.Message;
      }
      catch (Exception ex)
      {
          Console.WriteLine("\nMessage ---\n{0}", ex.Message);
      }
      finally
      {
        if (this.IsStarting && udpClient != null)
          udpClient.BeginReceive(this.OnDataReceiveCallBack, (object) udpClient);
      }
    }
  }
}
