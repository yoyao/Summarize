﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyCompany("eSage")]
[assembly: ComVisible(false)]
[assembly: AssemblyTitle("ViewCommunication")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: Guid("b79c34ef-accc-4a01-aa8c-da9c29217d1e")]
[assembly: AssemblyProduct("ViewCommunication")]
[assembly: AssemblyCopyright("Copyright © eSage 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
