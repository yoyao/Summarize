﻿
using System.Collections.Generic;

namespace View.DesktopAgent.Communication.Message
{
  public class SessionEventMessage : MessageBase
  {
    private string _UUID;
    private string _IP;
    private string _RemoteIP;
    private string _UserAccount;
    private string _SessionEvent;
    private string _LoginTime;
    private string _ConnectTime;
    private string _IdleTime;
    private string _WindowsStation;
    private string _OSVersion;
    private string _TimeStamp;
    private string _ServerIP;
    private string _SessionID;

    public SessionEventMessage(string UUID, string IP, string UserAccount, string RemoteIP, string SessionEvent, string LoginTime, string ConnectTime, string IdleTime, string WindowsStation, string OSVersion, string TimeStamp, string ServerIP, string SessionID)
      : base(MessageType.SessionEvent)
    {
      this._UUID = UUID;
      this._IP = IP;
      this._RemoteIP = RemoteIP;
      this._UserAccount = UserAccount;
      this._SessionEvent = SessionEvent;
      this._LoginTime = LoginTime;
      this._ConnectTime = ConnectTime;
      this._IdleTime = IdleTime;
      this._WindowsStation = WindowsStation;
      this._OSVersion = OSVersion;
      this._TimeStamp = TimeStamp;
      this._ServerIP = ServerIP;
      this._SessionID = SessionID;
    }

    public override byte[] GetPackageData()
    {
      List<byte> byteList = new List<byte>(100);
      byteList.AddRange((IEnumerable<byte>) base.GetPackageData());
      byteList.AddRange((IEnumerable<byte>) MessageBase.Charset.GetBytes(this._UUID + "|" + this._RemoteIP + "|" + this._IP + "|" + this._UserAccount + "|" + this._SessionEvent + "|" + this._LoginTime + "|" + this._ConnectTime + "|" + this._IdleTime + "|" + this._WindowsStation + "|" + this._OSVersion + "|" + this._TimeStamp + "|" + this._ServerIP + "|" + this._SessionID));
      return byteList.ToArray();
    }

    public static SessionEventMessage FromPackage(byte[] data)
    {
      return (SessionEventMessage) null;
    }
  }
}
