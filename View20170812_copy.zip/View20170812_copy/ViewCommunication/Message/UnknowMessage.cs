﻿
namespace View.DesktopAgent.Communication.Message
{
  public class UnknowMessage
  {
    public string Message;

    public UnknowMessage(string Message)
    {
      this.Message = Message;
    }

    public static UnknowMessage FromPackage(byte[] data)
    {
      try
      {
        return new UnknowMessage(MessageBase.Charset.GetString(data, 0, data.Length));
      }
      catch
      {
        return (UnknowMessage) null;
      }
    }
  }
}
