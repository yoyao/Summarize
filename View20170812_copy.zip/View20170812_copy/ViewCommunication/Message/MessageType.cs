﻿
namespace View.DesktopAgent.Communication.Message
{
  public enum MessageType : byte
  {
    Unknown = 0,
    HeartBeat = 10,
    SessionEvent = 11,
    Query = 17,
    Command = 20,
    Identity = 100,
  }
}
