﻿
using System.Collections.Generic;

namespace View.DesktopAgent.Communication.Message
{
  public class HeartBeatMessage : MessageBase
  {
    private string _UUID;
    private string _IP;
    private string _OSVersion;
    private string _ComputerName;
    private string _SessionState;
    private string _ConnectTime;
    private string _LogonTime;
    private string _TimeStamp;

    public HeartBeatMessage(string UUID, string IP, string OSVersion, string ComputerName, string SessionState, string ConnectTime, string LogonTime, string TimeStamp)
      : base(MessageType.HeartBeat)
    {
      this._UUID = UUID;
      this._IP = IP;
      this._OSVersion = OSVersion;
      this._ComputerName = ComputerName;
      this._SessionState = SessionState;
      this._ConnectTime = ConnectTime;
      this._LogonTime = LogonTime;
      this._TimeStamp = TimeStamp;
    }

    public override byte[] GetPackageData()
    {
      List<byte> byteList = new List<byte>(100);
      byteList.AddRange((IEnumerable<byte>) base.GetPackageData());
      byteList.AddRange((IEnumerable<byte>) MessageBase.Charset.GetBytes(this._UUID + "|" + this._IP + "|" + this._OSVersion + "|" + this._ComputerName + "|" + this._SessionState + "|" + this._ConnectTime + "|" + this._LogonTime + "|" + this._TimeStamp));
      return byteList.ToArray();
    }

    public static HeartBeatMessage FromPackage(byte[] data)
    {
      return (HeartBeatMessage) null;
    }
  }
}
