﻿
using System.Text;

namespace View.DesktopAgent.Communication.Message
{
  public abstract class MessageBase
  {
    public static readonly Encoding Charset = Encoding.Default;
    public static readonly char[] Splitter = new char[1]{ '|' };

    public MessageType Type { get; private set; }

    protected MessageBase(MessageType type)
    {
      this.Type = type;
    }

    public virtual byte[] GetPackageData()
    {
      return new byte[1]
      {
        (byte) this.Type
      };
    }

    internal static MessageType GetMessageType(byte[] data)
    {
      if (data == null || data.Length == 0)
        return MessageType.Unknown;
      return (MessageType) data[0];
    }
  }
}
