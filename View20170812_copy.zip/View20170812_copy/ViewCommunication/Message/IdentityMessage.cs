﻿

namespace View.DesktopAgent.Communication.Message
{
  public class IdentityMessage : MessageBase
  {
    private string _ServerIP;
    private string _GridName;
    private string _UUID;
    private string _Interval;

    public string ServerIP
    {
      get
      {
        return this._ServerIP;
      }
      set
      {
        this._ServerIP = value;
      }
    }

    public string GridName
    {
      get
      {
        return this._GridName;
      }
      set
      {
        this._GridName = value;
      }
    }

    public string UUID
    {
      get
      {
        return this._UUID;
      }
      set
      {
        this._UUID = value;
      }
    }

    public string Interval
    {
      get
      {
        return this._Interval;
      }
      set
      {
        this._Interval = value;
      }
    }

    public IdentityMessage(string _ServerIP, string _GridName, string _UUID, string _Interval)
      : base(MessageType.Identity)
    {
      this.ServerIP = _ServerIP;
      this.GridName = _GridName;
      this.UUID = _UUID;
      this.Interval = _Interval;
    }

    public static IdentityMessage FromPackage(byte[] data)
    {
      try
      {
        string[] strArray = MessageBase.Charset.GetString(data, 1, data.Length - 1).Split(MessageBase.Splitter);
        return new IdentityMessage(strArray[0], strArray[1], strArray[2], strArray[3]);
      }
      catch
      {
        return (IdentityMessage) null;
      }
    }
  }
}
