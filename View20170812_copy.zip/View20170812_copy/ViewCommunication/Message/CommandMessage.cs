﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace View.DesktopAgent.Communication.Message
{
  public class CommandMessage : MessageBase
  {
    public new static readonly Encoding Charset = Encoding.Default;

    public string Message { get; private set; }

    public DateTime Time { get; private set; }

    public CommandMessage(string Message)
      : base(MessageType.Command)
    {
      this.Message = Message;
    }

    public override byte[] GetPackageData()
    {
      List<byte> byteList = new List<byte>(100);
      byteList.AddRange((IEnumerable<byte>) base.GetPackageData());
      byteList.AddRange((IEnumerable<byte>) CommandMessage.Charset.GetBytes(this.Message));
      return byteList.ToArray();
    }

    public static CommandMessage FromPackage(byte[] data)
    {
      try
      {
        return new CommandMessage(CommandMessage.Charset.GetString(data, 1, data.Length - 1));
      }
      catch
      {
        return (CommandMessage) null;
      }
    }
  }
}
