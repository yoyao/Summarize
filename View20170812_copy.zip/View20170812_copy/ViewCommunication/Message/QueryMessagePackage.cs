﻿
namespace View.DesktopAgent.Communication.Message
{
  public class QueryMessagePackage : MessageBase
  {
    public QueryMessagePackage()
      : base(MessageType.Query)
    {
    }
  }
}
