#include "stdafx.h"
#include "Crypt.h"

BYTE Decode_GetByte(char c);
char Encode_GetChar(BYTE num);
size_t Base64_Decode(char *pDest, const char *pSrc, size_t srclen);
size_t Base64_Encode(char *pDest, const char *pSrc, size_t srclen);

#define SHA1_ROTL(a,b) (SHA1_tmp=(a),((SHA1_tmp>>(32-b))&(0x7fffffff>>(31-b)))|(SHA1_tmp<<b))
#define SHA1_F(B,C,D,t) ((t<40)?((t<20)?((B&C)|((~B)&D)):(B^C^D)):((t<60)?((B&C)|(B&D)|(C&D)):(B^C^D)))
long SHA1_tmp;
void StrSHA1(const char* str, long length, long* state)
{
	/*
	�����ַ���SHA-1
	����˵����
	str         �ַ���ָ��
	length      �ַ�������
	*/
	unsigned char *pp, *ppend;
	long l, i, K[80], W[80], TEMP, A, B, C, D, E;
	 
	state[0] = 0x67452301, state[1] = 0xEFCDAB89, state[2] = 0x98BADCFE, state[3] = 0x10325476, state[4] = 0xC3D2E1F0;
	for (i = 0; i < 20; K[i++] = 0x5A827999);
	for (i = 20; i < 40; K[i++] = 0x6ED9EBA1);
	for (i = 40; i < 60; K[i++] = 0x8F1BBCDC);
	for (i = 60; i < 80; K[i++] = 0xCA62C1D6);
	l = length + ((length % 64 > 56) ? (128 - length % 64) : (64 - length % 64));
	if (!(pp = (unsigned char*)malloc((unsigned long)l)))
		return ;
	for (i = 0; i < length; pp[i + 3 - 2 * (i % 4)] = str[i], i++);
	for (pp[i + 3 - 2 * (i % 4)] = 128, i++; i < l; pp[i + 3 - 2 * (i % 4)] = 0, i++);
	*((long*)(pp + l - 4)) = length << 3;
	*((long*)(pp + l - 8)) = length >> 29;
	for (ppend = pp + l; pp < ppend; pp += 64)
	{
		for (i = 0; i < 16; W[i] = ((long*)pp)[i], i++);
		for (i = 16; i < 80; W[i] = SHA1_ROTL((W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16]), 1), i++);
		A = state[0], B = state[1], C = state[2], D = state[3], E = state[4];
		for (i = 0; i < 80; i++)
		{
			TEMP = SHA1_ROTL(A, 5) + SHA1_F(B, C, D, i) + E + W[i] + K[i];
			E = D, D = C, C = SHA1_ROTL(B, 30), B = A, A = TEMP;
		}
		state[0] += A, state[1] += B, state[2] += C, state[3] += D, state[4] += E;
	}
	free(pp - l);
}

CString MyGetSHA(CString spwd)
{
	CString shash(_T(""));

	size_t   length;
	char *str = new char[64];
	wcstombs_s(&length, str, 64, spwd.GetBuffer(), 64);
	long  state[5];
	length = spwd.GetLength();
	StrSHA1(str, length, state);
	delete[] str;
	str = NULL;
	
	shash.Format(_T("%08x%08x%08x%08x%08x"), state[0], state[1], state[2], state[3], state[4]);

	return shash;
}

BYTE Decode_GetByte(char c)
{
	if (c == '+')
		return 62;
	else if (c == '/')
		return 63;
	else if (c <= '9')
		return (BYTE)(c - '0' + 52);
	else if (c == '=')
		return 64;
	else if (c <= 'Z')
		return (BYTE)(c - 'A');
	else if (c <= 'z')
		return (BYTE)(c - 'a' + 26);
	return 64;
}

CString MyDecodeBase64(CString strCode)
{
	size_t len;
	int size = 2 * strCode.GetLength() + 1;
	char* stemp = new char[size];
	wcstombs_s(&len, stemp, size, strCode.GetBuffer(), strCode.GetLength());
	
	char* pDest = new char[1024];
	len = Base64_Decode(pDest, stemp, len-1);
	delete[] stemp;

	wchar_t scode[64];
	memset(scode, 0, sizeof(scode));
	mbstowcs_s(&len, scode, 64, pDest, len);
	delete[] pDest;

	return CString(scode);
}

size_t Base64_Decode(char *pDest, const char *pSrc, size_t srclen)
{
	BYTE input[4];
	size_t i, index = 0;
	for (i = 0; i < srclen; i += 4)
	{
		//byte[0]
		input[0] = Decode_GetByte(pSrc[i]);
		input[1] = Decode_GetByte(pSrc[i + 1]);
		pDest[index++] = (input[0] << 2) + (input[1] >> 4);

		//byte[1]
		if (pSrc[i + 2] != '=')
		{
			input[2] = Decode_GetByte(pSrc[i + 2]);
			pDest[index++] = ((input[1] & 0x0f) << 4) + (input[2] >> 2);
		}

		//byte[2]
		if (pSrc[i + 3] != '=')
		{
			input[3] = Decode_GetByte(pSrc[i + 3]);
			pDest[index++] = ((input[2] & 0x03) << 6) + (input[3]);
		}
	}

	//null-terminator
	pDest[index] = 0;
	return index;
}

//===================================
//    Base64 ����
//===================================
char Encode_GetChar(BYTE num)
{
	return
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz"
		"0123456789"
		"+/="[num];
}

//����
size_t Base64_Encode(char *pDest, const char *pSrc, size_t srclen)
{
	BYTE input[3], output[4];
	size_t i, index_src = 0, index_dest = 0;
	for (i = 0; i < srclen; i += 3)
	{
		//char [0]
		input[0] = pSrc[index_src++];
		output[0] = (BYTE)(input[0] >> 2);
		pDest[index_dest++] = Encode_GetChar(output[0]);

		//char [1]
		if (index_src < srclen)
		{
			input[1] = pSrc[index_src++];
			output[1] = (BYTE)(((input[0] & 0x03) << 4) + (input[1] >> 4));
			pDest[index_dest++] = Encode_GetChar(output[1]);
		}
		else
		{
			output[1] = (BYTE)((input[0] & 0x03) << 4);
			pDest[index_dest++] = Encode_GetChar(output[1]);
			pDest[index_dest++] = '=';
			pDest[index_dest++] = '=';
			break;
		}

		//char [2]
		if (index_src < srclen)
		{
			input[2] = pSrc[index_src++];
			output[2] = (BYTE)(((input[1] & 0x0f) << 2) + (input[2] >> 6));
			pDest[index_dest++] = Encode_GetChar(output[2]);
		}
		else
		{
			output[2] = (BYTE)((input[1] & 0x0f) << 2);
			pDest[index_dest++] = Encode_GetChar(output[2]);
			pDest[index_dest++] = '=';
			break;
		}

		//char [3]
		output[3] = (BYTE)(input[2] & 0x3f);
		pDest[index_dest++] = Encode_GetChar(output[3]);
	}
	//null-terminator
	pDest[index_dest] = 0;
	return index_dest;
}
