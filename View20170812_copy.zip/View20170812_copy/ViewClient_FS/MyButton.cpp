#include "stdafx.h"
#include "MyButton.h"

#define CTRL_NOFOCUS		1
#define CTRL_FOCUS			2
#define CTRL_SELECTED		3
#define CTRL_DISABLED		4

CMyButton::CMyButton()
{
	m_bTracking = FALSE;
	m_nState = CTRL_NOFOCUS;
	m_font.CreateFont(21, // nHeight 
		0, // nWidth 
		0, // nEscapement 
		0, // nOrientation 
		FW_NORMAL, // nWeight 
		FALSE, // bItalic 
		FALSE, // bUnderline 
		0, // cStrikeOut 
		ANSI_CHARSET, // nCharSet 
		OUT_CHARACTER_PRECIS, // nOutPrecision 
		CLIP_CHARACTER_PRECIS, // nClipPrecision 
		PROOF_QUALITY, // nQuality 
		DEFAULT_PITCH | FF_SWISS, // nPitchAndFamily 
		_T("΢���ź�"));
}


CMyButton::~CMyButton()
{
}


void CMyButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	UINT state = lpDrawItemStruct->itemState;
	COLORREF crColor;
	

	switch (m_nState)
	{
		case CTRL_NOFOCUS:
		{
			crColor = RGB(40, 80, 140);
		}
		break;

		case CTRL_FOCUS:
		{
			crColor = RGB(40, 80, 160);
		}
		break;
		case CTRL_SELECTED:
		{
			crColor = RGB(40, 80, 120);
		}
		break;

		case CTRL_DISABLED:
		{
			crColor = RGB(220, 200, 220);
		}
		break;

		default:
			break;
	}

	if (state & ODS_DISABLED)
		crColor = RGB(220, 220, 220);

	// ���ư�ť����߿�
	CPen OutBorderPen(PS_SOLID, 1, crColor);	
	CRect rect = lpDrawItemStruct->rcItem;
	CDC *pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	int nSavedDC = pDC->SaveDC();
		
	POINT pt;
	pt.x = 8;
	pt.y = 8;
	CPen *pOldPen = pDC->SelectObject(&OutBorderPen);
	pDC->RoundRect(&rect, pt);
	pDC->SelectObject(pOldPen);

	// ���ư�ť������ɫ
	CBrush BackgroundBrush(crColor);
	CRgn rgn;
	rgn.CreateRoundRectRgn(rect.left, rect.top, rect.right, rect.bottom+2,9,9);
	pDC->FillRgn(&rgn, &BackgroundBrush);
	
	// ���ư�ť�ı�
	CString strButtonText;
	GetWindowText(strButtonText);
	if (!(strButtonText.IsEmpty()))
	{
		CString strText(strButtonText);

		//CString strText;
		//int i = 0;
		//for (i = 0; i < strButtonText.GetLength()-1; i++)
		//{
		//	strText.AppendChar(strButtonText.GetAt(i));
		//	strText.Append(_T(" "), 1);
		//}
		//strText.AppendChar(strButtonText.GetAt(i));

		CFont *pOldFont = pDC->SelectObject(&m_font);
		CSize szExtent = pDC->GetTextExtent(strText, _tcslen(strText));
		CRect rectText = lpDrawItemStruct->rcItem;
		if (state & ODS_SELECTED)
		{
			rectText.OffsetRect(1, 1);
		}
		rectText.DeflateRect(rect.CenterPoint().x - szExtent.cx / 2, rect.CenterPoint().y - szExtent.cy / 2, rect.CenterPoint().x - szExtent.cx / 2, rect.CenterPoint().y - szExtent.cy / 2);
		int nOldBkMode = pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(255, 255, 0));
		pDC->DrawText(strText, -1, rectText, DT_WORDBREAK | DT_CENTER);
		pDC->SelectObject(pOldFont);
		pDC->SetBkMode(nOldBkMode);
	}
}

void CMyButton::PreSubclassWindow()
{
	ModifyStyle(0, BS_OWNERDRAW);

	CButton::PreSubclassWindow();
}
BEGIN_MESSAGE_MAP(CMyButton, CButton)
	ON_WM_MOUSEHOVER()
	ON_WM_MOUSELEAVE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_ENABLE()
END_MESSAGE_MAP()

void CMyButton::OnMouseHover(UINT nFlags, CPoint point)
{
	if (m_nState == CTRL_NOFOCUS)
	{
		m_nState = CTRL_FOCUS;
		Invalidate();
	}

	m_bTracking = FALSE;

	CButton::OnMouseHover(nFlags, point);
}


void CMyButton::OnMouseLeave()
{
	if (m_nState != CTRL_NOFOCUS)
	{
		m_nState = CTRL_NOFOCUS;
		Invalidate();
	}

	m_bTracking = FALSE;

	CButton::OnMouseLeave();
}


void CMyButton::OnMouseMove(UINT nFlags, CPoint point)
{
	if (!m_bTracking)
	{
		TRACKMOUSEEVENT tme;
		tme.cbSize = sizeof(tme);
		tme.hwndTrack = m_hWnd;
		tme.dwFlags = TME_LEAVE | TME_HOVER;
		tme.dwHoverTime = 1;
		m_bTracking = _TrackMouseEvent(&tme);
	}

	CButton::OnMouseMove(nFlags, point);
}


void CMyButton::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_nState == CTRL_FOCUS)
	{
		m_nState = CTRL_SELECTED;
		Invalidate();
	}

	CButton::OnLButtonDown(nFlags, point);
}


void CMyButton::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_nState == CTRL_SELECTED)
	{
		m_nState = CTRL_FOCUS;
		Invalidate();
	}

	CButton::OnLButtonUp(nFlags, point);
}
