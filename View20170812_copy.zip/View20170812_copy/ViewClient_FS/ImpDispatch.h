#pragma once  
class ImpDispatch :public IDispatch
{
public:
	ImpDispatch(void);
	~ImpDispatch(void);
	ULONG m_Ref;
public:
	//IUnknown�ӿڵ�ʵ��  
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(
		/* [in] */ REFIID riid,
		/* [iid_is][out] */ __RPC__deref_out void __RPC_FAR *__RPC_FAR *ppvObject)
	{
		if (riid == IID_IUnknown)
		{
			*ppvObject = (IUnknown*)this;
			return S_OK;
		}
		else if (riid == IID_IDispatch)
		{
			*ppvObject = (IDispatch*)this;
			return S_OK;
		}
		return E_FAIL;
	}

	virtual ULONG STDMETHODCALLTYPE AddRef(void)
	{
		m_Ref++;
		return m_Ref;
	}

	virtual ULONG STDMETHODCALLTYPE Release(void)
	{
		m_Ref--;
		return m_Ref;

	}
	//IDispatch�ӿڵ�ʵ��  
	virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount(
		/* [out] */ __RPC__out UINT *pctinfo)
	{
		return E_FAIL;;
	}

	virtual HRESULT STDMETHODCALLTYPE GetTypeInfo(
		/* [in] */ UINT iTInfo,
		/* [in] */ LCID lcid,
		/* [out] */ __RPC__deref_out_opt ITypeInfo **ppTInfo)
	{
		return E_FAIL;
	}

	virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames(
		/* [in] */ __RPC__in REFIID riid,
		/* [size_is][in] */ __RPC__in_ecount_full(cNames) LPOLESTR *rgszNames,
		/* [range][in] */ __RPC__in_range(0, 16384) UINT cNames,
		/* [in] */ LCID lcid,
		/* [size_is][out] */ __RPC__out_ecount_full(cNames) DISPID *rgDispId)
	{
		rgDispId[0] = 100;
		return S_OK;
	}

	virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke(
		/* [in] */ DISPID dispIdMember,
		/* [in] */ REFIID riid,
		/* [in] */ LCID lcid,
		/* [in] */ WORD wFlags,
		/* [out][in] */ DISPPARAMS *pDispParams,
		/* [out] */ VARIANT *pVarResult,
		/* [out] */ EXCEPINFO *pExcepInfo,
		/* [out] */ UINT *puArgErr)
	{
		//if (dispIdMember == 100)
		//{
		//	MessageBox(NULL, L"����C++���õĽ��", L"��ʾ", 0);
		//}
		//������Ҫע�����������в������ݵĻ���������������������Ӧ��������ȡ!!!!!
		int val1 = pDispParams->rgvarg[0].intVal;
		int val2 = pDispParams->rgvarg[1].intVal;
		return S_OK;
	}
};