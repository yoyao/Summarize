
// MFCViewClientDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCViewClient.h"
#include "MFCViewClientDlg.h"
#include <TlHelp32.h>
#include <string>
#include <sstream>
#include "afxdialogex.h"
#include "UserInfoWeb.h"
#include "resource.h"
#include "errorcode.h"

using namespace std;

#define IDT_TIMER_AUTOLOGIN		20
#define IDT_TIMER_RDP_CHANGE    30

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#ifdef WIN32

#endif


SIZE clientRect[11] =
{
	{ 0, 0 }, { 640, 480 }, { 800, 600 }, { 1024, 768 }, { 1280, 720 }, { 1280, 768 }, { 1366, 768 }, { 1440, 900 }, { 1600, 900 }, { 1680, 1050 }, { 1920, 1080 }
};


Desktop CMFCViewClientDlg::m_desktop;

// CMFCViewClientDlg �Ի���
CMFCViewClientDlg::CMFCViewClientDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMFCViewClientDlg::IDD, pParent)
{
	m_pRDPDlg = NULL;
	m_bIsLowRDP = FALSE;
	m_bShow = FALSE;
}

void CMFCViewClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_USER, m_user);
	DDX_Control(pDX, IDC_EDIT_PASSWORD, m_password);
	DDX_Control(pDX, IDC_EDIT_SERVERIP, m_serverip);
	DDX_Control(pDX, IDC_PICTURE_BOX, m_picturebox);
	DDX_Control(pDX, IDC_BUTTON_SAVE, m_save);
	DDX_Control(pDX, IDC_BUTTON_CANCEL, m_cancel);
	DDX_Control(pDX, IDC_BUTTON_PBUSERINFO, m_pbuserinfo);
	DDX_Control(pDX, IDC_CHECK_PASSWORD, m_remember);
	DDX_Control(pDX, IDC_CHECK_AUTOLOGIN, m_autologin);
	DDX_Control(pDX, IDC_CHECK_FULLSCREEN, m_fullscreen);
	DDX_Control(pDX, IDC_STATIC_SERVERIP, m_labelip);
	DDX_Control(pDX, IDC_STATIC_ICON, m_icon);
	//DDX_Control(pDX, IDC_STATIC_ESAGE, m_esage);
	DDX_Control(pDX, IDC_STATIC_USER, m_labeluser);
	DDX_Control(pDX, IDC_STATIC_PASSWORD, m_labelpassword);
	DDX_Control(pDX, IDC_BUTTON_LOGIN, m_login);
	DDX_Control(pDX, IDC_STATIC_VERSION, m_staticVersion);
	DDX_Control(pDX, IDC_SCREEN_PX, m_screenpx);
	//�˳���ť
	DDX_Control(pDX, IDC_BUTTON_EXIT, m_ExitDlg);
}

BEGIN_MESSAGE_MAP(CMFCViewClientDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_MESSAGE(WM_HOTKEY, OnHotKey)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_CHECK_PASSWORD, &CMFCViewClientDlg::OnBnClickedCheckPassword)
	ON_BN_CLICKED(IDC_CHECK_AUTOLOGIN, &CMFCViewClientDlg::OnBnClickedCheckAutologin)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CMFCViewClientDlg::OnBnClickedButtonSave)
	ON_BN_CLICKED(IDC_CHECK_FULLSCREEN, &CMFCViewClientDlg::OnBnClickedButtonChangePX)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CMFCViewClientDlg::OnBnClickedButtonCancel)
	ON_BN_CLICKED(IDC_BUTTON_LOGIN, &CMFCViewClientDlg::OnBnClickedButtonLogin)
	ON_BN_CLICKED(IDC_BUTTON_PBUSERINFO, &CMFCViewClientDlg::OnBnClickedButtonPbuserinfo)
	//�˳���ť
	ON_BN_CLICKED(IDC_BUTTON_EXIT, &CMFCViewClientDlg::OnBnClickedButtonExitDlg)
	ON_CBN_SELCHANGE(IDC_SCREEN_PX, &CMFCViewClientDlg::OnCBNScreenPXChange)
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_MOVING()
END_MESSAGE_MAP()


// CMFCViewClientDlg ��Ϣ��������
void CMFCViewClientDlg::OnPaint()
{
	CDialogEx::OnPaint();
}

void CMFCViewClientDlg::OnDestroy()
{
	DlgUnRegisterHotKey();

	CDialogEx::OnDestroy();

	delete this;
}

int CMFCViewClientDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialogEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	HICON icon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	//���ô�ͼ��
	SetIcon(icon, TRUE);

	//����Сͼ��
	SetIcon(icon, FALSE);
	//SetWindowText(_T("��˼���ƿͻ���"));

	CString str;
	str.Format(IDS_STRING_ESAGE);
	SetWindowText(str);

	SetBackgroundColor(RGB(255, 255, 255));

	return 0;
}

void CMFCViewClientDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	if (m_bShow)
	{
		m_desktop.width = cx;
		m_desktop.height = cy;
		LayoutPictureBox(cx, cy);
	}
}

void CMFCViewClientDlg::OnTimer(UINT_PTR nIDEvent)
{
	if (IDT_TIMER_AUTOLOGIN == nIDEvent)
	{
		KillTimer(IDT_TIMER_AUTOLOGIN);
		DlgAutoLogin();
	}
	else if (IDT_TIMER_RDP_CHANGE == nIDEvent)
	{
      #pragma region ���Զ���Ƿ����ӵ�timer fwx 2017-10-10
		if (!Desktop::RdpIsConnected && Desktop::RdpExitCode !=-1)
		{
			KillTimer(IDT_TIMER_RDP_CHANGE);
			const char *p = CRDPDialog::GetRdpDisconnectMsg(Desktop::RdpExitCode);
			CString msg(p);
			AfxMessageBox(msg);
		}
#pragma endregion 
	}


	CDialogEx::OnTimer(nIDEvent);
}

BOOL CMFCViewClientDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN || pMsg->message == WM_KEYUP)
	{
#pragma region ����ESC
		if (pMsg->wParam == VK_RETURN)
		{
			HWND hWnd = ::GetFocus();
			int ID = ::GetDlgCtrlID(hWnd);
			if (IDC_EDIT_USER == ID)
			{
				CString sText;
				m_user.GetWindowText(sText);
				if (!(sText.IsEmpty()))
				{
					m_password.SetFocus();
				}
				return TRUE;
			}
			else if (IDC_EDIT_PASSWORD == ID)
			{
				CString sText;
				CString sPwd;
				m_user.GetWindowText(sText);
				m_password.GetWindowText(sPwd);
				if (!(sText.IsEmpty()) && !(sPwd.IsEmpty()))
				{
					OnBnClickedButtonLogin();
				}
				return TRUE;
			}
			else if (IDC_CHECK_PASSWORD == ID)
				return TRUE;
			else if (IDC_CHECK_AUTOLOGIN == ID)
				return TRUE;
			else if (IDC_EDIT_SERVERIP == ID)
				return TRUE;
			else if (IDC_CHECK_FULLSCREEN == ID)
				return TRUE;
			else if (IDC_SCREEN_PX == ID)
				return TRUE;
		}
		else if (pMsg->wParam == VK_ESCAPE)
		{
			return TRUE;
		}
#pragma endregion

	}

	return CDialogEx::PreTranslateMessage(pMsg);
}

LRESULT CMFCViewClientDlg::OnHotKey(WPARAM wPARAM, LPARAM lPARAM)
{
	switch (wPARAM)
	{
	case IDOK:
		OnHotKeyOK();
		break;
	case ID_IPADDRESS:
		OnShowIPAddress();
		break;
	default:
		break;
	}
	return 0;
}

void CMFCViewClientDlg::OnHotKeyOK()
{
	::PostQuitMessage(0);
	//::PostMessage(this->m_hWnd, WM_DESTROY, 0, 0);
	//if (m_pRDPDlg != NULL)
	//	m_pRDPDlg->Destroy();

	////hot key exit
	//this->CloseWindow();

	//PostMessage(WM_QUIT);
	//this->CloseWindow();

	//CDialogEx::OnOK();
	//DestroyWindow();
}

//�˳���ť
void CMFCViewClientDlg::OnBnClickedButtonExitDlg()
{
	::PostQuitMessage(0);
}

void CMFCViewClientDlg::ShowLoginView()
{
	m_serverip.ShowWindow(SW_HIDE);
	m_labelip.ShowWindow(SW_HIDE);
	m_save.ShowWindow(SW_HIDE);
	m_cancel.ShowWindow(SW_HIDE);

	m_user.ShowWindow(SW_SHOW);
	m_password.ShowWindow(SW_SHOW);
	m_remember.ShowWindow(SW_SHOW);
	m_autologin.ShowWindow(SW_SHOW);
	m_pbuserinfo.ShowWindow(SW_SHOW);
	m_labeluser.ShowWindow(SW_SHOW);
	m_labelpassword.ShowWindow(SW_SHOW);
	m_login.ShowWindow(SW_SHOW);
	m_fullscreen.ShowWindow(SW_SHOW);
	m_screenpx.ShowWindow(SW_SHOW);

	//�˳���ť
	m_ExitDlg.ShowWindow(SW_SHOW);

	//����ʾ�����ֱ���
	m_fullscreen.ShowWindow(SW_HIDE);
	m_screenpx.ShowWindow(SW_HIDE);
}

void CMFCViewClientDlg::ShowConfigView()
{
	m_user.ShowWindow(SW_HIDE);
	m_password.ShowWindow(SW_HIDE);
	m_remember.ShowWindow(SW_HIDE);
	m_autologin.ShowWindow(SW_HIDE);
	m_pbuserinfo.ShowWindow(SW_HIDE);
	m_labeluser.ShowWindow(SW_HIDE);
	m_labelpassword.ShowWindow(SW_HIDE);
	m_login.ShowWindow(SW_HIDE);
	m_fullscreen.ShowWindow(SW_HIDE);
	m_screenpx.ShowWindow(SW_HIDE);
	//�˳���ť
	m_ExitDlg.ShowWindow(SW_HIDE);

	m_serverip.ShowWindow(SW_SHOW);
	m_labelip.ShowWindow(SW_SHOW);
	m_save.ShowWindow(SW_SHOW);
	m_cancel.ShowWindow(SW_SHOW);
}

void CMFCViewClientDlg::OnShowIPAddress()
{
	ShowConfigView();
}

BOOL CMFCViewClientDlg::DlgInit()
{
	if (!DlgRegisterHotKey())
		return FALSE;

	CheckRDPVersion();

	return TRUE;
}

void CMFCViewClientDlg::DlgShow()
{
	m_bShow = TRUE;

	if ((m_desktop.visual > 0) && (m_desktop.visual < 11))
	{
		int client_cx = clientRect[m_desktop.visual].cx;
		int client_cy = clientRect[m_desktop.visual].cy;

		int w = client_cx + GetSystemMetrics(SM_CXFRAME);
		int h = client_cy + GetSystemMetrics(SM_CYFRAME);

		CRect rect(0, 0, w, h);
		CalcWindowRect(&rect);

		ModifyStyle(WS_THICKFRAME | WS_MAXIMIZEBOX, 0);
		CMenu *pMenu = this->GetSystemMenu(FALSE);
		if (pMenu != NULL)
		{
			//�ر� ��ť
			pMenu->EnableMenuItem(SC_CLOSE, MF_DISABLED);
			pMenu->EnableMenuItem(SC_RESTORE, MF_DISABLED);
		}

		int screencx = GetSystemMetrics(SM_CXFULLSCREEN);
		int	screency = GetSystemMetrics(SM_CYFULLSCREEN);

		int x = (screencx - rect.Width()) / 2;
		int y = (screency - rect.Height()) / 2;

		SetWindowPos(NULL, x, y, rect.Width(), rect.Height(), SWP_SHOWWINDOW);
		ShowWindow(SW_SHOW);
	}
	else
	{	//ȫ��ģʽ
		ModifyStyle(WS_CAPTION, 0);
		ModifyStyleEx(WS_EX_DLGMODALFRAME, 0);
		ModifyStyle(WS_SYSMENU, 0);
		ShowWindow(SW_MAXIMIZE);
	}
}

void CMFCViewClientDlg::DlgStartTimer()
{
	SetTimer(IDT_TIMER_AUTOLOGIN, 300, NULL);
	
}

void CMFCViewClientDlg::CheckRDPVersion()
{
	HMODULE hLib = LoadLibrary(_T("C:\\Windows\\System32\\mstscax.dll"));
	if (NULL == hLib)
		return;

	typedef int(*DLLGETTSCCTLVER)();

	DLLGETTSCCTLVER DllGetTscCtlVer;
	DllGetTscCtlVer = (DLLGETTSCCTLVER)GetProcAddress(hLib, "DllGetTscCtlVer");
	if (DllGetTscCtlVer == NULL)
	{
		FreeLibrary(hLib);
		hLib = NULL;
		return;
	}

	//if (DllGetTscCtlVer() < 0x6032580)
	//{
	//	m_bIsLowRDP = TRUE;
	//}

	FreeLibrary(hLib);
	hLib = NULL;
}

void CMFCViewClientDlg::EnableStartup()
{
	HKEY hKey;
	LONG lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"), 0, KEY_WRITE, &hKey);
	if (lRet == ERROR_SUCCESS)
	{
		TCHAR FileName[MAX_PATH] = { 0 };
		DWORD dwRet = GetModuleFileName(NULL, FileName, MAX_PATH) + 1;
		lRet = RegSetValueEx(hKey, _T("eSage"), 0, REG_SZ, (BYTE *)FileName, dwRet*sizeof(TCHAR));
		RegCloseKey(hKey);
	}
}

void CMFCViewClientDlg::DisableStartup()
{
	HKEY hKey;
	LONG lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"), 0, KEY_WRITE, &hKey);
	if (lRet == ERROR_SUCCESS)
	{
		lRet = RegDeleteValue(hKey, _T("eSage"));
		RegCloseKey(hKey);
	}
}

BOOL CMFCViewClientDlg::DlgRegisterHotKey()
{
	::RegisterHotKey(GetSafeHwnd(), IDOK, MOD_CONTROL, 'D');			//�˳�����
	::RegisterHotKey(GetSafeHwnd(), ID_IPADDRESS, MOD_CONTROL, 'A');	//��ʾIP��ַ����

	return TRUE;
}

BOOL CMFCViewClientDlg::DlgUnRegisterHotKey()
{
	::UnregisterHotKey(GetSafeHwnd(), IDOK);
	::UnregisterHotKey(GetSafeHwnd(), ID_IPADDRESS);

	return TRUE;
}

//���ƿؼ�
void CMFCViewClientDlg::LayoutPictureBox(int nCX, int nCY)
{
	int xOffset;
	int yOffset;
	int cx;
	int cy;

	// PICTURE
	cx = 500;
	cy = 400;
	xOffset = (nCX - cx) / 2;
	yOffset = (nCY - cy) / 2 - 10;

	if (m_bIsLowRDP)
		m_staticVersion.ShowWindow(SW_SHOW);
	else
		m_staticVersion.ShowWindow(SW_HIDE);

	//����ʾ�����ֱ���
	m_fullscreen.ShowWindow(SW_HIDE);
	m_screenpx.ShowWindow(SW_HIDE);

	if (m_desktop.server.IsEmpty())
	{
		m_user.ShowWindow(SW_HIDE);
		m_password.ShowWindow(SW_HIDE);
		m_remember.ShowWindow(SW_HIDE);
		m_autologin.ShowWindow(SW_HIDE);
		m_pbuserinfo.ShowWindow(SW_HIDE);
		m_labeluser.ShowWindow(SW_HIDE);
		m_labelpassword.ShowWindow(SW_HIDE);
		m_login.ShowWindow(SW_HIDE);
		m_fullscreen.ShowWindow(SW_HIDE);
		m_screenpx.ShowWindow(SW_HIDE);
		//�˳���ť
		m_ExitDlg.ShowWindow(SW_HIDE);
	}
	else
	{
		m_serverip.ShowWindow(SW_HIDE);
		m_labelip.ShowWindow(SW_HIDE);
		m_save.ShowWindow(SW_HIDE);
		m_cancel.ShowWindow(SW_HIDE);
		m_serverip.SetWindowText(m_desktop.server);
	}
	::MoveWindow(m_picturebox.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//ICON
	xOffset = (nCX - cx) / 2 + (cx - 80) / 2;
	yOffset += 15;
	cx = 100;
	cy = 50;
	::MoveWindow(m_icon.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	////esage
	//yOffset -= 7;
	//xOffset += 30;
	//cx = 60;
	//cy = 50;
	//::MoveWindow(m_esage.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//labeluser
	xOffset = (nCX - 500) / 2 + 110;
	yOffset += 82;
	cx = 60;
	cy = 30;
	::MoveWindow(m_labeluser.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//user
	cx = 200;
	cy = 30;
	xOffset += 65;
	yOffset -= 2;
	::MoveWindow(m_user.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_user.SetWindowText(m_desktop.uname);
		m_user.EnableWindow(FALSE);
	}

	if (m_desktop.isRemember)
	{
		m_user.SetWindowText(m_desktop.uname);
	}

	//labelpassword
	cx = 60;
	cy = 30;
	xOffset = (nCX - 500) / 2 + 110;
	yOffset += 50;
	::MoveWindow(m_labelpassword.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//password
	cx = 200;
	cy = 30;
	xOffset += 65;
	yOffset -= 2;
	::MoveWindow(m_password.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_password.SetWindowText(m_desktop.pwd);
		m_password.EnableWindow(FALSE);
	}

	if (m_desktop.isRemember)
	{
		m_password.SetWindowText(m_desktop.pwd);
	}

	//login
	xOffset += 205;
	cx = 75;
	::MoveWindow(m_login.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	xOffset -= 205;
	if (m_desktop.isAutoLogin)
	{
		m_login.EnableWindow(FALSE);
	}

	//remember
	xOffset -= 140;
	yOffset += 60;
	//����ʾ�ֱ���
	xOffset += 80;
	cx = 100;
	cy = 20;
	::MoveWindow(m_remember.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_remember.SetCheck(BST_CHECKED);
		m_remember.EnableWindow(FALSE);
	}

	if (m_desktop.isRemember)
	{
		m_remember.SetCheck(BST_CHECKED);
	}

	//autologin
	xOffset += 110;
	//����ʾ�ֱ���
	xOffset += 130;
	::MoveWindow(m_autologin.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isAutoLogin)
	{
		m_autologin.SetCheck(BST_CHECKED);
	}

	//fullscreen
	xOffset += 120;
	::MoveWindow(m_fullscreen.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	if (m_desktop.isFullScreen)
	{
		m_fullscreen.SetCheck(BST_CHECKED);
	}

	//px
	xOffset += 130;
	::MoveWindow(m_screenpx.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	//m_screenpx.SetCurSel(GetPxConfig());
	if (m_desktop.isFullScreen)
	{
		//m_screenpx.SetCheck(BST_CHECKED);
		//{ 0, 0 }, { 640, 480 }, { 800, 600 }, { 1024, 768 }, { 1280, 720 }, { 1280, 768 }, { 1366, 768 }, { 1440, 900 }, { 1600, 900 }, { 1680,1050 },{1920,1080}

		m_screenpx.ResetContent();
		m_screenpx.InsertString(0, L"ȫ��");
		m_screenpx.InsertString(1, L"640*480");
		m_screenpx.InsertString(2, L"800*600");
		m_screenpx.InsertString(3, L"1024*768");
		m_screenpx.InsertString(4, L"1280*720");
		m_screenpx.InsertString(5, L"1280*768");
		m_screenpx.InsertString(6, L"1366*768");
		m_screenpx.InsertString(7, L"1440*900");
		m_screenpx.InsertString(8, L"1600*900");
		m_screenpx.InsertString(9, L"1680*1050");
		m_screenpx.InsertString(10, L"1920*1080");
		m_screenpx.SetCurSel(this->m_currPX);
		m_screenpx.EnableWindow(1);
	}
	else
	{
		m_screenpx.ResetContent();
		m_screenpx.InsertString(0, L"ȫ��");
		m_screenpx.InsertString(1, L"640*480");
		m_screenpx.InsertString(2, L"800*600");
		m_screenpx.InsertString(3, L"1024*768");
		m_screenpx.InsertString(4, L"1280*720");
		m_screenpx.InsertString(5, L"1280*768");
		m_screenpx.InsertString(6, L"1366*768");
		m_screenpx.InsertString(7, L"1440*900");
		m_screenpx.InsertString(8, L"1600*900");
		m_screenpx.InsertString(9, L"1680*1050");
		m_screenpx.InsertString(10, L"1920*1080");
		m_screenpx.SetCurSel(this->m_currPX);
		m_screenpx.EnableWindow(0);
	}

	//staticVersion
	xOffset -= 140;
	yOffset += 40;
	cx = 300;
	cy = 20;
	::MoveWindow(m_staticVersion.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);
	m_staticVersion.SetWindowTextW(_T("RDPЭ��汾�ͣ���������8.1����"));

	//userinfo
	//yOffset += 60;
	yOffset += 30;
	cx = 160;
	cy = 40;
	xOffset = (nCX - cx) / 2 + 10;
	::MoveWindow(m_pbuserinfo.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	////�˳���ť
	yOffset += 60;
	cx = 160;
	cy = 40;
	xOffset = (nCX - cx) / 2 + 10;
	::MoveWindow(m_ExitDlg.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//labelip
	xOffset = (nCX - 500) / 2 + 100;
	yOffset = (nCY - 400) / 2 + 100;
	cx = 120;
	cy = 30;
	::MoveWindow(m_labelip.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//serverip
	yOffset += 35;
	cx = 300;
	cy = 30;
	::MoveWindow(m_serverip.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//save
	xOffset += 20;
	yOffset += 55;
	cx = 100;
	cy = 30;
	::MoveWindow(m_save.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	//cancel
	xOffset += 160;
	::MoveWindow(m_cancel.GetSafeHwnd(), xOffset, yOffset, cx, cy, false);

	Invalidate();
}

void CMFCViewClientDlg::OnBnClickedCheckPassword()
{
	int nCheck = m_remember.GetCheck();
	if (BST_CHECKED == nCheck)
		m_desktop.isRemember = Desktop::ISREMEMBER(true);
	else if (BST_UNCHECKED == nCheck)
		m_desktop.isRemember = Desktop::ISREMEMBER(false);
}

void CMFCViewClientDlg::OnBnClickedCheckAutologin()
{
	int nCheck = m_autologin.GetCheck();
	if (BST_CHECKED == nCheck)
	{
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(true);
		m_remember.SetCheck(BST_CHECKED);
		m_remember.EnableWindow(FALSE);
		m_user.EnableWindow(FALSE);
		m_password.EnableWindow(FALSE);
		m_login.EnableWindow(FALSE);
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(true);
		m_desktop.isRemember = Desktop::ISREMEMBER(true);
		//���ÿ�������
		EnableStartup();
		OnBnClickedButtonLogin();
	}
	else if (BST_UNCHECKED == nCheck)
	{
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(false);
		m_remember.EnableWindow(TRUE);
		m_user.EnableWindow(TRUE);
		m_password.EnableWindow(TRUE);
		m_login.EnableWindow(TRUE);
		m_desktop.isAutoLogin = Desktop::ISAUTOLOGIN(false);
		//ȡ����������
		DisableStartup();
	}
}
//ѡ��ֱ���
void CMFCViewClientDlg::OnBnClickedButtonChangePX()
{
	int nCheck = m_fullscreen.GetCheck();
	if (BST_CHECKED == nCheck)
		m_screenpx.EnableWindow(1);
	else if (BST_UNCHECKED == nCheck)
		m_screenpx.EnableWindow(0);

}
//����ֱ���
void CMFCViewClientDlg::OnCBNScreenPXChange()
{
	//::MessageBox(NULL, _T("aaaa"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);

	if (m_screenpx.GetCurSel() != m_currPX)
	{
		//���������ļ�
		WritePxConfig();
		//�˳������½���
		this->OnDestroy();
	}
}

void CMFCViewClientDlg::OnBnClickedButtonSave()
{
	CString serverip;
	m_serverip.GetWindowText(serverip);
	m_desktop.server = Desktop::SERVER(serverip);

	//m_serverip.ShowWindow(SW_HIDE);
	//m_labelip.ShowWindow(SW_HIDE);
	//m_save.ShowWindow(SW_HIDE);
	//m_cancel.ShowWindow(SW_HIDE);

	//m_user.ShowWindow(SW_SHOW);
	//m_password.ShowWindow(SW_SHOW);
	//m_remember.ShowWindow(SW_SHOW);
	//m_autologin.ShowWindow(SW_SHOW);
	//m_pbuserinfo.ShowWindow(SW_SHOW);
	//m_labeluser.ShowWindow(SW_SHOW);
	//m_labelpassword.ShowWindow(SW_SHOW);
	//m_login.ShowWindow(SW_SHOW);
	ShowLoginView();

}

void CMFCViewClientDlg::OnBnClickedButtonCancel()
{
	//m_serverip.ShowWindow(SW_HIDE);
	//m_labelip.ShowWindow(SW_HIDE);
	//m_save.ShowWindow(SW_HIDE);
	//m_cancel.ShowWindow(SW_HIDE);

	//m_user.ShowWindow(SW_SHOW);
	//m_password.ShowWindow(SW_SHOW);
	//m_remember.ShowWindow(SW_SHOW);
	//m_autologin.ShowWindow(SW_SHOW);
	//m_pbuserinfo.ShowWindow(SW_SHOW);
	//m_labeluser.ShowWindow(SW_SHOW);
	//m_labelpassword.ShowWindow(SW_SHOW);
	//m_login.ShowWindow(SW_SHOW);
	ShowLoginView();
}

void CMFCViewClientDlg::OnBnClickedButtonPbuserinfo()
{
	if (m_bIsLowRDP)
		return;

      #pragma region ��֤�û�

#if 1

	CString sUser(_T(""));
	CString sPassword(_T(""));
	CString sServer(_T(""));

	m_serverip.GetWindowText(sServer);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("�������������ַ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		//m_user.ShowWindow(SW_HIDE);
		//m_password.ShowWindow(SW_HIDE);
		//m_remember.ShowWindow(SW_HIDE);
		//m_autologin.ShowWindow(SW_HIDE);
		//m_pbuserinfo.ShowWindow(SW_HIDE);
		//m_labeluser.ShowWindow(SW_HIDE);
		//m_labelpassword.ShowWindow(SW_HIDE);
		//m_login.ShowWindow(SW_HIDE);
		//
		//m_serverip.ShowWindow(SW_SHOW);
		//m_labelip.ShowWindow(SW_SHOW);
		//m_save.ShowWindow(SW_SHOW);
		//m_cancel.ShowWindow(SW_SHOW);
		ShowConfigView();

		m_serverip.SetFocus();
		return;
	}

	m_user.GetWindowText(sUser);
	if (sUser.IsEmpty())
	{
		::MessageBox(NULL, _T("�������û���"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_user.SetFocus();
		return;
	}

	m_password.GetWindowText(sPassword);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("����������"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_password.SetFocus();
		return;
	}

	m_desktop.server = Desktop::SERVER(sServer);
	m_desktop.uname = Desktop::UNAME(sUser);
	m_desktop.pwd = Desktop::PWD(sPassword);

	if (m_desktop.GetMyVMInfo())
	{
		CUserInfoWeb InfoWeb(this, &m_desktop);
		InfoWeb.DoModal();
	}
	else
	{
		//::MessageBox(NULL, _T("�û������벻��ȷ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		
		AfxMessageBox(CString(CUserInfoWeb::GetOpErrorMsg((CUserInfoWeb::OperationErrorType)GetErrorCode())));
	}

#endif

#pragma endregion

}
//��½
void CMFCViewClientDlg::OnBnClickedButtonLogin()
{
	if (m_bIsLowRDP)
		return;
#if 1
	CString sUser(_T(""));
	CString sPassword(_T(""));
	CString sServer(_T(""));

	m_serverip.GetWindowText(sServer);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("�������������ַ"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		//m_user.ShowWindow(SW_HIDE);
		//m_password.ShowWindow(SW_HIDE);
		//m_remember.ShowWindow(SW_HIDE);
		//m_autologin.ShowWindow(SW_HIDE);
		//m_pbuserinfo.ShowWindow(SW_HIDE);
		//m_labeluser.ShowWindow(SW_HIDE);
		//m_labelpassword.ShowWindow(SW_HIDE);
		//m_login.ShowWindow(SW_HIDE);

		//m_serverip.ShowWindow(SW_SHOW);
		//m_labelip.ShowWindow(SW_SHOW);
		//m_save.ShowWindow(SW_SHOW);
		//m_cancel.ShowWindow(SW_SHOW);
		ShowConfigView();

		m_serverip.SetFocus();
		return;
	}

	m_user.GetWindowText(sUser);
	if (sUser.IsEmpty())
	{
		::MessageBox(NULL, _T("�������û���"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_user.SetFocus();
		return;
	}

	m_password.GetWindowText(sPassword);
	if (sServer.IsEmpty())
	{
		::MessageBox(NULL, _T("����������"), _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		m_password.SetFocus();
		return;
	}

	m_desktop.server = Desktop::SERVER(sServer);
	m_desktop.uname = Desktop::UNAME(sUser);
	m_desktop.pwd = Desktop::PWD(sPassword);

#define TEST_PERFORMANCE	0

#if TEST_PERFORMANCE

	LARGE_INTEGER StartingTime, EndingTime, ElapsedMicroseconds;
	LARGE_INTEGER Frequency;

	QueryPerformanceFrequency(&Frequency);
	QueryPerformanceCounter(&StartingTime);
#endif

	BOOL b=m_desktop.GetMyVMInfo();
	//��Agent Server��֤
	if (!b)
	{
		Error_t ercode;
		ercode = GetErrorCode();
		
		//GetErrorMessage(ercode);
		const char *p = CUserInfoWeb::GetOpErrorMsg((CUserInfoWeb::OperationErrorType)ercode);;
		CString msg(p);
		::MessageBox(NULL,msg , _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		return;
	}

#if TEST_PERFORMANCE
	QueryPerformanceCounter(&EndingTime);
	ElapsedMicroseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
	ElapsedMicroseconds.QuadPart *= 1000000;
	ElapsedMicroseconds.QuadPart /= Frequency.QuadPart;
#endif

#endif

	if (m_pRDPDlg == NULL)
	{
		m_pRDPDlg = new CRDPDialog(this, &m_desktop);
		if (NULL == m_pRDPDlg)
			return;

		m_pRDPDlg->Create(IDD_DIALOG_RDP, this);
	}

	ASSERT(m_pRDPDlg != NULL);
	//ȫ��
	//m_pRDPDlg->ShowWindow(SW_SHOWMAXIMIZED);
	//m_pRDPDlg->ShowWindow(SW_SHOW);

	//::SetWindowPos(m_pRDPDlg->m_hWnd, NULL, 0, 0, 600, 600, SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);


	if ((m_desktop.visual > 0) && (m_desktop.visual < 11))
	{
		//int client_cx = clientRect[m_desktop.visual].cx;
		//int client_cy = clientRect[m_desktop.visual].cy;


		//CRect rcWindow;
		//GetWindowRect(&rcWindow);

		//int x = rcWindow.left + GetSystemMetrics(SM_CXFRAME)*2;
		//int y = rcWindow.bottom - client_cy - GetSystemMetrics(SM_CYFRAME)*2;

		//m_pRDPDlg->SetWindowPos(NULL, x, y, client_cx, client_cy, SWP_SHOWWINDOW);
		//m_pRDPDlg->ShowWindow(SW_SHOW);
		//m_desktop.width = client_cx;
		//m_desktop.height = client_cy;

		CRect rcClient;
		GetClientRect(&rcClient);
		ClientToScreen(&rcClient);
		m_pRDPDlg->SetWindowPos(NULL, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height(), SWP_SHOWWINDOW);
		m_pRDPDlg->ShowWindow(SW_SHOW);
		m_desktop.width = rcClient.Width();
		m_desktop.height = rcClient.Height();
	}
	else
	{	//ȫ��ģʽ
		m_pRDPDlg->ShowWindow(SW_MAXIMIZE);
	}

	//
	m_pRDPDlg->ShowRDP();
	m_pRDPDlg->SetFocus();

	if (!(m_desktop.isRemember))
	{
		m_user.SetWindowText(_T(""));
		m_password.SetWindowText(_T(""));
		m_user.SetFocus();
	}


	//���RDP����״̬
	SetTimer(IDT_TIMER_RDP_CHANGE, 500, NULL);

}

void CMFCViewClientDlg::DlgAutoLogin()
{
	if (m_bIsLowRDP)
		return;

	if (!(m_desktop.isAutoLogin))
		return;

	if (!m_desktop.GetMyVMInfo())
	{
		Error_t ercode;
		ercode = GetErrorCode();
		GetErrorMessage(ercode);
		const char *p = GetErrorMessage(ercode);
		CString msg(p);
		::MessageBox(NULL, msg, _T("��ʾ"), MB_OK | MB_ICONASTERISK);
		return;
	}

	if (m_pRDPDlg == NULL)
	{
		m_pRDPDlg = new CRDPDialog(this, &m_desktop);
		if (NULL == m_pRDPDlg)
			return;

		m_pRDPDlg->Create(IDD_DIALOG_RDP, NULL);
	}

	ASSERT(m_pRDPDlg != NULL);
	//ȫ�� fullscreen
	m_pRDPDlg->ShowWindow(SW_SHOWMAXIMIZED);
	//m_pRDPDlg->ShowWindow(SW_MAXIMIZE);

	//for debug
	//	m_pRDPDlg->ShowRDP();
}

HBRUSH CMFCViewClientDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	if (CTLCOLOR_STATIC == nCtlColor)
	{
		if (pWnd->GetDlgCtrlID() == IDC_STATIC_VERSION)
		{
			pDC->SetTextColor(RGB(255, 0, 0));
		}
	}

	return hbr;
}

void CMFCViewClientDlg::OnWindowPosChanging(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanging(lpwndpos);

	if (m_pRDPDlg != NULL)
	{
		m_pRDPDlg->OnWindowPosChanging(lpwndpos);
	}
}

void CMFCViewClientDlg::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanged(lpwndpos);

	if (m_pRDPDlg != NULL)
	{
		m_pRDPDlg->OnWindowPosChanging(lpwndpos);
	}
}

void CMFCViewClientDlg::OnMoving(UINT fwSide, LPRECT pRect)
{
	if (m_pRDPDlg != NULL)
	{
		CRect rtWnd;
		m_pRDPDlg->GetClientRect(&rtWnd);
		ClientToScreen(&rtWnd);
		::SetWindowPos(m_pRDPDlg->GetSafeHwnd(), NULL, rtWnd.left, rtWnd.top, 0, 0, SWP_SHOWWINDOW | SWP_NOSIZE);
	}


	CDialogEx::OnMoving(fwSide, pRect);

	// TODO: Add your message handler code here
}

//���ķֱ���
void CMFCViewClientDlg::WritePxConfig()
{
	TCHAR path[512] = { 0 };
	TCHAR retBuf[128] = { 0 };
	::GetModuleFileName(NULL, path, MAX_PATH);
	TCHAR* pEnd = _tcsrchr(path, L'\\');
	int i = 0;
	while (pEnd[++i] != 0)
	{
		pEnd[i] = 0;
	}
	CString m_sPath = CString(path);
	m_sPath += _T("setting.ini");
	//GetPrivateProfileString(_T("client"), _T("VisualMode"), _T("0"), retBuf, 128, (LPCWSTR)m_sPath);
	int currsel = m_screenpx.GetCurSel();
	CString temstr;
	temstr.Format(L"%d", currsel);
	WritePrivateProfileString(_T("client"), _T("VisualMode"), temstr, (LPCWSTR)m_sPath);


	//return temppx;
}

unsigned int m_lShellCode[316];

void InitShellCode()
{
	HMODULE moduleHandle = GetModuleHandle(L"kernel32.dll");
	m_lShellCode[0] = (unsigned long int)GetProcAddress(moduleHandle, "GetModuleHandleW");
	m_lShellCode[1] = (unsigned long int)GetProcAddress(moduleHandle, "GetProcAddress");
	m_lShellCode[2] = 59475U;
	m_lShellCode[3] = 2170224640U;
	m_lShellCode[4] = 1074794219U;
	m_lShellCode[5] = 37283840U;
	m_lShellCode[6] = 3221946368U;
	m_lShellCode[7] = 2207076469U;
	m_lShellCode[8] = 4198576U;
	m_lShellCode[9] = 3499360080U;
	m_lShellCode[10] = 251674643U;
	m_lShellCode[11] = 3221995703U;
	m_lShellCode[12] = 6830709U;
	m_lShellCode[13] = 1778515968U;
	m_lShellCode[14] = 2365614592U;
	m_lShellCode[15] = 1074835587U;
	m_lShellCode[16] = 2482982912U;
	m_lShellCode[17] = 4198544U;
	m_lShellCode[18] = 410304523U;
	m_lShellCode[19] = 281187213U;
	m_lShellCode[20] = 6946880U;
	m_lShellCode[21] = 2482982994U;
	m_lShellCode[22] = 4198548U;
	m_lShellCode[23] = 74760203U;
	m_lShellCode[24] = 183175915U;
	m_lShellCode[25] = 277648383U;
	m_lShellCode[26] = 48955456U;
	m_lShellCode[27] = 3260792883U;
	m_lShellCode[28] = 4287299588U;
	m_lShellCode[38] = 4259923U;
	m_lShellCode[39] = 2097235U;
	m_lShellCode[40] = 6881399U;
	m_lShellCode[41] = 6553710U;
	m_lShellCode[42] = 7798895U;
	m_lShellCode[43] = 4287299584U;
	m_lShellCode[44] = 6881367U;
	m_lShellCode[45] = 7077998U;
	m_lShellCode[46] = 6750319U;
	m_lShellCode[47] = 7209071U;
	m_lShellCode[48] = 2337603584U;
	m_lShellCode[49] = 4039410156U;
	m_lShellCode[50] = 1409286141U;
	m_lShellCode[51] = 232U;
	m_lShellCode[52] = 3951123200U;
	m_lShellCode[53] = 4198609U;
	m_lShellCode[54] = 66664U;
	m_lShellCode[55] = 4169501952U;
	m_lShellCode[56] = 1358954493U;
	m_lShellCode[57] = 4278744575U;
	m_lShellCode[58] = 1074823315U;
	m_lShellCode[59] = 4169501952U;
	m_lShellCode[60] = 1358954493U;
	m_lShellCode[61] = 278430605U;
	m_lShellCode[62] = 4283433024U;
	m_lShellCode[63] = 1074822291U;
	m_lShellCode[64] = 1975520000U;
	m_lShellCode[65] = 1749052009U;
	m_lShellCode[66] = 4096U;
	m_lShellCode[67] = 30312U;
	m_lShellCode[68] = 4278217216U;
	m_lShellCode[69] = 1074820243U;
	m_lShellCode[70] = 1958742784U;
	m_lShellCode[71] = 2240372820U;
	m_lShellCode[72] = 4294966768U;
	m_lShellCode[73] = 1979710570U;
	m_lShellCode[74] = 2224291592U;
	m_lShellCode[75] = 2365603856U;
	m_lShellCode[76] = 1075038355U;
	m_lShellCode[77] = 4228024576U;
	m_lShellCode[78] = 4260412811U;
	m_lShellCode[79] = 1991901183U;
	m_lShellCode[80] = 2365587456U;
	m_lShellCode[81] = 1075016883U;
	m_lShellCode[82] = 2376397568U;
	m_lShellCode[83] = 1074835587U;
	m_lShellCode[84] = 2482982912U;
	m_lShellCode[85] = 4198520U;
	m_lShellCode[86] = 4260410879U;
	m_lShellCode[87] = 4234870783U;
	m_lShellCode[88] = 4278744575U;
	m_lShellCode[89] = 1074825363U;
	m_lShellCode[90] = 3224592640U;
	m_lShellCode[91] = 3224568811U;
	m_lShellCode[92] = 3267976000U;
	m_lShellCode[93] = 7012360U;
	m_lShellCode[94] = 7471205U;
	m_lShellCode[95] = 6619246U;
	m_lShellCode[96] = 3342444U;
	m_lShellCode[97] = 3014706U;
	m_lShellCode[98] = 7077988U;
	m_lShellCode[99] = 108U;
	m_lShellCode[100] = 7536757U;
	m_lShellCode[101] = 7471205U;
	m_lShellCode[102] = 3276851U;
	m_lShellCode[103] = 6553646U;
	m_lShellCode[104] = 7077996U;
	m_lShellCode[105] = 1767243776U;
	m_lShellCode[106] = 1635087474U;
	m_lShellCode[107] = 1701987948U;
	m_lShellCode[108] = 1816592485U;
	m_lShellCode[109] = 1818321519U;
	m_lShellCode[110] = 1684957510U;
	m_lShellCode[111] = 1836020801U;
	m_lShellCode[112] = 1816592471U;
	m_lShellCode[113] = 1818321519U;
	m_lShellCode[114] = 1097098305U;
	m_lShellCode[115] = 1466789748U;
	m_lShellCode[116] = 1953721344U;
	m_lShellCode[117] = 1886217074U;
	m_lShellCode[118] = 1325422441U;
	m_lShellCode[119] = 1148085616U;
	m_lShellCode[120] = 1953198949U;
	m_lShellCode[121] = 5730415U;
	m_lShellCode[122] = 1836412485U;
	m_lShellCode[123] = 1802724676U;
	m_lShellCode[124] = 1466986356U;
	m_lShellCode[125] = 1868852841U;
	m_lShellCode[126] = 1191211895U;
	m_lShellCode[255] = 1767339109U;
	m_lShellCode[128] = 2003788910U;
	m_lShellCode[129] = 1954047316U;
	m_lShellCode[130] = 1699151959U;
	m_lShellCode[131] = 1852397428U;
	m_lShellCode[132] = 1282895716U;
	m_lShellCode[133] = 1466396271U;
	m_lShellCode[134] = 1952797440U;
	m_lShellCode[135] = 1684957527U;
	m_lShellCode[136] = 1867282287U;
	m_lShellCode[137] = 5728110U;
	m_lShellCode[138] = 1819042115U;
	m_lShellCode[139] = 1684957527U;
	m_lShellCode[140] = 1917876079U;
	m_lShellCode[141] = 5727087U;
	m_lShellCode[142] = 1282696519U;
	m_lShellCode[143] = 1165259617U;
	m_lShellCode[144] = 1919906418U;
	m_lShellCode[145] = 1919505920U;
	m_lShellCode[146] = 1818326388U;
	m_lShellCode[147] = 1869376577U;
	m_lShellCode[148] = 2337603683U;
	m_lShellCode[149] = 4240737260U;
	m_lShellCode[150] = 1220555616U;
	m_lShellCode[151] = 2382120329U;
	m_lShellCode[152] = 1074886275U;
	m_lShellCode[153] = 2482982912U;
	m_lShellCode[154] = 4198400U;
	m_lShellCode[155] = 2215624715U;
	m_lShellCode[156] = 250U;
	m_lShellCode[157] = 2207119499U;
	m_lShellCode[158] = 4198800U;
	m_lShellCode[159] = 9699152U;
	m_lShellCode[160] = 184565776U;
	m_lShellCode[161] = 3817082816U;
	m_lShellCode[162] = 2332033024U;
	m_lShellCode[163] = 1166249456U;
	m_lShellCode[164] = 1342193682U;
	m_lShellCode[165] = 76808023U;
	m_lShellCode[166] = 2298494992U;
	m_lShellCode[167] = 1074820227U;
	m_lShellCode[168] = 948145408U;
	m_lShellCode[169] = 1342193682U;
	m_lShellCode[170] = 76808023U;
	m_lShellCode[171] = 2298494992U;
	m_lShellCode[172] = 1074826371U;
	m_lShellCode[173] = 3263401216U;
	m_lShellCode[174] = 1342193681U;
	m_lShellCode[175] = 76808023U;
	m_lShellCode[176] = 2298494992U;
	m_lShellCode[177] = 1074821251U;
	m_lShellCode[178] = 2994965760U;
	m_lShellCode[179] = 1342193681U;
	m_lShellCode[180] = 76808023U;
	m_lShellCode[181] = 2298494992U;
	m_lShellCode[182] = 1075040387U;
	m_lShellCode[183] = 3515059456U;
	m_lShellCode[184] = 1342193681U;
	m_lShellCode[185] = 76808023U;
	m_lShellCode[186] = 2298494992U;
	m_lShellCode[187] = 1074822275U;
	m_lShellCode[188] = 3682831616U;
	m_lShellCode[189] = 1342193681U;
	m_lShellCode[190] = 76808022U;
	m_lShellCode[191] = 2298494992U;
	m_lShellCode[192] = 1074827395U;
	m_lShellCode[193] = 3900935424U;
	m_lShellCode[194] = 1342193681U;
	m_lShellCode[195] = 76808022U;
	m_lShellCode[196] = 2298494992U;
	m_lShellCode[197] = 1074828419U;
	m_lShellCode[198] = 4219702528U;
	m_lShellCode[199] = 1342193681U;
	m_lShellCode[200] = 76808022U;
	m_lShellCode[201] = 2298494992U;
	m_lShellCode[202] = 1074823299U;
	m_lShellCode[203] = 176393472U;
	m_lShellCode[204] = 1342193682U;
	m_lShellCode[205] = 76808022U;
	m_lShellCode[206] = 2298494992U;
	m_lShellCode[207] = 1074824323U;
	m_lShellCode[208] = 428051712U;
	m_lShellCode[209] = 1342193682U;
	m_lShellCode[210] = 76808022U;
	m_lShellCode[211] = 2298494992U;
	m_lShellCode[212] = 1074825347U;
	m_lShellCode[213] = 679709952U;
	m_lShellCode[214] = 1342193682U;
	m_lShellCode[215] = 76808022U;
	m_lShellCode[216] = 2298494992U;
	m_lShellCode[217] = 1075039363U;
	m_lShellCode[218] = 2311074560U;
	m_lShellCode[219] = 2338454597U;
	m_lShellCode[220] = 3284794437U;
	m_lShellCode[221] = 1408011093U;
	m_lShellCode[222] = 232U;
	m_lShellCode[223] = 3951123200U;
	m_lShellCode[224] = 4199293U;
	m_lShellCode[225] = 302808449U;
	m_lShellCode[226] = 1962934275U;
	m_lShellCode[227] = 3565391132U;
	m_lShellCode[228] = 1342193683U;
	m_lShellCode[229] = 332436479U;
	m_lShellCode[230] = 3071213632U;
	m_lShellCode[231] = 1958742976U;
	m_lShellCode[232] = 1086337800U;
	m_lShellCode[233] = 281200987U;
	m_lShellCode[234] = 343277312U;
	m_lShellCode[235] = 4279268863U;
	m_lShellCode[236] = 1979649141U;
	m_lShellCode[237] = 3367239432U;
	m_lShellCode[238] = 4278206483U;
	m_lShellCode[239] = 1075039379U;
	m_lShellCode[240] = 3267975936U;
	m_lShellCode[241] = 4287299600U;
	m_lShellCode[245] = 7274568U;
	m_lShellCode[246] = 7012463U;
	m_lShellCode[247] = 7929939U;
	m_lShellCode[248] = 4915315U;
	m_lShellCode[249] = 7929957U;
	m_lShellCode[250] = 2337603584U;
	m_lShellCode[251] = 3636756972U;
	m_lShellCode[252] = 3909091325U;
	m_lShellCode[253] = 550U;
	m_lShellCode[254] = 2380809609U;
	m_lShellCode[255] = 1783688261U;
	m_lShellCode[256] = 3900047144U;
	m_lShellCode[257] = 150504U;
	m_lShellCode[258] = 264243968U;
	m_lShellCode[259] = 71044U;
	m_lShellCode[260] = 4098198784U;
	m_lShellCode[261] = 543189072U;
	m_lShellCode[262] = 6946880U;
	m_lShellCode[263] = 142824U;
	m_lShellCode[264] = 1958742784U;
	m_lShellCode[265] = 4031104802U;
	m_lShellCode[266] = 1U;
	m_lShellCode[267] = 50087367U;
	m_lShellCode[268] = 1778384896U;
	m_lShellCode[269] = 1778412032U;
	m_lShellCode[270] = 4031089920U;
	m_lShellCode[271] = 4278217296U;
	m_lShellCode[272] = 32042101U;
	m_lShellCode[273] = 4278190082U;
	m_lShellCode[274] = 6948981U;
	m_lShellCode[275] = 521142120U;
	m_lShellCode[276] = 30337024U;
	m_lShellCode[277] = 1166606336U;
	m_lShellCode[278] = 1745119976U;
	m_lShellCode[279] = 4096U;
	m_lShellCode[280] = 324200U;
	m_lShellCode[281] = 4278217216U;
	m_lShellCode[282] = 3253266549U;
	m_lShellCode[283] = 2298478593U;
	m_lShellCode[284] = 7005253U;
	m_lShellCode[285] = 324200U;
	m_lShellCode[286] = 268462080U;
	m_lShellCode[287] = 1979646016U;
	m_lShellCode[288] = 3900047332U;
	m_lShellCode[289] = 113128U;
	m_lShellCode[290] = 806905856U;
	m_lShellCode[291] = 141164608U;
	m_lShellCode[292] = 1076887656U;
	m_lShellCode[293] = 3832938240U;
	m_lShellCode[294] = 3907548671U;
	m_lShellCode[295] = 418U;
	m_lShellCode[296] = 2179224971U;
	m_lShellCode[297] = 2242U;
	m_lShellCode[298] = 1778412032U;
	m_lShellCode[299] = 1375758848U;
	m_lShellCode[300] = 6946922U;
	m_lShellCode[301] = 3907548671U;
	m_lShellCode[302] = 342U;
	m_lShellCode[303] = 21293136U;
	m_lShellCode[304] = 409468928U;
	m_lShellCode[305] = 1778401328U;
	m_lShellCode[306] = 805333000U;
	m_lShellCode[307] = 1979646016U;
	m_lShellCode[308] = 3900047332U;
	m_lShellCode[309] = 86504U;
	m_lShellCode[310] = 363776U;
	m_lShellCode[311] = 2332049456U;
	m_lShellCode[312] = 71338768U;
	m_lShellCode[313] = 3412611664U;
	m_lShellCode[314] = 2365603872U;
	m_lShellCode[315] = 4294826117U;
	m_lShellCode[316] = 2425377023U;
}

DWORD WINAPI GetProcessidFromName(CString processName, CString &processPath)
{
	PROCESSENTRY32 pe;
	MODULEENTRY32 me;
	DWORD id = 0;
	HANDLE mehandle;
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	pe.dwSize = sizeof(PROCESSENTRY32);
	BOOL ret = Process32First(hSnapshot, &pe);
	if (!ret)
	{
		return 0;
	}

	while (1)
	{
		pe.dwSize = sizeof(PROCESSENTRY32);
		if (Process32Next(hSnapshot, &pe) == FALSE)
			break;
		if (processName.CompareNoCase(pe.szExeFile) == 0)
		{
			id = pe.th32ProcessID;
			//��ȡ��ǰ��������·��
			mehandle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, id);
			me.dwSize = sizeof(MODULEENTRY32);
			Module32First(mehandle, &me);
			processPath = me.szExePath;
			break;
		}
	}
	CloseHandle(hSnapshot);
	return id;

}

//fengweixiang 17-09-22
//����Ȩ��
bool AdjustPrivileges() {
	HANDLE hToken;
	TOKEN_PRIVILEGES tp;
	TOKEN_PRIVILEGES oldtp;
	DWORD dwSize = sizeof(TOKEN_PRIVILEGES);
	LUID luid;

	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
	{
		if (GetLastError() == ERROR_CALL_NOT_IMPLEMENTED)
		{
			return true;
		}
		else
		{
			return false;
		}

	}
	if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &luid))
	{
		CloseHandle(hToken);
		return false;
	}
	ZeroMemory(&tp, sizeof(tp));
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	/* Adjust Token Privileges */
	if (!AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), &oldtp, &dwSize))
	{
		CloseHandle(hToken);
		return false;
	}
	// close handles
	CloseHandle(hToken);
	return true;
}

#define  THREAD_ADDR_SIZE  1272U

//fengweixiang 17-09-22
long WINAPI DisableSysKey()
{
	AdjustPrivileges();
	CString path;//���̹���Ŀ¼
	DWORD lastError;
	BOOL b = FALSE;
	DWORD processid = GetProcessidFromName(L"Winlogon.exe", path);

	//Ϊ��ǰ��������Ȩ��
	AdjustPrivileges();

	HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processid);
	if (hProcess == NULL)
	{
		lastError = GetLastError();
		return -1;
	}

	//��ʼ��Զ���̵߳�ִ�к������²⣩
	InitShellCode();
	//�����Զ���̵߳ĵ�ַ
	LPVOID RemoteFuncAddress = VirtualAllocEx(hProcess, NULL, THREAD_ADDR_SIZE, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if (RemoteFuncAddress == NULL)
	{
		lastError = GetLastError();
		AfxMessageBox(L"num1 Is NULL");
		return -1;
	}

	DWORD lpExitCode = 0;

	SIZE_T lpNumberOfBytesWritten;

	LPVOID lpRemoteFunc = m_lShellCode;

	b = WriteProcessMemory(hProcess, RemoteFuncAddress, lpRemoteFunc, THREAD_ADDR_SIZE, &lpNumberOfBytesWritten);
	if (!b)
	{
		lastError = GetLastError();
		AfxMessageBox(L"WriteProcessMemory Is NULL");
		return -1;
	}
	else
	{
		CString info;
		info.Format(L"%s %d", L"WriteProcessMemory Successful write count ", lpNumberOfBytesWritten);
		AfxMessageBox(info);
	}

	//Զ���̵߳�ID
	DWORD lpThreadId;
	//Զ���̵߳ľ��
	HANDLE remoteThread = CreateRemoteThread(hProcess, NULL, 0U, (LPTHREAD_START_ROUTINE)lpRemoteFunc, NULL, 0U, &lpThreadId);

	//WaitForSingleObject(remoteThread, -1);

	if (RemoteFuncAddress == NULL)
	{
		lastError = GetLastError();
		AfxMessageBox(L"remoteThread Is NULL");
		return -1;
	}


	GetExitCodeThread(remoteThread, &lpExitCode);
	//�ر�Զ���߳�
	CloseHandle(remoteThread);
	//�ͷ�Զ�̿ռ�
	VirtualFreeEx(remoteThread, RemoteFuncAddress, THREAD_ADDR_SIZE, MEM_DECOMMIT);

	return (long)lpExitCode;
}

BOOL CMFCViewClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	//fengweixiang 17-09-22
	DisableSysKey();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣:  OCX ����ҳӦ���� FALSE
}

