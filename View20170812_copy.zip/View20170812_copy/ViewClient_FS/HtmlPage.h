#pragma once
class CHtmlPage
{
public:
	CHtmlPage();
	~CHtmlPage();

	char*	 GetHtmlPage(const CString& sServerIP, const CString& sRequest, int nPort);
	void	 PostHtmlPage(const CString& sServerIP, const CString& sRequest1, const CString& strRequest2, int nPort);
};

