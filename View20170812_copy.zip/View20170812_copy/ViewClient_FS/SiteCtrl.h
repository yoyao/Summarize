#pragma once  
#include <mshtmhst.h>  
#include"ImpDispatch.h"  
class SiteCtrl : public COleControlSite
{
public:
	ImpDispatch* pImp;
public:

	~SiteCtrl(void);
	SiteCtrl(COleControlContainer*pCtrl) :COleControlSite(pCtrl)
	{
		pImp = new ImpDispatch();
	}
	BEGIN_INTERFACE_PART(DocHostUIHandler, IDocHostUIHandler)


		virtual HRESULT STDMETHODCALLTYPE ShowContextMenu(
		/* [in] */ DWORD dwID,
		/* [in] */ POINT *ppt,
		/* [in] */ IUnknown *pcmdtReserved,
		/* [in] */ IDispatch *pdispReserved);

		virtual HRESULT STDMETHODCALLTYPE GetHostInfo(
			/* [out][in] */ DOCHOSTUIINFO *pInfo);

		virtual HRESULT STDMETHODCALLTYPE ShowUI(
			/* [in] */ DWORD dwID,
			/* [in] */ IOleInPlaceActiveObject *pActiveObject,
			/* [in] */ IOleCommandTarget *pCommandTarget,
			/* [in] */ IOleInPlaceFrame *pFrame,
			/* [in] */ IOleInPlaceUIWindow *pDoc);

		virtual HRESULT STDMETHODCALLTYPE HideUI(void);

		virtual HRESULT STDMETHODCALLTYPE UpdateUI(void);

		virtual HRESULT STDMETHODCALLTYPE EnableModeless(
			/* [in] */ BOOL fEnable);

		virtual HRESULT STDMETHODCALLTYPE OnDocWindowActivate(
			/* [in] */ BOOL fActivate);

		virtual HRESULT STDMETHODCALLTYPE OnFrameWindowActivate(
			/* [in] */ BOOL fActivate);

		virtual HRESULT STDMETHODCALLTYPE ResizeBorder(
			/* [in] */ LPCRECT prcBorder,
			/* [in] */ IOleInPlaceUIWindow *pUIWindow,
			/* [in] */ BOOL fRameWindow);
		virtual HRESULT STDMETHODCALLTYPE TranslateAccelerator(
			/* [in] */ LPMSG lpMsg,
			/* [in] */ const GUID *pguidCmdGroup,
			/* [in] */ DWORD nCmdID);
		virtual HRESULT STDMETHODCALLTYPE GetOptionKeyPath(
			/* [annotation][out] */
			__out  LPOLESTR *pchKey,
			/* [in] */ DWORD dw);

		virtual HRESULT STDMETHODCALLTYPE GetDropTarget(
			/* [in] */ IDropTarget *pDropTarget,
			/* [out] */ IDropTarget **ppDropTarget);
		virtual HRESULT STDMETHODCALLTYPE GetExternal(
			/* [out] */ IDispatch **ppDispatch);

		virtual HRESULT STDMETHODCALLTYPE TranslateUrl(
			/* [in] */ DWORD dwTranslate,
			/* [annotation][in] */
			__in __nullterminated  OLECHAR *pchURLIn,
			/* [annotation][out] */
			__out  OLECHAR **ppchURLOut);

		virtual HRESULT STDMETHODCALLTYPE FilterDataObject(
			/* [in] */ IDataObject *pDO,
			/* [out] */ IDataObject **ppDORet);

	END_INTERFACE_PART(DocHostUIHandler);
	DECLARE_INTERFACE_MAP();

};