#pragma once

class Desktop
{
public:
	Desktop();
	~Desktop();

	int  EnumMonitor();
	BOOL GetMyVMInfo();
	BOOL GetMyVMInfoV2_1();

	static bool ISOPEN(bool bValue);
	static bool ISPRESET(bool bValue);
	static bool ISREMEMBER(bool bValue);
	static bool ISAUTOLOGIN(bool bValue);
	static bool ISUSERCENTER(bool bValue);
	//static bool REMEMBER(bool bValue);
	//static bool AUTOLOGIN(bool bValue);
	static bool DISPLAYCONNECTIONBAR(bool bValue);
	static bool REDIRECTCLIPBOARD(bool bValue);
	static bool REDIRECTPRINTERS(bool bValue);
	static bool REDIRECTSMARTCARDS(bool bValue);
	static bool REDIRECTPORTS(bool bValue);
	static bool REDIRECTDRIVES(bool bValue);
	static bool REDIRECTDEVICES(bool bValue);
	static bool CONNECTED(bool bValue);
	static bool CONNECTING(bool bValue);
	static bool LOCKTEXT(bool bValue);
	static bool LOCKTASK(bool bValue);
	static bool OVER(bool bValue);
	static bool KISOK(bool bValue);
	static int PORT(int nValue);
	static int SCREEN(int nValue);
	static int WIDTH(int nValue);
	static int HEIGHT(int nValue);
	static int COLOR(int nValue);
	static int AUDIO(int nValue);
	static int KEYBOARD(int nValue);
	static int NUM(int nValue);
	static const CString& COMPANY(const CString& sValue);
	static const CString& ADDRESS(const CString& sValue);
	static const CString& COMPUTERNAME(const CString& sValue);
	static const CString& IP(const CString& sValue);
	static const CString& UNAME(const CString& sValue);
	static const CString& PWD(const CString& sValue);
	static const CString& PREUSERNAME(const CString& sValue);
	static const CString& PREPASSWORD(const CString& sValue);
	static const CString& SERVER(const CString& sValue);
	static const CString& DOMAINVALUE(const CString& sValue);
	static const CString& FILENAME(const CString& sValue);
	static const CString& VERSION(const CString& sValue);
	static const CString& COMPUTERNAME1(const CString& sValue);
	static const CString& HOSTIP(const CString& sValue);
	static const CString& VM1(const CString& sValue);
	static CString& GetUUID( CString& sValue);

public:
	bool isOpen;
	bool isPreset;
	bool isRemember;
	bool isAutoLogin;
	bool isUserCenter;
	bool isFullScreen;
	//bool remember;
	//bool autoLogin;
	bool displayConnectionBar;
	bool redirectClipboard;
	bool redirectPrinters;
	bool redirectSmartCards;
	bool redirectPorts;
	bool redirectDrives;
	bool redirectDevices;
	bool connected;
	mutable bool connecting;
	bool lockText;
	bool lockTask;
	bool over;
	bool kisok;
	int port;
	static int screen;
	static bool RdpIsConnected;
	static long RdpExitCode;
	int width;
	int height;
	int color;
	int audio;
	int keyboard;
	int num;
	int visual;
	CString company;
	CString address;
	CString computerName;
	CString ip;
	CString uname;
	CString pwd;
	CString preUsername;
	CString prePassword;
	CString server;
	CString domain;
	CString fileName;
	CString version;
	CString computername1;
	CString ip1;
	CString cpu1;
	CString memory1;
	CString storage1;
	CString vm1;
	CString computername2;
	CString ip2;
	CString cpu2;
	CString memory2;
	CString storage2;
	CString vm2;
	CString computername3;
	CString ip3;
	CString cpu3;
	CString memory3;
	CString storage3;
	CString vm3;
	CString computername4;
	CString ip4;
	CString cpu4;
	CString memory4;
	CString storage4;
	CString vm4;
	CString hostip;
	static RECT screenArea[4];

protected:
	void	ReadSetting(const CString& sPath);
	void	WriteSetting(const CString& sPath);
	void	GetHostIP();
	void	ParseJSON(const char* buf);
	void	ParseVM(CString VM);

private:
	static CString	m_sPath;
	static CString uuid;

	public:
		enum ESServerErrType
		{
			SERV_NONE_ERROR = 0,
			SERV_CLIENT_NOT_FOUND=2
		};
};

