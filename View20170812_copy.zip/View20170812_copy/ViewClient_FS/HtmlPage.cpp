#include "stdafx.h"
#include "HtmlPage.h"

#define LOG	0
#ifdef LOG
#include <fstream>
#endif


CHtmlPage::CHtmlPage()
{
}


CHtmlPage::~CHtmlPage()
{
}

void CHtmlPage::PostHtmlPage(const CString& sServerIP, const CString& sRequest1, const CString& strRequest2, int nPort)
{
	CInternetSession session(_T("esage1"));
	CHttpConnection* pConnection = session.GetHttpConnection(sServerIP, (INTERNET_PORT)nPort);
	CHttpFile* pFile = pConnection->OpenRequest(CHttpConnection::HTTP_VERB_GET, sRequest1);
	pFile->AddRequestHeaders(_T("X-Requested-With:XMLHttpRequest\r\n"));
	pFile->AddRequestHeaders(_T("Accept:application/json, text/javascript, */*; q=0.01\r\n"));
	pFile->AddRequestHeaders(_T("Accept-Language:zh - CN\r\n"));
	pFile->AddRequestHeaders(_T("Referer:http://192.168.0.163:8080/desktop.do?parm=dt\r\n"));
	pFile->AddRequestHeaders(_T("Accept-Encoding:gzip,deflate\r\n"));
	pFile->AddRequestHeaders(_T("User-Agent:Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko\r\n"));
	pFile->AddRequestHeaders(_T("Host:192.168.0.163:8080"));
	pFile->AddRequestHeaders(_T("DNT:1\r\n"));
	pFile->AddRequestHeaders(_T("Cookie:JSESSIONID=92972685BFDB01511E71043C22AAF629\r\n"));
	pFile->SendRequest();

	DWORD dwRet;
	pFile->QueryInfoStatusCode(dwRet);
	pFile->Close();
	delete pFile;

	pFile = pConnection->OpenRequest(CHttpConnection::HTTP_VERB_GET, strRequest2);
	pFile->AddRequestHeaders(_T("X-Requested-With:XMLHttpRequest\r\n"));
	pFile->AddRequestHeaders(_T("Accept:application/json, text/javascript, */*; q=0.01\r\n"));
	pFile->AddRequestHeaders(_T("Referer:http://192.168.0.163:8080/desktop.do?parm=dt\r\n"));
	pFile->AddRequestHeaders(_T("Accept-Language:zh-CN\r\n"));
	pFile->AddRequestHeaders(_T("Accept-Encoding:gzip,deflate\r\n"));
	pFile->AddRequestHeaders(_T("User-Agent:Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko\r\n"));
	pFile->AddRequestHeaders(_T("Host:192.168.0.163:8080"));
	pFile->AddRequestHeaders(_T("DNT:1\r\n"));
	pFile->AddRequestHeaders(_T("Cookie:JSESSIONID=92972685BFDB01511E71043C22AAF629\r\n"));
	pFile->SendRequest();

	pFile->QueryInfoStatusCode(dwRet);

	session.Close();
	pFile->Close();
	delete pFile;
}

char*  CHtmlPage::GetHtmlPage(const CString& sServerIP, const CString& sRequest, int nPort)
{
	CInternetSession session(_T("esage"));

	//session.SetOption(INTERNET_OPTION_CONNECT_BACKOFF, 1000);
	//session.SetOption(INTERNET_OPTION_CONNECT_RETRIES, 1);
	//session.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, 5000);      // 5������ӳ�ʱ  
	//session.SetOption(INTERNET_OPTION_SEND_TIMEOUT, 2000);         // 2��ķ��ͳ�ʱ  
	//session.SetOption(INTERNET_OPTION_RECEIVE_TIMEOUT, 2000);      // 2��Ľ��ճ�ʱ  
	//session.SetOption(INTERNET_OPTION_DATA_SEND_TIMEOUT, 2000);    // 2��ķ��ͳ�ʱ  
	//session.SetOption(INTERNET_OPTION_DATA_RECEIVE_TIMEOUT, 2000); // 2��Ľ��ճ�ʱ

	CHttpConnection* pConnection = session.GetHttpConnection(sServerIP, (INTERNET_PORT)nPort);
	CHttpFile* pFile = pConnection->OpenRequest(CHttpConnection::HTTP_VERB_GET, sRequest);

	//CString strHead = _T("Host:");
	//strHead += sServerIP;
	//CString str1;
	//str1.Format(_T(":%d\r\n"), nPort);

	pFile->AddRequestHeaders(_T("User-Agent:MSIE 7.0;Windows NT 5.1\r\n"));
	//pFile->AddRequestHeaders(strHead);
	pFile->AddRequestHeaders(_T("Connection:close\r\n"));
	pFile->SendRequest();
	
	DWORD dwRet;
	pFile->QueryInfoStatusCode(dwRet);
	char* buf = NULL;
	int numread;

	if (HTTP_STATUS_OK == dwRet)
	{
		numread = pFile->GetLength() + 1;
		buf = new char[numread];
		int length;
		while ((numread = pFile->Read(buf, numread-1)) > 0)
		{
			length = numread;
			buf[numread] = '\0';
		}

#ifdef LOG
		std::ofstream outfile("C:\\Windows\\Temp\\error.log");
		if (outfile.is_open())
		{
			outfile.write(buf, length);
			outfile.close();
		}
#endif
	}

	session.Close();
	pFile->Close();
	delete pFile;	
	
	return buf;
}
