#pragma once
#include "afxwin.h"

class CMyButton : public CButton
{
public:
	CMyButton();
	virtual ~CMyButton();
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void PreSubclassWindow();

private:
	CFont	m_font;
	BOOL	m_bTracking;
	int		m_nState;
public:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnMouseHover(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
};

