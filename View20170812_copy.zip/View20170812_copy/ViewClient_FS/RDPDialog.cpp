// RDPDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCViewClient.h"
#include "RDPDialog.h"
#include "afxdialogex.h"
#include "CMsRdpClientAdvancedSettings8.h"
#include "mstscax.h"
#include "mstscaxguid.h"
#include "resource.h"

#define IDT_TIMER_CONNECTING	10

// CRDPDialog �Ի���
IMPLEMENT_DYNAMIC(CRDPDialog, CDialogEx)
//����Ƿ�����
bool CRDPDialog::IsConnected = false;

CRDPDialog::CRDPDialog(CWnd* pParent, const Desktop* pDesktop)
: CDialogEx(CRDPDialog::IDD, pParent), m_pDesktop(pDesktop)
{
	ASSERT(m_pDesktop != NULL);

	m_nCount = 1;
}

CRDPDialog::~CRDPDialog()
{
}

void CRDPDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MSTSCAX_RDP, m_mstscControl);
}


BEGIN_MESSAGE_MAP(CRDPDialog, CDialogEx)
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_WINDOWPOSCHANGING()
END_MESSAGE_MAP()

//��ʼ��
BOOL CRDPDialog::OnInitDialog()
{
	
	CDialogEx::OnInitDialog();         //ԭ��ΪCDialog::OnInitDialog()
//	AfxMessageBox(L"sssss");

	return TRUE;

}

// CRDPDialog ��Ϣ��������
void CRDPDialog::OnDestroy()
{
	CDialogEx::OnDestroy();

	delete this;
}

BEGIN_EVENTSINK_MAP(CRDPDialog, CDialogEx)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 2, CRDPDialog::OnConnectedMstscaxRdp, VTS_NONE)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 4, CRDPDialog::OnDisconnectedMstscaxRdp, VTS_I4)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 1, CRDPDialog::OnConnectingMstscaxRdp, VTS_NONE)
	ON_EVENT(CRDPDialog, IDC_MSTSCAX_RDP, 15, CRDPDialog::OnConfirmCloseMstscaxRdp, VTS_PBOOL)
END_EVENTSINK_MAP()

void CRDPDialog::Destroy()
{
	CDialogEx::OnOK();

	DestroyWindow();
}

void CRDPDialog::ShowRDP()
{
	m_mstscControl.put_Server(m_pDesktop->ip);
	//m_mstscControl.put_Server(L"192.168.0.197");
	//�����С
	m_mstscControl.put_DesktopHeight(m_pDesktop->height);
	m_mstscControl.put_DesktopWidth(m_pDesktop->width);
	//ȫ��
	m_mstscControl.put_FullScreen(TRUE);

	CMsRdpClientAdvancedSettings8 AdvancedSettings9 = CMsRdpClientAdvancedSettings8(m_mstscControl.get_AdvancedSettings9());

	AdvancedSettings9.put_EnableCredSspSupport(TRUE);
	if (m_pDesktop->isPreset)
	{
		m_mstscControl.put_UserName(m_pDesktop->preUsername);
		AdvancedSettings9.put_ClearTextPassword(m_pDesktop->prePassword);
	}
	else
	{
		m_mstscControl.put_UserName(m_pDesktop->uname);
		AdvancedSettings9.put_ClearTextPassword(m_pDesktop->pwd);
	}

	if ((m_pDesktop->domain).IsEmpty())
	{
		m_mstscControl.put_Domain(m_pDesktop->computerName);
	}
	else
	{
		m_mstscControl.put_Domain(m_pDesktop->domain);
	}

	if (m_pDesktop->port > 0)
		AdvancedSettings9.put_RDPPort(m_pDesktop->port);

	AdvancedSettings9.put_SmartSizing(TRUE);

	CString str;
	str.Format(IDS_STRING_LOGIN);
	m_mstscControl.put_ConnectingText(str);

	DWORD lerror;
	CString errstr;
	
	AdvancedSettings9.put_EnableWindowsKey(TRUE);
	AdvancedSettings9.put_DisableCtrlAltDel(FALSE);

	AdvancedSettings9.put_DisableRdpdr(0);
	
	AdvancedSettings9.put_RedirectClipboard(m_pDesktop->redirectClipboard);
	
	AdvancedSettings9.put_RedirectSmartCards(m_pDesktop->redirectSmartCards);
	
	AdvancedSettings9.put_RedirectPorts(m_pDesktop->redirectPorts);
	
	AdvancedSettings9.put_RedirectPrinters(m_pDesktop->redirectPrinters);
	
	AdvancedSettings9.put_AudioCaptureRedirectionMode(TRUE);
	
	AdvancedSettings9.put_GrabFocusOnConnect(TRUE);
	
	AdvancedSettings9.put_DisableCtrlAltDel(FALSE);
	AdvancedSettings9.put_BitmapPeristence(1);
	AdvancedSettings9.put_Compress(TRUE);
	

	AdvancedSettings9.put_allowBackgroundInput(0);
	AdvancedSettings9.put_EnableAutoReconnect(TRUE);
	AdvancedSettings9.put_AcceleratorPassthrough(1);
	AdvancedSettings9.put_DoubleClickDetect(1);
	AdvancedSettings9.put_RedirectDevices(m_pDesktop->redirectDevices);
	AdvancedSettings9.put_RedirectDrives(m_pDesktop->redirectDrives);

	
	TCHAR  SysDisk[64] = { 0 };
	if (m_pDesktop->redirectDrives)
	{
		GetSystemDirectory(SysDisk, 64);
	}

#pragma region lpUnknown
	LPUNKNOWN	lpUnknown = m_mstscControl.GetControlUnknown();
	ASSERT(lpUnknown != NULL);
	if (lpUnknown != NULL)
	{
		IMsRdpClient8* pClient8 = NULL;
		HRESULT result = S_FALSE;

		result = lpUnknown->QueryInterface(IID_IMsRdpClient8, (void**)&pClient8);
		if (SUCCEEDED(result))
		{
			IMsRdpClientNonScriptable5* pNon5 = NULL;
			result = pClient8->QueryInterface(IID_IMsRdpClientNonScriptable5, (void**)&pNon5);
			if (SUCCEEDED(result))
			{
				pNon5->put_DisableConnectionBar(VARIANT_TRUE);
				//2017-08-12�� ������̬���̺��豸�ض���  caijian
				pNon5->put_RedirectDynamicDevices(VARIANT_TRUE);
				pNon5->put_RedirectDynamicDrives(VARIANT_TRUE);

                #pragma region pDriveCollection
				IMsRdpDriveCollection* pDriveCollection = NULL;
				result = pNon5->get_DriveCollection(&pDriveCollection);
				if (SUCCEEDED(result))
				{
					unsigned long nDriveCount = 0;
					result = pDriveCollection->get_DriveCount(&nDriveCount);
					if (SUCCEEDED(result))
					{
						IMsRdpDrive* pRdpDrive = NULL;
						for (int i = 0; i < nDriveCount; i++)
						{
							result = pDriveCollection->get_DriveByIndex(i, &pRdpDrive);
							if (SUCCEEDED(result))
							{
								BSTR DriveName = ::SysAllocString(L"");
								result = pRdpDrive->get_Name(&DriveName);
								if (SUCCEEDED(result))
								{
									pRdpDrive->put_RedirectionState(VARIANT_TRUE);

									UINT len = ::SysStringLen(DriveName);
									TCHAR* sz = new TCHAR[len + 1];
									_tcsncpy(sz, DriveName, len);
									if (sz[0] == SysDisk[0])
									{
										//�Ƿ��ض���ϵͳ��
										if (GetRedirectSysDisk() != 1)
										{
											pRdpDrive->put_RedirectionState(VARIANT_FALSE);
										}
									}
									delete[] sz;
									sz = NULL;
								}
								::SysFreeString(DriveName);
							}
						}
					}
					pDriveCollection->Release();
				}
#pragma endregion

                #pragma region  pDeviceCollection

				IMsRdpDeviceCollection* pDeviceCollection = NULL;
				result = pNon5->get_DeviceCollection(&pDeviceCollection);
				if (SUCCEEDED(result))
				{
					IMsRdpDeviceCollection2* pDeviceCollection2 = NULL;
					result = pDeviceCollection->QueryInterface(IID_IMsRdpDeviceCollection2, (void**)&pDeviceCollection2);
					if (SUCCEEDED(result))
					{
						unsigned long nDeviceCount = 0;
						result = pDeviceCollection2->get_DeviceCount(&nDeviceCount);
						if (SUCCEEDED(result))
						{
							IMsRdpDevice* pRdpDevice = NULL;
							for (int i = 0; i < nDeviceCount; i++)
							{
								result = pDeviceCollection2->get_DeviceByIndex(i, &pRdpDevice);
								if (SUCCEEDED(result))
								{
									BSTR DeviceInstanceId = SysAllocString(L"");
									IMsRdpDeviceV2* pRdpDeviceV2 = NULL;
									result = pRdpDevice->QueryInterface(IID_IMsRdpDeviceV2, (void**)&pRdpDeviceV2);
									if (SUCCEEDED(result))
									{
										result = pRdpDeviceV2->put_RedirectionState(VARIANT_TRUE);
										result = pRdpDeviceV2->get_DeviceInstanceId(&DeviceInstanceId);
										result = pDeviceCollection2->raw_AddDeviceByInstanceId(UsbDevice, DeviceInstanceId);
										pRdpDeviceV2->Release();
									}
									SysFreeString(DeviceInstanceId);
									pRdpDevice->Release();
								}
							}
						}
						result = pDeviceCollection2->raw_RedirectNow(UsbDevice);
						pDeviceCollection2->Release();
					}
					pDeviceCollection->Release();
				}
#pragma endregion

				pNon5->Release();
			}
			pClient8->Release();
		}
	}
#pragma endregion

	m_mstscControl.Connect();

	CRDPDialog::IsConnected = true;
	Desktop::RdpIsConnected = true;
}

void CRDPDialog::OnConnectedMstscaxRdp()
{
	KillTimer(IDT_TIMER_CONNECTING);
}

void CRDPDialog::OnDisconnectedMstscaxRdp(long discReason)
{
//	MessageBoxA(NULL, "disconnect", "00", MB_OK);

	ShowWindow(SW_HIDE);
	//yangyuewei  for  disconnect
//	::PostQuitMessage(0);

	//fengweixiang 2017-10-09
	switch (discReason)
	{
	case 0x3:
		//AfxMessageBox(_T("���û��ڱ𴦵�¼�����Ѿ���ǿ�����ߣ��������ʣ�����ϵ����Ա"));
		break;
	default:
		//AfxMessageBox(_T("Զ������ʧ�ܣ������Ի���ϵ����Ա"));
		break;
	}
	IsConnected = false;
	Desktop::RdpIsConnected = false;
	Desktop::RdpExitCode = discReason;

	this->CloseWindow();
	
}

void CRDPDialog::OnConnectingMstscaxRdp()
{
	SetTimer(IDT_TIMER_CONNECTING, 600, NULL);
}

void CRDPDialog::OnConfirmCloseMstscaxRdp(BOOL* pfAllowClose)
{
	ShowWindow(SW_HIDE);
	//yangyuewei  for  close

	this->CloseWindow();
}

void CRDPDialog::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	::MoveWindow(m_mstscControl.GetSafeHwnd(), 0, 0, cx, cy, FALSE);
	Invalidate();
}

CString strLoading[6] =
{
	_T("."),
	_T(".."),
	_T("..."),
	_T("...."),
	_T("....."),
	_T("......")
};

void CRDPDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch (nIDEvent)
	{
	case IDT_TIMER_CONNECTING:
		{
			m_nCount %= 6;
			CString str1;
			str1.Format(IDS_STRING_LOGIN);
			//CString str = _T("��ӭʹ����˼��������,���ڵ�½") + strLoading[m_nCount];
			CString str = str1 + strLoading[m_nCount];
			m_mstscControl.put_ConnectingText(str);
			m_nCount++;
		}
		break;
	default:
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}

void CRDPDialog::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanged(lpwndpos);

	// TODO: Add your message handler code here
}


void CRDPDialog::OnWindowPosChanging(WINDOWPOS* lpwndpos)
{
	CDialogEx::OnWindowPosChanging(lpwndpos);

	// TODO: Add your message handler code here
}

int CRDPDialog::GetRedirectSysDisk()
{
	TCHAR path[512] = { 0 };
	TCHAR retBuf[128] = { 0 };
	::GetModuleFileName(NULL, path, MAX_PATH);
	TCHAR* pEnd = _tcsrchr(path, L'\\');
	int i = 0;
	while (pEnd[++i] != 0)
	{
		pEnd[i] = 0;
	}
	CString m_sPath = CString(path);
	m_sPath += _T("setting.ini");
	//GetPrivateProfileString(_T("client"), _T("VisualMode"), _T("0"), retBuf, 128, (LPCWSTR)m_sPath);
	int temppx = GetPrivateProfileInt(_T("client"), _T("redirectsysdisk"), 0, (LPCWSTR)m_sPath);


	return temppx;
}

//2017-08-12  caijian
LRESULT CRDPDialog::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	try
	{
	//�豸���֪ͨԶ������
	if (WM_DEVICECHANGE == message)
	{
		LPUNKNOWN	lpUnknown = m_mstscControl.GetControlUnknown();
		ASSERT(lpUnknown != NULL);
		if (lpUnknown != NULL)
		{
			IMsRdpClient8* pClient8 = NULL;
			HRESULT result = S_FALSE;

			result = lpUnknown->QueryInterface(IID_IMsRdpClient8, (void**)&pClient8);
			if (SUCCEEDED(result))
			{
				IMsRdpClientNonScriptable5* pNon5 = NULL;
				result = pClient8->QueryInterface(IID_IMsRdpClientNonScriptable5, (void**)&pNon5);
				if (SUCCEEDED(result))
				{
					pNon5->raw_NotifyRedirectDeviceChange(wParam, lParam);
					pNon5->Release();
				}
				pClient8->Release();
			
			}
		}
		
	}
	}
	catch (...)
	{
		this->CloseWindow();
	}

	return CDialogEx::WindowProc(message, wParam, lParam);


	//�豸���֪ͨԶ������
	/*
	if (WM_DEVICECHANGE == message)
	{
		// 32768 == DBT_DEVICEARRIVAL 
		// 32772 == DBT_DEVICEREMOVECOMPLETE 
		if ((32768 == wParam) || (32772 == wParam))
		{
			LPUNKNOWN	lpUnknown = m_mstscControl.GetControlUnknown();
			ASSERT(lpUnknown != NULL);
			if (lpUnknown != NULL)
			{
				IMsRdpClient8* pClient8 = NULL;
				HRESULT result = S_FALSE;

				result = lpUnknown->QueryInterface(IID_IMsRdpClient8, (void**)&pClient8);
				if (SUCCEEDED(result))
				{
					IMsRdpClientNonScriptable5* pNon5 = NULL;
					result = pClient8->QueryInterface(IID_IMsRdpClientNonScriptable5, (void**)&pNon5);
					if (SUCCEEDED(result))
					{
						pNon5->raw_NotifyRedirectDeviceChange(wParam, lParam);

						IMsRdpDriveCollection* pDriveCollection = NULL;
						result = pNon5->get_DriveCollection(&pDriveCollection);
						if (SUCCEEDED(result))
						{
							pDriveCollection->raw_RescanDrives(VARIANT_TRUE);
							pDriveCollection->Release();
						}

						pNon5->Release();
					}
					pClient8->Release();
				}
			}
		}
	}

	return CDialogEx::WindowProc(message, wParam, lParam);
	*/

}



const char* CRDPDialog::GetRdpDisconnectMsg(long code)
{
	const char *msg = "";
	switch (code)
	{
	case NONE_ERROR:
	{
		msg = "û����Ϣ���á�";
		break;
	}
	case LOCAL_DISCONNECT:
	{
		msg = "���ضϿ����ӡ�";
		break;
	}
	case REMOTE_DISCONN_USER:
	{
		msg = "Զ�̶Ͽ��û���";
		break;
	}
	case REMOTE_DISCONN_SERVER:
	{
		msg = "Զ�̶Ͽ���������";
		break;
	}
	case DNSNAME_FIND_FAILED:
	{
		msg = "DNS���Ʋ���ʧ�ܡ�";
		break;
	}
	case MEM_NOT_ENOUGH:
	{
		msg = "�ڴ治�㡣";
		break;
	}
	case CONNECT_TIMEOUT:
	{
		msg = "���ӳ�ʱ��";
		break;
	}
	case SOCKET_CONNECT_FAILED:
	{
		msg = "Winsock�׽�������ʧ�ܡ�";
		break;
	}
	case MEM_NOT_ENOUGH_SERVER:
	{
		msg = "�ڴ治�㡣";
		break;
	}
	case REMOTE_HOST_NOT_FOUND:
	{
		msg = "������δ�ҵ�������";
		break;
	}
	case WINSOCKET_SEND_FAILED:
	{
		msg = "Winsock���ͺ���ʧ�ܡ�";
		break;
	}
	case MEM_NOT_ENOUGH_SERVER_2:
	{
		msg = "�ڴ治�㡣";
		break;
	}
	case IPADDR_INVALID:
	{
		msg = "ָ����IP��ַ��Ч��";
		break;
	}
	case WINSOCKET_RECV_FAILED:
	{
		msg = "Winsockrecv����ʧ�ܡ�";
		break;
	}
	case SECURITY_INFO_INVALID:
	{
		msg = "��Ч�İ�ȫ���ϡ�";
		break;
	}
	case INTERNAL_ERROR:
	{
		msg = "�ڲ�����";
		break;
	}
	case ENCRYPTED_INVALID:
	{
		msg = "ָ����Ч�ļ��ܷ�ʽ��";
		break;
	}
	case DNS_FIND_FAILED:
	{
		msg = "DNS����ʧ��";
		break;
	}
	case SERVERHOST_NOT_FOUND:
	{
		msg = "�޷��ҵ�������ķ��������豸��������";
		break;
	}
	case SERVER_SECURITY_INFO_INVALID:
	{
		msg = "��Ч�ķ�������ȫ�����ݡ�";
		break;
	}
	case INTERNAL_TIMER_ERROR:
	{
		msg = "�ڲ���ʱ������";
		break;
	}
	case CONNECT_TIMEOUT_HAPPEN:
	{
		msg = "��ʱ������";
		break;
	}
	case UNZIP_SERVER_CERY:
	{
		msg = "�޷���ѹ��������֤��";
		break;
	}
	case IPADDR_NOT_RIGHT:
	{
		msg = "ָ����IP��ַ����ȷ";
		break;
	}
	case INTERNAL_SECURITY_ERROR:
	{
		msg = "�ڲ���ȫ����";
		break;
	}
	case 2308:
	{
		msg = "��Ͳ�ر�";
		break;
	}
	case 2310:
	{
		msg = "�ڲ���ȫ����";
		break;
	}
	case 2312:
	{
		msg = "���ɳ�ʱ";
		break;
	}
	case 2566:
	{
		msg = "�ڲ���ȫ����";
		break;
	}
	case ENCRYPTED_ERROR:
	{
		msg = "���ܴ���";
		break;
	}
	case DEENCRYPTED_ERROR:
	{
		msg = "���ܴ���";
		break;
	}
	default:
	{
		msg = "δ֪����";
		break;
	}
	}
	return msg;
}