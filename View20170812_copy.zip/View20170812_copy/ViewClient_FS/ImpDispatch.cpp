#include "stdafx.h"
#include "ImpDispatch.h"

ImpDispatch::ImpDispatch(void)
{
	m_Ref = 0;
}


ImpDispatch::~ImpDispatch(void)
{
}