#pragma once

#include "SiteCtrl.h"

class  CSiteManager : public COccManager
{
public:
	CSiteManager(){}
	COleControlSite* CreateSite(COleControlContainer* pCtrlCont)
	{
		SiteCtrl*pSite = NULL;
		pSite = new SiteCtrl(pCtrlCont);
		return pSite;
	}
};