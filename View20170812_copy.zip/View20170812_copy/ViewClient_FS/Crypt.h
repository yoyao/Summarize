#pragma once

CString MyGetSHA(CString strPassword);
CString MyEncodeBase64(CString strCode);
CString MyDecodeBase64(CString strCode);