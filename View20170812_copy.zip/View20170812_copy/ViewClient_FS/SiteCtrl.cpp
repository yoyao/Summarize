#include "StdAfx.h"  
#include "SiteCtrl.h"  
//#include"Custom.h"  

BEGIN_INTERFACE_MAP(SiteCtrl, COleControlSite)
	INTERFACE_PART(SiteCtrl, IID_IDocHostUIHandler, DocHostUIHandler)
END_INTERFACE_MAP()


ULONG SiteCtrl::XDocHostUIHandler::AddRef()
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return pThis->ExternalAddRef();
}


ULONG SiteCtrl::XDocHostUIHandler::Release()
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return pThis->ExternalRelease();
}

HRESULT SiteCtrl::XDocHostUIHandler::QueryInterface(REFIID riid, void** ppvObj)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		HRESULT hr = (HRESULT)pThis->ExternalQueryInterface(&riid, ppvObj);
	return hr;
}

HRESULT SiteCtrl::XDocHostUIHandler::GetHostInfo(DOCHOSTUIINFO* pInfo)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		pInfo->dwFlags = DOCHOSTUIFLAG_NO3DBORDER;
	pInfo->dwDoubleClick = DOCHOSTUIDBLCLK_DEFAULT;
	return S_OK;
}

HRESULT SiteCtrl::XDocHostUIHandler::ShowUI(
	DWORD dwID,
	IOleInPlaceActiveObject* /*pActiveObject*/,
	IOleCommandTarget* pCommandTarget,
	IOleInPlaceFrame* /*pFrame*/,
	IOleInPlaceUIWindow* /*pDoc*/)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return S_OK;
}

HRESULT SiteCtrl::XDocHostUIHandler::HideUI(void)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return S_OK;
}

HRESULT SiteCtrl::XDocHostUIHandler::UpdateUI(void)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return S_OK;
}

HRESULT SiteCtrl::XDocHostUIHandler::EnableModeless(BOOL /*fEnable*/)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

HRESULT SiteCtrl::XDocHostUIHandler::OnDocWindowActivate(BOOL /*fActivate*/)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

HRESULT SiteCtrl::XDocHostUIHandler::OnFrameWindowActivate(BOOL /*fActivate*/)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

HRESULT SiteCtrl::XDocHostUIHandler::ResizeBorder(
	LPCRECT /*prcBorder*/,
	IOleInPlaceUIWindow* /*pUIWindow*/,
	BOOL /*fRameWindow*/)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

HRESULT SiteCtrl::XDocHostUIHandler::ShowContextMenu(
	DWORD /*dwID*/,
	POINT* pptPosition,
	IUnknown* /*pCommandTarget*/,
	IDispatch* /*pDispatchObjectHit*/)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return S_OK; // We've shown our own context menu. MSHTML.DLL will no longer try to show its own.  
}

HRESULT SiteCtrl::XDocHostUIHandler::TranslateAccelerator(
	/* [in] */ LPMSG lpMsg,
	/* [in] */ const GUID __RPC_FAR* pguidCmdGroup,
	/* [in] */ DWORD nCmdID)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)

	//	//disable F5  
	//	if (lpMsg->message == WM_KEYDOWN && GetAsyncKeyState(VK_F5)<0)
	//	{
	//		return S_OK;
	//	}

	//if (GetKeyState(VK_CONTROL) & 0x8000)
	//{
	//	// disable ctrl + O  
	//	if (lpMsg->message == WM_KEYDOWN && GetAsyncKeyState(0x4F)<0)
	//	{
	//		return S_OK;
	//	}
	//	//disable ctrl + p  
	//	if (lpMsg->message == WM_KEYDOWN && GetAsyncKeyState(0x50)<0)
	//	{
	//		return S_OK;
	//	}
	//	//disable ctrl + N  
	//	if (lpMsg->message == WM_KEYDOWN && GetAsyncKeyState(0x4E)<0)
	//	{
	//		return S_OK;
	//	}
	//}

	////disable back space  
	////  if(lpMsg->wParam == VK_BACK)  
	////  {  
	////      return S_OK;  
	////  }  

	return S_FALSE;
}

HRESULT SiteCtrl::XDocHostUIHandler::GetOptionKeyPath(BSTR* pbstrKey, DWORD)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

STDMETHODIMP SiteCtrl::XDocHostUIHandler::GetDropTarget(
	/* [in] */ IDropTarget __RPC_FAR* pDropTarget,
	/* [out] */ IDropTarget __RPC_FAR*__RPC_FAR* ppDropTarget)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

STDMETHODIMP SiteCtrl::XDocHostUIHandler::GetExternal(
	/* [out] */ IDispatch __RPC_FAR*__RPC_FAR* ppDispatch)
{
	// return the IDispatch we have for extending the object Model  
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
	*ppDispatch = pThis->pImp;
	return S_OK;
}

STDMETHODIMP SiteCtrl::XDocHostUIHandler::TranslateUrl(
	/* [in] */ DWORD dwTranslate,
	/* [in] */ OLECHAR __RPC_FAR *pchURLIn,
	/* [out] */ OLECHAR __RPC_FAR*__RPC_FAR* ppchURLOut)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

STDMETHODIMP SiteCtrl::XDocHostUIHandler::FilterDataObject(
	/* [in] */ IDataObject __RPC_FAR* pDO,
	/* [out] */ IDataObject __RPC_FAR*__RPC_FAR* ppDORet)
{
	METHOD_PROLOGUE(SiteCtrl, DocHostUIHandler)
		return E_NOTIMPL;
}

SiteCtrl::~SiteCtrl(void)
{
}