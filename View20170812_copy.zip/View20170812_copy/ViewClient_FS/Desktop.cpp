#include "stdafx.h"
#include "Desktop.h"
#include "HtmlPage.h"
#include "Crypt.h"
#include "errorcode.h"
#include <string>
#include "UserInfoWeb.h"
#include "include\base64.h"
#include "include\json\json.h"

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "IPHLPAPI.lib")

//#pragma comment(lib, JSONLIB_PATH)

#define AGENT_SERVER_PORT 32022

BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData);

CString Desktop::m_sPath;
int Desktop::screen;
RECT Desktop::screenArea[4];
bool Desktop::RdpIsConnected = false;
long Desktop::RdpExitCode = -1;
CString Desktop::uuid("");

Desktop::Desktop()
{
	TCHAR	path[512];
	::GetModuleFileName(NULL, path, MAX_PATH);
	TCHAR* pEnd = _tcsrchr(path, L'\\');
	int i = 0;
	while (pEnd[++i] != 0)
	{
		pEnd[i] = 0;
	}
	m_sPath = CString(path);
	m_sPath += _T("setting.ini");

	ReadSetting(m_sPath);

	GetHostIP();
}


Desktop::~Desktop()
{
}

void Desktop::ReadSetting(const CString& sPath)
{
	TCHAR retBuf[128];
	GetPrivateProfileString(_T("client"), _T("company"), _T(""), retBuf, 128, (LPCWSTR)sPath);
	company = CString(retBuf);
	GetPrivateProfileString(_T("client"), _T("address"), _T(""), retBuf, 128, (LPCWSTR)sPath);
	address = CString(retBuf);
	GetPrivateProfileString(_T("client"), _T("uname"), _T(""), retBuf, 128, (LPCWSTR)sPath);
	uname = CString(retBuf);
	GetPrivateProfileString(_T("client"), _T("pwd"), _T(""), retBuf, 128, (LPCWSTR)sPath);
	pwd = CString(retBuf);
	GetPrivateProfileString(_T("client"), _T("server"), _T(""), retBuf, 128, (LPCWSTR)sPath);
	server = CString(retBuf);
	GetPrivateProfileString(_T("client"), _T("vm"), _T(""), retBuf, 128, (LPCWSTR)sPath);
	vm1 = CString(retBuf);
	GetPrivateProfileString(_T("client"), _T("version"), _T(""), retBuf, 128, (LPCWSTR)sPath);
	version = CString(retBuf);

	GetPrivateProfileString(_T("client"), _T("isRemember"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		isRemember = true;
	else
		isRemember = false;

	GetPrivateProfileString(_T("client"), _T("isAutoLogin"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		isAutoLogin = true;
	else
		isAutoLogin = false;

	GetPrivateProfileString(_T("client"), _T("isUserCenter"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		isUserCenter = true;
	else
		isUserCenter = false;
	/*
		GetPrivateProfileString(_T("client"), _T("remember"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
		if (_tcscmp(retBuf, _T("TRUE")) == 0)
		remember = true;
		else
		remember = false;

		GetPrivateProfileString(_T("client"), _T("autoLogin"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
		if (_tcscmp(retBuf, _T("TRUE")) == 0)
		autoLogin = true;
		else
		autoLogin = false;
		*/
	GetPrivateProfileString(_T("client"), _T("RedirectPrinters"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		redirectPrinters = true;
	else
		redirectPrinters = false;

	GetPrivateProfileString(_T("client"), _T("RedirectSmartCards"), _T("TRUE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		redirectSmartCards = true;
	else
		redirectSmartCards = false;

	GetPrivateProfileString(_T("client"), _T("RedirectPorts"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		redirectPorts = true;
	else
		redirectPorts = false;

	GetPrivateProfileString(_T("client"), _T("RedirectDrives"), _T("TRUE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		redirectDrives = true;
	else
		redirectDrives = false;

	GetPrivateProfileString(_T("client"), _T("RedirectDevices"), _T("TRUE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		redirectDevices = true;
	else
		redirectDevices = false;

	GetPrivateProfileString(_T("client"), _T("lockText"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		lockText = true;
	else
		lockText = false;

	GetPrivateProfileString(_T("client"), _T("lockTask"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		lockTask = true;
	else
		lockTask = false;

	GetPrivateProfileString(_T("client"), _T("kisok"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		kisok = true;
	else
		kisok = false;

	GetPrivateProfileString(_T("client"), _T("DisplayConnectionBar"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		displayConnectionBar = true;
	else
		displayConnectionBar = false;

	GetPrivateProfileString(_T("client"), _T("RedirectClipboard"), _T("FALSE"), retBuf, 128, (LPCWSTR)sPath);
	if (_tcscmp(retBuf, _T("TRUE")) == 0)
		redirectClipboard = true;
	else
		redirectClipboard = false;

	color = GetPrivateProfileInt(_T("client"), _T("color"), 3, (LPCWSTR)sPath);
	screen = GetPrivateProfileInt(_T("client"), _T("screen"), 3, (LPCWSTR)sPath);
	width = GetPrivateProfileInt(_T("client"), _T("width"), 3, (LPCWSTR)sPath);
	height = GetPrivateProfileInt(_T("client"), _T("height"), 3, (LPCWSTR)sPath);
	audio = GetPrivateProfileInt(_T("client"), _T("AudioRedirectionMode"), 3, (LPCWSTR)sPath);
	keyboard = GetPrivateProfileInt(_T("client"), _T("KeyboardHookMode"), 3, (LPCWSTR)sPath);
	visual = GetPrivateProfileInt(_T("client"), _T("VisualMode"), 0, (LPCWSTR)sPath);
	if (visual == 0)
	{
		CString temstr;
		temstr.Format(L"%d", visual);
		WritePrivateProfileString(_T("client"), _T("VisualMode"), temstr, (LPCWSTR)m_sPath);
	}
}


void Desktop::WriteSetting(const CString& sPath)
{
	WritePrivateProfileString(_T("client"), _T("company"), (LPCWSTR)company, (LPCWSTR)sPath);
	WritePrivateProfileString(_T("client"), _T("address"), (LPCWSTR)address, (LPCWSTR)sPath);
	WritePrivateProfileString(_T("client"), _T("uname"), (LPCWSTR)uname, (LPCWSTR)sPath);
	WritePrivateProfileString(_T("client"), _T("pwd"), (LPCWSTR)pwd, (LPCWSTR)sPath);
	WritePrivateProfileString(_T("client"), _T("server"), (LPCWSTR)server, (LPCWSTR)sPath);
	WritePrivateProfileString(_T("client"), _T("vm"), (LPCWSTR)vm1, (LPCWSTR)sPath);
	WritePrivateProfileString(_T("client"), _T("version"), (LPCWSTR)version, (LPCWSTR)sPath);

	if (isRemember)
		WritePrivateProfileString(_T("client"), _T("isRemember"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isRemember"), _T("FALSE"), (LPCWSTR)sPath);

	if (isAutoLogin)
		WritePrivateProfileString(_T("client"), _T("isAutoLogin"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isAutoLogin"), _T("FALSE"), (LPCWSTR)sPath);

	if (isUserCenter)
		WritePrivateProfileString(_T("client"), _T("isUserCenter"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isUserCenter"), _T("FALSE"), (LPCWSTR)sPath);

	/*
		if (remember)
		WritePrivateProfileString(_T("client"), _T("remember"), _T("TRUE"), (LPCWSTR)sPath);
		else
		WritePrivateProfileString(_T("client"), _T("remember"), _T("FALSE"), (LPCWSTR)sPath);

		if (autoLogin)
		WritePrivateProfileString(_T("client"), _T("autoLogin"), _T("TRUE"), (LPCWSTR)sPath);
		else
		WritePrivateProfileString(_T("client"), _T("autoLogin"), _T("FALSE"), (LPCWSTR)sPath);
		*/
	if (redirectPrinters)
		WritePrivateProfileString(_T("client"), _T("redirectPrinters"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectPrinters"), _T("FALSE"), (LPCWSTR)sPath);

	if (redirectSmartCards)
		WritePrivateProfileString(_T("client"), _T("redirectSmartCards"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectSmartCards"), _T("FALSE"), (LPCWSTR)sPath);

	if (redirectPorts)
		WritePrivateProfileString(_T("client"), _T("redirectPorts"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectPorts"), _T("FALSE"), (LPCWSTR)sPath);

	if (redirectDrives)
		WritePrivateProfileString(_T("client"), _T("redirectDrives"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectDrives"), _T("FALSE"), (LPCWSTR)sPath);

	if (redirectDevices)
		WritePrivateProfileString(_T("client"), _T("redirectDevices"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectDevices"), _T("FALSE"), (LPCWSTR)sPath);

	if (lockText)
		WritePrivateProfileString(_T("client"), _T("lockText"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("lockText"), _T("FALSE"), (LPCWSTR)sPath);

	if (lockTask)
		WritePrivateProfileString(_T("client"), _T("lockTask"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("lockTask"), _T("FALSE"), (LPCWSTR)sPath);

	if (kisok)
		WritePrivateProfileString(_T("client"), _T("kisok"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("kisok"), _T("FALSE"), (LPCWSTR)sPath);

	if (displayConnectionBar)
		WritePrivateProfileString(_T("client"), _T("displayConnectionBar"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("displayConnectionBar"), _T("FALSE"), (LPCWSTR)sPath);

	if (redirectClipboard)
		WritePrivateProfileString(_T("client"), _T("redirectClipboard"), _T("TRUE"), (LPCWSTR)sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectClipboard"), _T("FALSE"), (LPCWSTR)sPath);


	WritePrivateProfileStruct(_T("client"), _T("color"), &color, sizeof(color), (LPCWSTR)sPath);
	WritePrivateProfileStruct(_T("client"), _T("screen"), &screen, sizeof(screen), (LPCWSTR)sPath);
	WritePrivateProfileStruct(_T("client"), _T("width"), &width, sizeof(width), (LPCWSTR)sPath);
	WritePrivateProfileStruct(_T("client"), _T("height"), &height, sizeof(height), (LPCWSTR)sPath);
	WritePrivateProfileStruct(_T("client"), _T("audio"), &audio, sizeof(audio), (LPCWSTR)sPath);
	WritePrivateProfileStruct(_T("client"), _T("keyboard"), &keyboard, sizeof(keyboard), (LPCWSTR)sPath);
}

bool Desktop::ISOPEN(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("isOpen"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isOpen"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::ISPRESET(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("isPreset"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isPreset"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::ISREMEMBER(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("isRemember"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isRemember"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::ISAUTOLOGIN(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("isAutoLogin"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isAutoLogin"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::ISUSERCENTER(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("isUserCenter"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("isUserCenter"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

/*
bool Desktop::REMEMBER(bool bValue)
{
if (bValue)
WritePrivateProfileString(_T("client"), _T("remember"), _T("TRUE"), (LPCWSTR)m_sPath);
else
WritePrivateProfileString(_T("client"), _T("remember"), _T("FALSE"), (LPCWSTR)m_sPath);
return bValue;
}

bool Desktop::AUTOLOGIN(bool bValue)
{
if (bValue)
WritePrivateProfileString(_T("client"), _T("autologin"), _T("TRUE"), (LPCWSTR)m_sPath);
else
WritePrivateProfileString(_T("client"), _T("autologin"), _T("FALSE"), (LPCWSTR)m_sPath);
return bValue;
}
*/
bool Desktop::DISPLAYCONNECTIONBAR(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("displayConnectionBar"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("displayConnectionBar"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::REDIRECTCLIPBOARD(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("redirectClipboard"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectClipboard"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::REDIRECTPRINTERS(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("redirectPrinters"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectPrinters"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::REDIRECTSMARTCARDS(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("redirectSmartCards"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectSmartCards"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::REDIRECTPORTS(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("redirectPorts"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectPorts"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::REDIRECTDRIVES(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("redirectDrives"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectDrives"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::REDIRECTDEVICES(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("redirectDevices"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("redirectDevices"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::LOCKTEXT(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("lockText"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("lockText"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::LOCKTASK(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("lockTask"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("lockTask"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::KISOK(bool bValue)
{
	if (bValue)
		WritePrivateProfileString(_T("client"), _T("kisok"), _T("TRUE"), (LPCWSTR)m_sPath);
	else
		WritePrivateProfileString(_T("client"), _T("kisok"), _T("FALSE"), (LPCWSTR)m_sPath);
	return bValue;
}

bool Desktop::CONNECTED(bool bValue)
{
	return bValue;
}

bool Desktop::CONNECTING(bool bValue)
{
	return bValue;
}

bool Desktop::OVER(bool bValue)
{
	return bValue;
}

int Desktop::PORT(int nValue)
{
	return nValue;
}

int Desktop::SCREEN(int nValue)
{
	WritePrivateProfileStruct(_T("client"), _T("screen"), &nValue, sizeof(nValue), (LPCWSTR)m_sPath);
	return nValue;
}
int Desktop::WIDTH(int nValue)
{
	WritePrivateProfileStruct(_T("client"), _T("width"), &nValue, sizeof(nValue), (LPCWSTR)m_sPath);
	return nValue;
}
int Desktop::HEIGHT(int nValue)
{
	WritePrivateProfileStruct(_T("client"), _T("height"), &nValue, sizeof(nValue), (LPCWSTR)m_sPath);
	return nValue;
}
int Desktop::COLOR(int nValue)
{
	WritePrivateProfileStruct(_T("client"), _T("color"), &nValue, sizeof(nValue), (LPCWSTR)m_sPath);
	return nValue;
}
int Desktop::AUDIO(int nValue)
{
	WritePrivateProfileStruct(_T("client"), _T("audio"), &nValue, sizeof(nValue), (LPCWSTR)m_sPath);
	return nValue;
}
int Desktop::KEYBOARD(int nValue)
{
	WritePrivateProfileStruct(_T("client"), _T("keyboard"), &nValue, sizeof(nValue), (LPCWSTR)m_sPath);
	return nValue;
}

int Desktop::NUM(int nValue)
{
	return nValue;
}

const CString& Desktop::COMPANY(const CString& sValue)
{
	WritePrivateProfileString(_T("client"), _T("company"), (LPCWSTR)sValue, (LPCWSTR)m_sPath);
	return sValue;
}

const CString&  Desktop::ADDRESS(const CString& sValue)
{
	WritePrivateProfileString(_T("client"), _T("address"), (LPCWSTR)sValue, (LPCWSTR)m_sPath);
	return sValue;
}

const CString&  Desktop::COMPUTERNAME(const CString& sValue)
{
	return sValue;
}

const CString&  Desktop::IP(const CString& sValue)
{
	return sValue;
}

const CString&  Desktop::UNAME(const CString& sValue)
{
	WritePrivateProfileString(_T("client"), _T("uname"), (LPCWSTR)sValue, (LPCWSTR)m_sPath);
	return sValue;
}

const CString&  Desktop::PWD(const CString& sValue)
{
	WritePrivateProfileString(_T("client"), _T("pwd"), (LPCWSTR)sValue, (LPCWSTR)m_sPath);
	return sValue;
}

const CString&  Desktop::PREUSERNAME(const CString& sValue)
{
	return sValue;
}

const CString&  Desktop::PREPASSWORD(const CString& sValue)
{
	return sValue;
}

const CString&  Desktop::SERVER(const CString& sValue)
{
	WritePrivateProfileString(_T("client"), _T("server"), (LPCWSTR)sValue, (LPCWSTR)m_sPath);
	return sValue;
}

const CString&  Desktop::DOMAINVALUE(const CString& sValue)
{
	return sValue;
}

const CString&  Desktop::VERSION(const CString& sValue)
{
	WritePrivateProfileString(_T("client"), _T("version"), (LPCWSTR)sValue, (LPCWSTR)m_sPath);
	return sValue;
}

const CString&  Desktop::VM1(const CString& sValue)
{
	WritePrivateProfileString(_T("client"), _T("vm"), (LPCWSTR)sValue, (LPCWSTR)m_sPath);
	return sValue;
}

const CString&  Desktop::COMPUTERNAME1(const CString& sValue)
{
	return sValue;
}
const CString&  Desktop::HOSTIP(const CString& sValue)
{
	return sValue;
}
const CString&  Desktop::FILENAME(const CString& sValue)
{
	return sValue;
}

/*
void Desktop::GetHostIP()
{
hostip = _T("");
WSADATA wsaData;
WORD wVersionRequested = MAKEWORD(2, 2);
int err = ::WSAStartup(wVersionRequested, &wsaData);
if (err != 0)
return;

if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
{
WSACleanup();
return ;
}

WCHAR szHostName[64];
::GetHostNameW(szHostName, 64);

ADDRINFOEX hints;
ADDRINFOEX *res, *cur;
int ret;
SOCKADDR_IN *addr;

memset(&hints, 0, sizeof(ADDRINFOEX));
hints.ai_family		= AF_INET;
hints.ai_flags		= AI_PASSIVE;
hints.ai_protocol	= IPPROTO_TCP;
hints.ai_socktype	= SOCK_STREAM;
//ret = getaddrinfo(szHostName, NULL, &hints, &res);
ret = GetAddrInfoEx(szHostName, NULL, NS_DNS, NULL, &hints, &res, NULL, NULL, NULL, NULL);
//if (ret != -1)
if (ret == NO_ERROR)
{
for (cur = res; cur != NULL; cur = cur->ai_next)
{
addr = (SOCKADDR_IN*)cur->ai_addr;
}
FreeAddrInfoEx(res);
}
::WSACleanup();
}
*/

void Desktop::GetHostIP()
{
	if (server.IsEmpty())
		return;

	unsigned long userver[4];
	unsigned int uip[4];
	unsigned int umask[4];

	TCHAR* pEnd;
	userver[0] = wcstoul(server.GetBuffer(), &pEnd, 10);
	userver[1] = wcstoul(pEnd + 1, &pEnd, 10);
	userver[2] = wcstoul(pEnd + 1, &pEnd, 10);
	userver[3] = wcstoul(pEnd + 1, &pEnd, 10);


	PIP_ADAPTER_INFO pAdapterInfo;
	PIP_ADAPTER_INFO pAdapter = NULL;
	DWORD dwRetVal = 0;

	ULONG outBufLen = sizeof(IP_ADAPTER_INFO);
	pAdapter = (PIP_ADAPTER_INFO)malloc(outBufLen);

	ASSERT(pAdapter != NULL);

	dwRetVal = GetAdaptersInfo(pAdapter, &outBufLen);
	if (ERROR_BUFFER_OVERFLOW == dwRetVal)
	{
		free(pAdapter);
		pAdapter = (PIP_ADAPTER_INFO)malloc(outBufLen);
		ASSERT(pAdapter != NULL);
	}

	dwRetVal = GetAdaptersInfo(pAdapter, &outBufLen);
	if (NO_ERROR == dwRetVal)
	{
		pAdapterInfo = pAdapter;
		while (pAdapterInfo != NULL)
		{
			sscanf(pAdapterInfo->IpAddressList.IpAddress.String, "%d.%d.%d.%d",
				&uip[0], &uip[1], &uip[2], &uip[3]);
			sscanf(pAdapterInfo->IpAddressList.IpMask.String, "%d.%d.%d.%d",
				&umask[0], &umask[1], &umask[2], &umask[3]);
			pAdapterInfo = pAdapterInfo->Next;
			if ((0 == uip[0]) || (0 == umask[0]))
				continue;
			if (((uip[0] & umask[0]) == (userver[0] & umask[0])) &&
				((uip[1] & umask[1]) == (userver[1] & umask[1])) &&
				((uip[2] & umask[2]) == (userver[2] & umask[2])) &&
				((uip[3] & umask[3]) == (userver[3] & umask[3])))
				break;
		}
		free(pAdapter);
		pAdapter = NULL;
	}

	hostip.Format(_T("%d.%d.%d.%d"), uip[0], uip[1], uip[2], uip[3]);
}

int Desktop::EnumMonitor()
{
	EnumDisplayMonitors(NULL, NULL, MonitorEnumProc, 0);

	return Desktop::screen;
}

BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData)
{
	static BOOL first = TRUE;   //��־  

	//������ʾ����Ϣ  
	MONITORINFO monitorinfo;
	monitorinfo.cbSize = sizeof(MONITORINFO);

	//�����ʾ����Ϣ������Ϣ���浽monitorinfo��  
	GetMonitorInfo(hMonitor, &monitorinfo);

	//����⵽����  
	if (monitorinfo.dwFlags == MONITORINFOF_PRIMARY)
	{
		if (first)  //��һ�μ�⵽����  
		{
			first = FALSE;
			Desktop::screen = 1;

			//����ʾ���ķֱ�����Ϣ���浽rect  
			Desktop::screenArea[0] = monitorinfo.rcMonitor;
			return TRUE;

		}
		else //�ڶ��μ�⵽����,˵�����еļ��������Ѿ������һ�飬�ʿ���ֹͣ�����  
		{
			first = TRUE;    //��־��λ  
			return FALSE;    //�������  
		}
	}

	Desktop::screenArea[Desktop::screen] = monitorinfo.rcMonitor;
	Desktop::screen++;
	return TRUE;
}

BOOL Desktop::GetMyVMInfo()
{
#if 1
	GetHostIP();

	WORD sockVersion = MAKEWORD(2, 2);
	WSADATA data;
	CUserInfoWeb::OperationErrorType err_code = CUserInfoWeb::OperationErrorType::OP_NONE_ERROR;
	BOOL ret = TRUE;

	if (WSAStartup(sockVersion, &data) != 0)
	{
		return 0;
	}
	SOCKET sclient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sclient == INVALID_SOCKET)
	{
		SetErrorCode(SOCKET_CREATE_FAILED);
		printf("invalid socket !");
		return 0;
	}

	do
	{
		sockaddr_in serAddr;
		serAddr.sin_family = AF_INET;
		serAddr.sin_port = htons(AGENT_SERVER_PORT);
		char  sMgrip[128] = { 0 };
		wcstombs(sMgrip, server.GetBuffer(), 128);

		serAddr.sin_addr.S_un.S_addr = inet_addr(sMgrip);

		if (connect(sclient, (sockaddr *)&serAddr, sizeof(serAddr)) == SOCKET_ERROR)
		{
			printf("connect error !");
			//����errnoΪ���ӳ�ʱ
			err_code = CUserInfoWeb::OperationErrorType::SOCKET_CONNN_TIMEOUT;
			ret = FALSE;
			break;
		}

        #pragma region ������֤����

		char mbName[256] = { 0 };
		char mbPwd[256] = { 0 };
		char mversion[64] = { 0 }; 
		wcstombs(mbName, uname.GetBuffer(), 256);
		wcstombs(mbPwd, pwd.GetBuffer(), 256);
		//�ͻ��˰汾 by fengweixiang 2017-10-10
		wcstombs(mversion, version.GetBuffer(), 64);

		 char sendData[1024] = { 0 };
		sprintf_s(sendData, 1024, "{\"agentreq\":{\"loginDesktop\":{\"username\":\"%s\",\"password\":\"%s\",\"cversion\":\"%s\"}}}", mbName, mbPwd, mversion);

		char buffer[2048];
		memset(buffer, 0, 2048);
		memcpy_s(buffer, 1024, sendData, strlen(sendData));
		std::string base64_str=Base64Tool::base64_encode((unsigned char*)sendData, strlen(sendData));
		ret = send(sclient, base64_str.c_str(), base64_str.length(), 0);
		if (ret < 1)
		{
			ret = FALSE;
			err_code = CUserInfoWeb::OperationErrorType::SOCKET_CLIENT_SEND_FAILED;
			break;
		}

#pragma endregion 
		//���ر��ĸ�ʽ {"date":"Wed Oct 11 18:56:21 CST 2017","ip":"192.168.0.197","error":"0","uuid":"null"}

		char recData[2048];
		memset(recData, 0, 2048);
		int retlen = 2048;
	    ret = recv(sclient, recData, retlen, 0);
		if (ret < 1)
		{
			ret = FALSE;
			err_code = CUserInfoWeb::OperationErrorType::SERVER_NONE_MSG;
			break;
		}
		recData[ret] = 0x00;
		
		char svmip[64] = { 0 };

		/*
		strncpy(svmip, recData + 3, strlen(recData) - 3);
		if (strcmp("null", recData + 3)==0)
		{
			err_code = SERVER_IP_NOT_FOUND;
			ret= FALSE;
			break;
		}
		*/
		
        #pragma region �������ر���  fengweixiang 2017-10-11
		try
		{
			std::string json;
			json=Base64Tool::base64_decode(std::string(recData));
			//json = recData;
			//json = R"({"date":"Wed Oct 11 18:56:21 CST 2017","ip":"192.168.0.197","error":"0","uuid":"null"})";
			
			Json::Reader reader;
			Json::Value root;
			if (!reader.parse(json, root))
			{
				ret = FALSE;
				//json����ʧ��
				err_code = CUserInfoWeb::OperationErrorType::SERVER_REPLY_ERROR;
				break;
			}

			Json::Value value;
			value = root["error"];
			std::string valstr = value.asString();
			int ecode;
			ecode = atoi(valstr.c_str());
			err_code = (CUserInfoWeb::OperationErrorType)ecode;

			if (ecode != CUserInfoWeb::OperationErrorType::OP_NONE_ERROR)
			{
				ret = FALSE;
				break;
			}

			value = root["ip"];
			valstr = value.asString();
			if (valstr == "null")
			{
				ret = FALSE;
				break;
			}

			strncpy(svmip, valstr.c_str(), valstr.length());

			wchar_t wvmip[64] = { 0 };
			mbstowcs(wvmip, svmip, 32);
			ip.Format(L"%s", wvmip);
			//preUsername = uname;


			value = root["uuid"];
			valstr = value.asString();
			if (valstr == "null"||valstr.length()<1)
			{
				ret = FALSE;
				break;
			}
			uuid = CString(valstr.c_str());

			//���û���֤
			preUsername.Format(L"univew50\\%s", uname);

			//��������Ϣ  yyw
			domain = L"univew50";

			prePassword = pwd;


		}
		catch (std::exception ex)
		{
			err_code = CUserInfoWeb::OperationErrorType::SERVER_NONE_USE_DESKTOP;
			ret = FALSE;
			break;
		}

   #pragma endregion
		

	} while (0);

	if (sclient != INVALID_SOCKET)
	{
		closesocket(sclient);
	}
	
	WSACleanup();

	//CString dname;
	//dname.Format(L"univew50\\%s", m_pDesktop->preUsername);
	SetErrorCode((ESClientErrorType)err_code);

	return ret;
#endif

	return 1;
}

//old version login
BOOL Desktop::GetMyVMInfoV2_1()
{
	GetHostIP();
	CString spwd = MyGetSHA(pwd);

	CString strRequest = _T("/user.do?parm=login&username=") + uname + _T("&password=") + spwd + _T("&ip=") + hostip;

	CHtmlPage *pHtml = new CHtmlPage();

	char* pBuf = pHtml->GetHtmlPage(server, strRequest, 8080);

	if (pBuf != NULL)
	{
		ParseJSON(pBuf);

		delete[] pBuf;
		pBuf = NULL;
	}

	delete pHtml;

	if (preUsername.IsEmpty())
		return FALSE;

	return TRUE;
}

void Desktop::ParseVM(CString VM)
{
	int start = 0;
	int end;
	int i = 0;
	while ((end = VM.Find(_T('='), start)) != -1)
	{
		switch (i)
		{
		case 0:
			computername1 = VM.Mid(start, end - start);
			break;
		case 1:
			ip1 = VM.Mid(start, end - start);
			break;
		case 2:
			cpu1 = VM.Mid(start, end - start);
			break;
		case 3:
			memory1 = VM.Mid(start, end - start);
			break;
		case 4:
			storage1 = VM.Mid(start, end - start);
			break;
		case 5:
			break;
		default:
			break;
		}
		start = end + 1;
		i++;
	}
	vm1 = VM.Mid(start);
	ip = ip1;
	computerName = computername1;
}

void Desktop::ParseJSON(const char* buf)
{
	int i = 0;
	char* pStart = const_cast<char*>(buf);
	char* pEnd = pStart;
	char temp[512];
	memset(temp, 0, 512);

	vm1 = _T("");
	preUsername = _T("");
	prePassword = _T("");

	while (pEnd != NULL)
	{
		switch (i)
		{
		case 0:		//vm
		{
			pStart += 7;
			pEnd = strchr(pStart, '\"');
			memcpy(temp, pStart, pEnd - pStart);
			ParseVM(CString(temp));
		}
		break;
		case 1:		//preusername
		{
			pStart += 16;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t username[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(username, 0, sizeof(username));
			while (k < len)
			{
				username[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			preUsername = MyDecodeBase64(username);
		}
		break;
		case 2:		//prepassword
		{
			pStart += 16;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t password[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(password, 0, sizeof(password));
			while (k < len)
			{
				password[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			prePassword = MyDecodeBase64(password);
		}
		break;
		case 3:		//remember
		{
			pStart += 13;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t remember[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(remember, 0, sizeof(remember));
			while (k < len)
			{
				remember[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(remember, _T("false")) == 0)
				isRemember = false;
			else
				isRemember = true;
		}
		break;
		case 4:		//autologin
		{
			pStart += 14;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t autologin[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(autologin, 0, sizeof(autologin));
			while (k < len)
			{
				autologin[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(autologin, _T("false")) == 0)
				isAutoLogin = false;
			else
				isAutoLogin = true;
		}
		break;
		case 5:		//usercenter
		{
			pStart += 15;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t usercenter[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(usercenter, 0, sizeof(usercenter));
			while (k < len)
			{
				usercenter[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(usercenter, _T("false")) == 0)
				isUserCenter = false;
			else
				isUserCenter = true;
		}
		break;
		case 6:		//redirectDrives
		{
			pStart += 19;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t rDrives[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(rDrives, 0, sizeof(rDrives));
			while (k < len)
			{
				rDrives[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(rDrives, _T("false")) == 0)
				redirectDrives = false;
			else
				redirectDrives = true;
		}
		break;
		case 7:		//redirectPrinters
		{
			pStart += 21;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t rPrinters[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(rPrinters, 0, sizeof(rPrinters));
			while (k < len)
			{
				rPrinters[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(rPrinters, _T("false")) == 0)
				redirectPrinters = false;
			else
				redirectPrinters = true;
		}
		break;
		case 8:		//redirectPorts
		{
			pStart += 18;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t rPorts[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(rPorts, 0, sizeof(rPorts));
			while (k < len)
			{
				rPorts[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(rPorts, _T("false")) == 0)
				redirectPorts = false;
			else
				redirectPorts = true;
		}
		break;
		case 9:		//redirectSmartCards
		{
			pStart += 23;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t rSmartCards[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(rSmartCards, 0, sizeof(rSmartCards));
			while (k < len)
			{
				rSmartCards[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(rSmartCards, _T("false")) == 0)
				redirectSmartCards = false;
			else
				redirectSmartCards = true;
		}
		break;
		case 10:	//redirectDevices
		{
			pStart += 20;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t rDevices[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(rDevices, 0, sizeof(rDevices));
			while (k < len)
			{
				rDevices[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(rDevices, _T("false")) == 0)
				redirectDevices = false;
			else
				redirectDevices = true;
		}
		break;
		case 11:	//domain
		{
			pStart += 11;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			wchar_t dmain[32];
			memset(dmain, 0, sizeof(dmain));
			if (len > 2)
				memcpy(temp, pStart + 2, len - 2);
			int k = 0;
			int t = 0;
			char* endptr;
			while (k < len)
			{
				dmain[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			domain = CString(dmain);
		}
		break;
		case 12:	//ispassed
		{
			pStart += 13;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t ispassed[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(ispassed, 0, sizeof(ispassed));
			while (k < len)
			{
				ispassed[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
		}
		break;
		case 13:	//ispreset
		{
			pStart += 13;
			pEnd = strchr(pStart, '\"');
			int len = pEnd - pStart;
			memcpy(temp, pStart + 2, len - 2);
			wchar_t ispreset[32];
			int k = 0;
			int t = 0;
			char* endptr;
			memset(ispreset, 0, sizeof(ispreset));
			while (k < len)
			{
				ispreset[t] = strtol(&temp[k], &endptr, 16);
				k += 6;
				t++;
			}
			if (_tcscmp(ispreset, _T("false")) == 0)
				isPreset = false;
			else
				isPreset = true;
		}
		break;
		default:
			break;

		}
		i++;

		pEnd = strchr(pStart, ',');
		pStart = pEnd;
	}
}

 CString& Desktop::GetUUID(CString& sValue)
{
	sValue = uuid;
	return sValue;
}