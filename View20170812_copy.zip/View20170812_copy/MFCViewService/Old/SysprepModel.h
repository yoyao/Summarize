#pragma once

typedef struct tag_SysprepModel
{
	mystring	_ServerIP;
	mystring	_Password;
	mystring	_TimeZone;
	mystring	_ProductKey;
	mystring	_FullName;
	mystring	_OrgName;
	mystring	_ComputerName;
	mystring	_LanguageGroup;
	mystring	_JoinDomain;
	mystring	_DomainAdmin;
	mystring	_DomainAdminPassword;
	mystring	_PreUserName;
	mystring	_PrePassword;

} SysprepModel;

void SysprepParse(SysprepModel& model, const char* message, int length);
void SysprepReceive(const SysprepModel& model);