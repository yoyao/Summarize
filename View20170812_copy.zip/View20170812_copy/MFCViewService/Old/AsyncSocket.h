#pragma once

void	RegisterSocket(HWND hWnd, UINT msg);
void UnRegisterSocket();

LRESULT AsyncSocketProc(WPARAM wParam, LPARAM lParam);