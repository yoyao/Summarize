#include "stdafx.h"
#include <process.h>
#include "StateMachine.h"
#include "Send.h"
#include "LOG.h"

unsigned int __stdcall SendThreadFunc(void* pArguments);

uintptr_t  OnSend(const StateMachine* machine)
{
	return _beginthreadex(NULL, 0, SendThreadFunc, (void*)machine, 0, NULL);
}

unsigned int __stdcall SendThreadFunc(void* pArguments)
{
	assert(pArguments != NULL);
	if (NULL == pArguments)
	{
		LOGW(_T("pArguments=NULL. Line %d, Function %s, File %s\n"), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	StateMachine* machine = (StateMachine*)pArguments;

	SOCKET s = WSASocket(AF_INET, SOCK_DGRAM, 0, NULL, 0, 0);
	if (INVALID_SOCKET == s)
	{
		LOGW(_T("WSASocket failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	// �������SOCKET���ö˿ڵ�ַ
	char yes = 1;
	if (SOCKET_ERROR == setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes)))
	{
		LOGW(_T("setsockopt failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		closesocket(s);
		return 0;
	}

	struct sockaddr_in to = { 0 };
	ULONG addr = 0;
	to.sin_family = AF_INET;
	to.sin_port = htons(machine->_Port);
	InetPton(AF_INET, (machine->_ServerIP).c_str(), &addr);
	to.sin_addr.s_addr = addr;

	int nInterval = machine->_Interval;
	DWORD dwIndex = 0;
	while (1)
	{
		dwIndex = WaitForSingleObject(machine->StopEvent, nInterval);
		if (WAIT_FAILED == dwIndex)
		{
			LOGW(_T("WaitForSingleObject failed with error: %d. Line %d, Function %s, File %s\n"), GetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
			break;
		}

		if (WAIT_OBJECT_0 == dwIndex)
		{
			break;
		}

		machine->EnumSession();
		mystring message = machine->_UUID + _T("|") +
										machine->_AgentIP + _T("|") +
										machine->_OSVersion + _T("|") +
										machine->_ComputerName + _T("|") +
										machine->_SessionState + _T("|") +
										machine->_ConnectTime + _T("|") +
										machine->_LogonTime + _T("|") +
										machine->_TimeStamp;

		size_t len = message.size() * sizeof(TCHAR) + 1;
		char* buffer = new char[len];
		memset(buffer, 0, len);
		size_t i = 0;
		wcstombs_s(&i, buffer, len, message.c_str(), len);
		buffer[i] = 0;

		if (SOCKET_ERROR == sendto(s, buffer, i, 0, (struct sockaddr*)&to, sizeof(to)))
		{
			LOGW(_T("sendto failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
			delete[] buffer;
			buffer = NULL;
			break;
		}

		delete[] buffer;
		buffer = NULL;
	}

	closesocket(s);

	LOGW(_T("Function %s ended.\n"), __FUNCTIONW__);

	_endthreadex(0);

	return 0;
}


