#pragma once

typedef struct tag_ControlModel
{
	mystring	_TimeStamp;
	mystring	_ServerName;
	mystring	_SessionID;
	mystring	_ControlType;

} ControlModel;

void ControlParse(ControlModel& model, const char* message, int length);
void ControlReceive(const ControlModel& model);