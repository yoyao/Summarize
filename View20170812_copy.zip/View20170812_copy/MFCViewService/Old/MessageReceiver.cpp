#include "stdafx.h"
#include "MessageReceiver.h"
#include <WinSock2.h>
#include  <Ws2tcpip.h>
#include <Mswsock.h>


MessageReceiver::MessageReceiver()
{
}


MessageReceiver::~MessageReceiver()
{
}

void MessageReceiver::Start()
{
	unsigned short uVersionRequired = MAKEWORD(2, 2);
	WSADATA wsaData = { 0 };
  
	if (WSAStartup(uVersionRequired, &wsaData) != 0)
		return;

	m_Socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
	if (INVALID_SOCKET == m_Socket)
	{
		WSACleanup();
		return;
	}

	sockaddr_in service = { 0 };
	service.sin_family = AF_INET;
	service.sin_port = m_nPort;
	//service.sin_addr.s_addr = inet_addr(m_BroadcastAddress.c_str());
	ULONG address = 0;
	inet_pton(AF_INET, m_BroadcastAddress.c_str(), &address);
	service.sin_addr.s_addr = address;

	
	if (bind(m_Socket, (SOCKADDR*)&service, sizeof(service)) == SOCKET_ERROR)
	{
		closesocket(m_Socket);
		WSACleanup();
		return;
	}

	IP_MREQ imr;
	inet_pton(AF_INET, m_IP.c_str(), &address);
	imr.imr_interface.s_addr = address;
	inet_pton(AF_INET, m_BroadcastAddress.c_str(), &address);
	imr.imr_multiaddr.s_addr = address;
	//imr.imr_interface.s_addr = inet_addr(m_IP.c_str());
	//imr.imr_multiaddr.s_addr = inet_addr(m_BroadcastAddress.c_str());
	if (setsockopt(m_Socket, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&imr, sizeof(imr)) == SOCKET_ERROR)
	{
		closesocket(m_Socket);
		WSACleanup();
		return;
	}

	m_Event[0] = WSACreateEvent();
	m_Event[1] = WSACreateEvent();
	WSAEventSelect(m_Socket, m_Event[0], FD_READ);
}

void MessageReceiver::Stop()
{
	WSASetEvent(m_Event[1]);
	IP_MREQ imr;
	ULONG address;
	inet_pton(AF_INET, m_IP.c_str(), &address);
	imr.imr_interface.s_addr = address;
	inet_pton(AF_INET, m_BroadcastAddress.c_str(), &address);
	imr.imr_multiaddr.s_addr = address;
//	imr.imr_interface.s_addr = inet_addr(m_IP.c_str());
//	imr.imr_multiaddr.s_addr = inet_addr(m_BroadcastAddress.c_str());
	if (m_Socket != INVALID_SOCKET)
	{
		setsockopt(m_Socket, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char *)&imr, sizeof(imr));
		closesocket(m_Socket);
		WSACleanup();
	}
}

void MessageReceiver::Receive()
{
	for (;;)
	{
		DWORD dwResult = WSAWaitForMultipleEvents(2, m_Event, FALSE, INFINITE, FALSE);
		dwResult -= WSA_WAIT_EVENT_0;
		if (0 == dwResult)
		{
			int flag = MSG_PARTIAL;
			std::string	recvmsg;
			char	buf[1024] = { 0 };
			while (flag & MSG_PARTIAL)
			{
				memset(buf, 0, 1024);
				//WSARecvEx(m_Socket, buf, 1024, &flag);
				//WSARecv(m_Socket, buf, 1024, &flag);
				recvmsg += std::string(buf);
			}
		}
		else  if (1 == dwResult)
		{
			break;
		}
	}
}