#pragma once

class MessageBase;

class UdpClient
{
public:
	UdpClient();
	~UdpClient();

	void Send(const mystring& data, const mystring& ServerIP,  int nPort);

private:
	SOCKET	m_hSocket;
};

class MessageSender
{
public:
	MessageSender();
	~MessageSender();

	void SendMessage(const mystring& ServerIP, int Port, MessageBase Message);
	void SendMessage(const mystring& ServerIP, int Port, const mystring& Message);

private:
	UdpClient		m_UdpClient;
};

