#include "stdafx.h"
#include "FireWall.h"
#include "INetFwManger.h"
#include "StateMachine.h"

void FireWallOpen(const StateMachine* machine)
{
	assert(machine != NULL);
	if (NULL == machine)
		return;

	TCHAR  buffer[MAX_PATH] = { 0 };
	::GetModuleFileName(NULL, buffer, MAX_PATH);

	INetFwManger::NetFwAddPorts(_T("ViewService"), machine->_Port, _T("UDP"));
	INetFwManger::NetFwAddPorts(_T("ViewService"), machine->_Port, _T("TCP"));
	INetFwManger::NetFwAddApps(_T("ViewService"), mystring(buffer));

	if (((machine->_OSVersion).find(_T("Windows 7")) > -1) || ((machine->_OSVersion).find(_T("Windows 8")) > -1))
	{
		HKEY hKey;
		if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE,
			_T("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\NetworkList\\Profiles"), 0, KEY_ALL_ACCESS, &hKey))
		{
			DWORD dwIndex = 0;
			DWORD dwSize = MAX_PATH;
			HKEY hSubKey;
			while (ERROR_SUCCESS == RegEnumKeyEx(hKey, dwIndex, buffer, &dwSize, NULL, NULL, NULL, NULL))
			{
				if (ERROR_SUCCESS == RegOpenKeyEx(hKey, buffer, 0, KEY_ALL_ACCESS, &hSubKey))
				{
					DWORD dwType = 0;
					TCHAR	ValueData[128] = { 0 };
					dwSize = sizeof(ValueData);
					if (ERROR_SUCCESS == RegQueryValueEx(hSubKey, _T("Description"), NULL, &dwType, (BYTE*)ValueData, &dwSize))
					{
						if (_tcsstr(buffer, _T("����")) != NULL)
						{
							DWORD dwData = 1;
							RegSetValueEx(hSubKey, _T("Category"), 0, REG_DWORD, (BYTE*)&dwData, sizeof(dwData));
							dwData = 0;
							RegSetValueEx(hSubKey, _T("CategoryType"), 0, REG_DWORD, (BYTE*)&dwData, sizeof(dwData));
							RegSetValueEx(hSubKey, _T("IconType"), 0, REG_DWORD, (BYTE*)&dwData, sizeof(dwData));
						}
						else
						{
							DWORD dwData = 2;
							RegSetValueEx(hSubKey, _T("Category"), 0, REG_DWORD, (BYTE*)&dwData, sizeof(dwData));
						}
					}
					RegCloseKey(hSubKey);
				}
				dwIndex++;
			}
			RegCloseKey(hKey);
		}

		if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE,
			_T("SYSTEM\\CurrentControlSet\\services\\SharedAccess\\Parameters\\FirewallPolicy\\FirewallRules"), 0, KEY_ALL_ACCESS, &hKey))
		{
			DWORD dwIndex = 0;
			DWORD dwSize = MAX_PATH;
			DWORD dwType = REG_SZ;
			while (ERROR_SUCCESS == RegEnumValue(hKey, dwIndex, buffer, &dwSize, NULL, &dwType, NULL, NULL))
			{
				if (_tcsstr(buffer, _T("RemoteDesktop-In-TCP")) != NULL)
				{
					TCHAR* pData = _T("v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=6|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=System|Name=Զ������(TCP-In)|Desc=@FirewallAPI.dll,-28756|EmbedCtxt=@FirewallAPI.dll,-28752|");
					dwSize = sizeof(_T("v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=6|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=System|Name=Զ������(TCP-In)|Desc=@FirewallAPI.dll,-28756|EmbedCtxt=@FirewallAPI.dll,-28752|"));
					RegSetValueEx(hKey, buffer, 0, dwType, (BYTE*)pData, dwSize);
				}
				else if (_tcsstr(buffer, _T("RemoteDesktop-UserMode-In-TCP")) != NULL)
				{
					TCHAR* pData = _T("v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=6|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=%SystemRoot%\\system32\\svchost.exe|Svc=termservice|Name=Զ������ - RemoteFX (TCP-In)|Desc=@FirewallAPI.dll,-28856|EmbedCtxt=@FirewallAPI.dll,-28852|");
					dwSize = sizeof(_T("v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=6|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=%SystemRoot%\\system32\\svchost.exe|Svc=termservice|Name=Զ������ - RemoteFX (TCP-In)|Desc=@FirewallAPI.dll,-28856|EmbedCtxt=@FirewallAPI.dll,-28852|"));
					RegSetValueEx(hKey, buffer, 0, dwType, (BYTE*)pData, dwSize);
				}
				else if (_tcsstr(buffer, _T("RemoteDesktop-UserMode-In-UDP")) != NULL)
				{
					TCHAR* pData = _T("v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=17|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=%SystemRoot%\\system32\\svchost.exe|Svc=termservice|Name=Remote Desktop - RemoteFX (UDP-In)|Desc=@RdpGroupPolicyExtension.dll,-102|EmbedCtxt=@FirewallAPI.dll,-28852|");
					dwSize = sizeof(_T("v2.10|Action=Allow|Active=TRUE|Dir=In|Protocol=17|Profile=Domain|Profile=Private|Profile=Public|LPort=3389|App=%SystemRoot%\\system32\\svchost.exe|Svc=termservice|Name=Remote Desktop - RemoteFX (UDP-In)|Desc=@RdpGroupPolicyExtension.dll,-102|EmbedCtxt=@FirewallAPI.dll,-28852|"));
					RegSetValueEx(hKey, buffer, 0, dwType, (BYTE*)pData, dwSize);
				}

				dwIndex++;
				dwSize = MAX_PATH;
			}
			RegCloseKey(hKey);
		}
		else
		{
			_stprintf_s(buffer, MAX_PATH, _T("%d:UDP"), machine->_Port);

			TCHAR data[64] = { 0 };
			int count = _stprintf_s(data, 64, _T("%d:UDP:*:Enabled:ViewService"), machine->_Port) + 1;

			HKEY hKey;
			if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE,
				_T("SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\DomainProfile\\GloballyOpenPorts\\List"), 0, KEY_ALL_ACCESS, &hKey))
			{
				RegSetValueEx(hKey, buffer, 0, REG_SZ, (BYTE*)data, count*sizeof(TCHAR));
				RegCloseKey(hKey);
			}

			if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE,
				_T("SYSTEM\\CurrentControlSet\\Services\\SharedAccess\\Parameters\\FirewallPolicy\\StandardProfile\\GloballyOpenPorts\\List"), 0, KEY_ALL_ACCESS, &hKey))
			{
				RegSetValueEx(hKey, buffer, 0, REG_SZ, (BYTE*)data, count*sizeof(TCHAR));
				RegCloseKey(hKey);
			}
		}
	}
}
