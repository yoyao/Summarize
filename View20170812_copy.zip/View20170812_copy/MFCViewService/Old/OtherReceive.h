#pragma once

typedef struct tag_SyncModel
{
	mystring	_DateTime;

} SyncModel;

typedef struct tag_RestoreModel
{
	bool	_Start;

} RestoreModel;

typedef struct tag_ShareModel
{
	mystring	_ServerIP;
	mystring	_UserID;

} ShareModel;


void SyncDateTimeReceive(const SyncModel& model);
void RestoreReceive(const RestoreModel& model);
void ShareReceive(const ShareModel& model);

void SyncDateTimeParse(SyncModel& model, const char* message, int length);
void RestoreParse(RestoreModel& model, const char* message, int length);
void ShareParse(ShareModel& model, const char* message, int length);
