#include "stdafx.h"
#include "ITerminalServiceSession.h"


ITerminalServiceSession::ITerminalServiceSession()
{


}

ITerminalServiceSession::~ITerminalServiceSession()
{
	m_listSession.clear();
}

bool ITerminalServiceSession::Init()
{
	DWORD Level = 1;
	PWTS_SESSION_INFO_1	pInfo1 = NULL;
	DWORD Count = 0;
	WTSEnumerateSessionsEx(WTS_CURRENT_SERVER_HANDLE, &Level, 0, &pInfo1, &Count);

	for (int i = 0; i < Count; ++i)
	{
		ISESSION_INFO sessionInfo = { 0 };
		DWORD dwBytesReturned = 0;
		WTSINFOEX*	infoex = NULL;
		WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, pInfo1[i].SessionId, WTSSessionInfoEx, (LPTSTR*)&infoex, &dwBytesReturned);

		sessionInfo.ConnectionState = infoex->Data.WTSInfoExLevel1.SessionState;
		sessionInfo.ConnectTime = infoex->Data.WTSInfoExLevel1.ConnectTime;
		sessionInfo.CurrentTime = infoex->Data.WTSInfoExLevel1.CurrentTime;
		sessionInfo.DisconnectTime = infoex->Data.WTSInfoExLevel1.DisconnectTime;
		sessionInfo.DomainName = infoex->Data.WTSInfoExLevel1.DomainName;
		sessionInfo.UserName = infoex->Data.WTSInfoExLevel1.UserName;
		sessionInfo.LoginTime = infoex->Data.WTSInfoExLevel1.LogonTime;
		sessionInfo.LastInputTime = infoex->Data.WTSInfoExLevel1.LastInputTime;
		sessionInfo.WindowStationName = infoex->Data.WTSInfoExLevel1.WinStationName;
		sessionInfo.SessionId = pInfo1[i].SessionId;
		WTSFreeMemory(infoex);
		infoex = NULL;
		
		WTSCLIENT* client = NULL;
		dwBytesReturned = 0;
		WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, pInfo1[i].SessionId, WTSClientInfo, (LPTSTR*)&client, &dwBytesReturned);

		sessionInfo.ClientBuildNumber = client->ClientBuildNumber;
		sessionInfo.ClientName = client->ClientName;
		//sessionInfo.ClientIPAddress = client->ClientAddress;
		WTSFreeMemory(client);
		client = NULL;

		m_listSession.push_back(sessionInfo);
	}

	return true;
}