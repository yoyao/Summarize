#pragma once

typedef struct __SessionEventModel
{
	mystring	_UUID;
	mystring	_TimeStamp;
	mystring	_SessionEvent;
	mystring	_OSVersion;
	mystring	_IP;
	mystring	_UserAccount;
	mystring	_WindowStationName;
	mystring	_ConnectTime;
	mystring	_LogonTime;
	mystring	_IdleTime;
	mystring	_ServerIP;
	mystring	_State;
	mystring	_SessionID;

	__SessionEventModel()
	{
		mystring	_UUID = _T("");
		mystring	_TimeStamp = _T("");
		mystring	_SessionEvent = _T("");
		mystring	_OSVersion = _T("");
		mystring	_IP = _T("");
		mystring	_UserAccount = _T("");
		mystring	_WindowStationName = _T("");
		mystring	_ConnectTime = _T("");
		mystring	_LogonTime = _T("");
		mystring	_IdleTime = _T("");
		mystring	_ServerIP = _T("");
		mystring	_State = _T("");
		mystring	_SessionID = _T("");
	}
} SessionEventModel;


class Common
{
public:
	Common();
	~Common();

	static mystring GetIP(mystring ServerIP);
	static mystring GetWindowsVersion();
	static mystring decodeUnicode(mystring dataStr);
	static mystring encodeUnicode(mystring str);
};

