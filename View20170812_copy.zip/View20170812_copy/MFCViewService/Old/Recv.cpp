#include "stdafx.h"
#include "Recv.h"
#include "StateMachine.h"
#include "LOG.h"
#include <process.h>
#include "SysprepModel.h"
#include "FormatDiskModel.h"
#include "ControlModel.h"
#include "OtherReceive.h"

const int TYPE_Unknown		= 0;
const int TYPE_HeartBeat		= 10;
const int TYPE_SessionEvent = 11;
const int TYPE_Query			= 17;
const int TYPE_Command		= 20;
const int TYPE_Identity			= 100;
const int TYPE_Register			= 128;

unsigned int __stdcall RecvThreadFunc(void* pArguments);

uintptr_t	OnRecv(const StateMachine* machine)
{
	return _beginthreadex(NULL, 0, RecvThreadFunc, (void*)machine, 0, NULL);
}

unsigned int __stdcall RecvThreadFunc(void* pArguments)
{
	assert(pArguments != NULL);
	if (NULL == pArguments)
	{
		LOGW(_T("pArguments=NULL. Line %d, Function %s, File %s\n"), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	StateMachine* machine = (StateMachine*)pArguments;

	SOCKET s = WSASocket(AF_INET, SOCK_DGRAM, 0, NULL, 0, 0);
	if (INVALID_SOCKET == s)
	{
		LOGW(_T("WSASocket failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	// �������SOCKET���ö˿ڵ�ַ
	char yes = 1;
	if (SOCKET_ERROR == setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes)))
	{
		LOGW(_T("setsockopt failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		closesocket(s);
		return 0;
	}

	struct sockaddr_in from = { 0 };
	from.sin_family = AF_INET;
	from.sin_port = htons(machine->_Port);
	from.sin_addr.s_addr = INADDR_ANY;
	if (bind(s, (sockaddr*)&from, sizeof(from)) == SOCKET_ERROR)
	{
		LOGW(_T("bind failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		closesocket(s);
		return 0;
	}

	//����ಥ��
	IP_MREQ imr = { 0 };
	ULONG addr = 0;
	InetPton(AF_INET, _T("224.224.224.224"), &addr);
	imr.imr_multiaddr.s_addr = addr;
	imr.imr_interface.s_addr = htonl(INADDR_ANY);
	if (setsockopt(s, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&imr, sizeof(imr)) == SOCKET_ERROR)
	{
		LOGW(_T("setsockopt failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		closesocket(s);
		return 0;
	}

	//RecvEvent��FD_READ��
	WSAEventSelect(s, machine->RecvEvent, FD_READ);

	WSAEVENT events[2] = {machine->StopEvent, machine->RecvEvent };

	DWORD dwIndex = 0;
	char message[1024];
	struct sockaddr_in truefrom = { 0 };
	int truesize = sizeof(truefrom);
	int ret = 0;

	while (1)
	{
		dwIndex = WSAWaitForMultipleEvents(2, events, FALSE, WSA_INFINITE, FALSE);
		if (WAIT_FAILED == dwIndex)
		{
			LOGW(_T("WSAWaitForMultipleEvents failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
			break;
		}

		if (WSA_WAIT_EVENT_0 == dwIndex)
		{
			break;
		}

		WSANETWORKEVENTS NetworkEvents = { 0 };
		WSAEnumNetworkEvents(s, events[1], &NetworkEvents);
		if (NetworkEvents.lNetworkEvents & FD_READ)
		{
			if (NetworkEvents.iErrorCode[FD_READ_BIT] != 0)
			{
				continue;
			}

			memset(message, 0, sizeof(message));
			ret = recvfrom(s, message, sizeof(message), 0, (sockaddr*)&truefrom, &truesize);
			if (SOCKET_ERROR == ret)
			{
				LOGW(_T("recvfrom failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
				break;
			}
			
			LOGW(_T("message = %s, ret=%d, truesize=%d, sizeof(sockaddr_in)=%d\n"), message, ret, truesize, sizeof(sockaddr_in));

			switch (message[0])
			{
			case TYPE_Command:
				{
					LOGW(_T("Enter TYPE_Command = %d\n"), message[0]);
					TCHAR buffer[64] = { 0 };
					DWORD addrLength = 64;
					if (WSAAddressToString((sockaddr*)&truefrom, truesize, NULL, buffer, &addrLength) == SOCKET_ERROR)
					{
						LOGW(_T("WSAAddressToString failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
					}

					TCHAR* pFind = _tcsrchr(buffer, _T(':'));
					int i = 0;
					while (pFind[i++] != 0)
					{
						pFind[i] = 0;
					}

					if (strstr(&message[1], "sysprep|") != NULL)
					{
						// message[0 - 7] = {TYPE_Command, "sysprep|"}
						SysprepModel model;
						model._ServerIP = mystring(buffer);
						SysprepParse(model, &message[9], ret-9);
						SysprepReceive(model);
					}
					else if (strstr(&message[1], "control|") != NULL)
					{
						ControlModel model;
						ControlParse(model, &message[9], ret - 9);
						ControlReceive(model);
					}
					else if (strstr(&message[1], "format|") != NULL)
					{
						FormatDiskModel model;
						FormatDiskParse(model, &message[8], ret - 8);
						FormatDiskReceive(model);
					}
					else if (strstr(&message[1], "sync|") != NULL)
					{
						SyncModel model;
						SyncDateTimeParse(model, &message[6], ret - 6);
						SyncDateTimeReceive(model);
					}
					else if (strstr(&message[1], "restore|") != NULL)
					{
						RestoreModel model;
						RestoreParse(model, &message[9], ret - 9);
						RestoreReceive(model);
					}
					else if (strstr(&message[1], "share|") != NULL)
					{
						ShareModel model;
						ShareParse(model, &message[7], ret - 7);
						ShareReceive(model);
					}
				}
				break;
			case TYPE_Identity:
				break;
			default:
				break;
			}
		}
	}
	
	//
	if (setsockopt(s, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char *)&imr, sizeof(imr)) == SOCKET_ERROR)
	{
		LOGW(_T("setsockopt failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		_endthreadex(0);
		closesocket(s);
		return 0;
	}


	closesocket(s);

	LOGW(_T("Function %s ended.\n"), __FUNCTIONW__);

	_endthreadex(0);

	return 0;
}