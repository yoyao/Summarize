#pragma once

class StateMachine;

uintptr_t  OnSend(const StateMachine* machine);
