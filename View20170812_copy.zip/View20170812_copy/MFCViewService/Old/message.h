#pragma once

enum class MessageType
{
	Unknown		= 0,
	HeartBeat		= 10,
	SessionEvent = 11,
	Query			= 17,
	Command	= 20,
	Identity			= 100,
};

class MessageBase
{
public:
	MessageBase() {};
	MessageBase(MessageType type) : m_Type(type) {};
	~MessageBase(){};

	const mystring& GetPackageData() { return _T(""); };

private:
	MessageType		m_Type;
};


class HeartBeatMessage : public MessageBase
{
private:
	mystring _UUID;
	mystring _IP;
	mystring _OSVersion;
	mystring _ComputerName;
	mystring _SessionState;
	mystring _ConnectTime;
	mystring _LogonTime;
	mystring _TimeStamp;

public:
	HeartBeatMessage(mystring UUID,  mystring IP, mystring OSVersion, mystring ComputerName, 
		mystring SessionState, mystring ConnectTime, mystring LogonTime, mystring TimeStamp)
		: MessageBase(MessageType::HeartBeat)
	{
		_UUID = UUID;
		_IP = IP;
		_OSVersion = OSVersion;
		_ComputerName = ComputerName;
		_SessionState = SessionState;
		_ConnectTime = ConnectTime;
		_LogonTime = LogonTime;
		_TimeStamp = TimeStamp;
	};

	~HeartBeatMessage(){};

	const mystring& GetPackageData()
	{
		mystring str1 = _UUID;
		str1 += _T("|");
		str1 += _IP;
		str1 += _T("|");
		str1 += _OSVersion;
		str1 += _T("|");
		str1 += _ComputerName;
		str1 += _T("|");
		str1 += _SessionState;
		str1 += _T("|");
		str1 += _ConnectTime;
		str1 += _T("|");
		str1 += _LogonTime;
		str1 += _T("|");
		str1 += _TimeStamp;
	}
};


