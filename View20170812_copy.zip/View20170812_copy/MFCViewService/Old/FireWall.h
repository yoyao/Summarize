#pragma once

class StateMachine;

void FireWallOpen(const StateMachine* machine);
