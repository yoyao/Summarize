#pragma once

class StateMachine;

class AgentUdp
{
public:
	AgentUdp();
	~AgentUdp();

	void		OnSendHeartBeat(const StateMachine* machine);
	void		OnListen(const StateMachine* machine);
	void		OnStop(const StateMachine* machine);
private:
	bool		m_bInitSock;			//Winsock2�Ƿ��ʼ��
};

