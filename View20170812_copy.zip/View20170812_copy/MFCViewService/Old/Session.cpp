#include "stdafx.h"
#include "Session.h"

LRESULT SessionProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	TCHAR buf[64];
	_stprintf_s(buf, 64, _T("SessionID = %d in SessionProc"), lParam);
	OutputDebugString(buf);

	switch (wParam)
	{
	case WTS_CONSOLE_CONNECT:
		break;
	case WTS_CONSOLE_DISCONNECT:
		break;
	case WTS_REMOTE_CONNECT:
		break;
	case WTS_REMOTE_DISCONNECT:
		break;
	case WTS_SESSION_LOGON:
		break;
	case WTS_SESSION_LOGOFF:
		break;
	case WTS_SESSION_LOCK:
		break;
	case WTS_SESSION_UNLOCK:
		break;
	case WTS_SESSION_REMOTE_CONTROL:
		break;
	default:
		break;
	}

	return 0;
}