#pragma once

BOOL	InitAgent();
void		RunAgent();
void		StopAgent();



	