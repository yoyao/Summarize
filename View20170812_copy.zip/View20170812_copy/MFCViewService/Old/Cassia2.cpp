#include "stdafx.h"
#include "Cassia2.h"
#include "Common.h"
#include "ITerminalServiceSession.h"


Cassia2::Cassia2()
{
}


Cassia2::~Cassia2()
{
}

SessionEventModel Cassia2::ShowCurrentSession3()
{
	ITerminalServiceSession	terminal;
	terminal.Init();

	SessionEventModel	eventModel;

	ISESSION_INFO sessionInfo = { 0 };

	while (!(terminal.m_listSession.empty()))
	{
		sessionInfo = terminal.m_listSession.front();
		if ((sessionInfo.ConnectionState = WTSActive) &&
			(sessionInfo.WindowStationName.find(_T("RDP-Tcp#")) != mystring::npos) &&
			(!(sessionInfo.ClientIPAddress.empty())))
		{
			eventModel = WriteSessionInfo3(sessionInfo);
			break;
		}

		if ((sessionInfo.ConnectionState = WTSDisconnected) &&
			(sessionInfo.WindowStationName.find(_T("RDP-Tcp#")) != mystring::npos) &&
			(sessionInfo.UserName.empty()))
		{
			eventModel = WriteSessionInfo3(sessionInfo);
			break;
		}

		if ((sessionInfo.ConnectionState = WTSDisconnected) && (sessionInfo.UserName.empty()))
		{
			eventModel = WriteSessionInfo3(sessionInfo);
			break;
		}
	}

	return eventModel;
}

SessionEventModel Cassia2::WriteSessionInfo3(ISESSION_INFO& isessionInfo)
{
	SessionEventModel	eventModel;

	if (!(isessionInfo.UserName.empty()))
		eventModel._UserAccount = isessionInfo.UserName;

	if (!(isessionInfo.WindowStationName.empty()))
		eventModel._WindowStationName = isessionInfo.WindowStationName;

	if (!(isessionInfo.ClientIPAddress.empty()))
		eventModel._ServerIP = isessionInfo.ClientIPAddress;

	TCHAR  temp[512] = { 0 };
	_stprintf_s(temp, 512, _T("%dI64"), isessionInfo.ConnectTime);
	eventModel._ConnectTime = mystring(temp);

	_stprintf_s(temp, 512, _T("%dI64"), isessionInfo.LoginTime);
	eventModel._LogonTime = mystring(temp);

	_stprintf_s(temp, 512, _T("%d"), isessionInfo.SessionId);
	eventModel._LogonTime = mystring(temp);

	_stprintf_s(temp, 512, _T("%d"), isessionInfo.ConnectionState);
	eventModel._State = mystring(temp);

	return eventModel;
}