#include "stdafx.h"
#include "AgentMain.h"
#include "resource.h"
#include "Session.h"
#include "StateMachine.h"
#include "AsyncSocket.h"
#include "AgentUdp.h"
#include "StateMachine.h"
#include "LOG.h"
#include "FireWall.h"



#define WM_TRAY_NOTIFY						(WM_USER + 100)  
#define IDT_TIMER_REGISTERSESSION		10
#define IDT_TIMER_HEARTBEAT				20

static HWND				g_hWnd = NULL;
static AgentUdp			g_AgentUdp;
static StateMachine*	g_StateMachine = NULL;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

void	AddNotifyIcon(HWND hWnd);
void DeleteNotifyIcon(HWND hWnd);

void	OnAgentStart();		//����Agent��Server��ͨѶ

void  RunAgent()
{
	// ����Ϣѭ��: 
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	StateMachine::Release();
}

void StopAgent()
{
	if (g_StateMachine != NULL)
	{
		g_AgentUdp.OnStop(g_StateMachine);
	}

	if (g_hWnd != NULL)
	{
		KillTimer(g_hWnd, IDT_TIMER_HEARTBEAT);
		::PostMessage(g_hWnd, WM_DESTROY, 0, 0);
	}
}

BOOL  InitAgent()
{
	HINSTANCE hInstance = ::GetModuleHandle(NULL);

	WNDCLASSEX wcex;

	ZeroMemory(&wcex, sizeof(wcex));
	wcex.cbSize				= sizeof(WNDCLASSEX);
	wcex.lpfnWndProc	= WndProc;
	wcex.hInstance			= hInstance;
	wcex.lpszClassName = _T("esageAgent");

	if (!RegisterClassEx(&wcex))
	{
		TCHAR buffer[64] = { 0 };
		_stprintf_s(buffer, 64, _T("RegisterClassEx failed with error:%d"), GetLastError());
		OutputDebugString(buffer);
		return FALSE;
	}

	g_hWnd = CreateWindow(_T("esageAgent"), NULL, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if (!g_hWnd)
	{
		TCHAR buffer[64] = { 0 };
		_stprintf_s(buffer, 64, _T("CreateWindow failed with error:%d"), GetLastError());
		OutputDebugString(buffer);
		return FALSE;
	}

	SetTimer(g_hWnd, IDT_TIMER_REGISTERSESSION, 500, NULL);

#define TEST		1
#if TEST
	ShowWindow(g_hWnd, SW_SHOW);
	UpdateWindow(g_hWnd);
#endif
	
	g_StateMachine = StateMachine::GetInstance();
	if (NULL == g_StateMachine)
	{
		OutputDebugString(_T("g_StateMachine = NULL"));
	}
	
	FireWallOpen(g_StateMachine);

	SetTimer(g_hWnd, IDT_TIMER_HEARTBEAT, g_StateMachine->_Interval, NULL);

	g_AgentUdp.OnListen(g_StateMachine);

	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_CREATE:
		//AddNotifyIcon(hWnd);
		break;
	case WM_DESTROY:
		//DeleteNotifyIcon(hWnd);
		WTSUnRegisterSessionNotification(hWnd);
		PostQuitMessage(0);
		break;
	case WM_TIMER:
		 if (wParam == IDT_TIMER_HEARTBEAT)
		{
			if (g_StateMachine != NULL)
			{
				OutputDebugString(_T("IDT_TIMER_HEARTBEAT Succeed"));
				g_StateMachine->EnumSession();
				g_AgentUdp.OnSendHeartBeat(g_StateMachine);
			}
		}
		else if (wParam == IDT_TIMER_REGISTERSESSION)
		{
			if (WTSRegisterSessionNotification(hWnd, NOTIFY_FOR_ALL_SESSIONS))
			{
				KillTimer(hWnd, IDT_TIMER_REGISTERSESSION);
				OutputDebugString(_T("WTSRegisterSessionNotification Succeed"));
			}
			else
			{
				OutputDebugString(_T("WTSRegisterSessionNotification Failed"));
			}
		}	
		break;
	case WM_WTSSESSION_CHANGE:
		SessionProc(hWnd, wParam, lParam);
		break;
	case WM_TRAY_NOTIFY:

		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

void AddNotifyIcon(HWND hWnd)
{
	NOTIFYICONDATA data = { 0 };

	data.cbSize = sizeof(data);
	data.hWnd = hWnd;
	data.uCallbackMessage = WM_TRAY_NOTIFY;
	data.uID		= IDI_ICON_AGENT;
	data.hIcon	= LoadIcon(::GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON_AGENT));
	data.uFlags	= NIF_ICON | NIF_MESSAGE;
	data.uVersion = NOTIFYICON_VERSION_4;
	Shell_NotifyIcon(NIM_ADD, &data);
}

void DeleteNotifyIcon(HWND hWnd)
{
	NOTIFYICONDATA data = { 0 };

	data.hWnd	= hWnd;
	data.uID		= IDI_ICON_AGENT;
	Shell_NotifyIcon(NIM_DELETE, &data);
}


//////////////////////////////////////////////////////////////////
void OnAgentStart()
{



}
