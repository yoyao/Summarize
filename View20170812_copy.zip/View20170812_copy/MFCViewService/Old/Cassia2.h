#pragma once

#include "Common.h"
#include "ITerminalServiceSession.h"

class Cassia2
{
public:
	Cassia2();
	~Cassia2();

	static SessionEventModel ShowCurrentSession3();
	static SessionEventModel WriteSessionInfo3(ISESSION_INFO& isessionInfo);
};

