#include "stdafx.h"
#include "MessageSender.h"
#include "message.h"


UdpClient::UdpClient()
{
	WORD			wVersionRequested = 0;
	WSADATA	wsaData = { 0 };

	m_hSocket = INVALID_SOCKET;
	wVersionRequested = MAKEWORD(2, 2);
	if (WSAStartup(wVersionRequested, &wsaData) == 0)
	{
		if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
		{
			WSACleanup();
			TCHAR  buf[64] = { 0 };
			_stprintf_s(buf, 64, _T("Version is not 2.2. Version is %d.%d"), HIBYTE(wsaData.wVersion), LOBYTE(wsaData.wVersion));
			OutputDebugString(buf);
		}
		else
		{
			m_hSocket = socket(AF_INET, SOCK_DGRAM, 0);
			if (m_hSocket == INVALID_SOCKET)
			{
				WSACleanup();
				OutputDebugString(_T("Failed to create UDP socket in UpdClient"));
			}
		}
	}
}

UdpClient::~UdpClient()
{
	if (m_hSocket != INVALID_SOCKET)
	{
		closesocket(m_hSocket);
	}

	WSACleanup();
}

void UdpClient::Send(const mystring& data, const mystring& ServerIP, int nPort)
{
	struct sockaddr_in server_addr = { 0 };
	
	char  server[64] = { 0 };
	size_t len = 0;
#ifdef UNICODE
	wcstombs_s(&len, server, 64, ServerIP.c_str(), ServerIP.length());
#else
	strcpy_s(server, 64, ServerIP.c_str());
#endif

	server_addr.sin_family = AF_INET;
//	server_addr.sin_addr.s_addr = inet_addr(server);
	ULONG address = 0;
	inet_pton(AF_INET, server, &address);
	server_addr.sin_addr.s_addr = address; 
	server_addr.sin_port = htons(nPort);

	if (m_hSocket != INVALID_SOCKET)
	{
		len = data.length() * sizeof(TCHAR);
		char* buf = (char*)malloc(len);
		memcpy(buf, (char*)(data.c_str()), len);
		if (sendto(m_hSocket, buf, len, 0, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0)
		{
			OutputDebugString(_T("Failed to sendto in UdpClient"));
		}
		free(buf);
		buf = NULL;
	}
}

MessageSender::MessageSender()
{
}


MessageSender::~MessageSender()
{
}


void MessageSender::SendMessage(const mystring& ServerIP, int Port, MessageBase Message)
{
	if (ServerIP.empty())
	{
		OutputDebugString(_T("ServerIP is empty in MessageSender"));
		return;
	}

	const mystring packagedata = Message.GetPackageData();
	m_UdpClient.Send(packagedata, ServerIP, Port);
}

void MessageSender::SendMessage(const mystring& ServerIP, int Port, const mystring& Message)
{
#ifdef UNICODE
	int len = WideCharToMultiByte(CP_UTF8, 0, Message.c_str(), -1, NULL, 0, NULL, NULL);
	char *utf8 = (char*)malloc(len+1);
	utf8[len] = 0;
	WideCharToMultiByte(CP_UTF8, 0, Message.c_str(), -1, utf8, len, NULL, NULL);

	len = MultiByteToWideChar(CP_ACP, 0, utf8, -1, NULL, 0);
	wchar_t* UTF8 = (wchar_t*)malloc(len + 1);
	UTF8[len] = 0;
	MultiByteToWideChar(CP_ACP, 0, utf8, -1, UTF8, len);
	mystring packagedata(UTF8);

	free(utf8);
	free(UTF8);
	utf8		= NULL;
	UTF8	= NULL;
#else
	mystring packagedata(Message);
#endif
	m_UdpClient.Send(packagedata, ServerIP, Port);
}

