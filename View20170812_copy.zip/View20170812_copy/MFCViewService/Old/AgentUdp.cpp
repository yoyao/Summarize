#include "stdafx.h"
#include "AgentUdp.h"
#include "StateMachine.h"
#include <process.h>
#include "LOG.h"

unsigned int __stdcall ListenThreadFunc(void* pArguments);


AgentUdp::AgentUdp()
{
	m_bInitSock = true;

	WSADATA wsaData = { 0 };
	int nError = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (nError != 0)
	{
		TCHAR buffer[64];
		_stprintf_s(buffer, 64, _T("WSAStartup failed with error: %d in AgentUdp()"), nError);
		OutputDebugString(buffer);
		m_bInitSock = false;
	}

	if ((LOBYTE(wsaData.wVersion) != 2) || (HIBYTE(wsaData.wVersion) != 2))
	{
		OutputDebugString(_T("Winsock 2.2 dll was not found"));
		WSACleanup();
		m_bInitSock = false;
	}
}

AgentUdp::~AgentUdp()
{
	WSACleanup();
}

void AgentUdp::OnSendHeartBeat(const StateMachine* machine)
{
	assert(machine != NULL);
	if (NULL == machine)
	{
		OutputDebugString(_T("Parameter: machine = NULL in OnSendHeartBeat()"));
		return;
	}

	if (!m_bInitSock)
	{
		OutputDebugString(_T("Winsock was not initialized in OnSendHeartBeat()"));
		return;
	}

	SOCKET s = socket(AF_INET, SOCK_DGRAM, 0);

	machine->Lock();

	struct sockaddr_in agentto = { 0 };
	agentto.sin_family = AF_INET;
	agentto.sin_port = htons(machine->_Port);
	ULONG addr = 0;
	InetPton(AF_INET, (machine->_ServerIP).c_str(), &addr); //server�ĵ�ַ 
	agentto.sin_addr.s_addr = addr;

	mystring message = machine->_UUID + _T("|") + 
									machine->_AgentIP + _T("|") + 
									machine->_OSVersion + _T("|") + 
									machine->_ComputerName + _T("|") +
									machine->_SessionState + _T("|") + 
									machine->_ConnectTime + _T("|") + 
									machine->_LogonTime + _T("|") + 
									machine->_TimeStamp;

	machine->UnLock();

	//LOGW(_T("%s"), message.c_str());
	
	if (sendto(s, (char*)(message.c_str()), message.size() * sizeof(TCHAR), 0, (struct sockaddr*)&agentto, sizeof(agentto)) == SOCKET_ERROR)
	{
		TCHAR buffer[64];
		_stprintf_s(buffer, 64, _T("sendto failed with error:%d in UdpSend()"), WSAGetLastError());
		OutputDebugString(buffer);
		LOGW(_T("%s"), buffer);
	}

	closesocket(s);
}

void AgentUdp::OnListen(const StateMachine* machine)
{
	assert(machine != NULL);
	if (NULL == machine)
	{
		OutputDebugString(_T("Parameter: machine = NULL in OnListen()"));
		return;
	}

	if (!m_bInitSock)
	{
		OutputDebugString(_T("Winsock was not initialized in OnListen()"));
		return;
	}

	machine->Lock();

	if (machine->_Event[0] != WSA_INVALID_EVENT)
		WSASetEvent(machine->_Event[0]);

	if (machine->_Event[1] != WSA_INVALID_EVENT)
		WSASetEvent(machine->_Event[1]);

	machine->_Event[0] = WSACreateEvent();	// ��ֹ�߳������¼�
	machine->_Event[1] = WSACreateEvent();	// SOCKET�¼�

	machine->UnLock();

	_beginthreadex(NULL, 0, ListenThreadFunc, (void*)machine, 0, NULL);
}

unsigned int __stdcall ListenThreadFunc(void* pArguments)
{
	IP_MREQ imr = { 0 };
	SOCKET s = INVALID_SOCKET;
	struct sockaddr_in agentfrom = { 0 };
	ULONG addr = 0;
	DWORD dwIndex = 0;
	struct sockaddr_in from = { 0 };
	int fromlen = sizeof(from);
	char message[1024] = { 0 };
	char loop = 0;
	char	ttl = 100;
	bool bDrop = false;

	assert(pArguments != NULL);
	if (NULL == pArguments)
	{
		OutputDebugString(_T("pArguments is NULL in ListenThreadFunc()"));
		_endthreadex(0);
		return 0;
	}

	StateMachine* machine = (StateMachine*)pArguments;
	
	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (INVALID_SOCKET == s)
	{
		TCHAR buffer[64];
		_stprintf_s(buffer, 64, _T("socket with error: %d in ListenThreadFunc()"), WSAGetLastError());
		OutputDebugString(buffer);

		LOGW(_T("%s"), buffer);
		goto END;
	}
	
	agentfrom.sin_family = AF_INET;
	machine->Lock();
	agentfrom.sin_port = htons(machine->_Port);
	machine->UnLock();
	agentfrom.sin_addr.s_addr = INADDR_ANY;

	if (bind(s, (SOCKADDR*)&agentfrom, sizeof(agentfrom)) == SOCKET_ERROR)
	{
		TCHAR buffer[64];
		_stprintf_s(buffer, 64, _T("bind failed with error: %d in ListenThreadFunc()"), WSAGetLastError());
		OutputDebugString(buffer);

		LOGW(_T("%s"), buffer);
		goto END ;
	}

	//�ಥ���ݰ�����������
	if (setsockopt(s, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(ttl)) == SOCKET_ERROR)
	{
		TCHAR buffer[64];
		_stprintf_s(buffer, 64, _T("setsockopt(IP_MULTICAST_TTL) failed with error: %d in ListenThreadFunc()"), WSAGetLastError());
		OutputDebugString(buffer);

		LOGW(_T("%s"), buffer);
		goto END;
	}

	// ��ֹ�ಥ����
	if (setsockopt(s, IPPROTO_IP, IP_MULTICAST_LOOP, &loop, sizeof(loop)) == SOCKET_ERROR)
	{
		TCHAR buffer[64];
		_stprintf_s(buffer, 64, _T("setsockopt(IP_MULTICAST_LOOP) failed with error: %d in ListenThreadFunc()"), WSAGetLastError());
		OutputDebugString(buffer);

		LOGW(_T("%s"), buffer);
		goto END;
	}

	//����ಥ��
	InetPton(AF_INET, _T("224.224.224.224"), &addr);;
	imr.imr_multiaddr.s_addr = addr;
	imr.imr_interface.s_addr = INADDR_ANY;
	if (setsockopt(s, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&imr, sizeof(imr)) == SOCKET_ERROR)
	{
		TCHAR buffer[64];
		_stprintf_s(buffer, 64, _T("setsockopt(IP_ADD_MEMBERSHIP) failed with error: %d in ListenThreadFunc()"), WSAGetLastError());
		OutputDebugString(buffer);

		LOGW(_T("%s"), buffer);
		goto END;
	}

	bDrop = true;

	WSAEventSelect(s, machine->_Event[1], FD_READ);

	while (1)
	{
		dwIndex = WSAWaitForMultipleEvents(2, machine->_Event, FALSE, WSA_INFINITE, FALSE);
		if (WSA_WAIT_TIMEOUT == dwIndex)
			continue;

		if (WSA_WAIT_EVENT_0 == dwIndex)
			break;

		WSANETWORKEVENTS NetworkEvents = { 0 };
		WSAEnumNetworkEvents(s, machine->_Event[1], &NetworkEvents);

		if (NetworkEvents.lNetworkEvents & FD_READ)
		{
			if (NetworkEvents.iErrorCode[FD_READ_BIT] != 0) 
			{
				continue;
			}

			if (recvfrom(s, message, 1024, 0, (sockaddr*)&from, &fromlen) == SOCKET_ERROR)
			{
				TCHAR buffer[64];
				_stprintf_s(buffer, 64, _T("recvfrom failed with error: %d in ListenThreadFunc()"), WSAGetLastError());
				OutputDebugString(buffer);

				LOGW(_T("%s"), buffer);
				continue;
			}

			LOGA("%s", message);
		}
	}

END:

	if (s != INVALID_SOCKET)
	{
		if (bDrop)
			setsockopt(s, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char *)&imr, sizeof(imr));
		closesocket(s);
	}		

	WSACloseEvent(machine->_Event[0]);
	WSACloseEvent(machine->_Event[1]);
	machine->_Event[0] = WSA_INVALID_EVENT;
	machine->_Event[1] = WSA_INVALID_EVENT;

	_endthreadex(0);

	return 0;
}

void AgentUdp::OnStop(const StateMachine* machine)
{
	assert(machine != NULL);
	if (machine != NULL)
	{
		if (machine->_Event[0] != INVALID_HANDLE_VALUE)
		{
			WSASetEvent(machine->_Event[0]);
		}
	}
}

