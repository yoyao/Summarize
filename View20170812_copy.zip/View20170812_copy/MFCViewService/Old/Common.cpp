#include "stdafx.h"
#include "Common.h"
#include <Iphlpapi.h>

#if (_WIN32_WINNT >= _WIN32_WINNT_WINBLUE)
#include <VersionHelpers.h>
#endif

#pragma comment(lib, "IPHLPAPI.lib")


Common::Common()
{
}


Common::~Common()
{
}

mystring Common::GetIP(mystring ServerIP)
{
	if (ServerIP.empty())
		return mystring(_T(""));

	unsigned long	userver[4] = { 0 };
	unsigned int		uip[4]		= { 0 };
	unsigned int		umask[4]	= { 0 };

	TCHAR* pEnd = NULL;
	userver[0] = _tcstoul(ServerIP.c_str(), &pEnd, 10);
	userver[1] = _tcstoul(pEnd + 1, &pEnd, 10);
	userver[2] = _tcstoul(pEnd + 1, &pEnd, 10);
	userver[3] = _tcstoul(pEnd + 1, &pEnd, 10);
	
	PIP_ADAPTER_INFO pAdapterInfo = NULL;
	PIP_ADAPTER_INFO pAdapter		 = NULL;
	DWORD dwRetVal = 0;

	ULONG outBufLen = sizeof(IP_ADAPTER_INFO);
	pAdapter = (PIP_ADAPTER_INFO)malloc(outBufLen);

	assert(pAdapter != NULL);

	dwRetVal = GetAdaptersInfo(pAdapter, &outBufLen);
	if (ERROR_BUFFER_OVERFLOW == dwRetVal)
	{
		free(pAdapter);
		pAdapter = (PIP_ADAPTER_INFO)malloc(outBufLen);
		assert(pAdapter != NULL);
	}

	dwRetVal = GetAdaptersInfo(pAdapter, &outBufLen);
	if (NO_ERROR == dwRetVal)
	{
		pAdapterInfo = pAdapter;
		while (pAdapterInfo != NULL)
		{
			sscanf_s(pAdapterInfo->IpAddressList.IpAddress.String, "%d.%d.%d.%d",
				&uip[0], &uip[1], &uip[2], &uip[3]);
			sscanf_s(pAdapterInfo->IpAddressList.IpMask.String, "%d.%d.%d.%d",
				&umask[0], &umask[1], &umask[2], &umask[3]);
			pAdapterInfo = pAdapterInfo->Next;
			if ((0 == uip[0]) || (0 == umask[0]))
				continue;
			if (((uip[0] & umask[0]) == (userver[0] & umask[0])) &&
				((uip[1] & umask[1]) == (userver[1] & umask[1])) &&
				((uip[2] & umask[2]) == (userver[2] & umask[2])) &&
				((uip[3] & umask[3]) == (userver[3] & umask[3])))
				break;
		}
		free(pAdapter);
		pAdapter = NULL;
	}

	TCHAR ip[32] = { 0 };
	_stprintf_s(ip, 32, _T("%d.%d.%d.%d"), uip[0], uip[1], uip[2], uip[3]);
	
	return mystring(ip);
}

mystring Common::GetWindowsVersion()
{
#if (_WIN32_WINNT < _WIN32_WINNT_WINBLUE)

	OSVERSIONINFOEX	os = { 0 };

	os.dwOSVersionInfoSize = sizeof(os);
	GetVersionEx((LPOSVERSIONINFO)&os);

	if ((os.dwMajorVersion == 6) && (os.dwMinorVersion == 1))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			int *p = 0;
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 7(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 7(64-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2008 R2"));
		}
	}
	else if ((os.dwMajorVersion == 6) && (os.dwMinorVersion == 2))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			int *p = 0;
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 8(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 8(64-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2012"));
		}
	}
	else if ((os.dwMajorVersion == 6) && (os.dwMinorVersion == 3))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			int *p = 0;
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 8.1(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 8.1(64-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2012 R2"));
		}
	}
	else if ((os.dwMajorVersion == 10) && (os.dwMinorVersion == 0))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			int *p = 0;
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 10(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 10(64-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2016 Technical Preview"));
		}
	}

	return mystring(_T("Windows Vista or Lower"));
#else
	int* p = 0;
	bool bIsServer = IsWindowsServer();

//#if (_WIN32_WINNT >= _WIN32_WINNT_WIN10)
//	if (IsWindows10OrGreater())
//	{
//		if (bIsServer)
//		{
//			return mystring(_T("Windows Server 2016 Technical Preview)"));
//		}
//		else
//		{
//			return mystring(_T("Windows 10"));
//		}
//	}
//#endif

	if (IsWindows8Point1OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012 R2"));
		}
		else
		{
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 8.1(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 8.1(64-bit)"));
			}
		}
	}
	else if (IsWindows8OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012"));
		}
		else
		{
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 8.1(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 8.1(64-bit)"));
			}
		}
	}
	else if (IsWindows7SP1OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012 R2"));
		}
		else
		{
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 7 SP1(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 7 SP1(64-bit)"));
			}
		}
	}
	else if (IsWindows7OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012"));
		}
		else
		{
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows 7(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows 7(64-bit)"));
			}
		}
	}
	else
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2003"));
		}
		else
		{
			if (sizeof(p) == 4)
			{
				return mystring(_T("Windows XP(32-bit)"));
			}
			else if (sizeof(p) == 8)
			{
				return mystring(_T("Windows XP(64-bit)"));
			}
		}
	}

	//return mystring(_T("Windows Vista or Lower"));
#endif
}

mystring Common::decodeUnicode(mystring dataStr)
{
	int length = dataStr.length();
	TCHAR* pStart = (TCHAR*)malloc(length+1);
	TCHAR* pCopy = pStart;
	wmemcpy_s(pStart, length, dataStr.c_str(), length);
	pStart[length] = 0;
	mystring str1;
	TCHAR temp = 0;
	while (pStart != NULL)
	{
		memcpy_s((char*)temp, sizeof(temp), (char*)pStart + 2, sizeof(temp));
		str1 += temp;
		pStart++;
	}

	free(pCopy);
	pCopy = NULL;

	return str1;
}

mystring Common::encodeUnicode(mystring str)
{
	int length = str.length();
#ifdef UNICODE
	TCHAR*  pUnicode = (TCHAR*)malloc(length);
	wmemcpy_s(pUnicode, length, str.c_str(), length);
	char BigEndian[2] = { 0 };
	char temp = 0;
	for (int i = 0; i < length; ++i)
	{
		memcpy_s(BigEndian, 2, (char*)&pUnicode[i], 2);
		temp = BigEndian[0];
		BigEndian[0] = BigEndian[1];
		BigEndian[1] = temp;
		memcpy_s((char*)&pUnicode[i], 2, BigEndian, 2);
	}

	size_t byteConverted = length * 2 + 1;
	char* bytes = (char*)malloc(byteConverted);
	wcstombs_s(&byteConverted, bytes, byteConverted, pUnicode, length);
	free(pUnicode);
	pUnicode = NULL;
#else
	size_t byteConverted = str.legnth();
	char* bytes = (char*)malloc(byteConverted);
	memcpy_s(bytes, byteConverted, str.c_str(), str.length());
#endif

	TCHAR bitConverter[2] = { 0 };
	mystring str1;
	for (size_t startIndex = 0; startIndex < byteConverted; ++startIndex)
	{
		_stprintf_s(bitConverter, 2, _T("%02X"), bytes[startIndex]);
		if (startIndex % 2 == 0)
		{
			str1 += _T("\\u");
		}
		else
		{
			str1 += bitConverter;
		}
	}
	
	return str1;
}