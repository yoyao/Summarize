#include "stdafx.h"
#include "Listener.h"
#include <process.h>

Listener::Listener()
{
}


Listener::~Listener()
{
}

void Listener::Start()
{
	_beginthreadex(NULL, 0, DataReceive, NULL, 0, NULL);
}

void Listener::Abort()
{
}

unsigned int __stdcall Listener::DataReceive(void* param)
{



	_endthreadex(0);
	return  0;
}
