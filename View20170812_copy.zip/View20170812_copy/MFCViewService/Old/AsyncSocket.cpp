#include "stdafx.h"
#include "AsyncSocket.h"
#include "LOG.h"



void	RegisterSocket(HWND hWnd, UINT msg)
{

}

void UnRegisterSocket()
{

}

LRESULT AsyncSocketProc(WPARAM wParam, LPARAM lParam)
{
	SOCKET s = (SOCKET)wParam;

	if (FD_READ == LOBYTE(lParam))
	{
		struct sockaddr_in from = { 0 };
		int fromlen = sizeof(from);
		TCHAR message[1024] = { 0 };
		if (recvfrom(s, (char*)message, 1024 * sizeof(TCHAR), 0, (sockaddr*)&from, &fromlen) == SOCKET_ERROR)
		{
			TCHAR buffer[64];
			_stprintf_s(buffer, 64, _T("recvfrom failed with error: %d in AsyncSocketProc()"), WSAGetLastError());
		}

		LOGW(_T("%s"), message);
	}

	return 0;
}

