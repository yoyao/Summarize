#include "stdafx.h"
#include "IMessageSender.h"
#include "StateMachine.h"
#include "message.h"
#include "MessageSender.h"
#include "Common.h"
#include "Cassia2.h"

IMessageSender::IMessageSender()
{
}


IMessageSender::~IMessageSender()
{
}

void IMessageSender::SendMessage(MessageBase message)
{
	if (StateMachine::GetDesktopState() != DesktopState::WORKING)
		return;

	m_MessageSender.SendMessage(StateMachine::GetServerIP(), StateMachine::GetServerPort(), message);
}

void  IMessageSender::SendHeartBeat()
{
	if (StateMachine::GetDesktopState() != DesktopState::WORKING)
		return;

	mystring ip = Common::GetIP(StateMachine::GetServerIP());
	mystring string1 = Common::GetWindowsVersion();		//string string1 = Environment.OSVersion.ToString();
	TCHAR computer[128] = { 0 };
	GetEnvironmentVariable(_T("ComputerName"), computer, 128);
	mystring environmentVariable = mystring(computer);
	SYSTEMTIME localtime;
	GetLocalTime(&localtime);
	TCHAR  datetime[32] = { 0 };
	_stprintf_s(datetime, 32, _T("%04d-%02d-%02d %02d:%02d:%02d.%03d"),
	localtime.wYear, localtime.wMonth, localtime.wDay, localtime.wHour, localtime.wMinute, localtime.wSecond, localtime.wMilliseconds);
	mystring UUID = Common::encodeUnicode(StateMachine::GetUUID());
	
	mystring SessionState	= _T("EMPTY");
	mystring ConnectTime = _T("");
	mystring LogonTime		= _T("");

	SessionEventModel sessionEventModel = Cassia2::ShowCurrentSession3();
	if (sessionEventModel._State.compare(_T("Active")) == 0)
	{
		SessionState = _T("IN_USE");
	}
	else if (sessionEventModel._State.compare(_T("Disconnected")) == 0)
	{
		if (sessionEventModel._UserAccount.empty())
			SessionState = _T("DISCONNECT");
	}

	ConnectTime = sessionEventModel._ConnectTime;
	LogonTime = sessionEventModel._LogonTime;

	HeartBeatMessage heartm(UUID, ip, string1, environmentVariable, SessionState, ConnectTime, LogonTime, datetime);
	m_MessageSender.SendMessage(StateMachine::GetServerIP(), StateMachine::GetServerPort(), heartm);
}
