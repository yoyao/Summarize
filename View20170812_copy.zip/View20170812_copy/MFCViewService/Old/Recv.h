#pragma once

class StateMachine;

uintptr_t OnRecv(const StateMachine* machine);