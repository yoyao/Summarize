#include "stdafx.h"
#include "ControlModel.h"
#include "LOG.h"

void ControlReceive(const ControlModel& model)
{
	LOGW(_T("model._TimeStamp=%s\n"), model._TimeStamp.c_str());
	LOGW(_T("model._ServerName=%s\n"), model._ServerName.c_str());
	LOGW(_T("model._SessionID=%s\n"), model._SessionID.c_str());
	LOGW(_T("model._ControlType=%s\n"), model._ControlType.c_str());

	HANDLE hToken;
	BOOL bRet = OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken);
	TOKEN_PRIVILEGES tp;
	LUID luid;
	bRet = LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &luid);
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	bRet = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), NULL, NULL);

	if (_tcscmp(model._ControlType.c_str(), _T("shutdown")) == 0)
	{
		ExitWindowsEx(EWX_SHUTDOWN, 0);
	}
	else if (_tcscmp(model._ControlType.c_str(), _T("restart")) == 0)
	{
		ExitWindowsEx(EWX_REBOOT, 0);
	}
	else if (_tcscmp(model._ControlType.c_str(), _T("logoff")) == 0)
	{
		ExitWindowsEx(EWX_LOGOFF, 0);
	}
	else if (_tcscmp(model._ControlType.c_str(), _T("disconnect")) == 0)
	{
		DWORD SessionId = _tstoi(model._SessionID.c_str());
		WTSDisconnectSession(WTS_CURRENT_SERVER_HANDLE, SessionId, FALSE);
	}
}

void ControlParse(ControlModel& model, const char* message, int length)
{
	int i = 0;
	char* pStart = (char*)message;
	char* pEnd = strchr(pStart, '|');
	wchar_t  buffer[128] = { 0 };
	char temp[128] = { 0 };
	int len = 0;
	size_t ret = 0;
	int total = length;

	while (pEnd != NULL)
	{
		pEnd = strchr(pStart, '|');
		if (pEnd != NULL)
		{
			len = pEnd - pStart;
		}
		else
		{
			len = total;
		}

		total -= len;
		memset(temp, 0, sizeof(temp));
		memcpy_s(temp, sizeof(temp), pStart, len);
		memset(buffer, 0, sizeof(buffer));
		mbstowcs_s(&ret, buffer, 128, temp, 128);

		switch (i)
		{
		case 0:
			model._TimeStamp = mystring(buffer);
			break;
		case 1:
			model._ServerName = mystring(buffer);
			break;
		case 2:
			model._SessionID = mystring(buffer);
			break;
		case 3:
			model._ControlType = mystring(buffer);
			break;
		default:
			break;
		}
		if (i < 3)
		{
			pStart = pEnd + 1;
		}
		else
			break;
		i++;
	}

	LOGW(_T("%s\n"), _T("ControlParse End"));
}