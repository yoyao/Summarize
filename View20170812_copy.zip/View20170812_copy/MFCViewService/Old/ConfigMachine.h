#pragma once
class ConfigMachine
{
public:
	ConfigMachine();
	~ConfigMachine();

	static mystring	GetDir();
	static mystring	GetServerIP();
	static int			GetPort();
	static mystring GetIP();
	static mystring GetUUID();
	static mystring GetGridName();
	static mystring GetInterval();
	static mystring GetAD();
	static mystring GetPreUserName();
	static mystring GetFireWall();
	static mystring GetRestore();
	static mystring GetIsInstalled();
	static void			SetDir(mystring Dir);
	static void			SetServerIP(mystring ServerIP);
	static void			SetPort(mystring Port);
	static void			SetIP(mystring IP);
	static void			SetUUID(mystring UUID);
	static void			SetGridName(mystring GridName);
	static void			SetInterval(mystring Interval);
	static void			SetAD(mystring AD);
	static void			SetPreUserName(mystring PreUserName);
	static void			SetFireWall(mystring FireWall);
	static void			SetRestore(mystring Restore);
	static void			SetIsInstalled(mystring IsInstalled);

private:
	static mystring		_Dir;
	static mystring		_ServerIP;
	static mystring		 _Port;
	static mystring		_IP;
	static mystring		_UUID;
	static mystring		_GridName;
	static mystring		_Interval;
	static mystring		_AD;
	static mystring		_PreUserName;
	static mystring		_FireWall;
	static mystring		_Restore;
	static mystring		_IsInstalled;
};

