#pragma once

#include "MessageSender.h"

enum class MessageType;
class MessageBase;

class IMessageSender
{
public:
	IMessageSender();
	~IMessageSender();

	void SendMessage(MessageBase message);
	void SendHeartBeat();

private:
	MessageSender	m_MessageSender;
};


