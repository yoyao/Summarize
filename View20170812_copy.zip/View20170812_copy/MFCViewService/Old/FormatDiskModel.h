#pragma once

typedef struct tag_FormatDiskModel
{
	mystring	_Disk;
	mystring	_Size;
	mystring	_Letter;

} FormatDiskModel;

void FormatDiskParse(FormatDiskModel& model, const char* message, int length);
void FormatDiskReceive(const FormatDiskModel& model);