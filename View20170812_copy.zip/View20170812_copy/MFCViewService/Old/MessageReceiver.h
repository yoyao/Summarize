#pragma once
class MessageReceiver
{
public:
	MessageReceiver();
	~MessageReceiver();

	void		Start();
	void		Stop();
	void		Receive();

private:
	int				m_nPort;
	std::string		m_BroadcastAddress;
	std::string		m_IP;
	SOCKET		m_Socket;
	WSAEVENT	m_Event[2];
};

