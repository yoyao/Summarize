#include "stdafx.h"
#include "Config.h"

mystring Config::m_BaseDirectory;

Config::Config()
{
	TCHAR	path[MAX_PATH];
	::GetCurrentDirectory(MAX_PATH, path);

	m_BaseDirectory = mystring(path);
}


Config::~Config()
{
}

mystring Config::GetValue(mystring IniName, mystring ValName)
{
	TCHAR retBuf[128] = { 0 };

	mystring sPath = m_BaseDirectory + IniName + mystring(_T(".ini"));
	GetPrivateProfileString(_T("section1"), ValName.c_str(), _T(""), retBuf, 128, (LPCWSTR)sPath.c_str());

	return mystring(retBuf);
}

void Config::UpdateValue(mystring IniName, mystring KeyName, mystring ValName)
{
	mystring sPath = m_BaseDirectory + IniName + mystring(_T(".ini"));
	WritePrivateProfileString(_T("section1"), KeyName.c_str(), ValName.c_str(), (LPCWSTR)sPath.c_str());
}
