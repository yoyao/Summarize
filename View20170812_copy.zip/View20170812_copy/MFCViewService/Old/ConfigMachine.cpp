#include "stdafx.h"
#include "ConfigMachine.h"
#include "Config.h"

mystring		ConfigMachine::_Dir;
mystring		ConfigMachine::_ServerIP;
mystring		 ConfigMachine::_Port;
mystring		ConfigMachine::_IP;
mystring		ConfigMachine::_UUID;
mystring		ConfigMachine::_GridName;
mystring		ConfigMachine::_Interval;
mystring		ConfigMachine::_AD;
mystring		ConfigMachine::_PreUserName;
mystring		ConfigMachine::_FireWall;
mystring		ConfigMachine::_Restore;
mystring		ConfigMachine::_IsInstalled;


ConfigMachine::ConfigMachine()
{
}


ConfigMachine::~ConfigMachine()
{
}

mystring ConfigMachine::GetDir()
{
	if (_Dir.empty())
		_Dir = Config::GetValue(mystring(_T("config")), mystring(_T("_dir")));
	return _Dir;
}

mystring ConfigMachine::GetServerIP()
{
	if (_ServerIP.empty())
		_ServerIP = Config::GetValue( mystring(_T("config")), mystring(_T("_serverip")));
	return _ServerIP;
}

int ConfigMachine::GetPort()
{
	if (_Port.empty())
		_Port = Config::GetValue(mystring(_T("config")), mystring(_T("_port")));
	
	return  _tstol(_Port.c_str());
}

mystring ConfigMachine::GetIP()
{
	if (_IP.empty())
		_IP = Config::GetValue(mystring(_T("config")), mystring(_T("_ip")));
	return _IP;
}

mystring ConfigMachine::GetUUID()
{
	if (_UUID.empty())
		_UUID = Config::GetValue(mystring(_T("config")), mystring(_T("_uuid")));
	return _UUID;
}

mystring ConfigMachine::GetGridName()
{
	if (_GridName.empty())
		_GridName = Config::GetValue(mystring(_T("config")), mystring(_T("_gridname")));
	return _GridName;
}

mystring ConfigMachine::GetInterval()
{
	if (_Interval.empty())
		_Interval = Config::GetValue(mystring(_T("config")), mystring(_T("_interval")));
	if (_Interval.empty())
		_Interval = mystring(_T("50000"));
	return _Interval;
}

mystring ConfigMachine::GetAD()
{
	if (_AD.empty())
		_AD = Config::GetValue(mystring(_T("config")), mystring(_T("_ad")));
	return _AD;
}

mystring ConfigMachine::GetPreUserName()
{
	if (_PreUserName.empty())
		_PreUserName = Config::GetValue(mystring(_T("config")), mystring(_T("_preusername")));
	return _PreUserName;
}

mystring ConfigMachine::GetFireWall()
{
	if (_FireWall.empty())
		_FireWall = Config::GetValue(mystring(_T("config")), mystring(_T("_firewall")));
	return _FireWall;
}

mystring ConfigMachine::GetRestore()
{
	if (_Restore.empty())
		_Restore = Config::GetValue(mystring(_T("config")), mystring(_T("_restore")));
	return _Restore;
}

mystring ConfigMachine::GetIsInstalled()
{
	if (_IsInstalled.empty())
		_IsInstalled = Config::GetValue(mystring(_T("config")), mystring(_T("_isinstalled")));
	return _IsInstalled;
}

void ConfigMachine::SetDir(mystring Dir)
{
	_Dir = Dir;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_dir")), Dir);
}

void ConfigMachine::SetServerIP(mystring ServerIP)
{
	_ServerIP = ServerIP;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_serverip")), ServerIP);
}

void ConfigMachine::SetPort(mystring Port)
{
	_Port = Port;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_port")), Port);
}

void ConfigMachine::SetIP(mystring IP)
{
	_IP = IP;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_ip")), IP);
}

void ConfigMachine::SetUUID(mystring UUID)
{
	_UUID = UUID;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_uuid")), UUID);
}

void ConfigMachine::SetGridName(mystring GridName)
{
	_GridName = GridName;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_gridname")), GridName);
}

void ConfigMachine::SetInterval(mystring Interval)
{
	_Interval = Interval;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_interval")), Interval);
}

void ConfigMachine::SetAD(mystring AD)
{
	_AD = AD;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_ad")), AD);
}

void ConfigMachine::SetPreUserName(mystring PreUserName)
{
	_PreUserName = PreUserName;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_preusername")), PreUserName);
}

void ConfigMachine::SetFireWall(mystring FireWall)
{
	_FireWall = FireWall;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_firewall")), FireWall);
}

void ConfigMachine::SetRestore(mystring Restore)
{
	_Restore = Restore;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_restore")), Restore);
}

void ConfigMachine::SetIsInstalled(mystring IsInstalled)
{
	_IsInstalled = IsInstalled;
	Config::UpdateValue(mystring(_T("config")), mystring(_T("_isinstalled")), IsInstalled);
}
