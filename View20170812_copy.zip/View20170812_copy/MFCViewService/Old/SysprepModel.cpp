#include "stdafx.h"
#include "SysprepModel.h"
#include <fstream>
#include "StateMachine.h"
#include "LOG.h"

void SysprepReceive(const SysprepModel& model)
{
	LOGW(_T("model._ComputerName=%s\n"), model._ComputerName.c_str());
	LOGW(_T("model._DomainAdmin=%s\n"), model._DomainAdmin.c_str());
	LOGW(_T("model._DomainAdminPassword=%s\n"), model._DomainAdminPassword.c_str());
	LOGW(_T("model._FullName=%s\n"), model._FullName.c_str());
	LOGW(_T("model._JoinDomain=%s\n"), model._JoinDomain.c_str());
	LOGW(_T("model._LanguageGroup=%s\n"), model._LanguageGroup.c_str());
	LOGW(_T("model._OrgName=%s\n"), model._OrgName.c_str());
	LOGW(_T("model._Password=%s\n"), model._Password.c_str());
	LOGW(_T("model._PrePassword=%s\n"), model._PrePassword.c_str());
	LOGW(_T("model._PreUserName=%s\n"), model._PreUserName.c_str());
	LOGW(_T("model._ProductKey=%s\n"), model._ProductKey.c_str());
	LOGW(_T("model._ServerIP=%s\n"), model._ServerIP.c_str());
	LOGW(_T("model._TimeZone=%s\n"), model._TimeZone.c_str());

	TCHAR path[MAX_PATH] = { 0 };
	::GetModuleFileName(NULL, path, MAX_PATH);
	int i = 0;
	TCHAR *pFind = _tcsrchr(path, L'\\');
	while (pFind[++i] != 0)
	{
		pFind[i] = 0;
	}

	TCHAR InfName[MAX_PATH] = { 0 };
	_tcscpy_s(InfName, MAX_PATH, path);
	_tcscat_s(InfName, MAX_PATH, _T("sysprep_win7_64_2.inf"));

	std::wifstream	infile(InfName);
	if (infile.is_open())
	{
		mystring str1, str2;
		TCHAR temp[512];

		while (!(infile.eof()))
		{
			infile.getline(temp, 512);
			str2 = mystring(temp);
			LOGW(_T("str2 = %s\n"), temp);
			str1 += str2;
		}

		if (model._JoinDomain.empty())
		{
			str1.replace(mystring(_T("{ProductKey}")).begin(), mystring(_T("{ProductKey}")).end(), model._ProductKey);
			str1.replace(mystring(_T("{FullName}")).begin(), mystring(_T("{FullName}")).end(), model._FullName);
			str1.replace(mystring(_T("{OrgName}")).begin(), mystring(_T("{OrgName}")).end(), model._OrgName);
			str1.replace(mystring(_T("ComputerName")).begin(), mystring(_T("{ComputerName}")).end(), model._ComputerName);
			str1.replace(mystring(_T("{PreUserName}")).begin(), mystring(_T("{PreUserName}")).end(), model._PreUserName);
			str1.replace(mystring(_T("{PrePassword}")).begin(), mystring(_T("{PrePassword}")).end(), model._PrePassword);

			StateMachine::SetPreUserName(model._PreUserName);
		}
		else
		{
			str1.replace(mystring(_T("{ProductKey}")).begin(), mystring(_T("{ProductKey}")).end(), model._ProductKey);
			str1.replace(mystring(_T("{FullName}")).begin(), mystring(_T("{FullName}")).end(), model._FullName);
			str1.replace(mystring(_T("{OrgName}")).begin(), mystring(_T("{OrgName}")).end(), model._OrgName);
			str1.replace(mystring(_T("{ComputerName}")).begin(), mystring(_T("{ComputerName}")).end(), model._ComputerName);
			str2 = model._JoinDomain + _T(".COM");
			str1.replace(mystring(_T("{JoinDomain}")).begin(), mystring(_T("{JoinDomain}")).end(), str2);
			str1.replace(mystring(_T("{DomainAdmin}")).begin(), mystring(_T("{DomainAdmin}")).end(), model._DomainAdmin);
			str1.replace(mystring(_T("{DomainAdminPassword}")).begin(), mystring(_T("{DomainAdminPassword}")).end(), model._DomainAdminPassword);
		}
		infile.close();

		std::wofstream outFile(_T("C:\\Windows\\system32\\sysprep\\sysprep.xml"));
		if (outFile.is_open())
		{
			outFile.write(str1.c_str(), str1.size());
			outFile.close();
		}
		StateMachine::SetServerIP(model._ServerIP);

		memset(InfName, 0, sizeof(InfName));
		_tcscpy_s(InfName, MAX_PATH, path);
		_tcscat_s(InfName, MAX_PATH, _T("sysprep_win7.bat"));
		::CreateProcess(InfName, NULL, NULL, NULL, FALSE, 0, NULL, NULL, NULL, NULL);
	}
}


void SysprepParse(SysprepModel& model, const char* message, int length)
{
	//View | 210 | 762RK - C976M - YGT26 - C6JP6 - VXTW8 | View User | View | *| , 9, 10, || || admin | abc123
	int i = 0;
	char* pStart = (char*)message;
	char* pEnd = strchr(pStart, '|');
	wchar_t  buffer[128] = { 0 };
	char temp[128] = { 0 };
	int len = 0;
	size_t ret = 0;
	int total = length;
	while (pEnd != NULL)
	{
		pEnd = strchr(pStart, '|');
		if (pEnd != NULL)
		{
			len = pEnd - pStart;
		}
		else
		{
			len = total;
		}
		
		total -= len;
		memset(temp, 0, sizeof(temp));
		memcpy(temp, pStart, len);
		memset(buffer, 0, sizeof(buffer));
		mbstowcs_s(&ret, buffer, 128, temp, 128);
		
		switch (i)
		{
		case 0:
			model._Password = mystring(buffer);
			//LOGW(_T("_Password = %s\n"), model._Password.c_str());
			break;
		case 1:
			model._TimeZone = mystring(buffer);
			//LOGW(_T("_TimeZone = %s\n"), model._TimeZone.c_str());
			break;
		case 2:
			model._ProductKey = mystring(buffer);
			//LOGW(_T("_ProductKey = %s\n"), model._ProductKey.c_str());
			break;
		case 3:
			model._FullName = mystring(buffer);
			//LOGW(_T("_FullName = %s\n"), model._FullName.c_str());
			break;
		case 4:
			model._OrgName = mystring(buffer);
			//LOGW(_T("_OrgName = %s\n"), model._OrgName.c_str());
			break;
		case 5:
			model._ComputerName = mystring(buffer);
			//LOGW(_T("_ComputerName = %s\n"), model._ComputerName.c_str());
			break;
		case 6:
			model._LanguageGroup = mystring(buffer);
			//LOGW(_T("_LanguageGroup = %s\n"), model._LanguageGroup.c_str());
			break;
		case 7:
			model._JoinDomain = mystring(buffer);
			//LOGW(_T("_JoinDomain = %s\n"), model._JoinDomain.c_str());
			break;
		case 8:
			model._DomainAdmin = mystring(buffer);
			//LOGW(_T("_DomainAdmin = %s\n"), model._DomainAdmin.c_str());
			break;
		case 9:
			model._DomainAdminPassword = mystring(buffer);
			//LOGW(_T("_DomainAdminPassword = %s\n"), model._DomainAdminPassword.c_str());
			break;
		case 10:
			model._PreUserName = mystring(buffer);
			//LOGW(_T("_PreUserName = %s\n"), model._PreUserName.c_str());
			break;
		case 11:
			model._PrePassword = mystring(buffer);
			//LOGW(_T("_PrePassword = %s\n"), model._PrePassword.c_str());
			break;
		default:
			break;
		}
		if (i < 11)
		{
			pStart = pEnd + 1;
		}
		else
			break;
		i++;	
	}
	LOGW(_T("%s\n"), _T("SysprepParse End"));
}