#pragma once

typedef  struct _TIMESPAN
{
	LARGE_INTEGER	t0;
	LARGE_INTEGER	t1;
	LARGE_INTEGER	t;
} TIMESPAN;

typedef struct _ISESSION_INFO
{
	int			ClientBuildNumber;
	int			SessionId;
	WTS_CONNECTSTATE_CLASS  ConnectionState;
	mystring	ClientIPAddress;
	mystring	ClientName;
	mystring	DomainName;
	mystring	UserName;
	mystring	WindowStationName;
	LARGE_INTEGER  ConnectTime;
	LARGE_INTEGER	CurrentTime;
	LARGE_INTEGER	DisconnectTime;
	LARGE_INTEGER	LastInputTime;
	LARGE_INTEGER	LoginTime;
	TIMESPAN			IdleTime;
} ISESSION_INFO, *PISESSION_INFO;

class ITerminalServiceSession
{
public:
	ITerminalServiceSession();
	~ITerminalServiceSession();
	
	std::list<ISESSION_INFO>	m_listSession;

	bool Init();
	void Disconnect();
	void Disconnect(bool synchronous);
	void Logoff();
	void Logoff(bool synchronous);
};
