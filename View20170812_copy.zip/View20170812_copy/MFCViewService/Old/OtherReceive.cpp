#include "stdafx.h"
#include "OtherReceive.h"
#include "StateMachine.h"
#include "LOG.h"

void SyncDateTimeReceive(const SyncModel& model)
{
	LOGW(_T("SyncDateTimeReceive: datetime = %s\n"), model._DateTime.c_str());

	SYSTEMTIME st = { 0 };

	SetLocalTime(&st);
}

void RestoreReceive(const RestoreModel& model)
{
	TCHAR path[MAX_PATH] = { 0 };
	::GetModuleFileName(NULL, path, MAX_PATH);
	int i = 0;
	TCHAR *pFind = _tcsrchr(path, _T('\\'));
	while (pFind[++i] != 0)
	{
		pFind[i] = 0;
	}

	if (model._Start)
	{
		StateMachine::SetRestore(mystring(_T("true")));
		_tcscat_s(path, MAX_PATH, _T("restoreStart.bat"));
		assert(CreateProcess(path, NULL, NULL, NULL, FALSE, 0, NULL, NULL, NULL, NULL));
	}
	else
	{
		StateMachine::SetRestore(mystring(_T("false")));
		_tcscat_s(path, MAX_PATH, _T("restoreEnd.bat"));
		assert(CreateProcess(path, NULL, NULL, NULL, FALSE, 0, NULL, NULL, NULL, NULL));
	}
}

void ShareReceive(const ShareModel& model)
{
	LOGW(_T("ShareReceive: serverIP=%s, userID=%s\n"), model._ServerIP.c_str(), model._UserID.c_str());

	TCHAR path[MAX_PATH] = { 0 };
	GetModuleFileName(NULL, path, MAX_PATH);

	TCHAR* pFind = _tcsrchr(path, _T('\\'));
	int i = 0;
	while (pFind[i++] != 0)
	{
		pFind[i] = 0;
	}

	mystring batFile = mystring(path) + model._UserID + _T(".bat");
	WIN32_FIND_DATA FindData = { 0 };
	if (FindFirstFile(batFile.c_str(), &FindData))
	{
		DeleteFile(batFile.c_str());
	}

	std::wofstream out(batFile.c_str());
	if (out.is_open())
	{
		mystring str = _T("@echo off\r\nECHO Y|net use * /del >NUL\r\nnet use h: \\\\") +	\
								model._ServerIP + _T("\\share$\\") + model._UserID +	\
								_T(" \"user\" /user:user123 >NUL\r\nexit\r\n@echo on");

		out.write(str.c_str(), str.length());
		out.close();
	}
}

void SyncDateTimeParse(SyncModel& model, const char* message, int length)
{
	wchar_t  buffer[128] = { 0 };
	char temp[128] = { 0 };
	size_t ret = 0;

	assert(length < sizeof(temp));

	memset(temp, 0, sizeof(temp));
	memcpy_s(temp, sizeof(temp), message, length);
	memset(buffer, 0, sizeof(buffer));
	mbstowcs_s(&ret, buffer, 128, temp, 128);

	model._DateTime = mystring(buffer);
}

void RestoreParse(RestoreModel& model, const char* message, int length)
{
	if (strcmp(message, "true") == 0)
	{
		model._Start = true;
	}
	else
		model._Start = false;
}

void ShareParse(ShareModel& model, const char* message, int length)
{
	int i = 0;
	char* pStart = (char*)message;
	char* pEnd = strchr(pStart, '|');
	wchar_t  buffer[128] = { 0 };
	char temp[128] = { 0 };
	int len = 0;
	size_t ret = 0;
	int total = length;

	while (pEnd != NULL)
	{
		pEnd = strchr(pStart, '|');
		if (pEnd != NULL)
		{
			len = pEnd - pStart;
		}
		else
		{
			len = total;
		}

		total -= len;
		memset(temp, 0, sizeof(temp));
		memcpy_s(temp, sizeof(temp), pStart, len);
		memset(buffer, 0, sizeof(buffer));
		mbstowcs_s(&ret, buffer, 128, temp, 128);

		switch (i)
		{
		case 0:
			model._ServerIP = mystring(buffer);
			break;
		case 1:
			model._UserID = mystring(buffer);
			break;
		default:
			break;
		}
		if (i < 1)
		{
			pStart = pEnd + 1;
		}
		else
			break;
		i++;
	}

	LOGW(_T("%s\n"), _T("ShareParse End"));

}