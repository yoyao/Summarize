#include "stdafx.h"
#include "DomainModel.h"
#include "LOG.h"

void DomainComputerName(const DomainModel& model)
{
	mystring newName = model._NewComputerName;
	//HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\ComputerName\ActiveComputerName
	HKEY hKey;
	LONG lRet = ERROR_SUCCESS;

	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\CurrentControlSet\\Control\\ComputerName"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	HKEY hSubKey;
	lRet = RegOpenKeyEx(hKey, _T("ActiveComputerName"), 0, KEY_WRITE, &hSubKey);
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hSubKey, _T("ComputerName"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hSubKey);
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hSubKey);

	lRet = RegOpenKeyEx(hKey, _T("ComputerName"), 0, KEY_WRITE, &hSubKey);
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hSubKey, _T("ComputerName"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hSubKey);
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hSubKey);
	RegCloseKey(hKey);


	//HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Tcpip\Parameters
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\CurrentControlSet\\Services\\Tcpip\\Parameters"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("Hostname"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hKey, _T("NV Hostname"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_CURRENT_USER\Volatile Environment
	lRet = RegOpenKeyEx(HKEY_CURRENT_USER, _T("Volatile Environment"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("USERDOMAIN"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	mystring str(_T("\\\\"));
	str += newName;
	lRet = RegSetValueEx(hKey, _T("LOGONSERVER"), 0, REG_SZ, (BYTE*)(str.c_str()), (str.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Reliability
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Reliability"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("LastComputerName"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\System\ControlSet002\Control\ComputerName\ComputerName
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\ControlSet002\\Control\\ComputerName\\ComputerName"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("ComputerName"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\System\ControlSet002\Services\Tcpip\Parameters
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\ControlSet002\\Services\\Tcpip\\Parameters"), 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueEx(hKey, _T("Hostname"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueEx(hKey, _T("NV Hostname"), 0, REG_SZ, (BYTE*)(newName.c_str()), (newName.length() + 1)*sizeof(TCHAR));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	HANDLE hToken;
	BOOL bRet = OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken);
	TOKEN_PRIVILEGES tp;
	LUID luid;
	bRet = LookupPrivilegeValue(NULL, _T("SeShutdownPrivilege"), &luid);
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	bRet = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), NULL, NULL);

	InitiateSystemShutdown(NULL, NULL, 0, TRUE, TRUE);
}

void DomainDns(const DomainModel& model)
{
	mystring DnsIP = model._DnsIP;
	HKEY hKey;
	LONG lRet = ERROR_SUCCESS;
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("System\\CurrentControlSet\\Control\\Class\\{4D36E972-E325-11CE-BFC1-08002BE10318}"), 0, KEY_READ, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	DWORD dwIndex = 0;
	TCHAR szSubKey[256] = { 0 };
	TCHAR szData[256] = { 0 };
	TCHAR szAapterName[256] = { 0 };
	DWORD dwBufSize = 256;
	HKEY hSubKey;
	HKEY hNdiIntKey;
	while (RegEnumKeyEx(hKey, dwIndex++, szSubKey, &dwBufSize, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
	{
		if (RegOpenKeyEx(hKey, szSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS)
		{

			if (RegOpenKeyEx(hSubKey, _T("Ndi\\Interfaces"), 0, KEY_READ, &hNdiIntKey) == ERROR_SUCCESS)
			{
				dwBufSize = 256 * sizeof(TCHAR);
				if (RegQueryValueEx(hNdiIntKey, _T("LowerRange"), 0, NULL, (BYTE*)szData, &dwBufSize) == ERROR_SUCCESS)
				{
					if (_tcscmp(szData, _T("ethernet")) == 0)
					{
						dwBufSize = 256 * sizeof(TCHAR);
						if (RegQueryValueEx(hSubKey, _T("NetCfgInstanceID"), 0, NULL, (BYTE*)szData, &dwBufSize) == ERROR_SUCCESS)
						{
							//szData�б�������������   
							_tcscpy_s(szAapterName, 256, szData);
							RegCloseKey(hNdiIntKey);
							RegCloseKey(hSubKey);
							break;
						}
					}
				}
				RegCloseKey(hNdiIntKey);
			}
			RegCloseKey(hSubKey);
		}
		dwBufSize = 256;
	}

	RegCloseKey(hKey);

	_tcscpy_s(szSubKey, 256, _T("SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\"));
	_tcscat_s(szSubKey, 256, szAapterName);
	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, szSubKey, 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	RegSetValueEx(hKey, _T("NameServer"), 0, REG_SZ, (BYTE*)(DnsIP.c_str()), (DnsIP.length() + 1)*sizeof(TCHAR));

	RegCloseKey(hKey);
}

void DomainJoin(const DomainModel& model)
{
	NET_API_STATUS status = NERR_Success;
	
	mystring strDomain = model._Domain;
	mystring strAccountOU = model._AccountOU;
	mystring strAccount = model._DomainAdmin;
	mystring strPassword = model._DomainAdminPassword;
	DWORD JoinOptions = NETSETUP_JOIN_DOMAIN | NETSETUP_ACCT_CREATE;

	status = NetJoinDomain(NULL, strDomain.c_str(), strAccountOU.c_str(), strAccount.c_str(), strPassword.c_str(), JoinOptions);
}

void DomainUnjoin(const DomainModel& model)
{
	NET_API_STATUS status = NERR_Success;

	mystring strAccount = model._DomainAdmin;
	mystring strPassword = model._DomainAdminPassword;
	status = NetUnjoinDomain(NULL, strAccount.c_str(), strPassword.c_str(), NETSETUP_ACCT_DELETE);
}

void DomainRemoteUsers(const DomainModel& model)
{
	NET_API_STATUS status = NERR_Success;

	mystring PreUserName = model._PreUserName;

	LOCALGROUP_MEMBERS_INFO_3 pmem3 = { 0 };
	DWORD dwSize =PreUserName.length() + 1;

	pmem3.lgrmi3_domainandname = new TCHAR[dwSize];
	_tcscpy_s(pmem3.lgrmi3_domainandname, dwSize, PreUserName.c_str());

	dwSize = 1;
	status = NetLocalGroupSetMembers(NULL, _T("Remote Desktop Users"), 3, (BYTE*)&pmem3, dwSize);
}