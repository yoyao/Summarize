#pragma once

LRESULT SessionProc(HWND hWnd, WPARAM wParam, LPARAM lParam);


