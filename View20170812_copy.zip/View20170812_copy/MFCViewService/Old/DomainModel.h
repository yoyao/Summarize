#pragma once

typedef struct tag_DomainModel
{
	mystring	_NewComputerName;
	mystring	_DnsIP;
	mystring  _Domain;
	mystring	_AccountOU;
	mystring	_DomainAdmin;
	mystring	_DomainAdminPassword;
	mystring	_PreUserName;
	mystring	_PrePassword;

} DomainModel;


void DomainComputerName(const DomainModel& model);
void DomainDns(const DomainModel& model);
void DomainJoin(const DomainModel& model);
void DomainUnjoin(const DomainModel& model);
void DomainRemoteUsers(const DomainModel& model);