#pragma once
class Config
{
public:
	Config();
	~Config();

	static mystring GetValue(mystring IniName, mystring ValName);
	static void			UpdateValue(mystring IniName, mystring KeyName, mystring ValName);

private:
	static mystring	m_BaseDirectory;
};
