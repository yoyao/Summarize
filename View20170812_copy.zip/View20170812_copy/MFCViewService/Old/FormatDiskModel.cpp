#include "stdafx.h"
#include "FormatDiskModel.h"
#include "LOG.h"

void FormatDiskReceive(const FormatDiskModel& model)
{
	LOGW(_T("model._Disk = %s\n"), model._Disk.c_str());
	LOGW(_T("model._Letter = %s\n"), model._Letter.c_str());
	LOGW(_T("model._Size = %s\n"), model._Size.c_str());

	TCHAR path[MAX_PATH] = { 0 };
	GetModuleFileName(NULL, path, MAX_PATH);

	TCHAR* pFind = _tcschr(path, _T('\\'));
	int i = 0;
	while (pFind[i++] != 0)
	{
		pFind[i] = 0;
	}

	mystring batFile = mystring(path) + model._Letter + _T(".bat");
	mystring txtFile = mystring(path) + model._Letter + _T(".txt");

	WIN32_FIND_DATA	FindData = { 0 };
	if (FindFirstFile(batFile.c_str(), &FindData))
	{
		DeleteFile(batFile.c_str());
	}

	memset(&FindData, 0, sizeof(FindData));
	if (FindFirstFile(txtFile.c_str(), &FindData))
	{
		DeleteFile(txtFile.c_str());
	}

	std::wofstream batout(batFile.c_str());
	if (batout.is_open())
	{
		mystring str = _T("diskpart /s ") + model._Letter + _T(".txt\r\necho y | format ") + model._Letter + _T(":/fs:ntfs /q");
		batout.write(str.c_str(), str.length());
		batout.close();
	}

	std::wofstream txtout(txtFile.c_str());
	if (txtout.is_open())
	{
		mystring str = _T("select disk ") + model._Disk + _T("\r\ncreate partition primary size=") + model._Size + _T("\r\nassign letter=") + model._Letter + _T("\r\nactive\r\nexit");
		txtout.write(str.c_str(), str.length());
		txtout.close();
	}

	CreateProcess(batFile.c_str(), NULL, NULL, NULL, FALSE, 0, NULL, NULL, NULL, NULL);	
}

void FormatDiskParse(FormatDiskModel& model, const char* message, int length)
{
	int i = 0;
	char* pStart = (char*)message;
	char* pEnd = strchr(pStart, '|');
	wchar_t  buffer[128] = { 0 };
	char temp[128] = { 0 };
	int len = 0;
	size_t ret = 0;
	int total = length;

	while (pEnd != NULL)
	{
		pEnd = strchr(pStart, '|');
		if (pEnd != NULL)
		{
			len = pEnd - pStart;
		}
		else
		{
			len = total;
		}

		total -= len;
		memset(temp, 0, sizeof(temp));
		memcpy_s(temp, sizeof(temp), pStart, len);
		memset(buffer, 0, sizeof(buffer));
		mbstowcs_s(&ret, buffer, 128, temp, 128);

		switch (i)
		{
		case 0:
			model._Disk = mystring(buffer);
			break;
		case 1:
			model._Size = mystring(buffer);
			break;
		case 2:
			model._Letter = mystring(buffer);
			break;
		default:
			break;
		}
		if (i < 2)
		{
			pStart = pEnd + 1;
		}
		else
			break;
		i++;
	}

	LOGW(_T("%s\n"), _T("FormatDiskParse End"));
}