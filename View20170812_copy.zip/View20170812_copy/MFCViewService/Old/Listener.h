#pragma once
class Listener
{
public:
	Listener();
	~Listener();

	void Start();
	void Abort();

	static unsigned int  __stdcall DataReceive(void* param);
};

