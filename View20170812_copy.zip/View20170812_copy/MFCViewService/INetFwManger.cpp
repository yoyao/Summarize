#include "stdafx.h"
#include "INetFwManger.h"
#include <Netfw.h>
#include <comdef.h>
#include <atlbase.h>

INetFwManger::INetFwManger()
{	
}

INetFwManger::~INetFwManger()
{
}

void INetFwManger::NetFwAddPorts(mystring name, int port, mystring protocol)
{
	HRESULT hr = NULL;
	hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	if (SUCCEEDED(hr))
	{
		INetFwMgr* pFwMgr = NULL;
		hr = CoCreateInstance(CLSID_NetFwMgr, NULL, CLSCTX_INPROC_SERVER, IID_INetFwMgr, (void**)&pFwMgr);
		if (SUCCEEDED(hr))
		{
			INetFwOpenPort* pFwOpenPort = NULL;
			hr = CoCreateInstance(CLSID_NetFwOpenPort, NULL, CLSCTX_INPROC_SERVER, IID_INetFwOpenPort, (void**)&pFwOpenPort);
			if (SUCCEEDED(hr))
			{
				BSTR bsrName = ::SysAllocString(name.c_str());
				pFwOpenPort->put_Name(bsrName);
				::SysFreeString(bsrName);

				pFwOpenPort->put_Port(port);
				
				NET_FW_IP_PROTOCOL_ ipprotocol;
				std::transform(protocol.begin(), protocol.end(), protocol.begin(), toupper);
				if (protocol.compare(_T("TCP")) == 0)
				{
					ipprotocol = NET_FW_IP_PROTOCOL_TCP;
				}
				else
				{
					ipprotocol = NET_FW_IP_PROTOCOL_UDP;
				}
				pFwOpenPort->put_Protocol(ipprotocol);
				pFwOpenPort->put_Scope(NET_FW_SCOPE_ALL);
				pFwOpenPort->put_Enabled(VARIANT_TRUE);

				bool bAdd = false;
				INetFwPolicy *pFwPolicy = NULL;
				hr = pFwMgr->get_LocalPolicy(&pFwPolicy);
				if (SUCCEEDED(hr))
				{
					INetFwProfile* pFwProfile = NULL;
					hr = pFwPolicy->get_CurrentProfile(&pFwProfile);
					if (SUCCEEDED(hr))
					{
						INetFwOpenPorts *pFwOpenPorts = NULL;
						hr = pFwProfile->get_GloballyOpenPorts(&pFwOpenPorts);
						if (SUCCEEDED(hr))
						{
							long count = 0;
							pFwOpenPorts->get_Count(&count);
							for (long i = 0; i < count; i++)
							{
								INetFwOpenPort* pNewOpenPort = NULL;
								hr = pFwOpenPorts->get__NewEnum((IUnknown**)&pNewOpenPort);
								if (SUCCEEDED(hr))
								{
									BSTR bsrNewName = ::SysAllocString(L"");
									hr = pNewOpenPort->get_Name(&bsrNewName);
									if (SUCCEEDED(hr))
									{
										_bstr_t bstr(bsrNewName);
										mystring newstring(bstr);
										if (newstring.compare(name) == 0)
										{
											bAdd = true;
											::SysFreeString(bsrNewName);
											pNewOpenPort->Release();
											break;
										}
									}
									::SysFreeString(bsrNewName);
									pNewOpenPort->Release();
								}
							}

							if (bAdd)
								pFwOpenPorts->Add(pFwOpenPort);
							pFwOpenPorts->Release();
						}					
						pFwProfile->Release();
					}
					pFwPolicy->Release();
				}
				pFwOpenPort->Release();
			}
			pFwMgr->Release();
		}
		CoUninitialize();
	}
}

void INetFwManger::NetFwAddApps(mystring name, mystring executablePath)
{
	HRESULT hr = NULL;
	hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	if (SUCCEEDED(hr))
	{
		INetFwMgr* pFwMgr = NULL;
		hr = CoCreateInstance(CLSID_NetFwMgr, NULL, CLSCTX_INPROC_SERVER, IID_INetFwMgr, (void**)&pFwMgr);
		if (SUCCEEDED(hr))
		{
			INetFwPolicy* pFwPolicy = NULL;
			hr = pFwMgr->get_LocalPolicy(&pFwPolicy);
			if (SUCCEEDED(hr))
			{
				INetFwProfile* pFwProfile = NULL;
				hr = pFwPolicy->get_CurrentProfile(&pFwProfile);
				if (SUCCEEDED(hr))
				{
					INetFwAuthorizedApplications* pFwApplications = NULL;
					hr = pFwProfile->get_AuthorizedApplications(&pFwApplications);
					if (SUCCEEDED(hr))
					{
						long count = 0;
						hr = pFwApplications->get_Count(&count);
						IEnumVARIANT *pEnum = NULL;
						hr = pFwApplications->get__NewEnum((IUnknown**)&pEnum);
						if (SUCCEEDED(hr))
						{
							VARIANT varCurrPosi;
							VariantInit(&varCurrPosi);
							int nGet;
							for (int i = 0; i < count; ++i)
							{
								hr = pEnum->Next(1, (VARIANT *)&varCurrPosi, (ULONG*)&nGet);
								if (SUCCEEDED(hr))
								{
									IDispatch *pDisp = V_DISPATCH(&varCurrPosi);
									INetFwAuthorizedApplication *app = NULL;
									hr = pDisp->QueryInterface(IID_INetFwAuthorizedApplication, (void**)&app);
									if (SUCCEEDED(hr))
									{
										BSTR appName;
										BSTR appPath;
										app->get_Name(&appName);
										app->get_ProcessImageFileName(&appPath);

										SysFreeString(appName);
										SysFreeString(appPath);
										app->Release();
										app = NULL;
									}
								}
							}
							pEnum->Release();
						}
						pFwApplications->Release();
					}
					pFwProfile->Release();
				}
				pFwPolicy->Release();
			}
			pFwMgr->Release();
		}
		CoUninitialize();
	}
}

/*
void INetFwManger::NetFwAddApps1(mystring name, mystring executablePath)
{
	INetFwMgr netFwMgr = (INetFwMgr)Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"));
	INetFwAuthorizedApplication app = (INetFwAuthorizedApplication)Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwAuthorizedApplication"));
	app.Name = name;
	app.ProcessImageFileName = executablePath;
	app.Enabled = true;
	netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
	bool flag = false;
	foreach(INetFwAuthorizedApplication authorizedApplication in netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications)
	{
		if (app.Name == authorizedApplication.Name)
		{
			flag = true;
			break;
		}
	}
	if (flag)
		return;
	netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
}

void INetFwManger::NetFwAddApps2(mystring name, mystring executablePath)
{
	INetFwMgr netFwMgr = (INetFwMgr)Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwMgr"));
	INetFwAuthorizedApplication app = (INetFwAuthorizedApplication)Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwAuthorizedApplication"));
	app.Name = name;
	app.ProcessImageFileName = executablePath;
	app.Enabled = true;
	netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
	bool flag = false;
	foreach(INetFwAuthorizedApplication authorizedApplication in netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications)
	{
		if (app.Name == authorizedApplication.Name)
		{
			flag = true;
			break;
		}
	}
	if (flag)
		return;
	netFwMgr.LocalPolicy.CurrentProfile.AuthorizedApplications.Add(app);
}
*/

void INetFwManger::NetFwDelApps(int port, mystring protocol)
{
	HRESULT hr = NULL;
	hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	if (SUCCEEDED(hr))
	{
		INetFwMgr* pFwMgr = NULL;
		hr = CoCreateInstance(CLSID_NetFwMgr, NULL, CLSCTX_INPROC_SERVER, IID_INetFwMgr, (void**)&pFwMgr);
		if (SUCCEEDED(hr))
		{
				INetFwPolicy *pFwPolicy = NULL;
				hr = pFwMgr->get_LocalPolicy(&pFwPolicy);
				if (SUCCEEDED(hr))
				{
					INetFwProfile* pFwProfile = NULL;
					hr = pFwPolicy->get_CurrentProfile(&pFwProfile);
					if (SUCCEEDED(hr))
					{
						INetFwOpenPorts *pFwOpenPorts = NULL;
						hr = pFwProfile->get_GloballyOpenPorts(&pFwOpenPorts);
						if (SUCCEEDED(hr))
						{
							std::transform(protocol.begin(), protocol.end(), protocol.begin(), toupper);
							if (protocol.compare(_T("TCP")) == 0)
							{
								pFwOpenPorts->Remove(port, NET_FW_IP_PROTOCOL_TCP);
							}
							else
							{
								pFwOpenPorts->Remove(port, NET_FW_IP_PROTOCOL_UDP);
							}
							pFwOpenPorts->Release();
						}
						pFwPolicy->Release();
					}
					pFwProfile->Release();
				}
				pFwMgr->Release();
		}

		CoUninitialize();
	}
}

void INetFwManger::NetFwDelApps(mystring executablePath)
{
	HRESULT hr = NULL;
	hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	if (SUCCEEDED(hr))
	{
		INetFwMgr* pFwMgr = NULL;
		hr = CoCreateInstance(CLSID_NetFwMgr, NULL, CLSCTX_INPROC_SERVER, IID_INetFwMgr, (void**)&pFwMgr);
		if (SUCCEEDED(hr))
		{
			INetFwPolicy *pFwPolicy = NULL;
			hr = pFwMgr->get_LocalPolicy(&pFwPolicy);
			if (SUCCEEDED(hr))
			{
				INetFwProfile* pFwProfile = NULL;
				hr = pFwPolicy->get_CurrentProfile(&pFwProfile);
				if (SUCCEEDED(hr))
				{
					INetFwAuthorizedApplications *pFwApplications = NULL;
					hr = pFwProfile->get_AuthorizedApplications(&pFwApplications);
					if (SUCCEEDED(hr))
					{
						BSTR bstrFileName = ::SysAllocString(executablePath.c_str());
						pFwApplications->Remove(bstrFileName);
						::SysFreeString(bstrFileName);
						pFwApplications->Release();
					}
					pFwPolicy->Release();
				}
				pFwProfile->Release();
			}
			pFwMgr->Release();
		}

		CoUninitialize();
	}
}
