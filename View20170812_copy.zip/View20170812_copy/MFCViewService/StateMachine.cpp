#include "stdafx.h"
#include "StateMachine.h"
#include <Iphlpapi.h>
#include "LOG.h"

#if (_WIN32_WINNT >= _WIN32_WINNT_WINBLUE)
#include <VersionHelpers.h>
#endif

#pragma comment(lib, "IPHLPAPI.lib")

StateMachine* StateMachine::m_pStateMachine = NULL;

StateMachine::StateMachine()
{
	Init();
}

StateMachine::~StateMachine()
{
	WSACloseEvent(StopEvent);
	WSACloseEvent(RecvEvent);
}

StateMachine* StateMachine::GetInstance()
{
	if (NULL == m_pStateMachine)
		m_pStateMachine = new StateMachine();

	return m_pStateMachine;
}

void StateMachine::Release()
{
	if (m_pStateMachine != NULL)
	{
		delete m_pStateMachine;
		m_pStateMachine = NULL;
	}
}

void StateMachine::Init()
{
	TCHAR	path[MAX_PATH] = { 0 };
	 ::GetModuleFileName(NULL, path, MAX_PATH);
	TCHAR* pEnd = _tcsrchr(path, L'\\');
	int i = 0;
	while (pEnd[++i] != 0)
	{
		pEnd[i] = 0;
	}	
	_Dir = mystring(path);

	_tcscat_s(path, MAX_PATH, _T("config.ini"));

	
	TCHAR retBuf[128] = { 0 };
	//GetPrivateProfileString(_T("desktop"), _T("_dir"), _T(""), retBuf, 128, path);
	//_Dir = mystring(retBuf);

	GetPrivateProfileString(_T("agent"), _T("_serverip"), _T("192.168.1.1"), retBuf, 128, path);
	_ServerIP = mystring(retBuf);

	_Port = GetPrivateProfileInt(_T("agent"), _T("_port"), 32021, path);
	
	GetPrivateProfileString(_T("agent"), _T("_uuid"), _T(""), retBuf, 128, path);
	_UUID = mystring(retBuf);

	GetPrivateProfileString(_T("agent"), _T("_gridname"), _T("MGRServer"), retBuf, 128, path);
	_GridName = mystring(retBuf);

	_Interval = GetPrivateProfileInt(_T("agent"), _T("_interval"), 20000, path);

	GetPrivateProfileString(_T("agent"), _T("_ad"), _T(""), retBuf, 128, path);
	_AD = mystring(retBuf);

	GetPrivateProfileString(_T("agent"), _T("_preusername"), _T(""), retBuf, 128, path);
	_PreUserName = mystring(retBuf);

	GetPrivateProfileString(_T("agent"), _T("_firewall"), _T("false"), retBuf, 128, path);
	_tcslwr_s(retBuf);	//תΪСд
	if (_tcscmp(retBuf, _T("true")) == 0)
		_FireWall = true;
	else
		_FireWall = false;

	GetPrivateProfileString(_T("agent"), _T("_restore"), _T("false"), retBuf, 128, path);
	_tcslwr_s(retBuf);	//תΪСд
	if (_tcscmp(retBuf, _T("true")) == 0)
		_IsRestore = true;
	else
		_IsRestore = false;

	GetPrivateProfileString(_T("agent"), _T("_isinstalled"), _T("false"), retBuf, 128, path);
	_tcslwr_s(retBuf);	//תΪСд
	if (_tcscmp(retBuf, _T("true")) == 0)
		_IsInstalled = true;
	else
		_IsInstalled = false;

	//ɾ��_IP�еĿո�
	_ServerIP.erase(0, _ServerIP.find_first_not_of(_T(" ")));
	_ServerIP.erase(_ServerIP.find_last_not_of(_T(" ")) + 1);

	_AgentIP = GetAgentIP(_ServerIP);

	_OSVersion = GetOSVersion();

	GetEnvironmentVariable(_T("ComputerName"), retBuf, 128);

	_ComputerName = mystring(retBuf);

	StopEvent = WSACreateEvent();
	RecvEvent = WSACreateEvent();
}

void StateMachine::UpdateMachineState(int nPort, const mystring& ServerIP, const mystring& UUID, const mystring& GridName, const mystring& Interval)
{
	_ServerIP = ServerIP;
	_Port		= nPort;
	_UUID		= UUID;
	_GridName = GridName;
	if (Interval.empty() || Interval.compare(_T("0")) == 0)
	{
		_Interval = 20000;
	}
	else
		_Interval = _tstoi(Interval.c_str());

	_AgentIP = GetAgentIP(ServerIP);

	TCHAR	path[MAX_PATH] = { 0 };
	::GetModuleFileName(NULL, path, MAX_PATH);
	TCHAR* pEnd = _tcsrchr(path, L'\\');
	int i = 0;
	while (pEnd[i++] != 0)
	{
		pEnd[i] = 0;
	}
	_tcscat_s(path, MAX_PATH, _T("config.ini"));

	WritePrivateProfileString(_T("agent"), _T("_serverip"), _ServerIP.c_str(), path);
	WritePrivateProfileString(_T("agent"), _T("_uuid"), _UUID.c_str(), path);
	WritePrivateProfileString(_T("agent"), _T("_gridname"), _GridName.c_str(), path);
	WritePrivateProfileStruct(_T("agent"), _T("_port"), &_Port, sizeof(_Port), path);
	WritePrivateProfileStruct(_T("agent"), _T("_interval"), &_Interval, sizeof(_Interval), path);
}

void StateMachine::EnumSession()
{
	DWORD	Level = 1;
	DWORD	Count = 0;
	TCHAR		buffer[64] = { 0 };
	PWTS_SESSION_INFO_1 pSessionInfo = NULL;

	if (!WTSEnumerateSessionsEx(WTS_CURRENT_SERVER_HANDLE, &Level, 0, &pSessionInfo, &Count))
	{
		LOGW( _T("WTSEnumerateSessionsEx failed with error: %d in Line %d, Function %s, File %s"), GetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		return;
	}

	//for (Level = 0; Level < Count; ++Level)
	//{
	//	if (pSessionInfo[Level].pDomainName != NULL)
	//	{
	//		LOGW(_T("Level=%d, pDomainName = %s"), Level, pSessionInfo[Level].pDomainName);
	//	}
	//	else
	//	{
	//		LOGW(_T("Level=%d, pDomainName = NULL"), Level);
	//	}

	//	if (pSessionInfo[Level].pFarmName != NULL)
	//	{
	//		LOGW(_T("Level=%d, pFarmName = %s"), Level, pSessionInfo[Level].pFarmName);
	//	}
	//	else
	//	{
	//		LOGW(_T("Level=%d, pFarmName = NULL"), Level);
	//	}

	//	if (pSessionInfo[Level].pHostName != NULL)
	//	{
	//		LOGW(_T("Level=%d, pHostName = %s"), Level, pSessionInfo[Level].pHostName);
	//	}
	//	else
	//	{
	//		LOGW(_T("Level=%d, pHostName = NULL"), Level);
	//	}

	//	if (pSessionInfo[Level].pSessionName != NULL)
	//	{
	//		LOGW(_T("Level=%d, pSessionName = %s"), Level, pSessionInfo[Level].pSessionName);
	//	}
	//	else
	//	{
	//		LOGW(_T("Level=%d, pSessionName = NULL"), Level);
	//	}

	//	if (pSessionInfo[Level].pUserName != NULL)
	//	{
	//		LOGW(_T("Level=%d, pUserName = %s"), Level, pSessionInfo[Level].pUserName);
	//	}
	//	else
	//	{
	//		LOGW(_T("Level=%d, pUserName = NULL"), Level);
	//	}

	//	LOGW(_T("Sate=%d, SessionID=%d"), pSessionInfo[Level].State, pSessionInfo[Level].SessionId);
	//	LOGW(_T("%s\n"), (TCHAR*)_T("------------------------------------------------------"));
	//}

	// ����Level����
	for (Level = 0; Level < Count; ++Level)
	{
		// RDP��½
		if ((pSessionInfo[Level].State == WTSActive) && (pSessionInfo[Level].pSessionName != NULL) &&
			(_tcsstr(pSessionInfo[Level].pSessionName, _T("RDP-Tcp#")) != NULL))
		{
			PWTS_CLIENT_ADDRESS	ClientIP = NULL;
			DWORD	ByteReturned = 0;
			if (WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, pSessionInfo[Level].SessionId, WTSClientAddress, (LPTSTR*)&ClientIP, &ByteReturned))
			{
				if (AF_INET == ClientIP->AddressFamily)
				{
					TCHAR bufIP[32] = { 0 };
					_stprintf_s(bufIP, 32, _T("%d.%d.%d.%d"), ClientIP->Address[2], ClientIP->Address[3], ClientIP->Address[4], ClientIP->Address[5]);
					_ClientIP = mystring(bufIP);
					//LOGW(_T("ClientIP = %s\n"), bufIP);
				}
				WTSFreeMemory(ClientIP);
				ClientIP = NULL;
			}	
			break;
		}
		
		//Console��½ , �����XenCenter����̨��¼����
		//if ((pSessionInfo[Level].State == WTSActive) && (pSessionInfo[Level].pSessionName != NULL) && (pSessionInfo[Level].pUserName != NULL))
		//{
		//}

		//RDP�Ͽ�
		if ((pSessionInfo[Level].State == WTSDisconnected) && (NULL == pSessionInfo[Level].pSessionName) && (pSessionInfo[Level].pUserName != NULL))
		{
			break;
		}
		
		//RDPע������δ��¼	
	}		

	if (Level < Count)
	{
		PWTSINFOEX ssInfoEx = NULL;
		DWORD ByteReturned = 0;
		if (!WTSQuerySessionInformation(WTS_CURRENT_SERVER_HANDLE, pSessionInfo[Level].SessionId, WTSSessionInfoEx, (LPTSTR*)&ssInfoEx, &ByteReturned))
		{
			WTSFreeMemoryEx(WTSTypeSessionInfoLevel1, pSessionInfo, Count);
			pSessionInfo = NULL;
			return;
		}

		_UserName = mystring((ssInfoEx->Data).WTSInfoExLevel1.UserName);
		_DomainName = mystring((ssInfoEx->Data).WTSInfoExLevel1.DomainName);
		_WinStationName = mystring((ssInfoEx->Data).WTSInfoExLevel1.WinStationName);
		_SessionID = (ssInfoEx->Data).WTSInfoExLevel1.SessionId;

		_LogonTime = TimeToString((ssInfoEx->Data).WTSInfoExLevel1.LogonTime);
		_ConnectTime = TimeToString((ssInfoEx->Data).WTSInfoExLevel1.ConnectTime);
		_DisconnectTime = TimeToString((ssInfoEx->Data).WTSInfoExLevel1.DisconnectTime);
		_LastInputTime = TimeToString((ssInfoEx->Data).WTSInfoExLevel1.LastInputTime);
		_CurrentTime = TimeToString((ssInfoEx->Data).WTSInfoExLevel1.CurrentTime);
		LARGE_INTEGER  idletime = { 0 };
		idletime.QuadPart = (ssInfoEx->Data).WTSInfoExLevel1.CurrentTime.QuadPart - (ssInfoEx->Data).WTSInfoExLevel1.LastInputTime.QuadPart;
		_IdleTime = TimeToString(idletime);

		_SessionState = mystring(_T("EMPTY"));
		if ((ssInfoEx->Data).WTSInfoExLevel1.SessionState == WTSActive)
		{
			_SessionState = mystring(_T("IN_USE"));
		}
		else if ((ssInfoEx->Data).WTSInfoExLevel1.SessionState == WTSDisconnected)
		{
			if (!_UserName.empty())
			{
				_SessionState = mystring(_T("DISCONNECT"));
			}
		}

		WTSFreeMemory(ssInfoEx);
		ssInfoEx = NULL;
	}
	else
	{
		_SessionState = mystring(_T("EMPTY"));
		_ConnectTime = _T("");
		_LogonTime = _T("");
	}

	SYSTEMTIME st = { 0 };
	GetLocalTime(&st);
	memset(buffer, 0, sizeof(buffer));
	_stprintf_s(buffer, 64, _T("%04d-%02d-%02d %02d:%02d:%02d.%03d"), st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
	_TimeStamp = mystring(buffer);

	WTSFreeMemoryEx(WTSTypeSessionInfoLevel1, pSessionInfo, Count);
	pSessionInfo = NULL;
}

mystring StateMachine::TimeToString(LARGE_INTEGER time)
{
	TCHAR	 buffer[128] = { 0 };
	_stprintf_s(buffer, 128, _T("%I64d"), time);

	return mystring(buffer);
}

mystring StateMachine::GetAgentIP(mystring ServerIP)
{
	if (ServerIP.empty())
	{
		return mystring(_T(""));
	}

	unsigned long	userver[4] = { 0 };
	unsigned int		uip[4] = { 0 };
	unsigned int		umask[4] = { 0 };

	TCHAR* pEnd = NULL;
	userver[0] = _tcstoul(ServerIP.c_str(), &pEnd, 10);
	userver[1] = _tcstoul(pEnd + 1, &pEnd, 10);
	userver[2] = _tcstoul(pEnd + 1, &pEnd, 10);
	userver[3] = _tcstoul(pEnd + 1, &pEnd, 10);

	PIP_ADAPTER_INFO pAdapterInfo = NULL;
	PIP_ADAPTER_INFO pAdapter = NULL;
	DWORD dwRetVal = 0;

	ULONG outBufLen = sizeof(IP_ADAPTER_INFO);
	pAdapter = (PIP_ADAPTER_INFO)malloc(outBufLen);

	assert(pAdapter != NULL);

	dwRetVal = GetAdaptersInfo(pAdapter, &outBufLen);
	if (ERROR_BUFFER_OVERFLOW == dwRetVal)
	{
		free(pAdapter);
		pAdapter = (PIP_ADAPTER_INFO)malloc(outBufLen);
		assert(pAdapter != NULL);
	}

	dwRetVal = GetAdaptersInfo(pAdapter, &outBufLen);
	if (NO_ERROR == dwRetVal)
	{
		pAdapterInfo = pAdapter;
		while (pAdapterInfo != NULL)
		{
			sscanf_s(pAdapterInfo->IpAddressList.IpAddress.String, "%d.%d.%d.%d",
				&uip[0], &uip[1], &uip[2], &uip[3]);
			sscanf_s(pAdapterInfo->IpAddressList.IpMask.String, "%d.%d.%d.%d",
				&umask[0], &umask[1], &umask[2], &umask[3]);
			pAdapterInfo = pAdapterInfo->Next;
			if ((0 == uip[0]) || (0 == umask[0]))
				continue;
			if (((uip[0] & umask[0]) == (userver[0] & umask[0])) &&
				((uip[1] & umask[1]) == (userver[1] & umask[1])) &&
				((uip[2] & umask[2]) == (userver[2] & umask[2])) &&
				((uip[3] & umask[3]) == (userver[3] & umask[3])))
				break;
		}
		free(pAdapter);
		pAdapter = NULL;
	}

	TCHAR ip[32] = { 0 };
	_stprintf_s(ip, 32, _T("%d.%d.%d.%d"), uip[0], uip[1], uip[2], uip[3]);

	return mystring(ip);
}

mystring StateMachine::GetOSVersion()
{
	BOOL bIsWow64 = FALSE;

	IsWow64Process(GetCurrentProcess(), &bIsWow64);

#if (_WIN32_WINNT < _WIN32_WINNT_WINBLUE)

	OSVERSIONINFOEX	os = { 0 };

	os.dwOSVersionInfoSize = sizeof(os);
	GetVersionEx((LPOSVERSIONINFO)&os);

	if ((os.dwMajorVersion == 6) && (os.dwMinorVersion == 1))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 7(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows 7(32-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2008 R2"));
		}
	}
	else if ((os.dwMajorVersion == 6) && (os.dwMinorVersion == 2))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 8(64-bit)"));
			}
			else 
			{
				return mystring(_T("Windows 8(32-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2012"));
		}
	}
	else if ((os.dwMajorVersion == 6) && (os.dwMinorVersion == 3))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 8.1(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows 8.1(32-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2012 R2"));
		}
	}
	else if ((os.dwMajorVersion == 10) && (os.dwMinorVersion == 0))
	{
		if (os.wProductType == VER_NT_WORKSTATION)
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 10(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows 10(32-bit)"));
			}
		}
		else
		{
			return mystring(_T("Windows Server 2016 Technical Preview"));
		}
	}

	return mystring(_T("Windows Vista or Lower"));
#else
	bool bIsServer = IsWindowsServer();

	//#if (_WIN32_WINNT >= _WIN32_WINNT_WIN10)
	//	if (IsWindows10OrGreater())
	//	{
	//		if (bIsServer)
	//		{
	//			return mystring(_T("Windows Server 2016 Technical Preview)"));
	//		}
	//		else
	//		{
	//			return mystring(_T("Windows 10"));
	//		}
	//	}
	//#endif

	if (IsWindows8Point1OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012 R2"));
		}
		else
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 8.1(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows 8.1(32-bit)"));
			}
		}
	}
	else if (IsWindows8OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012"));
		}
		else
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 8.1(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows 8.1(32-bit)"));
			}
		}
	}
	else if (IsWindows7SP1OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012 R2"));
		}
		else
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 7 SP1(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows 7 SP1(32-bit)"));
			}
		}
	}
	else if (IsWindows7OrGreater())
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2012"));
		}
		else
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows 7(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows 7(32-bit)"));
			}
		}
	}
	else
	{
		if (bIsServer)
		{
			return mystring(_T("Windows Server 2003"));
		}
		else
		{
			if (bIsWow64)
			{
				return mystring(_T("Windows XP(64-bit)"));
			}
			else
			{
				return mystring(_T("Windows XP(32-bit)"));
			}
		}
	}

	//return mystring(_T("Windows Vista or Lower"));
#endif
}

void StateMachine::SetPreUserName(mystring PreUserName)
{


}

void StateMachine::SetServerIP(mystring ServerIP)
{

}

void StateMachine::SetRestore(mystring restore)
{

}