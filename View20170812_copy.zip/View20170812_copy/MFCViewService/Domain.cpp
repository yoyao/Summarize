#include "stdafx.h"
#include "Domain.h"
#include "LOG.h"

void ModifyHostName(const char* name)
{
	//HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\ComputerName\ActiveComputerName
	HKEY hKey;
	LONG lRet = ERROR_SUCCESS;

	lRet = RegOpenKeyExA(HKEY_LOCAL_MACHINE, "System\\CurrentControlSet\\Control\\ComputerName", 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	HKEY hSubKey;
	lRet = RegOpenKeyExA(hKey, "ActiveComputerName", 0, KEY_WRITE, &hSubKey);
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueExA(hSubKey, "ComputerName", 0, REG_SZ, (BYTE*)name, (strlen(name)+ 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hSubKey);
		RegCloseKey(hKey);
		return;
	}

	RegCloseKey(hSubKey);

	lRet = RegOpenKeyExA(hKey, "ComputerName", 0, KEY_WRITE, &hSubKey);
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueExA(hSubKey, "ComputerName", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hSubKey);
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hSubKey);
	RegCloseKey(hKey);


	//HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Tcpip\Parameters
	lRet = RegOpenKeyExA(HKEY_LOCAL_MACHINE, "System\\CurrentControlSet\\Services\\Tcpip\\Parameters", 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueExA(hKey, "Hostname", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueExA(hKey, "NV Hostname", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_CURRENT_USER\Volatile Environment
	lRet = RegOpenKeyExA(HKEY_CURRENT_USER, "Volatile Environment", 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueExA(hKey, "USERDOMAIN", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	char buffer[256] = { 0 };
	strcpy_s(buffer, 256, "\\\\");
	strcat_s(buffer, 256, name);
	lRet = RegSetValueExA(hKey, "LOGONSERVER", 0, REG_SZ, (BYTE*)buffer, (strlen(buffer) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Reliability
	lRet = RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Reliability", 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueExA(hKey, "LastComputerName", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\System\ControlSet002\Control\ComputerName\ComputerName
	lRet = RegOpenKeyExA(HKEY_LOCAL_MACHINE, "System\\ControlSet002\\Control\\ComputerName\\ComputerName", 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueExA(hKey, "ComputerName", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	//HKEY_LOCAL_MACHINE\System\ControlSet002\Services\Tcpip\Parameters
	lRet = RegOpenKeyExA(HKEY_LOCAL_MACHINE, "System\\ControlSet002\\Services\\Tcpip\\Parameters", 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	lRet = RegSetValueExA(hKey, "Hostname", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}

	lRet = RegSetValueExA(hKey, "NV Hostname", 0, REG_SZ, (BYTE*)name, (strlen(name) + 1));
	if (lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return;
	}
	RegCloseKey(hKey);

	HANDLE hToken;
	BOOL bRet = OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken);
	TOKEN_PRIVILEGES tp;
	LUID luid;
	bRet = LookupPrivilegeValueA(NULL, "SeShutdownPrivilege", &luid);
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	bRet = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES), NULL, NULL);

	InitiateSystemShutdown(NULL, NULL, 0, TRUE, TRUE);
}


void ModifyDns(const char* dnsip)
{
	HKEY hKey;
	LONG lRet = ERROR_SUCCESS;
	lRet = RegOpenKeyExA(HKEY_LOCAL_MACHINE, "System\\CurrentControlSet\\Control\\Class\\{4D36E972-E325-11CE-BFC1-08002BE10318}", 0, KEY_READ, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	DWORD dwIndex = 0;
	char szSubKey[256] = { 0 };
	char szData[256] = { 0 };
	char szAapterName[256] = { 0 };
	DWORD dwBufSize = 256;
	HKEY hSubKey;
	HKEY hNdiIntKey;
	while (RegEnumKeyExA(hKey, dwIndex++, szSubKey, &dwBufSize, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
	{
		if (RegOpenKeyExA(hKey, szSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS)
		{

			if (RegOpenKeyExA(hSubKey, "Ndi\\Interfaces", 0, KEY_READ, &hNdiIntKey) == ERROR_SUCCESS)
			{
				dwBufSize = 256 ;
				if (RegQueryValueExA(hNdiIntKey, "LowerRange", 0, NULL, (BYTE*)szData, &dwBufSize) == ERROR_SUCCESS)
				{
					if (strcmp(szData, "ethernet") == 0)
					{
						dwBufSize = 256;
						if (RegQueryValueExA(hSubKey, "NetCfgInstanceID", 0, NULL, (BYTE*)szData, &dwBufSize) == ERROR_SUCCESS)
						{
							//szData�б�������������   
							strcpy_s(szAapterName, 256, szData);
							RegCloseKey(hNdiIntKey);
							RegCloseKey(hSubKey);
							break;
						}
					}
				}
				RegCloseKey(hNdiIntKey);
			}
			RegCloseKey(hSubKey);
		}
		dwBufSize = 256;
	}

	RegCloseKey(hKey);

	strcpy_s(szSubKey, 256, "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\");
	strcat_s(szSubKey, 256, szAapterName);
	lRet = RegOpenKeyExA(HKEY_LOCAL_MACHINE, szSubKey, 0, KEY_WRITE, &hKey);
	if (lRet != ERROR_SUCCESS)
	{
		return;
	}

	RegSetValueExA(hKey, "NameServer", 0, REG_SZ, (BYTE*)(dnsip), (strlen(dnsip) + 1));

	RegCloseKey(hKey);
}


void JoinDomain(const char* ou, const char* admin, const char* password)
{
	LOGW(_T("JoinDomain in with ou: %s. admin %s, password %s\n"), ou,admin,password);
	wchar_t buffer[256] = { 0 };
	size_t ret = 0;
	mbstowcs_s(&ret, buffer, 256, ou, strlen(ou));
	mystring strAccountOU(buffer);

	memset(buffer, 0, sizeof(buffer));
	ret = 0;
	mbstowcs_s(&ret, buffer, 256, admin, strlen(admin));
	mystring strAccount(buffer);

	memset(buffer, 0, sizeof(buffer));
	ret = 0;
	mbstowcs_s(&ret, buffer, 256, password, strlen(password));
	mystring strPassword(buffer);

	mystring::size_type pos = strAccount.find(_T("DC"));
	mystring strDomain = strAccount.substr(pos);
	while (1)   
	{
		mystring::size_type   pos;
		if ((pos = strDomain.find(_T("DC="))) != mystring::npos)
		{
			strDomain.replace(pos, _tcsclen(_T("DC=")), _T(""));
		}
		else
			break;
	}

	while (1)
	{
		mystring::size_type   pos;
		if ((pos = strDomain.find(_T(","))) != mystring::npos)
		{
			strDomain.replace(pos, _tcsclen(_T(",")), _T("."));
		}
		else
			break;
	}

	DWORD JoinOptions = NETSETUP_JOIN_DOMAIN | NETSETUP_ACCT_CREATE;

	NET_API_STATUS status = NERR_Success;
	status = NetJoinDomain(NULL, strDomain.c_str(), strAccountOU.c_str(), strAccount.c_str(), strPassword.c_str(), JoinOptions);
	if (status != NERR_Success)
	{
		LOGW(_T("NetJoinDomain failed with error: %d. Line %d, Function %s, File %s\n"), status, __LINE__, __FUNCTIONW__, __FILEW__);
	}
}

void UnjoinDomain(const char* admin, const char* password)
{
	wchar_t buffer[256] = { 0 };
	size_t ret = 0;
	mbstowcs_s(&ret, buffer, 256, admin, strlen(admin));
	mystring strAccount(buffer);

	memset(buffer, 0, sizeof(buffer));
	ret = 0;
	mbstowcs_s(&ret, buffer, 256, admin, strlen(admin));
	mystring strPassword(buffer);

	NET_API_STATUS status = NERR_Success;
	status = NetUnjoinDomain(NULL, strAccount.c_str(), strPassword.c_str(), NETSETUP_ACCT_DELETE);
	if (status != NERR_Success)
	{
		LOGW(_T("NetUnjoinDomain failed with error: %d. Line %d, Function %s, File %s\n"), status, __LINE__, __FUNCTIONW__, __FILEW__);
	}
}

void JoinRemoteUsers(const char* user)
{
	wchar_t buffer[256] = { 0 };
	size_t ret = 0;
	mbstowcs_s(&ret, buffer, 256, user, strlen(user));

	LOCALGROUP_MEMBERS_INFO_3 pmem3;
#if 0
	DWORD dwSize = ret + 1;
	pmem3.lgrmi3_domainandname = new TCHAR[dwSize];
	_tcscpy_s(pmem3.lgrmi3_domainandname, ret, buffer);
	pmem3.lgrmi3_domainandname[ret] = 0;

	NET_API_STATUS status = NERR_Success;
	dwSize = 1;
	status = NetLocalGroupSetMembers(NULL, _T("Remote Desktop Users"), 3, (BYTE*)&pmem3, dwSize);
	if (status != NERR_Success)
	{
		LOGW(_T("NetLocalGroupSetMembers failed with error: %d. Line %d, Function %s, File %s\n"), status, __LINE__, __FUNCTIONW__, __FILEW__);
	}

	delete[] pmem3.lgrmi3_domainandname;
	pmem3.lgrmi3_domainandname = NULL;
#else
	DWORD dwSize =1;
	pmem3.lgrmi3_domainandname =buffer;
	
	NET_API_STATUS status = NERR_Success;
	dwSize = 1;
	status = NetLocalGroupSetMembers(NULL, _T("Remote Desktop Users"), 3, (BYTE*)&pmem3, dwSize);
	if (status != NERR_Success)
	{
		LOGW(_T("NetLocalGroupSetMembers failed with error: %d. Line %d, Function %s, File %s\n"), status, __LINE__, __FUNCTIONW__, __FILEW__);
	}
#endif
}