#pragma once

void		RunView();
void		StopView();
