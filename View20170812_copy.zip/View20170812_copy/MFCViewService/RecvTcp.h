#pragma once

class StateMachine;

uintptr_t OnRecvTcp(const StateMachine* machine);