#include "stdafx.h"
#include "json\json.h"
#include "ParseJson.h"
#include "Domain.h"
#include <stdio.h>

void ParseRegisterDesktop(const Json::Value& root);
void WritePrivateFile(const char* ou, const char* admin, const char* password, const char* user);

void ParseJson(const std::string& document)
{
	
	
	Json::Value root = Json::Value::nullRef;
	Json::Reader reader;

	if (reader.parse(document, root))
	{
		Json::Value item = root["serverreq"];
		if (item != Json::Value::nullRef)
		{
			Json::Value subitem = item["JoinDomain"];
			if (subitem != Json::Value::nullRef)
			{
				printf("%s", subitem);
				ParseRegisterDesktop(subitem);
			}
			//��������
		//	Json::Value subitem = item["xxx"];
		//	if (subitem != Json::Value::nullRef)
		//	{
		//		printf("%s", subitem);
		//		//ParseRegisterDesktop(subitem);
		//	}
		}		
	}	
}

void ParseRegisterDesktop(const Json::Value& root)
{
	/*
		{
"serverreq":{"JoinDomain":{"dnsip":"192.168.0.121",
"vmname":"aaa","domainuser": "ad.desktop.local","ou":"OU=UVUsers,DC=univew50,DC=local","domainadmin":"administrator",
"password":"2012.cn"}}}
	*/
//Json::Value item0 = root["dnsip"];
	Json::Value item1 = root["vmname"];
	Json::Value item2 = root["domainuser"];
	Json::Value item3 = root["ou"];
	Json::Value item4 = root["domainadmin"];
	Json::Value item5 = root["password"];


	
//	MessageBoxA(NULL, item0.asCString(), item1.asCString(), MB_OK);
	printf("\n\n\n");
	printf("%s  %s   %s	%s  %s %s\n", item1.asCString(), item1.asCString(), item2.asCString(), item3.asCString(), item4.asCString(), item5.asCString());
	
//	WritePrivateFile(item2.asCString(), item3.asCString(), item4.asCString(), item5.asCString());
	
//	ModifyDns(item1.asCString());
//	ModifyHostName(item0.asCString());
}

void WritePrivateFile(const char* ou, const char* admin, const char* password, const char* user)
{
	std::ofstream out;

	char filename[256] = { 0 };
	GetModuleFileNameA(NULL, filename, 256);
	int i = 0;
	char* pFind = strchr(filename, '\\');
	while (pFind[++i] != 0)
	{
		pFind[i] = 0;
	}
	strcat_s(filename, 256, "viewa.bin");
	out.open(filename, std::ios::trunc, 2);
	out.write(ou, strlen(ou));
	out.write("\n", strlen("\n"));
	out.write(admin, strlen(admin));
	out.write("\n", strlen("\n"));
	out.write(password, strlen(password));
	out.write("\n", strlen("\n"));
	out.write(user, strlen(user));
	out.write("\n", strlen("\n"));
	out.close();
}

bool ReadPrivateFile()
{
	char filename[256] = { 0 };
	GetModuleFileNameA(NULL, filename, 256);
	int i = 0;
	char* pFind = strchr(filename, '\\');
	while (pFind[++i] != 0)
	{
		pFind[i] = 0;
	}
	strcat_s(filename, 256, "viewa.bin");

	std::ifstream in(filename);
	if (in.is_open())
	{
		char ou[256] = { 0 };
		in.getline(ou, 256);

		char admin[64] = { 0 };
		in.getline(admin, 64);

		char password[32] = { 0 };
		in.getline(password, 32);

		char user[64] = { 0 };
		in.getline(user, 64);

		in.close();
		DeleteFileA(filename);

		JoinDomain(ou, admin, password);
		JoinRemoteUsers(user);

		return true;
	}

	return false;
}