#pragma once

void ParseJson(const std::string& document);