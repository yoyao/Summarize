#pragma once
class INetFwManger
{
public:
	INetFwManger();
	~INetFwManger();

	static void NetFwAddPorts(mystring name, int port, mystring protocol);
	static void NetFwAddApps(mystring name, mystring executablePath);
	static void NetFwDelApps(int port, mystring protocol);
	static void NetFwDelApps(mystring executablePath);
};

