#include "stdafx.h"
#include "LOG.h"

void LOG(TCHAR* filename, TCHAR* format, ...)
{
	HKEY hKey;
	DWORD DebugLog = 0;
	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SYSTEM\\CurrentControlSet\\services\\ViewServer"), 0, KEY_READ, &hKey))
	{
		DWORD dwSize = sizeof(DebugLog);
		RegQueryValueEx(hKey, _T("DebugLog"), 0, NULL, (BYTE*)&DebugLog, &dwSize);
		RegCloseKey(hKey);
	}

	if (DebugLog != 1)
		return;

	TCHAR path[MAX_PATH] = { 0 };
	if (GetModuleFileName(NULL, path, MAX_PATH) == 0)
	{
		TCHAR out[512] = { 0 };
#ifdef UNICODE
	#define FUNC __FUNCTIONW__
	#define TFILE	__FILEW__
#else
	#define FUNC __FUNCTION__
	#define TFILE	__FILE__
#endif
		_stprintf_s	(out, 512, _T("GetModuleFileName failed with error: %d in Line %d, Function %s, File %s\n"), GetLastError(), __LINE__, FUNC, TFILE);
		OutputDebugString(out);
		return;
	}

	TCHAR* pFind = _tcsrchr(path, '\\');
	if (pFind != NULL)
	{
		int i = 0;
		while (pFind[++i] != 0)
		{
			pFind[i] = 0;
		}
		if (filename != NULL)
		{
			_tcscat_s(path, MAX_PATH, filename);
		}
		else
		{
			_tcscat_s(path, MAX_PATH, _T("DebugInfo.LOG"));
		}
	}
	else
	{
		TCHAR out[512] = { 0 };
#ifdef UNICODE
	#define FUNC __FUNCTIONW__
	#define TFILE	__FILEW__
#else
	#define FUNC __FUNCTION__
	#define TFILE	__FILE__
#endif
		_stprintf_s(out, 512, _T("Error path: %s in Line %d, Function %s, File %s\n"), path, __LINE__, FUNC, TFILE);
		OutputDebugString(out);
		return;
	}

	FILE* stream = NULL;
	errno_t errt = _tfopen_s(&stream, path, _T("a+"));
	if (errt != 0)
	{
		TCHAR out[512] = { 0 };
#ifdef UNICODE
	#define FUNC __FUNCTIONW__
	#define TFILE	__FILEW__
#else
	#define FUNC __FUNCTION__
	#define TFILE	__FILE__
#endif
		_stprintf_s(out, 512, _T("Failed to open file: %s in Line %d, Function %s, File %s\n"), path, __LINE__, FUNC, TFILE);
		OutputDebugString(out);
		return;
	}

	int count = 0;
	TCHAR buffer[1024] = { 0 };

	SYSTEMTIME st;
	GetLocalTime(&st);

	count = _stprintf_s(buffer, 1024, _T("\n%04d-%02d-%02d:%02d-%02d-%02d-%03d:	"), st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
	fwrite(buffer, sizeof(TCHAR), count, stream);

	va_list	arg;
	va_start(arg, format);
	count = _vstprintf_s	(buffer, 1024, format, arg);
	va_end(arg);

	fwrite(buffer, sizeof(TCHAR), count, stream);
	fflush(stream);
	fclose(stream);
}

void LOGA(char* format, ...)
{
	HKEY hKey;
	DWORD DebugLog = 0;
	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SYSTEM\\CurrentControlSet\\services\\ViewServer"), 0, KEY_READ, &hKey))
	{
		DWORD dwSize = sizeof(DebugLog);
		RegQueryValueEx(hKey, _T("DebugLog"), 0, NULL, (BYTE*)&DebugLog, &dwSize);
		RegCloseKey(hKey);
	}

	if (DebugLog != 1)
		return;

	char path[MAX_PATH] = { 0 };
	if (GetModuleFileNameA(NULL, path, MAX_PATH) == 0)
	{
		char out[512] = { 0 };
		sprintf_s(out, 512, "GetModuleFileNameA failed with error: %d in Line %d, Function %s, File %s\n", GetLastError(), __LINE__, __FUNCTION__, __FILE__);
		OutputDebugStringA(out);
		return;
	}

	char* pFind = strrchr(path, '\\');
	if (pFind != NULL)
	{
		int i = 0;
		while (pFind[++i] != 0)
		{
			pFind[i] = 0;
		}
		strcat_s(path, MAX_PATH, "DebugInfoA.LOG");
	}
	else
	{
		char out[512] = { 0 };
		sprintf_s(out, 512, "Error path: %s in Line %d, Function %s, File %s\n", path, __LINE__, __FUNCTION__, __FILE__);
		OutputDebugStringA(out);
		return;
	}

	FILE* stream = NULL;
	errno_t errt = fopen_s(&stream, path, "a+");
	if (errt != 0)
	{
		char out[512] = { 0 };
		sprintf_s(out, 512, "Failed to open file: %s in Line %d, Function %s, File %s\n", path, __LINE__, __FUNCTION__, __FILE__);
		OutputDebugStringA(out);
		return;
	}

	int count = 0;
	char buffer[1024] = { 0 };

	SYSTEMTIME st;
	GetLocalTime(&st);

	count = sprintf_s(buffer, 1024, "\n%04d-%02d-%02d:%02d-%02d-%02d-%03d:	", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
	fwrite(buffer, sizeof(char), count, stream);
	
	va_list	arg;
	va_start(arg, format);
	count = vsprintf_s(buffer, 1024, format, arg);
	va_end(arg);

	fwrite(buffer, sizeof(char), count, stream);
	fflush(stream);
	fclose(stream);
}


void LOGW(wchar_t* format, ...)
{
	HKEY hKey;
	DWORD DebugLog = 0;
	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SYSTEM\\CurrentControlSet\\services\\ViewServer"), 0, KEY_READ, &hKey))
	{
		DWORD dwSize = sizeof(DebugLog);
		RegQueryValueEx(hKey, _T("DebugLog"), 0, NULL, (BYTE*)&DebugLog, &dwSize);
		RegCloseKey(hKey);
	}

	if (DebugLog != 1)
		return;

	wchar_t path[MAX_PATH] = { 0 };
	if (GetModuleFileNameW(NULL, path, MAX_PATH) == 0)
	{
		wchar_t out[512] = { 0 };
		swprintf_s(out, 512, L"GetModuleFileNameW failed with error: %d in Line %d, Function %s, File %s\n", GetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		OutputDebugStringW(out);
		return;
	}

	wchar_t* pFind = wcsrchr(path, '\\');
	if (pFind != NULL)
	{
		int i = 0;
		while (pFind[++i] != 0)
		{
			pFind[i] = 0;
		}
		wcscat_s(path, MAX_PATH, L"DebugInfoW.LOG");
	}
	else
	{
		wchar_t out[512] = { 0 };
		swprintf_s(out, 512, L"Error path: %s in Line %d, Function %s, File %s\n", path, __LINE__, __FUNCTIONW__, __FILEW__);
		OutputDebugStringW(out);
		return;
	}
	
	FILE* stream = NULL;
	errno_t errt = _wfopen_s(&stream, path, L"a+");
	if (errt != 0)
	{
		wchar_t out[512] = { 0 };
		swprintf_s(out, 512, L"Failed to open file: %s in Line %d, Function %s, File %s\n", path, __LINE__, __FUNCTIONW__, __FILEW__);
		OutputDebugStringW(out);
		return;
	}

	wchar_t buffer[1024] = { 0 };
	int count = 0;

	SYSTEMTIME st;
	GetLocalTime(&st);

	count = swprintf_s(buffer, 1024, L"\n%04d-%02d-%02d:%02d-%02d-%02d-%03d:	", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
	fwrite(buffer, sizeof(wchar_t), count, stream);
	
	va_list	arg;
	va_start(arg, format);
	count = vswprintf_s(buffer, 1024, format, arg);
	va_end(arg);

	fwrite(buffer, sizeof(wchar_t), count, stream);
	fflush(stream);
	fclose(stream);
}
