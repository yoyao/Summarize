#pragma once

void DoServiceRun();

void DoServiceInstall();

void DoServiceDelete();

void DoServiceStart();

void DoServiceStop();

void DoServiceEnable();

void DoServiceDisable();

void DoServiceQuery();

void DoServiceUpdate(LPTSTR szDesc);

void DoServiceRegistry();

void DoServiceTestRun();

void DoServiceTestStop();