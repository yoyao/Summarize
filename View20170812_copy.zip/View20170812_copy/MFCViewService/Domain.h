#pragma once

void ModifyHostName(const char* name);
void ModifyDns(const char* dnsip);
void JoinDomain(const char* ou, const char* admin, const char* password);
void UnjoinDomain();
void JoinRemoteUsers(const char* user);

bool ReadPrivateFile();
