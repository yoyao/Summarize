#include "stdafx.h"
#include "MFCViewService.h"
#include "ServiceMsg.h"
#include "ViewMain.h"

#define		SERVICENAME		_T("ViewServer")

VOID	  WINAPI	ServiceMain(DWORD dwArgc, LPTSTR *lpszArgv);
DWORD WINAPI  ServiceCtrlHandlerEx(DWORD  dwControl, DWORD  dwEventType, LPVOID lpEventData, LPVOID lpContext);

VOID ServiceInit(DWORD dwArgc, LPTSTR *lpszArgv);
VOID ServiceReportStatus(DWORD dwCurrentState, DWORD dwWin32ExitCode, DWORD dwWaitHint);
VOID ServiceReportEvent(LPTSTR szFunction);
BOOL StopDependentServices(SC_HANDLE schSCManager, SC_HANDLE schService);

SERVICE_TABLE_ENTRY DispatchTable[] =
{
	{ SERVICENAME, (LPSERVICE_MAIN_FUNCTION)ServiceMain },
	{ NULL, NULL }
};

SERVICE_STATUS					g_ServiceStatus				= { 0 };
SERVICE_STATUS_HANDLE  g_hServiceStatusHandle	= NULL;

VOID WINAPI ServiceMain(DWORD dwArgc, LPTSTR *lpszArgv)
{
	g_hServiceStatusHandle = RegisterServiceCtrlHandlerEx(SERVICENAME, ServiceCtrlHandlerEx, NULL);
	if (g_hServiceStatusHandle == NULL)
	{
		ServiceReportEvent(_T("RegisterServiceCtrlHandlerEx"));
		return;
	}

	g_ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	g_ServiceStatus.dwServiceSpecificExitCode = 0;

	ServiceReportStatus(SERVICE_RUNNING, NO_ERROR, 0);

	ServiceInit(dwArgc, lpszArgv);
}

DWORD WINAPI ServiceCtrlHandlerEx(DWORD  dwControl, DWORD  dwEventType, LPVOID lpEventData, LPVOID lpContext)
{
	switch (dwControl)
	{
	case SERVICE_CONTROL_STOP:
		ServiceReportStatus(SERVICE_STOP_PENDING, NO_ERROR, 0);
		StopView(); //����ֹͣ�ź�
		ServiceReportStatus(g_ServiceStatus.dwCurrentState, NO_ERROR, 0);
		break;
	default:
		break;
	}

	return NO_ERROR;
}


VOID	ServiceReportEvent(LPTSTR szFunction)
{
		HANDLE	hEventSource = INVALID_HANDLE_VALUE;
		LPCTSTR	lpszStrings[2]  = { 0 };
		TCHAR		Buffer[80]		  = { 0 };
		DWORD	dwError = GetLastError();

		hEventSource = RegisterEventSource(NULL, SERVICENAME);

		if (NULL != hEventSource)
		{
			StringCchPrintf(Buffer, 80, _T("%s Failed with %d"), szFunction, dwError);

			lpszStrings[0] = SERVICENAME;
			lpszStrings[1] = Buffer;

			ReportEvent(hEventSource,		// event log handle
				EVENTLOG_ERROR_TYPE,		// event type
				0,											// event category
				SERVICEERROR,					// event identifier
				NULL,									// no security identifier
				2,											// size of lpszStrings array
				0,											// no binary data
				lpszStrings,							// array of strings
				NULL);									// no binary data

			DeregisterEventSource(hEventSource);
		}
}

VOID ServiceReportStatus(DWORD dwCurrentState, DWORD dwWin32ExitCode, DWORD dwWaitHint)
{
	static DWORD dwCheckPoint = 1;

	g_ServiceStatus.dwCurrentState		= dwCurrentState;
	g_ServiceStatus.dwWin32ExitCode	= dwWin32ExitCode;
	g_ServiceStatus.dwWaitHint				= dwWaitHint;

	if (dwCurrentState == SERVICE_START_PENDING)
		g_ServiceStatus.dwControlsAccepted = 0;
	else 
		g_ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;

	if ((dwCurrentState == SERVICE_RUNNING) || (dwCurrentState == SERVICE_STOPPED))
		g_ServiceStatus.dwCheckPoint = 0;
	else 
		g_ServiceStatus.dwCheckPoint = dwCheckPoint++;

	if (g_hServiceStatusHandle != NULL)
		SetServiceStatus(g_hServiceStatusHandle, &g_ServiceStatus);
}

VOID ServiceInit(DWORD dwArgc, LPTSTR *lpszArgv)
{
	ServiceReportStatus(SERVICE_RUNNING, NO_ERROR, 0);

	RunView();

	ServiceReportStatus(SERVICE_STOPPED, NO_ERROR, 0);
}

///////////////////////////////////////////////////////////////////////////////////////
void DoServiceInstall()
{
	SC_HANDLE schSCManager = NULL;
	SC_HANDLE schService		 = NULL;
	TCHAR			szPath[MAX_PATH] = { 0 };

	if (!GetModuleFileName(NULL, szPath, MAX_PATH))
	{
		ServiceReportEvent(_T("GetModuleFileName in DoServiceInstall"));
		return;
	}
	_tcscat_s(szPath, MAX_PATH, _T(" -run"));

	DoServiceRegistry();

	//�򿪷��������
	schSCManager = OpenSCManager(NULL,  NULL,  SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceInstall"));
		return;
	}

	// ��������
	schService = CreateService(schSCManager,              // SCM database 
		SERVICENAME,									// name of service 
		SERVICENAME,									// service name to display 
		SERVICE_ALL_ACCESS,						// desired access 
		SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS,	// service type 
		SERVICE_AUTO_START,						// start type 
		SERVICE_ERROR_NORMAL,				// error control type 
		szPath,												// path to service's binary 
		NULL,												// no load ordering group 
		NULL,												// no tag identifier 
		NULL,												// no dependencies 
		NULL,												// LocalSystem account 
		NULL);												// no password 

	if (schService == NULL)
	{
		ServiceReportEvent(_T("CreateService in DoServiceInstall"));
		CloseServiceHandle(schSCManager);
		return;
	}

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);

	printf("Install Service Succeed\n");
}

void DoServiceRun()
{
	if (!StartServiceCtrlDispatcher(DispatchTable))
	{
		ServiceReportEvent(_T("StartServiceCtrlDispatcher"));
	}

	printf("Run Service  Succeed\n");
}

void DoServiceDelete()
{
	SC_HANDLE			schSCManager = NULL;
	SC_HANDLE			schService		= NULL;	
	SERVICE_STATUS ssStatus			= { 0 };

	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceDelete"));
		return;
	}

	schService = OpenService(schSCManager, SERVICENAME, DELETE);
	if (schService == NULL)
	{
		ServiceReportEvent(_T("OpenService in DoServiceDelete"));
		CloseServiceHandle(schSCManager);
		return;
	}

	if (!DeleteService(schService))
	{
		ServiceReportEvent(_T("DeleteService in DoServiceDelete"));
	}

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);

	printf("Delete Service Succeed\n");
}

void DoServiceStart()
{
	SERVICE_STATUS_PROCESS ssProcess = { 0 };
	SC_HANDLE			schSCManager = NULL;
	SC_HANDLE			schService		= NULL;
	//SERVICE_STATUS ssStatus			= { 0 };
	DWORD dwOldCheckPoint	= 0;
	DWORD dwStartTickCount	= 0;
	DWORD dwWaitTime			= 0;
	DWORD dwBytesNeeded		= 0;

	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceStart"));
		return;
	}

	schService = OpenService(schSCManager, SERVICENAME, SERVICE_ALL_ACCESS);
	if (schService == NULL)
	{
		ServiceReportEvent(_T("OpenService in DoServiceStart"));
		CloseServiceHandle(schSCManager);
		return;
	}

	if (!QueryServiceStatusEx(schService, 
						SC_STATUS_PROCESS_INFO, 
						(LPBYTE)&ssProcess,
						sizeof(SERVICE_STATUS_PROCESS), 
						&dwBytesNeeded))
	{
		ServiceReportEvent(_T("QueryServiceStatusEx in DoServiceStart firstly"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	if (ssProcess.dwCurrentState != SERVICE_STOPPED && ssProcess.dwCurrentState != SERVICE_STOP_PENDING)
	{
		ServiceReportEvent(_T("Service Running"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	dwStartTickCount = GetTickCount();
	dwOldCheckPoint = ssProcess.dwCheckPoint;

	while (ssProcess.dwCurrentState == SERVICE_STOP_PENDING)
	{
		dwWaitTime = ssProcess.dwWaitHint / 10;

		if (dwWaitTime < 1000)
			dwWaitTime = 1000;
		else if (dwWaitTime > 10000)
			dwWaitTime = 10000;

		Sleep(dwWaitTime);

		if (!QueryServiceStatusEx(	schService, 
								SC_STATUS_PROCESS_INFO,
								(LPBYTE)&ssProcess,
								sizeof(SERVICE_STATUS_PROCESS),
								&dwBytesNeeded))
		{
			ServiceReportEvent(_T("QueryServiceStatusEx in DoServiceStart secondly"));
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}

		if (ssProcess.dwCheckPoint > dwOldCheckPoint)
		{
			dwStartTickCount = GetTickCount();
			dwOldCheckPoint = ssProcess.dwCheckPoint;
		}
		else
		{
			if (GetTickCount() - dwStartTickCount > ssProcess.dwWaitHint)
			{
				printf("Timeout waiting for service to stop\n");
				CloseServiceHandle(schService);
				CloseServiceHandle(schSCManager);
				return;
			}
		}
	}

	if (!StartService(schService, 0, NULL))
	{
		ServiceReportEvent(_T("StartService in DoServiceStart"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}
	//else printf("Service start pending...\n");

	if (!QueryServiceStatusEx(	schService, 
								SC_STATUS_PROCESS_INFO,
								(LPBYTE)&ssProcess,
								sizeof(SERVICE_STATUS_PROCESS),
								&dwBytesNeeded))
	{
		ServiceReportEvent(_T("QueryServiceStatusEx in DoServiceStart thirdly"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	dwStartTickCount = GetTickCount();
	dwOldCheckPoint = ssProcess.dwCheckPoint;
	while (ssProcess.dwCurrentState == SERVICE_START_PENDING)
	{
		dwWaitTime = ssProcess.dwWaitHint / 10;

		if (dwWaitTime < 1000)
			dwWaitTime = 1000;
		else if (dwWaitTime > 10000)
			dwWaitTime = 10000;

		Sleep(dwWaitTime);

		if (!QueryServiceStatusEx(schService,
								SC_STATUS_PROCESS_INFO,
								(LPBYTE)&ssProcess,
								sizeof(SERVICE_STATUS_PROCESS),
								&dwBytesNeeded))
		{
			ServiceReportEvent(_T("QueryServiceStatusEx in DoServiceStart fourthly"));
			break;
		}

		if (ssProcess.dwCheckPoint > dwOldCheckPoint)
		{
			dwStartTickCount = GetTickCount();
			dwOldCheckPoint = ssProcess.dwCheckPoint;
		}
		else
		{
			if (GetTickCount() - dwStartTickCount > ssProcess.dwWaitHint)
			{
				// No progress made within the wait hint.
				break;
			}
		}
	}

	if (ssProcess.dwCurrentState == SERVICE_RUNNING)
	{
		printf("Start Service  Succeed\n");
	}
	else
	{
		printf("Start Service Failed \n");
		printf("  Current State: %d\n", ssProcess.dwCurrentState);
		printf("  Exit Code: %d\n", ssProcess.dwWin32ExitCode);
		printf("  Check Point: %d\n", ssProcess.dwCheckPoint);
		printf("  Wait Hint: %d\n", ssProcess.dwWaitHint);
	}

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);
}

void DoServiceStop()
{
	SERVICE_STATUS_PROCESS ssProcess = { 0 };
	DWORD dwStartTime		= GetTickCount();
	DWORD dwBytesNeeded = 0;
	DWORD dwTimeout			= 30000; 
	DWORD dwWaitTime		= 0;
	SC_HANDLE			schSCManager = NULL;
	SC_HANDLE			schService		= NULL;
	SERVICE_STATUS ssStatus = { 0 };

	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceStop"));
		return;
	}

	schService = OpenService(schSCManager,  SERVICENAME,
								SERVICE_STOP | SERVICE_QUERY_STATUS | SERVICE_ENUMERATE_DEPENDENTS);
	if (schService == NULL)
	{
		ServiceReportEvent(_T("OpenService in DoServiceStop"));
		CloseServiceHandle(schSCManager);
		return;
	}

	if (!QueryServiceStatusEx(	schService,
							SC_STATUS_PROCESS_INFO,
							(LPBYTE)&ssProcess,
							sizeof(SERVICE_STATUS_PROCESS),
							&dwBytesNeeded))
	{
		ServiceReportEvent(_T("QueryServiceStatusEx in DoServiceStop firstly"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	if (ssProcess.dwCurrentState == SERVICE_STOPPED)
	{
		printf("Service already stopped.\n");
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	while (ssProcess.dwCurrentState == SERVICE_STOP_PENDING)
	{
		printf("Service stop pending...\n");

		dwWaitTime = ssProcess.dwWaitHint / 10;

		if (dwWaitTime < 1000)
			dwWaitTime = 1000;
		else if (dwWaitTime > 10000)
			dwWaitTime = 10000;

		Sleep(dwWaitTime);

		if (!QueryServiceStatusEx(schService,
									SC_STATUS_PROCESS_INFO,
									(LPBYTE)&ssProcess,
									sizeof(SERVICE_STATUS_PROCESS),
									&dwBytesNeeded))
		{
			ServiceReportEvent(_T("QueryServiceStatusEx in DoServiceStop secondly"));
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}

		if (ssProcess.dwCurrentState == SERVICE_STOPPED)
		{
			printf("Stop Service Succeed\n");
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}

		if (GetTickCount() - dwStartTime > dwTimeout)
		{
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}
	}

	// If the service is running, dependencies must be stopped first.
	StopDependentServices(schSCManager, schService);

	// Send a stop code to the service.
	if (!ControlService(schService,  SERVICE_CONTROL_STOP,  (LPSERVICE_STATUS)&ssStatus))
	{
		ServiceReportEvent(_T("ControlService in DoServiceStop"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	// Wait for the service to stop.
	while (ssStatus.dwCurrentState != SERVICE_STOPPED)
	{
		Sleep(ssStatus.dwWaitHint);
		if (!QueryServiceStatusEx(	schService,
									SC_STATUS_PROCESS_INFO,
									(LPBYTE)&ssProcess,
									sizeof(SERVICE_STATUS_PROCESS),
									&dwBytesNeeded))
		{
			ServiceReportEvent(_T("QueryServiceStatusEx in DoServiceStop thirdly"));
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}

		if (ssProcess.dwCurrentState == SERVICE_STOPPED)
			break;

		if (GetTickCount() - dwStartTime > dwTimeout)
		{
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}
	}

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);

	printf("Stop Service Succeed\n");
}

void DoServiceEnable()
{
	SC_HANDLE schSCManager		= NULL;
	SC_HANDLE schService			= NULL;

	schSCManager = OpenSCManager(	NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceEnable"));
		return;
	}

	schService = OpenService(schSCManager, SERVICENAME,  SERVICE_CHANGE_CONFIG);
	if (schService == NULL)
	{
		ServiceReportEvent(_T("OpenService in DoServiceEnable"));
		CloseServiceHandle(schSCManager);
		return;
	}

	if (!ChangeServiceConfig(schService,						// handle of service 
										SERVICE_NO_CHANGE,		// service type: no change 
										SERVICE_DEMAND_START,  // service start type 
										SERVICE_NO_CHANGE,		// error control: no change 
										NULL,									 // binary path: no change 
										NULL,									 // load order group: no change 
										NULL,									 // tag ID: no change 
										NULL,									 // dependencies: no change 
										NULL,									 // account name: no change 
										NULL,									 // password: no change 
										NULL))									 // display name: no change
	{
		ServiceReportEvent(_T("ChangeServiceConfig in DoServiceEnable"));
	}
	else
		printf("Enable Service Succeed\n");

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);
}

void DoServiceDisable()
{
	SC_HANDLE schSCManager		= NULL;
	SC_HANDLE schService			= NULL;

	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceDisable"));
		return;
	}

	schService = OpenService(schSCManager,  SERVICENAME, SERVICE_CHANGE_CONFIG);
	if (schService == NULL)
	{
		ServiceReportEvent(_T("OpenService in DoServiceDisable"));
		CloseServiceHandle(schSCManager);
		return;
	}

	if (!ChangeServiceConfig(schService,					 // handle of service 
										SERVICE_NO_CHANGE,	// service type: no change 
										SERVICE_DISABLED,			// service start type 
										SERVICE_NO_CHANGE,	// error control: no change 
										NULL,								// binary path: no change 
										NULL,								// load order group: no change 
										NULL,								// tag ID: no change 
										NULL,								// dependencies: no change 
										NULL,								// account name: no change 
										NULL,								// password: no change 
										NULL))								// display name: no change
	{
		ServiceReportEvent(_T("ChangeServiceConfig in DoServiceDisable"));
	}
	else
		printf("Disable Service Succeed\n");

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);
}

void DoServiceQuery()
{
	SC_HANDLE schSCManager		= NULL;
	SC_HANDLE schService			= NULL;
	LPQUERY_SERVICE_CONFIG lpsc	= NULL;
	LPSERVICE_DESCRIPTION lpsd		= NULL;
	DWORD	dwBytesNeeded = 0;
	DWORD	cbBufSize = 0;
	DWORD	dwError	= 0;

	schSCManager = OpenSCManager(NULL,  NULL,  SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceQuery"));
		return;
	}

	schService = OpenService(schSCManager,  SERVICENAME, SERVICE_QUERY_CONFIG);
	if (schService == NULL)
	{
		ServiceReportEvent(_T("OpenService in DoServiceQuery"));
		CloseServiceHandle(schSCManager);
		return;
	}

	if (!QueryServiceConfig(schService, NULL, 0, &dwBytesNeeded))
	{
		dwError = GetLastError();
		if (ERROR_INSUFFICIENT_BUFFER == dwError)
		{
			cbBufSize = dwBytesNeeded;
			lpsc = (LPQUERY_SERVICE_CONFIG)LocalAlloc(LMEM_FIXED, cbBufSize);
		}
		else
		{
			ServiceReportEvent(_T("QueryServiceConfig in DoServiceQuery firstly"));
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}
	}

	if (!QueryServiceConfig(schService, lpsc,  cbBufSize, &dwBytesNeeded))
	{
		LocalFree(lpsc);
		lpsc = NULL;
		ServiceReportEvent(_T("QueryServiceConfig in DoServiceQuery secondly"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	if (!QueryServiceConfig2(schService, SERVICE_CONFIG_DESCRIPTION, NULL, 	0, 	&dwBytesNeeded))
	{
		dwError = GetLastError();
		if (ERROR_INSUFFICIENT_BUFFER == dwError)
		{
			cbBufSize = dwBytesNeeded;
			lpsd = (LPSERVICE_DESCRIPTION)LocalAlloc(LMEM_FIXED, cbBufSize);
		}
		else
		{
			LocalFree(lpsc);
			lpsc = NULL;
			ServiceReportEvent(_T("QueryServiceConfig2 in DoServiceQuery firstly"));
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return;
		}
	}

	if (!QueryServiceConfig2(schService, SERVICE_CONFIG_DESCRIPTION, (LPBYTE)lpsd, cbBufSize, &dwBytesNeeded))
	{
		LocalFree(lpsc);
		lpsc = NULL;
		LocalFree(lpsd);
		lpsd = NULL;
		ServiceReportEvent(_T("QueryServiceConfig2 in DoServiceQuery secondly"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}

	// Print the configuration information.
	_tprintf(_T("%s configuration: \n"), SERVICENAME);
	_tprintf(_T("  Type: 0x%x\n"), lpsc->dwServiceType);
	_tprintf(_T("  Start Type: 0x%x\n"), lpsc->dwStartType);
	_tprintf(_T("  Error Control: 0x%x\n"), lpsc->dwErrorControl);
	_tprintf(_T("  Binary path: %s\n"), lpsc->lpBinaryPathName);
	_tprintf(_T("  Account: %s\n"), lpsc->lpServiceStartName);

	if (lpsd->lpDescription != NULL && lstrcmp(lpsd->lpDescription, _T("")) != 0)
		_tprintf(_T("  Description: %s\n"), lpsd->lpDescription);
	if (lpsc->lpLoadOrderGroup != NULL && lstrcmp(lpsc->lpLoadOrderGroup, _T("")) != 0)
		_tprintf(_T("  Load order group: %s\n"), lpsc->lpLoadOrderGroup);
	if (lpsc->dwTagId != 0)
		_tprintf(_T("  Tag ID: %d\n"), lpsc->dwTagId);
	if (lpsc->lpDependencies != NULL && lstrcmp(lpsc->lpDependencies, _T("")) != 0)
		_tprintf(_T("  Dependencies: %s\n"), lpsc->lpDependencies);

	LocalFree(lpsc);
	LocalFree(lpsd);
	lpsc = NULL;
	lpsd = NULL;

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);
}

void DoServiceUpdate(LPTSTR szDesc)
{
	if (NULL == szDesc)
		return;

	SC_HANDLE schSCManager		= NULL;
	SC_HANDLE schService			= NULL;
	SERVICE_DESCRIPTION  sd		= { 0 };
	
	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (NULL == schSCManager)
	{
		ServiceReportEvent(_T("OpenSCManager in DoServiceUpdate"));
		return;
	}

	schService = OpenService(schSCManager, SERVICENAME, SERVICE_CHANGE_CONFIG);
	if (schService == NULL)
	{
		ServiceReportEvent(_T("OpenService in DoServiceUpdate"));
		CloseServiceHandle(schSCManager);
		return;
	}

	// Change the service description.
	sd.lpDescription = szDesc;
	if (!ChangeServiceConfig2(schService, SERVICE_CONFIG_DESCRIPTION, &sd))
	{
		ServiceReportEvent(_T("ChangeServiceConfig2 in DoServiceUpdate"));
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return;
	}
	else 
		printf("Update Service Succeed\n");

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);
}

BOOL  StopDependentServices(SC_HANDLE schSCManager, SC_HANDLE schService)
{
	DWORD i;
	DWORD dwBytesNeeded;
	DWORD dwCount;

	LPENUM_SERVICE_STATUS  lpDependencies = NULL;
	ENUM_SERVICE_STATUS     ess;
	SC_HANDLE							schDepService		= NULL;
	SERVICE_STATUS_PROCESS ssProcess = { 0 };
	SERVICE_STATUS	 ssStatus = { 0 };
	DWORD dwStartTime = GetTickCount();
	DWORD dwTimeout = 30000; // 30-second time-out

	// Pass a zero-length buffer to get the required buffer size.
	if (EnumDependentServices(schService, SERVICE_ACTIVE,
		lpDependencies, 0, &dwBytesNeeded, &dwCount))
	{
		// If the Enum call succeeds, then there are no dependent
		// services, so do nothing.
		return TRUE;
	}
	else
	{
		if (GetLastError() != ERROR_MORE_DATA)
			return FALSE; // Unexpected error

		// Allocate a buffer for the dependencies.
		lpDependencies = (LPENUM_SERVICE_STATUS)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dwBytesNeeded);
		if (!lpDependencies)
			return FALSE;

		__try
		{
			// Enumerate the dependencies.
			if (!EnumDependentServices(schService,
												SERVICE_ACTIVE,
												lpDependencies,
												dwBytesNeeded,
												&dwBytesNeeded,
												&dwCount))
			{
				return FALSE;
			}
		

			for (i = 0; i < dwCount; i++)
			{
				ess = *(lpDependencies + i);
				// Open the service.
				schDepService = OpenService(schSCManager, ess.lpServiceName, SERVICE_STOP | SERVICE_QUERY_STATUS);
				if (!schDepService)
					return FALSE;

				__try 
				{
					// Send a stop code.
					if (!ControlService(schDepService, SERVICE_CONTROL_STOP, (LPSERVICE_STATUS)&ssStatus))
					{
						return FALSE;
					}

					// Wait for the service to stop.
					while (ssStatus.dwCurrentState != SERVICE_STOPPED)
					{
						Sleep(ssStatus.dwWaitHint);
						if (!QueryServiceStatusEx(schDepService,
														SC_STATUS_PROCESS_INFO,
														(LPBYTE)&ssProcess,
														sizeof(SERVICE_STATUS_PROCESS),
														&dwBytesNeeded))
						{
							return FALSE;
						}

						if (ssProcess.dwCurrentState == SERVICE_STOPPED)
							break;

						if (GetTickCount() - dwStartTime > dwTimeout)
							return FALSE;
					}
				}
				__finally
				{
					// Always release the service handle.
					CloseServiceHandle(schDepService);
				}
			}
		}
		__finally
		{
			// Always free the enumeration buffer.
			HeapFree(GetProcessHeap(), 0, lpDependencies);
		}
	}
	return TRUE;
}


void DoServiceRegistry()
{
	HKEY hKey;
	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE,
											_T("SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application"),
											0, KEY_ALL_ACCESS, &hKey))
	{
		HKEY hSubKey;
		if (ERROR_SUCCESS == RegCreateKeyEx(hKey, SERVICENAME, 0, NULL, 0, KEY_ALL_ACCESS, NULL, &hSubKey, NULL))
		{
			TCHAR FilePath[MAX_PATH] = { 0 };
			if (GetModuleFileName(NULL, FilePath, MAX_PATH) != 0)
			{ 
				TCHAR* pFind = _tcsrchr(FilePath, _T('\\'));
				if (pFind != NULL)
				{
					int n = pFind - FilePath;
					ZeroMemory(&FilePath[n + 1], sizeof(TCHAR) * (MAX_PATH - 1 - n ));
					_tcscat_s(FilePath, MAX_PATH, _T("ServiceMsg.dll"));
//#if _DEBUG
//					_tprintf(_T("%s\n"), FilePath);
//#endif
					n = _tcslen(FilePath) + 1;
					RegSetValueEx(hSubKey, _T("EventMessageFile"), 0, REG_SZ, (BYTE*)FilePath, sizeof(TCHAR) * n);
					DWORD dwValue = 0x00000007;
					RegSetValueEx(hSubKey, _T("TypesSupported"), 0, REG_DWORD, (BYTE*)&dwValue, sizeof(dwValue));
				}
			}
			RegCloseKey(hSubKey);
		}
		RegCloseKey(hKey);
	}
}

void DoServiceTestRun()
{
	RunView();
}

void DoServiceTestStop()
{
	StopView();
}


