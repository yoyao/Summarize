#include "stdafx.h"
#include "RecvTcp.h"
#include <process.h>
#include "StateMachine.h"
#include "LOG.h"
#include "json\json.h"
#include "ParseJson.h"

unsigned int __stdcall RecvTcpThreadFunc(void* pArguments);

uintptr_t OnRecvTcp(const StateMachine* machine)
{
	return _beginthreadex(NULL, 0, RecvTcpThreadFunc, (void*)machine, 0, NULL);
}

unsigned int __stdcall RecvTcpThreadFunc(void* pArguments)
{
	assert(pArguments != NULL);
	if (NULL == pArguments)
	{
		LOGW(_T("pArguments=NULL. Line %d, Function %s, File %s\n"), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	StateMachine* machine = (StateMachine*)pArguments;

	SOCKET ls = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0);
	if (INVALID_SOCKET == ls)
	{
		LOGW(_T("WSASocket failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	struct sockaddr_in from = { 0 };
	from.sin_family = AF_INET;
	from.sin_addr.s_addr = INADDR_ANY;
	from.sin_port = htons(machine->_Port);
	if (bind(ls, (sockaddr*)&from, sizeof(from)) == SOCKET_ERROR)
	{
		LOGW(_T("bind failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		closesocket(ls);
		return 0;
	}

	WSAEVENT ListenEvent = WSACreateEvent();
	WSAEventSelect(ls, ListenEvent, FD_ACCEPT|FD_CLOSE);

	if (listen(ls, SOMAXCONN) == SOCKET_ERROR) 
	{
		LOGW(_T("listen failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		closesocket(ls);
		return 0;
	}

	SOCKET rs = INVALID_SOCKET;
	SOCKET arrSocket[2] = { ls, rs };

	WSAEVENT events[3] = { machine->StopEvent, ListenEvent, 0};
	DWORD dwTotal = 2;
	DWORD dwIndex = 0;

	struct sockaddr_in truefrom = { 0 };
	int truesize = sizeof(truefrom);

	while (1)
	{
		dwIndex = WSAWaitForMultipleEvents(dwTotal, events, FALSE, WSA_INFINITE, FALSE);
		if (WAIT_FAILED == dwIndex)
		{
			LOGW(_T("WSAWaitForMultipleEvents failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
			break;
		}

		if (WSA_WAIT_EVENT_0 == dwIndex)
		{
			break;
		}

		LOGW(_T("Before NetworkEvents. dwInex=%d\n"), dwIndex);

		WSANETWORKEVENTS NetworkEvents = { 0 };
		WSAEnumNetworkEvents(arrSocket[dwIndex - WSA_WAIT_EVENT_0 - 1], events[dwIndex - WSA_WAIT_EVENT_0], &NetworkEvents);

		// accept the client;
		if (NetworkEvents.lNetworkEvents & FD_ACCEPT)
		{
			if (NetworkEvents.iErrorCode[FD_ACCEPT_BIT] != 0) 
			{
				continue;
			}
			rs = accept(arrSocket[dwIndex - WSA_WAIT_EVENT_0 - 1], (sockaddr*)&truefrom, &truesize);
			if (rs == INVALID_SOCKET) 
			{
				continue;
			}

			LOGW(_T("accept. dwInex=%d\n"), dwIndex);

			WSAEVENT RecvEvent = WSACreateEvent();
			arrSocket[dwIndex - WSA_WAIT_EVENT_0] = rs;
			WSAEventSelect(rs, RecvEvent, FD_READ | FD_CLOSE);

			events[dwTotal] = RecvEvent;
			++dwTotal;
		}

		// recv the data;
		if (NetworkEvents.lNetworkEvents & FD_READ)
		{
			if (NetworkEvents.iErrorCode[FD_READ_BIT] != 0)
			{
				continue;
			}
			LOGW(_T("recv. dwIndex=%d\n"), dwIndex);
			char message[1024] = { 0 };
			int ret = recv(arrSocket[dwIndex - WSA_WAIT_EVENT_0 - 1], (char *)message, 1024, 0);
			if (SOCKET_ERROR == ret)
			{
				LOGW(_T("recv failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
				closesocket(arrSocket[dwIndex - WSA_WAIT_EVENT_0 - 1]);
				WSACloseEvent(events[dwIndex - WSA_WAIT_EVENT_0]);
				--dwTotal;
				continue;
			}

			LOGW(_T("message = %s, ret=%d\n"), message, ret);

			std::string document(message);
			printf("%s", message);

			ParseJson(document);
		}

		// close the recv socket;
		if (NetworkEvents.lNetworkEvents & FD_CLOSE) 
		{
			if (NetworkEvents.iErrorCode[FD_CLOSE_BIT] != 0) 
			{
				continue;
			}
			closesocket(arrSocket[dwIndex - WSA_WAIT_EVENT_0-1]);
			WSACloseEvent(events[dwIndex - WSA_WAIT_EVENT_0]);
			--dwTotal;
		}
	}

	closesocket(ls);

	LOGW(_T("Function %s ended.\n"), __FUNCTIONW__);

	_endthreadex(0);

	return 0;
}