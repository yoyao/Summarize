#include "stdafx.h"
#include <process.h>
#include "RegVM.h"
#include "StateMachine.h"
#include "LOG.h"
#include "json\json.h"
#include "Domain.h"


unsigned int __stdcall RegVMThreadFunc(void* pArguments);

uintptr_t OnRegVM(const StateMachine* machine)
{
	if (ReadPrivateFile())
	{
		return 0;
	}
	else
		return _beginthreadex(NULL, 0, RegVMThreadFunc, (void*)machine, 0, NULL);
}

unsigned int __stdcall RegVMThreadFunc(void* pArguments)
{
	assert(pArguments != NULL);

	if (NULL == pArguments)
	{
		LOGW(_T("pArguments=NULL. Line %d, Function %s, File %s\n"), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	StateMachine* machine = (StateMachine*)pArguments;

	SOCKET s = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0);
	if (INVALID_SOCKET == s)
	{
		LOGW(_T("WSASocket failed with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		return 0;
	}

	struct sockaddr_in to = { 0 };
	ULONG addr = 0;
	to.sin_family = AF_INET;
	to.sin_port = htons(machine->_Port);
	InetPton(AF_INET, (machine->_ServerIP).c_str(), &addr);
	to.sin_addr.s_addr = addr;

	LOGW(_T("port=%d, serverip=%s\n"), machine->_Port, machine->_ServerIP.c_str());

	int ret = connect(s, (sockaddr *)&to, sizeof(to));
	DWORD dwIndex = 0;
	while ( SOCKET_ERROR == ret )
	{
		LOGW(_T("connect faild with error: %d. Line %d, Function %s, File %s\n"), WSAGetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		dwIndex = WaitForSingleObject(machine->StopEvent, 10000);
		if (WAIT_FAILED == dwIndex)
		{
			LOGW(_T("WaitForSingleObject failed with error: %d. Line %d, Function %s, File %s\n"), GetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
			break;
		}

		if (WAIT_OBJECT_0 == dwIndex)
		{
			break;
		}

		ret = connect(s, (sockaddr *)&to, sizeof(to));
	}

	if (ret != SOCKET_ERROR)
	{
		mystring agentIP = machine->_AgentIP;
		size_t len = agentIP.size() * sizeof(TCHAR) + 2;
		char buffer[1024] = { 0 };
		size_t i = 0;
		wcstombs_s(&i, buffer, 1024, agentIP.c_str(), len);

		Json::Value root;
		Json::Value item;
		Json::Value subitem;

		root["agentreq"] = Json::Value::nullRef;
		item["registerDesktop"] = Json::Value::nullRef;
		subitem["ip"] = buffer;
		item["registerDesktop"] = subitem;
		root["agentreq"] = item;
		
		JSONCPP_STRING str = root.toStyledString();

		memset(buffer, 0, 1024);
		memcpy_s(buffer, 1024, str.c_str(), str.size());

		ret = send(s, buffer, str.size(), 0);
		if (ret != SOCKET_ERROR)
		{
			LOGW(_T("send bytes = %d\n"), ret);
		}
		else
		{
			LOGW(_T("send faild with error: %d. Line %d, Function %s, File %s\n"), GetLastError(), __LINE__, __FUNCTIONW__, __FILEW__);
		}
	}

	closesocket(s);

	LOGW(_T("Function %s ended.\n"), __FUNCTIONW__);

	_endthreadex(0);

	return 0;
}
