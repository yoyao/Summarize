#pragma once 

class StateMachine
{
private:
	StateMachine();
	~StateMachine();
	StateMachine(const StateMachine& other) { };
	StateMachine& operator=(const StateMachine& other) {	};

	mystring GetOSVersion();
	mystring GetAgentIP(mystring ServerIP);
	mystring TimeToString(LARGE_INTEGER time);
	void Init();
	
	static StateMachine*	m_pStateMachine;
public:
	static StateMachine* GetInstance();
	static void Release();

	void UpdateMachineState(int nPort, const mystring& ServerIP, const mystring& UUID, const mystring& GridName, const mystring& Interval);
	void EnumSession();
	void static SetPreUserName(mystring PreUserName);
	void static SetServerIP(mystring ServerIP);
	void static SetRestore(mystring restore);

	int					_Port;
	int					_Interval;
	mystring			_Dir;
	mystring			_ServerIP;
	mystring			_UUID;
	mystring			_GridName;
	mystring			_AD;
	mystring			_PreUserName;
	mystring			_AgentIP;
	mystring			_UserAccount;
	mystring			_OSVersion;
	mystring			_ComputerName;
	bool					_IsInstalled;
	bool					_IsRestore;
	bool					_FireWall;

	// SESSION��Ϣ
	ULONG			_SessionID;
	mystring			_ClientIP;
	mystring			_UserName;
	mystring			_DomainName;
	mystring			_WinStationName;
	mystring			_SessionState;
	mystring			_LogonTime;
	mystring			_ConnectTime;
	mystring			_DisconnectTime;
	mystring			_LastInputTime;
	mystring			_CurrentTime;
	mystring			_IdleTime;
	mystring			_TimeStamp;

	WSAEVENT		StopEvent;		//�˳����ͺͽ����̵߳��¼�
	WSAEVENT		RecvEvent;		//��SOCKET��FD_READ�󶨵Ľ����¼�
};