#pragma once

void LOGA(char* format, ...);
void LOGW(wchar_t* format, ...);