#pragma once

class StateMachine;

uintptr_t OnRegVM(const StateMachine* machine);