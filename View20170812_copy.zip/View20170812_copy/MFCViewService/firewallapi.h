﻿#pragma once
#pragma pack(push, 8)

#include <comdef.h>

//
// Forward references and typedefs
//

struct __declspec(uuid("58fbcf7c-e7a9-467c-80b3-fc65e8fcca08"))
/* LIBID */ __NetFwTypeLib;
struct __declspec(uuid("d4becddf-6f73-4a83-b832-9c66874cd20e"))
/* dual interface */ INetFwRemoteAdminSettings;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0001;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0002;
struct __declspec(uuid("a6207b2e-7cdd-426a-951e-5e1cbc5afead"))
/* dual interface */ INetFwIcmpSettings;
struct __declspec(uuid("e0483ba0-47ff-4d9c-a6d6-7741d0b195f7"))
/* dual interface */ INetFwOpenPort;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0003;
struct __declspec(uuid("c0e9d7fa-e07e-430a-b19a-090ce82d92e2"))
/* dual interface */ INetFwOpenPorts;
struct __declspec(uuid("79fd57c8-908e-4a36-9888-d5b3f0a444cf"))
/* dual interface */ INetFwService;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0004;
struct __declspec(uuid("79649bb4-903e-421b-94c9-79848e79f6ee"))
/* dual interface */ INetFwServices;
struct __declspec(uuid("b5e64ffa-c2c5-444e-a301-fb5e00018050"))
/* dual interface */ INetFwAuthorizedApplication;
struct __declspec(uuid("644efd52-ccf9-486c-97a2-39f352570b30"))
/* dual interface */ INetFwAuthorizedApplications;
struct __declspec(uuid("8267bbe3-f890-491c-b7b6-2db1ef0e5d2b"))
/* dual interface */ INetFwServiceRestriction;
struct __declspec(uuid("9c4c6277-5027-441e-afae-ca1f542da009"))
/* dual interface */ INetFwRules;
struct __declspec(uuid("af230d27-baba-4e42-aced-f524f22cfce2"))
/* dual interface */ INetFwRule;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0005;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0006;
struct __declspec(uuid("9c27c8da-189b-4dde-89f7-8b39a316782c"))
/* dual interface */ INetFwRule2;
struct __declspec(uuid("b21563ff-d696-4222-ab46-4e89b73ab34a"))
/* dual interface */ INetFwRule3;
struct __declspec(uuid("174a0dda-e9f9-449d-993b-21ab667ca456"))
/* dual interface */ INetFwProfile;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0007;
struct __declspec(uuid("d46d2478-9ac9-4008-9dc7-5563ce5536cc"))
/* dual interface */ INetFwPolicy;
struct __declspec(uuid("98325047-c671-4174-8d81-defcd3f03186"))
/* dual interface */ INetFwPolicy2;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0008;
enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0009;
struct __declspec(uuid("f7898af5-cac4-4632-a2ec-da06e5111af2"))
/* dual interface */ INetFwMgr;
struct __declspec(uuid("71881699-18f4-458b-b892-3ffce5e07f75"))
/* dual interface */ INetFwProduct;
struct __declspec(uuid("39eb36e0-2097-40bd-8af2-63a13b525362"))
/* dual interface */ INetFwProducts;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0001 NET_FW_IP_VERSION_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0002 NET_FW_SCOPE_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0003 NET_FW_IP_PROTOCOL_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0004 NET_FW_SERVICE_TYPE_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0005 NET_FW_RULE_DIRECTION_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0006 NET_FW_ACTION_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0007 NET_FW_PROFILE_TYPE_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0008 NET_FW_PROFILE_TYPE2_;
typedef enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0009 NET_FW_MODIFY_STATE_;

//
// Smart pointer typedef declarations
//

_COM_SMARTPTR_TYPEDEF(INetFwRemoteAdminSettings, __uuidof(INetFwRemoteAdminSettings));
_COM_SMARTPTR_TYPEDEF(INetFwIcmpSettings, __uuidof(INetFwIcmpSettings));
_COM_SMARTPTR_TYPEDEF(INetFwOpenPort, __uuidof(INetFwOpenPort));
_COM_SMARTPTR_TYPEDEF(INetFwOpenPorts, __uuidof(INetFwOpenPorts));
_COM_SMARTPTR_TYPEDEF(INetFwService, __uuidof(INetFwService));
_COM_SMARTPTR_TYPEDEF(INetFwServices, __uuidof(INetFwServices));
_COM_SMARTPTR_TYPEDEF(INetFwAuthorizedApplication, __uuidof(INetFwAuthorizedApplication));
_COM_SMARTPTR_TYPEDEF(INetFwAuthorizedApplications, __uuidof(INetFwAuthorizedApplications));
_COM_SMARTPTR_TYPEDEF(INetFwRule, __uuidof(INetFwRule));
_COM_SMARTPTR_TYPEDEF(INetFwRules, __uuidof(INetFwRules));
_COM_SMARTPTR_TYPEDEF(INetFwServiceRestriction, __uuidof(INetFwServiceRestriction));
_COM_SMARTPTR_TYPEDEF(INetFwRule2, __uuidof(INetFwRule2));
_COM_SMARTPTR_TYPEDEF(INetFwRule3, __uuidof(INetFwRule3));
_COM_SMARTPTR_TYPEDEF(INetFwProfile, __uuidof(INetFwProfile));
_COM_SMARTPTR_TYPEDEF(INetFwPolicy, __uuidof(INetFwPolicy));
_COM_SMARTPTR_TYPEDEF(INetFwPolicy2, __uuidof(INetFwPolicy2));
_COM_SMARTPTR_TYPEDEF(INetFwMgr, __uuidof(INetFwMgr));
_COM_SMARTPTR_TYPEDEF(INetFwProduct, __uuidof(INetFwProduct));
_COM_SMARTPTR_TYPEDEF(INetFwProducts, __uuidof(INetFwProducts));

//
// Type library items
//

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0001
{
    NET_FW_IP_VERSION_V4 = 0,
    NET_FW_IP_VERSION_V6 = 1,
    NET_FW_IP_VERSION_ANY = 2,
    NET_FW_IP_VERSION_MAX = 3
};

struct __declspec(uuid("d4becddf-6f73-4a83-b832-9c66874cd20e"))
INetFwRemoteAdminSettings : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetIpVersion,put=PutIpVersion))
    NET_FW_IP_VERSION_ IpVersion;
    __declspec(property(get=GetScope,put=PutScope))
    NET_FW_SCOPE_ Scope;
    __declspec(property(get=GetRemoteAddresses,put=PutRemoteAddresses))
    _bstr_t RemoteAddresses;
    __declspec(property(get=GetEnabled,put=PutEnabled))
    VARIANT_BOOL Enabled;

    //
    // Wrapper methods for error-handling
    //

    NET_FW_IP_VERSION_ GetIpVersion ( );
    void PutIpVersion (
        NET_FW_IP_VERSION_ IpVersion );
    NET_FW_SCOPE_ GetScope ( );
    void PutScope (
        NET_FW_SCOPE_ Scope );
    _bstr_t GetRemoteAddresses ( );
    void PutRemoteAddresses (
        _bstr_t remoteAddrs );
    VARIANT_BOOL GetEnabled ( );
    void PutEnabled (
        VARIANT_BOOL Enabled );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_IpVersion (
        /*[out,retval]*/ NET_FW_IP_VERSION_ * IpVersion ) = 0;
      virtual HRESULT __stdcall put_IpVersion (
        /*[in]*/ NET_FW_IP_VERSION_ IpVersion ) = 0;
      virtual HRESULT __stdcall get_Scope (
        /*[out,retval]*/ NET_FW_SCOPE_ * Scope ) = 0;
      virtual HRESULT __stdcall put_Scope (
        /*[in]*/ NET_FW_SCOPE_ Scope ) = 0;
      virtual HRESULT __stdcall get_RemoteAddresses (
        /*[out,retval]*/ BSTR * remoteAddrs ) = 0;
      virtual HRESULT __stdcall put_RemoteAddresses (
        /*[in]*/ BSTR remoteAddrs ) = 0;
      virtual HRESULT __stdcall get_Enabled (
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_Enabled (
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0002
{
    NET_FW_SCOPE_ALL = 0,
    NET_FW_SCOPE_LOCAL_SUBNET = 1,
    NET_FW_SCOPE_CUSTOM = 2,
    NET_FW_SCOPE_MAX = 3
};

struct __declspec(uuid("a6207b2e-7cdd-426a-951e-5e1cbc5afead"))
INetFwIcmpSettings : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetAllowOutboundDestinationUnreachable,put=PutAllowOutboundDestinationUnreachable))
    VARIANT_BOOL AllowOutboundDestinationUnreachable;
    __declspec(property(get=GetAllowRedirect,put=PutAllowRedirect))
    VARIANT_BOOL AllowRedirect;
    __declspec(property(get=GetAllowInboundEchoRequest,put=PutAllowInboundEchoRequest))
    VARIANT_BOOL AllowInboundEchoRequest;
    __declspec(property(get=GetAllowOutboundTimeExceeded,put=PutAllowOutboundTimeExceeded))
    VARIANT_BOOL AllowOutboundTimeExceeded;
    __declspec(property(get=GetAllowOutboundParameterProblem,put=PutAllowOutboundParameterProblem))
    VARIANT_BOOL AllowOutboundParameterProblem;
    __declspec(property(get=GetAllowOutboundSourceQuench,put=PutAllowOutboundSourceQuench))
    VARIANT_BOOL AllowOutboundSourceQuench;
    __declspec(property(get=GetAllowInboundRouterRequest,put=PutAllowInboundRouterRequest))
    VARIANT_BOOL AllowInboundRouterRequest;
    __declspec(property(get=GetAllowInboundTimestampRequest,put=PutAllowInboundTimestampRequest))
    VARIANT_BOOL AllowInboundTimestampRequest;
    __declspec(property(get=GetAllowInboundMaskRequest,put=PutAllowInboundMaskRequest))
    VARIANT_BOOL AllowInboundMaskRequest;
    __declspec(property(get=GetAllowOutboundPacketTooBig,put=PutAllowOutboundPacketTooBig))
    VARIANT_BOOL AllowOutboundPacketTooBig;

    //
    // Wrapper methods for error-handling
    //

    VARIANT_BOOL GetAllowOutboundDestinationUnreachable ( );
    void PutAllowOutboundDestinationUnreachable (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowRedirect ( );
    void PutAllowRedirect (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowInboundEchoRequest ( );
    void PutAllowInboundEchoRequest (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowOutboundTimeExceeded ( );
    void PutAllowOutboundTimeExceeded (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowOutboundParameterProblem ( );
    void PutAllowOutboundParameterProblem (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowOutboundSourceQuench ( );
    void PutAllowOutboundSourceQuench (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowInboundRouterRequest ( );
    void PutAllowInboundRouterRequest (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowInboundTimestampRequest ( );
    void PutAllowInboundTimestampRequest (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowInboundMaskRequest ( );
    void PutAllowInboundMaskRequest (
        VARIANT_BOOL allow );
    VARIANT_BOOL GetAllowOutboundPacketTooBig ( );
    void PutAllowOutboundPacketTooBig (
        VARIANT_BOOL allow );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_AllowOutboundDestinationUnreachable (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowOutboundDestinationUnreachable (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowRedirect (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowRedirect (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowInboundEchoRequest (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowInboundEchoRequest (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowOutboundTimeExceeded (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowOutboundTimeExceeded (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowOutboundParameterProblem (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowOutboundParameterProblem (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowOutboundSourceQuench (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowOutboundSourceQuench (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowInboundRouterRequest (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowInboundRouterRequest (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowInboundTimestampRequest (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowInboundTimestampRequest (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowInboundMaskRequest (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowInboundMaskRequest (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
      virtual HRESULT __stdcall get_AllowOutboundPacketTooBig (
        /*[out,retval]*/ VARIANT_BOOL * allow ) = 0;
      virtual HRESULT __stdcall put_AllowOutboundPacketTooBig (
        /*[in]*/ VARIANT_BOOL allow ) = 0;
};

struct __declspec(uuid("e0483ba0-47ff-4d9c-a6d6-7741d0b195f7"))
INetFwOpenPort : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetName,put=PutName))
    _bstr_t Name;
    __declspec(property(get=GetIpVersion,put=PutIpVersion))
    NET_FW_IP_VERSION_ IpVersion;
    __declspec(property(get=GetProtocol,put=PutProtocol))
    NET_FW_IP_PROTOCOL_ Protocol;
    __declspec(property(get=GetPort,put=PutPort))
    long Port;
    __declspec(property(get=GetScope,put=PutScope))
    NET_FW_SCOPE_ Scope;
    __declspec(property(get=GetRemoteAddresses,put=PutRemoteAddresses))
    _bstr_t RemoteAddresses;
    __declspec(property(get=GetEnabled,put=PutEnabled))
    VARIANT_BOOL Enabled;
    __declspec(property(get=GetBuiltIn))
    VARIANT_BOOL BuiltIn;

    //
    // Wrapper methods for error-handling
    //

    _bstr_t GetName ( );
    void PutName (
        _bstr_t Name );
    NET_FW_IP_VERSION_ GetIpVersion ( );
    void PutIpVersion (
        NET_FW_IP_VERSION_ IpVersion );
    NET_FW_IP_PROTOCOL_ GetProtocol ( );
    void PutProtocol (
        NET_FW_IP_PROTOCOL_ ipProtocol );
    long GetPort ( );
    void PutPort (
        long portNumber );
    NET_FW_SCOPE_ GetScope ( );
    void PutScope (
        NET_FW_SCOPE_ Scope );
    _bstr_t GetRemoteAddresses ( );
    void PutRemoteAddresses (
        _bstr_t remoteAddrs );
    VARIANT_BOOL GetEnabled ( );
    void PutEnabled (
        VARIANT_BOOL Enabled );
    VARIANT_BOOL GetBuiltIn ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Name (
        /*[out,retval]*/ BSTR * Name ) = 0;
      virtual HRESULT __stdcall put_Name (
        /*[in]*/ BSTR Name ) = 0;
      virtual HRESULT __stdcall get_IpVersion (
        /*[out,retval]*/ NET_FW_IP_VERSION_ * IpVersion ) = 0;
      virtual HRESULT __stdcall put_IpVersion (
        /*[in]*/ NET_FW_IP_VERSION_ IpVersion ) = 0;
      virtual HRESULT __stdcall get_Protocol (
        /*[out,retval]*/ NET_FW_IP_PROTOCOL_ * ipProtocol ) = 0;
      virtual HRESULT __stdcall put_Protocol (
        /*[in]*/ NET_FW_IP_PROTOCOL_ ipProtocol ) = 0;
      virtual HRESULT __stdcall get_Port (
        /*[out,retval]*/ long * portNumber ) = 0;
      virtual HRESULT __stdcall put_Port (
        /*[in]*/ long portNumber ) = 0;
      virtual HRESULT __stdcall get_Scope (
        /*[out,retval]*/ NET_FW_SCOPE_ * Scope ) = 0;
      virtual HRESULT __stdcall put_Scope (
        /*[in]*/ NET_FW_SCOPE_ Scope ) = 0;
      virtual HRESULT __stdcall get_RemoteAddresses (
        /*[out,retval]*/ BSTR * remoteAddrs ) = 0;
      virtual HRESULT __stdcall put_RemoteAddresses (
        /*[in]*/ BSTR remoteAddrs ) = 0;
      virtual HRESULT __stdcall get_Enabled (
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_Enabled (
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
      virtual HRESULT __stdcall get_BuiltIn (
        /*[out,retval]*/ VARIANT_BOOL * BuiltIn ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0003
{
    NET_FW_IP_PROTOCOL_TCP = 6,
    NET_FW_IP_PROTOCOL_UDP = 17,
    NET_FW_IP_PROTOCOL_ANY = 256
};

struct __declspec(uuid("c0e9d7fa-e07e-430a-b19a-090ce82d92e2"))
INetFwOpenPorts : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetCount))
    long Count;
    __declspec(property(get=Get_NewEnum))
    IUnknownPtr _NewEnum;

    //
    // Wrapper methods for error-handling
    //

    long GetCount ( );
    HRESULT Add (
        struct INetFwOpenPort * Port );
    HRESULT Remove (
        long portNumber,
        NET_FW_IP_PROTOCOL_ ipProtocol );
    INetFwOpenPortPtr Item (
        long portNumber,
        NET_FW_IP_PROTOCOL_ ipProtocol );
    IUnknownPtr Get_NewEnum ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Count (
        /*[out,retval]*/ long * Count ) = 0;
      virtual HRESULT __stdcall raw_Add (
        /*[in]*/ struct INetFwOpenPort * Port ) = 0;
      virtual HRESULT __stdcall raw_Remove (
        /*[in]*/ long portNumber,
        /*[in]*/ NET_FW_IP_PROTOCOL_ ipProtocol ) = 0;
      virtual HRESULT __stdcall raw_Item (
        /*[in]*/ long portNumber,
        /*[in]*/ NET_FW_IP_PROTOCOL_ ipProtocol,
        /*[out,retval]*/ struct INetFwOpenPort * * openPort ) = 0;
      virtual HRESULT __stdcall get__NewEnum (
        /*[out,retval]*/ IUnknown * * newEnum ) = 0;
};

struct __declspec(uuid("79fd57c8-908e-4a36-9888-d5b3f0a444cf"))
INetFwService : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetName))
    _bstr_t Name;
    __declspec(property(get=GetType))
    NET_FW_SERVICE_TYPE_ Type;
    __declspec(property(get=GetCustomized))
    VARIANT_BOOL Customized;
    __declspec(property(get=GetIpVersion,put=PutIpVersion))
    NET_FW_IP_VERSION_ IpVersion;
    __declspec(property(get=GetScope,put=PutScope))
    NET_FW_SCOPE_ Scope;
    __declspec(property(get=GetRemoteAddresses,put=PutRemoteAddresses))
    _bstr_t RemoteAddresses;
    __declspec(property(get=GetEnabled,put=PutEnabled))
    VARIANT_BOOL Enabled;
    __declspec(property(get=GetGloballyOpenPorts))
    INetFwOpenPortsPtr GloballyOpenPorts;

    //
    // Wrapper methods for error-handling
    //

    _bstr_t GetName ( );
    NET_FW_SERVICE_TYPE_ GetType ( );
    VARIANT_BOOL GetCustomized ( );
    NET_FW_IP_VERSION_ GetIpVersion ( );
    void PutIpVersion (
        NET_FW_IP_VERSION_ IpVersion );
    NET_FW_SCOPE_ GetScope ( );
    void PutScope (
        NET_FW_SCOPE_ Scope );
    _bstr_t GetRemoteAddresses ( );
    void PutRemoteAddresses (
        _bstr_t remoteAddrs );
    VARIANT_BOOL GetEnabled ( );
    void PutEnabled (
        VARIANT_BOOL Enabled );
    INetFwOpenPortsPtr GetGloballyOpenPorts ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Name (
        /*[out,retval]*/ BSTR * Name ) = 0;
      virtual HRESULT __stdcall get_Type (
        /*[out,retval]*/ NET_FW_SERVICE_TYPE_ * Type ) = 0;
      virtual HRESULT __stdcall get_Customized (
        /*[out,retval]*/ VARIANT_BOOL * Customized ) = 0;
      virtual HRESULT __stdcall get_IpVersion (
        /*[out,retval]*/ NET_FW_IP_VERSION_ * IpVersion ) = 0;
      virtual HRESULT __stdcall put_IpVersion (
        /*[in]*/ NET_FW_IP_VERSION_ IpVersion ) = 0;
      virtual HRESULT __stdcall get_Scope (
        /*[out,retval]*/ NET_FW_SCOPE_ * Scope ) = 0;
      virtual HRESULT __stdcall put_Scope (
        /*[in]*/ NET_FW_SCOPE_ Scope ) = 0;
      virtual HRESULT __stdcall get_RemoteAddresses (
        /*[out,retval]*/ BSTR * remoteAddrs ) = 0;
      virtual HRESULT __stdcall put_RemoteAddresses (
        /*[in]*/ BSTR remoteAddrs ) = 0;
      virtual HRESULT __stdcall get_Enabled (
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_Enabled (
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
      virtual HRESULT __stdcall get_GloballyOpenPorts (
        /*[out,retval]*/ struct INetFwOpenPorts * * openPorts ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0004
{
    NET_FW_SERVICE_FILE_AND_PRINT = 0,
    NET_FW_SERVICE_UPNP = 1,
    NET_FW_SERVICE_REMOTE_DESKTOP = 2,
    NET_FW_SERVICE_NONE = 3,
    NET_FW_SERVICE_TYPE_MAX = 4
};

struct __declspec(uuid("79649bb4-903e-421b-94c9-79848e79f6ee"))
INetFwServices : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetCount))
    long Count;
    __declspec(property(get=Get_NewEnum))
    IUnknownPtr _NewEnum;

    //
    // Wrapper methods for error-handling
    //

    long GetCount ( );
    INetFwServicePtr Item (
        NET_FW_SERVICE_TYPE_ svcType );
    IUnknownPtr Get_NewEnum ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Count (
        /*[out,retval]*/ long * Count ) = 0;
      virtual HRESULT __stdcall raw_Item (
        /*[in]*/ NET_FW_SERVICE_TYPE_ svcType,
        /*[out,retval]*/ struct INetFwService * * service ) = 0;
      virtual HRESULT __stdcall get__NewEnum (
        /*[out,retval]*/ IUnknown * * newEnum ) = 0;
};

struct __declspec(uuid("b5e64ffa-c2c5-444e-a301-fb5e00018050"))
INetFwAuthorizedApplication : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetName,put=PutName))
    _bstr_t Name;
    __declspec(property(get=GetProcessImageFileName,put=PutProcessImageFileName))
    _bstr_t ProcessImageFileName;
    __declspec(property(get=GetIpVersion,put=PutIpVersion))
    NET_FW_IP_VERSION_ IpVersion;
    __declspec(property(get=GetScope,put=PutScope))
    NET_FW_SCOPE_ Scope;
    __declspec(property(get=GetRemoteAddresses,put=PutRemoteAddresses))
    _bstr_t RemoteAddresses;
    __declspec(property(get=GetEnabled,put=PutEnabled))
    VARIANT_BOOL Enabled;

    //
    // Wrapper methods for error-handling
    //

    _bstr_t GetName ( );
    void PutName (
        _bstr_t Name );
    _bstr_t GetProcessImageFileName ( );
    void PutProcessImageFileName (
        _bstr_t imageFileName );
    NET_FW_IP_VERSION_ GetIpVersion ( );
    void PutIpVersion (
        NET_FW_IP_VERSION_ IpVersion );
    NET_FW_SCOPE_ GetScope ( );
    void PutScope (
        NET_FW_SCOPE_ Scope );
    _bstr_t GetRemoteAddresses ( );
    void PutRemoteAddresses (
        _bstr_t remoteAddrs );
    VARIANT_BOOL GetEnabled ( );
    void PutEnabled (
        VARIANT_BOOL Enabled );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Name (
        /*[out,retval]*/ BSTR * Name ) = 0;
      virtual HRESULT __stdcall put_Name (
        /*[in]*/ BSTR Name ) = 0;
      virtual HRESULT __stdcall get_ProcessImageFileName (
        /*[out,retval]*/ BSTR * imageFileName ) = 0;
      virtual HRESULT __stdcall put_ProcessImageFileName (
        /*[in]*/ BSTR imageFileName ) = 0;
      virtual HRESULT __stdcall get_IpVersion (
        /*[out,retval]*/ NET_FW_IP_VERSION_ * IpVersion ) = 0;
      virtual HRESULT __stdcall put_IpVersion (
        /*[in]*/ NET_FW_IP_VERSION_ IpVersion ) = 0;
      virtual HRESULT __stdcall get_Scope (
        /*[out,retval]*/ NET_FW_SCOPE_ * Scope ) = 0;
      virtual HRESULT __stdcall put_Scope (
        /*[in]*/ NET_FW_SCOPE_ Scope ) = 0;
      virtual HRESULT __stdcall get_RemoteAddresses (
        /*[out,retval]*/ BSTR * remoteAddrs ) = 0;
      virtual HRESULT __stdcall put_RemoteAddresses (
        /*[in]*/ BSTR remoteAddrs ) = 0;
      virtual HRESULT __stdcall get_Enabled (
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_Enabled (
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
};

struct __declspec(uuid("644efd52-ccf9-486c-97a2-39f352570b30"))
INetFwAuthorizedApplications : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetCount))
    long Count;
    __declspec(property(get=Get_NewEnum))
    IUnknownPtr _NewEnum;

    //
    // Wrapper methods for error-handling
    //

    long GetCount ( );
    HRESULT Add (
        struct INetFwAuthorizedApplication * app );
    HRESULT Remove (
        _bstr_t imageFileName );
    INetFwAuthorizedApplicationPtr Item (
        _bstr_t imageFileName );
    IUnknownPtr Get_NewEnum ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Count (
        /*[out,retval]*/ long * Count ) = 0;
      virtual HRESULT __stdcall raw_Add (
        /*[in]*/ struct INetFwAuthorizedApplication * app ) = 0;
      virtual HRESULT __stdcall raw_Remove (
        /*[in]*/ BSTR imageFileName ) = 0;
      virtual HRESULT __stdcall raw_Item (
        /*[in]*/ BSTR imageFileName,
        /*[out,retval]*/ struct INetFwAuthorizedApplication * * app ) = 0;
      virtual HRESULT __stdcall get__NewEnum (
        /*[out,retval]*/ IUnknown * * newEnum ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0005
{
    NET_FW_RULE_DIR_IN = 1,
    NET_FW_RULE_DIR_OUT = 2,
    NET_FW_RULE_DIR_MAX = 3
};

struct __declspec(uuid("af230d27-baba-4e42-aced-f524f22cfce2"))
INetFwRule : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetName,put=PutName))
    _bstr_t Name;
    __declspec(property(get=GetDescription,put=PutDescription))
    _bstr_t Description;
    __declspec(property(get=GetApplicationName,put=PutApplicationName))
    _bstr_t ApplicationName;
    __declspec(property(get=GetserviceName,put=PutserviceName))
    _bstr_t serviceName;
    __declspec(property(get=GetProtocol,put=PutProtocol))
    long Protocol;
    __declspec(property(get=GetLocalPorts,put=PutLocalPorts))
    _bstr_t LocalPorts;
    __declspec(property(get=GetRemotePorts,put=PutRemotePorts))
    _bstr_t RemotePorts;
    __declspec(property(get=GetLocalAddresses,put=PutLocalAddresses))
    _bstr_t LocalAddresses;
    __declspec(property(get=GetRemoteAddresses,put=PutRemoteAddresses))
    _bstr_t RemoteAddresses;
    __declspec(property(get=GetIcmpTypesAndCodes,put=PutIcmpTypesAndCodes))
    _bstr_t IcmpTypesAndCodes;
    __declspec(property(get=GetDirection,put=PutDirection))
    NET_FW_RULE_DIRECTION_ Direction;
    __declspec(property(get=GetInterfaces,put=PutInterfaces))
    _variant_t Interfaces;
    __declspec(property(get=GetInterfaceTypes,put=PutInterfaceTypes))
    _bstr_t InterfaceTypes;
    __declspec(property(get=GetEnabled,put=PutEnabled))
    VARIANT_BOOL Enabled;
    __declspec(property(get=GetGrouping,put=PutGrouping))
    _bstr_t Grouping;
    __declspec(property(get=GetProfiles,put=PutProfiles))
    long Profiles;
    __declspec(property(get=GetEdgeTraversal,put=PutEdgeTraversal))
    VARIANT_BOOL EdgeTraversal;
    __declspec(property(get=GetAction,put=PutAction))
    NET_FW_ACTION_ Action;

    //
    // Wrapper methods for error-handling
    //

    _bstr_t GetName ( );
    void PutName (
        _bstr_t Name );
    _bstr_t GetDescription ( );
    void PutDescription (
        _bstr_t desc );
    _bstr_t GetApplicationName ( );
    void PutApplicationName (
        _bstr_t imageFileName );
    _bstr_t GetserviceName ( );
    void PutserviceName (
        _bstr_t serviceName );
    long GetProtocol ( );
    void PutProtocol (
        long Protocol );
    _bstr_t GetLocalPorts ( );
    void PutLocalPorts (
        _bstr_t portNumbers );
    _bstr_t GetRemotePorts ( );
    void PutRemotePorts (
        _bstr_t portNumbers );
    _bstr_t GetLocalAddresses ( );
    void PutLocalAddresses (
        _bstr_t localAddrs );
    _bstr_t GetRemoteAddresses ( );
    void PutRemoteAddresses (
        _bstr_t remoteAddrs );
    _bstr_t GetIcmpTypesAndCodes ( );
    void PutIcmpTypesAndCodes (
        _bstr_t IcmpTypesAndCodes );
    NET_FW_RULE_DIRECTION_ GetDirection ( );
    void PutDirection (
        NET_FW_RULE_DIRECTION_ dir );
    _variant_t GetInterfaces ( );
    void PutInterfaces (
        const _variant_t & Interfaces );
    _bstr_t GetInterfaceTypes ( );
    void PutInterfaceTypes (
        _bstr_t InterfaceTypes );
    VARIANT_BOOL GetEnabled ( );
    void PutEnabled (
        VARIANT_BOOL Enabled );
    _bstr_t GetGrouping ( );
    void PutGrouping (
        _bstr_t context );
    long GetProfiles ( );
    void PutProfiles (
        long profileTypesBitmask );
    VARIANT_BOOL GetEdgeTraversal ( );
    void PutEdgeTraversal (
        VARIANT_BOOL Enabled );
    NET_FW_ACTION_ GetAction ( );
    void PutAction (
        NET_FW_ACTION_ Action );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Name (
        /*[out,retval]*/ BSTR * Name ) = 0;
      virtual HRESULT __stdcall put_Name (
        /*[in]*/ BSTR Name ) = 0;
      virtual HRESULT __stdcall get_Description (
        /*[out,retval]*/ BSTR * desc ) = 0;
      virtual HRESULT __stdcall put_Description (
        /*[in]*/ BSTR desc ) = 0;
      virtual HRESULT __stdcall get_ApplicationName (
        /*[out,retval]*/ BSTR * imageFileName ) = 0;
      virtual HRESULT __stdcall put_ApplicationName (
        /*[in]*/ BSTR imageFileName ) = 0;
      virtual HRESULT __stdcall get_serviceName (
        /*[out,retval]*/ BSTR * serviceName ) = 0;
      virtual HRESULT __stdcall put_serviceName (
        /*[in]*/ BSTR serviceName ) = 0;
      virtual HRESULT __stdcall get_Protocol (
        /*[out,retval]*/ long * Protocol ) = 0;
      virtual HRESULT __stdcall put_Protocol (
        /*[in]*/ long Protocol ) = 0;
      virtual HRESULT __stdcall get_LocalPorts (
        /*[out,retval]*/ BSTR * portNumbers ) = 0;
      virtual HRESULT __stdcall put_LocalPorts (
        /*[in]*/ BSTR portNumbers ) = 0;
      virtual HRESULT __stdcall get_RemotePorts (
        /*[out,retval]*/ BSTR * portNumbers ) = 0;
      virtual HRESULT __stdcall put_RemotePorts (
        /*[in]*/ BSTR portNumbers ) = 0;
      virtual HRESULT __stdcall get_LocalAddresses (
        /*[out,retval]*/ BSTR * localAddrs ) = 0;
      virtual HRESULT __stdcall put_LocalAddresses (
        /*[in]*/ BSTR localAddrs ) = 0;
      virtual HRESULT __stdcall get_RemoteAddresses (
        /*[out,retval]*/ BSTR * remoteAddrs ) = 0;
      virtual HRESULT __stdcall put_RemoteAddresses (
        /*[in]*/ BSTR remoteAddrs ) = 0;
      virtual HRESULT __stdcall get_IcmpTypesAndCodes (
        /*[out,retval]*/ BSTR * IcmpTypesAndCodes ) = 0;
      virtual HRESULT __stdcall put_IcmpTypesAndCodes (
        /*[in]*/ BSTR IcmpTypesAndCodes ) = 0;
      virtual HRESULT __stdcall get_Direction (
        /*[out,retval]*/ NET_FW_RULE_DIRECTION_ * dir ) = 0;
      virtual HRESULT __stdcall put_Direction (
        /*[in]*/ NET_FW_RULE_DIRECTION_ dir ) = 0;
      virtual HRESULT __stdcall get_Interfaces (
        /*[out,retval]*/ VARIANT * Interfaces ) = 0;
      virtual HRESULT __stdcall put_Interfaces (
        /*[in]*/ VARIANT Interfaces ) = 0;
      virtual HRESULT __stdcall get_InterfaceTypes (
        /*[out,retval]*/ BSTR * InterfaceTypes ) = 0;
      virtual HRESULT __stdcall put_InterfaceTypes (
        /*[in]*/ BSTR InterfaceTypes ) = 0;
      virtual HRESULT __stdcall get_Enabled (
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_Enabled (
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
      virtual HRESULT __stdcall get_Grouping (
        /*[out,retval]*/ BSTR * context ) = 0;
      virtual HRESULT __stdcall put_Grouping (
        /*[in]*/ BSTR context ) = 0;
      virtual HRESULT __stdcall get_Profiles (
        /*[out,retval]*/ long * profileTypesBitmask ) = 0;
      virtual HRESULT __stdcall put_Profiles (
        /*[in]*/ long profileTypesBitmask ) = 0;
      virtual HRESULT __stdcall get_EdgeTraversal (
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_EdgeTraversal (
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
      virtual HRESULT __stdcall get_Action (
        /*[out,retval]*/ NET_FW_ACTION_ * Action ) = 0;
      virtual HRESULT __stdcall put_Action (
        /*[in]*/ NET_FW_ACTION_ Action ) = 0;
};

struct __declspec(uuid("9c4c6277-5027-441e-afae-ca1f542da009"))
INetFwRules : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetCount))
    long Count;
    __declspec(property(get=Get_NewEnum))
    IUnknownPtr _NewEnum;

    //
    // Wrapper methods for error-handling
    //

    long GetCount ( );
    HRESULT Add (
        struct INetFwRule * rule );
    HRESULT Remove (
        _bstr_t Name );
    INetFwRulePtr Item (
        _bstr_t Name );
    IUnknownPtr Get_NewEnum ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Count (
        /*[out,retval]*/ long * Count ) = 0;
      virtual HRESULT __stdcall raw_Add (
        /*[in]*/ struct INetFwRule * rule ) = 0;
      virtual HRESULT __stdcall raw_Remove (
        /*[in]*/ BSTR Name ) = 0;
      virtual HRESULT __stdcall raw_Item (
        /*[in]*/ BSTR Name,
        /*[out,retval]*/ struct INetFwRule * * rule ) = 0;
      virtual HRESULT __stdcall get__NewEnum (
        /*[out,retval]*/ IUnknown * * newEnum ) = 0;
};

struct __declspec(uuid("8267bbe3-f890-491c-b7b6-2db1ef0e5d2b"))
INetFwServiceRestriction : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetRules))
    INetFwRulesPtr Rules;

    //
    // Wrapper methods for error-handling
    //

    HRESULT RestrictService (
        _bstr_t serviceName,
        _bstr_t appName,
        VARIANT_BOOL RestrictService,
        VARIANT_BOOL serviceSidRestricted );
    VARIANT_BOOL ServiceRestricted (
        _bstr_t serviceName,
        _bstr_t appName );
    INetFwRulesPtr GetRules ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall raw_RestrictService (
        /*[in]*/ BSTR serviceName,
        /*[in]*/ BSTR appName,
        /*[in]*/ VARIANT_BOOL RestrictService,
        /*[in]*/ VARIANT_BOOL serviceSidRestricted ) = 0;
      virtual HRESULT __stdcall raw_ServiceRestricted (
        /*[in]*/ BSTR serviceName,
        /*[in]*/ BSTR appName,
        /*[out,retval]*/ VARIANT_BOOL * ServiceRestricted ) = 0;
      virtual HRESULT __stdcall get_Rules (
        /*[out,retval]*/ struct INetFwRules * * Rules ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0006
{
    NET_FW_ACTION_BLOCK = 0,
    NET_FW_ACTION_ALLOW = 1,
    NET_FW_ACTION_MAX = 2
};

struct __declspec(uuid("9c27c8da-189b-4dde-89f7-8b39a316782c"))
INetFwRule2 : INetFwRule
{
    //
    // Property data
    //

    __declspec(property(get=GetEdgeTraversalOptions,put=PutEdgeTraversalOptions))
    long EdgeTraversalOptions;

    //
    // Wrapper methods for error-handling
    //

    long GetEdgeTraversalOptions ( );
    void PutEdgeTraversalOptions (
        long lOptions );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_EdgeTraversalOptions (
        /*[out,retval]*/ long * lOptions ) = 0;
      virtual HRESULT __stdcall put_EdgeTraversalOptions (
        /*[in]*/ long lOptions ) = 0;
};

struct __declspec(uuid("b21563ff-d696-4222-ab46-4e89b73ab34a"))
INetFwRule3 : INetFwRule2
{
    //
    // Property data
    //

    __declspec(property(get=GetLocalAppPackageId,put=PutLocalAppPackageId))
    _bstr_t LocalAppPackageId;
    __declspec(property(get=GetLocalUserOwner,put=PutLocalUserOwner))
    _bstr_t LocalUserOwner;
    __declspec(property(get=GetLocalUserAuthorizedList,put=PutLocalUserAuthorizedList))
    _bstr_t LocalUserAuthorizedList;
    __declspec(property(get=GetRemoteUserAuthorizedList,put=PutRemoteUserAuthorizedList))
    _bstr_t RemoteUserAuthorizedList;
    __declspec(property(get=GetRemoteMachineAuthorizedList,put=PutRemoteMachineAuthorizedList))
    _bstr_t RemoteMachineAuthorizedList;
    __declspec(property(get=GetSecureFlags,put=PutSecureFlags))
    long SecureFlags;

    //
    // Wrapper methods for error-handling
    //

    _bstr_t GetLocalAppPackageId ( );
    void PutLocalAppPackageId (
        _bstr_t wszPackageId );
    _bstr_t GetLocalUserOwner ( );
    void PutLocalUserOwner (
        _bstr_t wszUserOwner );
    _bstr_t GetLocalUserAuthorizedList ( );
    void PutLocalUserAuthorizedList (
        _bstr_t wszUserAuthList );
    _bstr_t GetRemoteUserAuthorizedList ( );
    void PutRemoteUserAuthorizedList (
        _bstr_t wszUserAuthList );
    _bstr_t GetRemoteMachineAuthorizedList ( );
    void PutRemoteMachineAuthorizedList (
        _bstr_t wszUserAuthList );
    long GetSecureFlags ( );
    void PutSecureFlags (
        long lOptions );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_LocalAppPackageId (
        /*[out,retval]*/ BSTR * wszPackageId ) = 0;
      virtual HRESULT __stdcall put_LocalAppPackageId (
        /*[in]*/ BSTR wszPackageId ) = 0;
      virtual HRESULT __stdcall get_LocalUserOwner (
        /*[out,retval]*/ BSTR * wszUserOwner ) = 0;
      virtual HRESULT __stdcall put_LocalUserOwner (
        /*[in]*/ BSTR wszUserOwner ) = 0;
      virtual HRESULT __stdcall get_LocalUserAuthorizedList (
        /*[out,retval]*/ BSTR * wszUserAuthList ) = 0;
      virtual HRESULT __stdcall put_LocalUserAuthorizedList (
        /*[in]*/ BSTR wszUserAuthList ) = 0;
      virtual HRESULT __stdcall get_RemoteUserAuthorizedList (
        /*[out,retval]*/ BSTR * wszUserAuthList ) = 0;
      virtual HRESULT __stdcall put_RemoteUserAuthorizedList (
        /*[in]*/ BSTR wszUserAuthList ) = 0;
      virtual HRESULT __stdcall get_RemoteMachineAuthorizedList (
        /*[out,retval]*/ BSTR * wszUserAuthList ) = 0;
      virtual HRESULT __stdcall put_RemoteMachineAuthorizedList (
        /*[in]*/ BSTR wszUserAuthList ) = 0;
      virtual HRESULT __stdcall get_SecureFlags (
        /*[out,retval]*/ long * lOptions ) = 0;
      virtual HRESULT __stdcall put_SecureFlags (
        /*[in]*/ long lOptions ) = 0;
};

struct __declspec(uuid("174a0dda-e9f9-449d-993b-21ab667ca456"))
INetFwProfile : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetType))
    NET_FW_PROFILE_TYPE_ Type;
    __declspec(property(get=GetFirewallEnabled,put=PutFirewallEnabled))
    VARIANT_BOOL FirewallEnabled;
    __declspec(property(get=GetExceptionsNotAllowed,put=PutExceptionsNotAllowed))
    VARIANT_BOOL ExceptionsNotAllowed;
    __declspec(property(get=GetNotificationsDisabled,put=PutNotificationsDisabled))
    VARIANT_BOOL NotificationsDisabled;
    __declspec(property(get=GetUnicastResponsesToMulticastBroadcastDisabled,put=PutUnicastResponsesToMulticastBroadcastDisabled))
    VARIANT_BOOL UnicastResponsesToMulticastBroadcastDisabled;
    __declspec(property(get=GetRemoteAdminSettings))
    INetFwRemoteAdminSettingsPtr RemoteAdminSettings;
    __declspec(property(get=GetIcmpSettings))
    INetFwIcmpSettingsPtr IcmpSettings;
    __declspec(property(get=GetGloballyOpenPorts))
    INetFwOpenPortsPtr GloballyOpenPorts;
    __declspec(property(get=GetServices))
    INetFwServicesPtr Services;
    __declspec(property(get=GetAuthorizedApplications))
    INetFwAuthorizedApplicationsPtr AuthorizedApplications;

    //
    // Wrapper methods for error-handling
    //

    NET_FW_PROFILE_TYPE_ GetType ( );
    VARIANT_BOOL GetFirewallEnabled ( );
    void PutFirewallEnabled (
        VARIANT_BOOL Enabled );
    VARIANT_BOOL GetExceptionsNotAllowed ( );
    void PutExceptionsNotAllowed (
        VARIANT_BOOL notAllowed );
    VARIANT_BOOL GetNotificationsDisabled ( );
    void PutNotificationsDisabled (
        VARIANT_BOOL disabled );
    VARIANT_BOOL GetUnicastResponsesToMulticastBroadcastDisabled ( );
    void PutUnicastResponsesToMulticastBroadcastDisabled (
        VARIANT_BOOL disabled );
    INetFwRemoteAdminSettingsPtr GetRemoteAdminSettings ( );
    INetFwIcmpSettingsPtr GetIcmpSettings ( );
    INetFwOpenPortsPtr GetGloballyOpenPorts ( );
    INetFwServicesPtr GetServices ( );
    INetFwAuthorizedApplicationsPtr GetAuthorizedApplications ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Type (
        /*[out,retval]*/ NET_FW_PROFILE_TYPE_ * Type ) = 0;
      virtual HRESULT __stdcall get_FirewallEnabled (
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_FirewallEnabled (
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
      virtual HRESULT __stdcall get_ExceptionsNotAllowed (
        /*[out,retval]*/ VARIANT_BOOL * notAllowed ) = 0;
      virtual HRESULT __stdcall put_ExceptionsNotAllowed (
        /*[in]*/ VARIANT_BOOL notAllowed ) = 0;
      virtual HRESULT __stdcall get_NotificationsDisabled (
        /*[out,retval]*/ VARIANT_BOOL * disabled ) = 0;
      virtual HRESULT __stdcall put_NotificationsDisabled (
        /*[in]*/ VARIANT_BOOL disabled ) = 0;
      virtual HRESULT __stdcall get_UnicastResponsesToMulticastBroadcastDisabled (
        /*[out,retval]*/ VARIANT_BOOL * disabled ) = 0;
      virtual HRESULT __stdcall put_UnicastResponsesToMulticastBroadcastDisabled (
        /*[in]*/ VARIANT_BOOL disabled ) = 0;
      virtual HRESULT __stdcall get_RemoteAdminSettings (
        /*[out,retval]*/ struct INetFwRemoteAdminSettings * * RemoteAdminSettings ) = 0;
      virtual HRESULT __stdcall get_IcmpSettings (
        /*[out,retval]*/ struct INetFwIcmpSettings * * IcmpSettings ) = 0;
      virtual HRESULT __stdcall get_GloballyOpenPorts (
        /*[out,retval]*/ struct INetFwOpenPorts * * openPorts ) = 0;
      virtual HRESULT __stdcall get_Services (
        /*[out,retval]*/ struct INetFwServices * * Services ) = 0;
      virtual HRESULT __stdcall get_AuthorizedApplications (
        /*[out,retval]*/ struct INetFwAuthorizedApplications * * apps ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0007
{
    NET_FW_PROFILE_DOMAIN = 0,
    NET_FW_PROFILE_STANDARD = 1,
    NET_FW_PROFILE_CURRENT = 2,
    NET_FW_PROFILE_TYPE_MAX = 3
};

struct __declspec(uuid("d46d2478-9ac9-4008-9dc7-5563ce5536cc"))
INetFwPolicy : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetCurrentProfile))
    INetFwProfilePtr CurrentProfile;

    //
    // Wrapper methods for error-handling
    //

    INetFwProfilePtr GetCurrentProfile ( );
    INetFwProfilePtr GetProfileByType (
        NET_FW_PROFILE_TYPE_ profileType );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_CurrentProfile (
        /*[out,retval]*/ struct INetFwProfile * * profile ) = 0;
      virtual HRESULT __stdcall raw_GetProfileByType (
        /*[in]*/ NET_FW_PROFILE_TYPE_ profileType,
        /*[out,retval]*/ struct INetFwProfile * * profile ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0008
{
    NET_FW_PROFILE2_DOMAIN = 1,
    NET_FW_PROFILE2_PRIVATE = 2,
    NET_FW_PROFILE2_PUBLIC = 4,
    NET_FW_PROFILE2_ALL = 2147483647
};

struct __declspec(uuid("98325047-c671-4174-8d81-defcd3f03186"))
INetFwPolicy2 : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetCurrentProfileTypes))
    long CurrentProfileTypes;
    __declspec(property(get=GetFirewallEnabled,put=PutFirewallEnabled))
    VARIANT_BOOL FirewallEnabled[];
    __declspec(property(get=GetExcludedInterfaces,put=PutExcludedInterfaces))
    _variant_t ExcludedInterfaces[];
    __declspec(property(get=GetBlockAllInboundTraffic,put=PutBlockAllInboundTraffic))
    VARIANT_BOOL BlockAllInboundTraffic[];
    __declspec(property(get=GetNotificationsDisabled,put=PutNotificationsDisabled))
    VARIANT_BOOL NotificationsDisabled[];
    __declspec(property(get=GetUnicastResponsesToMulticastBroadcastDisabled,put=PutUnicastResponsesToMulticastBroadcastDisabled))
    VARIANT_BOOL UnicastResponsesToMulticastBroadcastDisabled[];
    __declspec(property(get=GetRules))
    INetFwRulesPtr Rules;
    __declspec(property(get=GetServiceRestriction))
    INetFwServiceRestrictionPtr ServiceRestriction;
    __declspec(property(get=GetDefaultInboundAction,put=PutDefaultInboundAction))
    NET_FW_ACTION_ DefaultInboundAction[];
    __declspec(property(get=GetDefaultOutboundAction,put=PutDefaultOutboundAction))
    NET_FW_ACTION_ DefaultOutboundAction[];
    __declspec(property(get=GetIsRuleGroupCurrentlyEnabled))
    VARIANT_BOOL IsRuleGroupCurrentlyEnabled[];
    __declspec(property(get=GetLocalPolicyModifyState))
    NET_FW_MODIFY_STATE_ LocalPolicyModifyState;

    //
    // Wrapper methods for error-handling
    //

    long GetCurrentProfileTypes ( );
    VARIANT_BOOL GetFirewallEnabled (
        NET_FW_PROFILE_TYPE2_ profileType );
    void PutFirewallEnabled (
        NET_FW_PROFILE_TYPE2_ profileType,
        VARIANT_BOOL Enabled );
    _variant_t GetExcludedInterfaces (
        NET_FW_PROFILE_TYPE2_ profileType );
    void PutExcludedInterfaces (
        NET_FW_PROFILE_TYPE2_ profileType,
        const _variant_t & Interfaces );
    VARIANT_BOOL GetBlockAllInboundTraffic (
        NET_FW_PROFILE_TYPE2_ profileType );
    void PutBlockAllInboundTraffic (
        NET_FW_PROFILE_TYPE2_ profileType,
        VARIANT_BOOL Block );
    VARIANT_BOOL GetNotificationsDisabled (
        NET_FW_PROFILE_TYPE2_ profileType );
    void PutNotificationsDisabled (
        NET_FW_PROFILE_TYPE2_ profileType,
        VARIANT_BOOL disabled );
    VARIANT_BOOL GetUnicastResponsesToMulticastBroadcastDisabled (
        NET_FW_PROFILE_TYPE2_ profileType );
    void PutUnicastResponsesToMulticastBroadcastDisabled (
        NET_FW_PROFILE_TYPE2_ profileType,
        VARIANT_BOOL disabled );
    INetFwRulesPtr GetRules ( );
    INetFwServiceRestrictionPtr GetServiceRestriction ( );
    HRESULT EnableRuleGroup (
        long profileTypesBitmask,
        _bstr_t group,
        VARIANT_BOOL enable );
    VARIANT_BOOL IsRuleGroupEnabled (
        long profileTypesBitmask,
        _bstr_t group );
    HRESULT RestoreLocalFirewallDefaults ( );
    NET_FW_ACTION_ GetDefaultInboundAction (
        NET_FW_PROFILE_TYPE2_ profileType );
    void PutDefaultInboundAction (
        NET_FW_PROFILE_TYPE2_ profileType,
        NET_FW_ACTION_ Action );
    NET_FW_ACTION_ GetDefaultOutboundAction (
        NET_FW_PROFILE_TYPE2_ profileType );
    void PutDefaultOutboundAction (
        NET_FW_PROFILE_TYPE2_ profileType,
        NET_FW_ACTION_ Action );
    VARIANT_BOOL GetIsRuleGroupCurrentlyEnabled (
        _bstr_t group );
    NET_FW_MODIFY_STATE_ GetLocalPolicyModifyState ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_CurrentProfileTypes (
        /*[out,retval]*/ long * profileTypesBitmask ) = 0;
      virtual HRESULT __stdcall get_FirewallEnabled (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall put_FirewallEnabled (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[in]*/ VARIANT_BOOL Enabled ) = 0;
      virtual HRESULT __stdcall get_ExcludedInterfaces (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[out,retval]*/ VARIANT * Interfaces ) = 0;
      virtual HRESULT __stdcall put_ExcludedInterfaces (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[in]*/ VARIANT Interfaces ) = 0;
      virtual HRESULT __stdcall get_BlockAllInboundTraffic (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[out,retval]*/ VARIANT_BOOL * Block ) = 0;
      virtual HRESULT __stdcall put_BlockAllInboundTraffic (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[in]*/ VARIANT_BOOL Block ) = 0;
      virtual HRESULT __stdcall get_NotificationsDisabled (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[out,retval]*/ VARIANT_BOOL * disabled ) = 0;
      virtual HRESULT __stdcall put_NotificationsDisabled (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[in]*/ VARIANT_BOOL disabled ) = 0;
      virtual HRESULT __stdcall get_UnicastResponsesToMulticastBroadcastDisabled (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[out,retval]*/ VARIANT_BOOL * disabled ) = 0;
      virtual HRESULT __stdcall put_UnicastResponsesToMulticastBroadcastDisabled (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[in]*/ VARIANT_BOOL disabled ) = 0;
      virtual HRESULT __stdcall get_Rules (
        /*[out,retval]*/ struct INetFwRules * * Rules ) = 0;
      virtual HRESULT __stdcall get_ServiceRestriction (
        /*[out,retval]*/ struct INetFwServiceRestriction * * ServiceRestriction ) = 0;
      virtual HRESULT __stdcall raw_EnableRuleGroup (
        /*[in]*/ long profileTypesBitmask,
        /*[in]*/ BSTR group,
        /*[in]*/ VARIANT_BOOL enable ) = 0;
      virtual HRESULT __stdcall raw_IsRuleGroupEnabled (
        /*[in]*/ long profileTypesBitmask,
        /*[in]*/ BSTR group,
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall raw_RestoreLocalFirewallDefaults ( ) = 0;
      virtual HRESULT __stdcall get_DefaultInboundAction (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[out,retval]*/ NET_FW_ACTION_ * Action ) = 0;
      virtual HRESULT __stdcall put_DefaultInboundAction (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[in]*/ NET_FW_ACTION_ Action ) = 0;
      virtual HRESULT __stdcall get_DefaultOutboundAction (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[out,retval]*/ NET_FW_ACTION_ * Action ) = 0;
      virtual HRESULT __stdcall put_DefaultOutboundAction (
        /*[in]*/ NET_FW_PROFILE_TYPE2_ profileType,
        /*[in]*/ NET_FW_ACTION_ Action ) = 0;
      virtual HRESULT __stdcall get_IsRuleGroupCurrentlyEnabled (
        /*[in]*/ BSTR group,
        /*[out,retval]*/ VARIANT_BOOL * Enabled ) = 0;
      virtual HRESULT __stdcall get_LocalPolicyModifyState (
        /*[out,retval]*/ NET_FW_MODIFY_STATE_ * modifyState ) = 0;
};

enum __MIDL___MIDL_itf_FirewallAPI_0000_0000_0009
{
    NET_FW_MODIFY_STATE_OK = 0,
    NET_FW_MODIFY_STATE_GP_OVERRIDE = 1,
    NET_FW_MODIFY_STATE_INBOUND_BLOCKED = 2
};

struct __declspec(uuid("f7898af5-cac4-4632-a2ec-da06e5111af2"))
INetFwMgr : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetLocalPolicy))
    INetFwPolicyPtr LocalPolicy;
    __declspec(property(get=GetCurrentProfileType))
    NET_FW_PROFILE_TYPE_ CurrentProfileType;

    //
    // Wrapper methods for error-handling
    //

    INetFwPolicyPtr GetLocalPolicy ( );
    NET_FW_PROFILE_TYPE_ GetCurrentProfileType ( );
    HRESULT RestoreDefaults ( );
    HRESULT IsPortAllowed (
        _bstr_t imageFileName,
        NET_FW_IP_VERSION_ IpVersion,
        long portNumber,
        _bstr_t localAddress,
        NET_FW_IP_PROTOCOL_ ipProtocol,
        VARIANT * allowed,
        VARIANT * restricted );
    HRESULT IsIcmpTypeAllowed (
        NET_FW_IP_VERSION_ IpVersion,
        _bstr_t localAddress,
        unsigned char Type,
        VARIANT * allowed,
        VARIANT * restricted );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_LocalPolicy (
        /*[out,retval]*/ struct INetFwPolicy * * LocalPolicy ) = 0;
      virtual HRESULT __stdcall get_CurrentProfileType (
        /*[out,retval]*/ NET_FW_PROFILE_TYPE_ * profileType ) = 0;
      virtual HRESULT __stdcall raw_RestoreDefaults ( ) = 0;
      virtual HRESULT __stdcall raw_IsPortAllowed (
        /*[in]*/ BSTR imageFileName,
        /*[in]*/ NET_FW_IP_VERSION_ IpVersion,
        /*[in]*/ long portNumber,
        /*[in]*/ BSTR localAddress,
        /*[in]*/ NET_FW_IP_PROTOCOL_ ipProtocol,
        /*[out]*/ VARIANT * allowed,
        /*[out]*/ VARIANT * restricted ) = 0;
      virtual HRESULT __stdcall raw_IsIcmpTypeAllowed (
        /*[in]*/ NET_FW_IP_VERSION_ IpVersion,
        /*[in]*/ BSTR localAddress,
        /*[in]*/ unsigned char Type,
        /*[out]*/ VARIANT * allowed,
        /*[out]*/ VARIANT * restricted ) = 0;
};

struct __declspec(uuid("71881699-18f4-458b-b892-3ffce5e07f75"))
INetFwProduct : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetRuleCategories,put=PutRuleCategories))
    _variant_t RuleCategories;
    __declspec(property(get=GetDisplayName,put=PutDisplayName))
    _bstr_t DisplayName;
    __declspec(property(get=GetPathToSignedProductExe))
    _bstr_t PathToSignedProductExe;

    //
    // Wrapper methods for error-handling
    //

    _variant_t GetRuleCategories ( );
    void PutRuleCategories (
        const _variant_t & RuleCategories );
    _bstr_t GetDisplayName ( );
    void PutDisplayName (
        _bstr_t DisplayName );
    _bstr_t GetPathToSignedProductExe ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_RuleCategories (
        /*[out,retval]*/ VARIANT * RuleCategories ) = 0;
      virtual HRESULT __stdcall put_RuleCategories (
        /*[in]*/ VARIANT RuleCategories ) = 0;
      virtual HRESULT __stdcall get_DisplayName (
        /*[out,retval]*/ BSTR * DisplayName ) = 0;
      virtual HRESULT __stdcall put_DisplayName (
        /*[in]*/ BSTR DisplayName ) = 0;
      virtual HRESULT __stdcall get_PathToSignedProductExe (
        /*[out,retval]*/ BSTR * path ) = 0;
};

struct __declspec(uuid("39eb36e0-2097-40bd-8af2-63a13b525362"))
INetFwProducts : IDispatch
{
    //
    // Property data
    //

    __declspec(property(get=GetCount))
    long Count;
    __declspec(property(get=Get_NewEnum))
    IUnknownPtr _NewEnum;

    //
    // Wrapper methods for error-handling
    //

    long GetCount ( );
    IUnknownPtr Register (
        struct INetFwProduct * product );
    INetFwProductPtr Item (
        long index );
    IUnknownPtr Get_NewEnum ( );

    //
    // Raw methods provided by interface
    //

      virtual HRESULT __stdcall get_Count (
        /*[out,retval]*/ long * Count ) = 0;
      virtual HRESULT __stdcall raw_Register (
        /*[in]*/ struct INetFwProduct * product,
        /*[out,retval]*/ IUnknown * * registration ) = 0;
      virtual HRESULT __stdcall raw_Item (
        /*[in]*/ long index,
        /*[out,retval]*/ struct INetFwProduct * * product ) = 0;
      virtual HRESULT __stdcall get__NewEnum (
        /*[out,retval]*/ IUnknown * * newEnum ) = 0;
};

//
// Wrapper method implementations
//

#pragma pack(pop)
